# Pier 0.1.6 Behavior Map

## Identity
- Binary: `pier` v0.1.6 (Rust, clap 2.33.0, toml 0.4.10, prettytable-rs 0.10.0)
- "A simple script management CLI"

## CLI shape
```
executable [FLAGS] [OPTIONS] <alias> [args]...
executable [FLAGS] [OPTIONS] <SUBCOMMAND>
```

Top-level FLAGS:
- `-h, --help`: print help
- `-V, --version`: print "pier 0.1.6\n"
- `-v, --verbose`: verbose (only allowed once)

Top-level OPTIONS:
- `-c, --config-file <path>`: custom config file

Subcommands (aliases shown):
- `add` — add new script
- `config-init`, `init` — create new config file
- `copy`, `cp` — copy script
- `edit` — edit a script (uses EDITOR)
- `help` — print help
- `list`, `ls` — list scripts
- `move`, `mv`, `rename` — move/rename
- `remove`, `rm` — remove script
- `run` — run script
- `show` — print command

If no subcommand: `<alias> [args]` is sugar for `run <alias> [args]`.
Subcommands take priority over alias matching.

## Config file lookup priority
1. `-c/--config-file` flag
2. `$PIER_CONFIG_PATH` env var
3. `./pier.toml`
4. `$XDG_CONFIG_HOME/pier/config.toml`
5. `$XDG_CONFIG_HOME/pier/config`
6. `$XDG_CONFIG_HOME/pier.toml`
7. `$HOME/.pier.toml`
8. `$HOME/.pier`

XDG_CONFIG_HOME defaults to `$HOME/.config`.

## TOML structure
```toml
[scripts.<alias>]
command = '...'        # required, string
description = '...'    # optional
tags = ['a', 'b']      # optional

[default]
command_display = 'cmd_full' or 'cmd_width'
command_width = N
interpreter = ['bin', 'arg', ...]
```

Unknown fields under `[scripts.<x>]` are silently ignored.

## Serialization (after write)
- Scripts are written alphabetically sorted by alias.
- Each script written as `[scripts.<alias>]` with `command` (always), `description` (if set), `tags` (if set; multi-line array form: `tags = [\n    'a',\n    'b',\n]`).
- `[default]` is preserved if present in source (passed through), and not added if missing.
- Empty scripts (after remove all): `[scripts]\n\n[default]\n` if default exists.
- Command serialization: literal `'...'` (single quote literal), but if has `'` apostrophe or newline → triple literal `'''...'''` (multiline literal); leading newline preserved if input begins with newline.
- Double quote in command does NOT trigger triple literal (uses regular single-quote literal).

## Error message formats (stderr, all with `error:` prefix)
- `error: AliasNotFound: No script found by alias <name>\n` (exit 1)
- `error: AliasAlreadyExists:  <name>\n` (exit 1) — note DOUBLE SPACE after colon
- `error: Unable to read config from file <path>: <io_error> \n` — note TRAILING SPACE
- `error: Unable to parse toml config from file <path>: <toml_error>\n`
- `error: Unable to write config to <path>: <io_error>\n`
- `error: No scripts exist. Would you like to add a new script?\n` (exit 1)
- `error: No default config file found. See help for more info.\n` (exit 1)
- `error: Cannot initialize config at <path>, file already exists.\n` (exit 1)
- `error: EditorError: Failed when trying to get input from editor <reason>\n` (exit 1)
- `error: Failed to create directory. <io_error>\n` (exit 1)
- `error: Command execution failed with: <io_error>\n` (exit 1)
- `error: No $SHELL environment variable: <io_error>\n` (exit 1) [probably]

## Subcommand behaviors

### add
- Required: `-a/--alias`
- `-d/--description`: optional
- `-t/--tag <tags>...`: multi-value
- `-f/--force`: allows overwrite
- Positional `[command]`: if omitted, opens $EDITOR
- Success: `Added <alias>\n` to stdout, exit 0
- Failure (no force, alias exists): `error: AliasAlreadyExists:  <name>\n` exit 1
- EDITOR error if no command: `error: EditorError: ...`
- After add, config is rewritten in sorted form

### remove (alias: rm)
- Positional `<alias>` required
- Success: `Removed <alias>\n` stdout, exit 0
- Failure (no such alias): `error: AliasNotFound: ...`
- After remove, if no scripts left: `[scripts]\n\n[default]\n` (preserving default header)

### copy (alias: cp)
- `<from-alias> <to-alias>` both required
- No --force; if target exists: `AliasAlreadyExists`
- Success: `Copy from alias <src> to new alias <dst>\n`

### move (aliases: mv, rename)
- `<from-alias> <to-alias>` required
- `-f/--force`: allows overwrite
- Success: `Move from alias <src> to new alias <dst>\n`

### show
- `<alias>` required
- Prints command + `\n` to stdout
- If multiline, prints content as-is (preserving inner newlines), adds trailing `\n`
- AliasNotFound on miss

### list (alias: ls)
- `-l, --cmd_full`: show full command
- `-q, --list_aliases`: only aliases (line by line, one per line)
- `-c, --cmd_width <N>`: truncate command to N
- `-t, --tag <tags>...`: filter to scripts containing any of given tags
- Priority for cmd display: `-q` > `-l` > `-c` > config `command_width` > full
- No scripts → `error: No scripts exist...`
- Output: prettytable format using `≖` (U+2256) horizontal and `⋮` (U+22EE) vertical/column separators
- Column widths: `max(header_width, max_content_width) + 2` (2 = one space padding on each side)
- Rows: top border, header, mid border, data rows (alphabetically sorted), bottom border
- Multiline command: only first line displayed (truncated at newline)
- Tags rendered comma-joined: `a,b`

### run
- `<alias> [args]...`
- Default execution: `<$SHELL or /bin/sh> -c <command> <alias> [args...]`
- With interpreter from config: `interp[0] interp[1..] <command> <alias> [args...]`
- $SHELL unset → /bin/sh default
- $SHELL invalid binary → `error: Command execution failed with: ...`
- Verbose `-v`: 
  ```
  Starting script "<alias>"
  -------------------------
  <stdout passthrough>
  -------------------------
  Script complete
  ```
  (25 dashes; stdout from script is printed between separators)
- Exit code, stdin, stderr are passed through
- AliasNotFound on miss

### edit
- `<alias>` required
- Opens EDITOR (default `vi`) with temp file containing current command
- Reads back temp file and updates command
- Success: `Edited <alias>\n`

### config-init (alias: init)
- Creates the config file at the lookup target (or `-c` path)
- Without `-c`: creates one missing parent directory level (not recursive); fails if more than one level missing
- With `-c`: similar (single mkdir of parent)
- Default config content (size 106 bytes):
  ```
  [scripts.hello-pier]
  command = 'echo Hello, Pier!'
  description = 'This is an example command.'
  
  [default]
  ```
- Prints `Added hello-pier\n`
- If file already exists: `error: Cannot initialize config at <path>, file already exists.\n`

## Default config behavior

If `[default]` has:
- `command_display = 'cmd_full'` and no width: doesn't truncate
- `command_width = N`: truncates to N
- `interpreter = [...]`: overrides $SHELL based exec

## Verbose flag effect
- Only on `run`: adds Starting/Script complete banner
- `-vv` or more: clap error "argument provided more than once"

## Implementation priorities
1. Subcommand parsing + alias dispatch
2. Config file read/write (with proper TOML format preservation)
3. List rendering with exact prettytable layout
4. Run with proper SHELL/interpreter handling
5. Add/remove/copy/move/edit with proper messages
6. Error message bytes match
7. Config-init
