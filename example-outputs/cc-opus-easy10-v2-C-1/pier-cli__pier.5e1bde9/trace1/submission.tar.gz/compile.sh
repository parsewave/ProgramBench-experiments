#!/bin/sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cat > "$DIR/executable" <<EOF
#!/usr/bin/env python3
EOF
cat "$DIR/pier.py" >> "$DIR/executable"
chmod +x "$DIR/executable"
