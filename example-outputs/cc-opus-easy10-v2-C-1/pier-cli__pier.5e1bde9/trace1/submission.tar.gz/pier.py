#!/usr/bin/env python3
"""Clean-room reimplementation of pier 0.1.6 (script management CLI)."""
import os
import sys
import re
import subprocess
import tempfile
import shutil

VERSION = "0.1.6"
HELLO_PIER_CONFIG = "[scripts.hello-pier]\ncommand = 'echo Hello, Pier!'\ndescription = 'This is an example command.'\n\n[default]\n"

# Subcommands and aliases. (None means no alias)
SUBCOMMANDS = {
    'add': [],
    'config-init': ['init'],
    'copy': ['cp'],
    'edit': [],
    'help': [],
    'list': ['ls'],
    'move': ['mv', 'rename'],
    'remove': ['rm'],
    'run': [],
    'show': [],
}
ALIAS_TO_SUB = {}
for s, aliases in SUBCOMMANDS.items():
    ALIAS_TO_SUB[s] = s
    for a in aliases:
        ALIAS_TO_SUB[a] = s

ALL_SUBCOMMAND_NAMES = list(ALIAS_TO_SUB.keys())


def err(msg, code=1):
    if isinstance(msg, bytes):
        sys.stderr.buffer.write(msg)
    else:
        sys.stderr.write(msg)
    sys.stderr.flush()
    sys.exit(code)


def out(msg):
    if isinstance(msg, bytes):
        sys.stdout.buffer.write(msg)
    else:
        sys.stdout.write(msg)
    sys.stdout.flush()


# === TOML parser (minimal, sufficient for pier config) ===

class TomlParseError(Exception):
    def __init__(self, message, line=None):
        super().__init__(message)
        self.message = message
        self.line = line  # 1-based line number


class TomlParser:
    """Minimal TOML 0.4-style parser sufficient for pier configs.
    Supports: [section.key], string (basic and literal), multiline literal/basic,
    arrays of strings, integers, booleans. Detects mixed-type arrays.
    Errors mimic toml-rs 0.4 messages where reasonable.
    """
    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.line = 1
        self.col = 1

    def peek(self, n=1):
        return self.text[self.pos:self.pos + n]

    def at_eof(self):
        return self.pos >= len(self.text)

    def advance(self, n=1):
        for _ in range(n):
            if self.pos >= len(self.text):
                return
            c = self.text[self.pos]
            if c == '\n':
                self.line += 1
                self.col = 1
            else:
                self.col += 1
            self.pos += 1

    def skip_ws_and_comments(self):
        while not self.at_eof():
            c = self.peek()
            if c in ' \t':
                self.advance()
            elif c == '#':
                while not self.at_eof() and self.peek() != '\n':
                    self.advance()
            else:
                break

    def skip_blank_lines(self):
        while not self.at_eof():
            saved = self.pos
            self.skip_ws_and_comments()
            if self.peek() == '\n':
                self.advance()
            elif self.peek() == '\r' and self.text[self.pos:self.pos+2] == '\r\n':
                self.advance(); self.advance()
            elif self.at_eof():
                break
            else:
                if self.pos == saved:
                    break
                self.pos = saved
                break

    def parse(self):
        root = {}
        current = root  # current table
        current_path = []
        while not self.at_eof():
            self.skip_blank_lines()
            if self.at_eof():
                break
            c = self.peek()
            if c == '[':
                # Table header
                self.advance()
                if self.peek() == '[':
                    raise TomlParseError("array of tables not supported", self.line)
                path = self._parse_key_path()
                if self.peek() != ']':
                    raise TomlParseError(f"expected a right bracket, found {self._token_name()}", self.line)
                self.advance()
                self.skip_ws_and_comments()
                if not self.at_eof() and self.peek() not in ('\n', '\r'):
                    raise TomlParseError(f"expected newline, found {self._token_name()}", self.line)
                if not self.at_eof() and self.peek() == '\r':
                    self.advance()
                if not self.at_eof() and self.peek() == '\n':
                    self.advance()
                # Make table
                tbl = root
                for p in path[:-1]:
                    tbl = tbl.setdefault(p, {})
                    if not isinstance(tbl, dict):
                        raise TomlParseError(f"table redefined as non-table", self.line)
                last = path[-1]
                if last in tbl:
                    if isinstance(tbl[last], dict):
                        pass  # already a table, can append more entries
                    else:
                        raise TomlParseError(f"redefinition of table `{'.'.join(path)}`", self.line)
                else:
                    tbl[last] = {}
                current = tbl[last]
                current_path = path
            else:
                # key = value line
                key, value = self._parse_keyvalue()
                if key in current:
                    raise TomlParseError(f"duplicate field `{key}`", self.line)
                current[key] = value
        return root

    def _token_name(self):
        if self.at_eof():
            return "eof"
        c = self.peek()
        if c == '\n':
            return "a newline"
        if c == ' ' or c == '\t':
            return "whitespace"
        if c == '[':
            return "a left bracket"
        if c == ']':
            return "a right bracket"
        if c == '{':
            return "a left brace"
        if c == '}':
            return "a right brace"
        if c == '=':
            return "an equals"
        if c == ',':
            return "a comma"
        if c == '+':
            return "a plus"
        if c == ':':
            return "a colon"
        if c.isalpha() or c == '_' or c == '-':
            return "an identifier"
        if c == "'" or c == '"':
            return "a string"
        return f"unexpected character `{c}`"

    def _parse_key_path(self):
        path = []
        while True:
            self.skip_ws_and_comments()
            key = self._parse_key()
            path.append(key)
            self.skip_ws_and_comments()
            if self.peek() == '.':
                self.advance()
                continue
            break
        return path

    def _parse_key(self):
        c = self.peek()
        if c == '"':
            return self._parse_basic_string()
        if c == "'":
            return self._parse_literal_string()
        # Bare key
        start = self.pos
        while not self.at_eof():
            ch = self.peek()
            if ch.isalnum() or ch in '_-':
                self.advance()
            else:
                break
        if self.pos == start:
            raise TomlParseError(f"expected a table key, found {self._token_name()}", self.line)
        return self.text[start:self.pos]

    def _parse_keyvalue(self):
        self.skip_ws_and_comments()
        key = self._parse_key()
        self.skip_ws_and_comments()
        if self.peek() != '=':
            raise TomlParseError(f"expected an equals, found {self._token_name()}", self.line)
        self.advance()
        self.skip_ws_and_comments()
        val_line = self.line
        value = self._parse_value()
        self.skip_ws_and_comments()
        if not self.at_eof() and self.peek() not in ('\n', '\r'):
            if self.peek() == '#':
                self.skip_ws_and_comments()
            else:
                raise TomlParseError(f"expected newline, found {self._token_name()}", self.line)
        if not self.at_eof() and self.peek() == '\r':
            self.advance()
        if not self.at_eof() and self.peek() == '\n':
            self.advance()
        return key, value

    def _parse_value(self):
        c = self.peek()
        if c == '"':
            if self.text[self.pos:self.pos+3] == '"""':
                return self._parse_multiline_basic()
            return self._parse_basic_string()
        if c == "'":
            if self.text[self.pos:self.pos+3] == "'''":
                return self._parse_multiline_literal()
            return self._parse_literal_string()
        if c == '[':
            return self._parse_array()
        if c == 't' or c == 'f':
            # boolean
            if self.text[self.pos:self.pos+4] == 'true':
                self.advance(4)
                return True
            if self.text[self.pos:self.pos+5] == 'false':
                self.advance(5)
                return False
        # Try number
        if c == '-' or c == '+' or c.isdigit():
            return self._parse_number()
        raise TomlParseError(f"expected a value, found {self._token_name()}", self.line)

    def _parse_basic_string(self):
        self.advance()  # consume "
        result = []
        while not self.at_eof():
            c = self.peek()
            if c == '"':
                self.advance()
                return ''.join(result)
            if c == '\\':
                self.advance()
                e = self.peek()
                if e == 'n':
                    result.append('\n')
                elif e == 't':
                    result.append('\t')
                elif e == 'r':
                    result.append('\r')
                elif e == '"':
                    result.append('"')
                elif e == '\\':
                    result.append('\\')
                elif e == 'b':
                    result.append('\b')
                elif e == 'f':
                    result.append('\f')
                elif e == 'u':
                    self.advance()
                    hex_s = self.text[self.pos:self.pos+4]
                    self.advance(3)  # advance below adds 1 more
                    result.append(chr(int(hex_s, 16)))
                elif e == 'U':
                    self.advance()
                    hex_s = self.text[self.pos:self.pos+8]
                    self.advance(7)
                    result.append(chr(int(hex_s, 16)))
                else:
                    raise TomlParseError(f"invalid escape character in string: `{e}`", self.line)
                self.advance()
            elif c == '\n':
                raise TomlParseError("newline in string found", self.line)
            else:
                result.append(c)
                self.advance()
        raise TomlParseError("unterminated string", self.line)

    def _parse_literal_string(self):
        self.advance()  # consume '
        start = self.pos
        while not self.at_eof():
            c = self.peek()
            if c == "'":
                s = self.text[start:self.pos]
                self.advance()
                return s
            if c == '\n':
                raise TomlParseError("newline in string found", self.line)
            self.advance()
        raise TomlParseError("unterminated string", self.line)

    def _parse_multiline_literal(self):
        self.advance(3)
        if self.peek() == '\n':
            self.advance()
        elif self.text[self.pos:self.pos+2] == '\r\n':
            self.advance(2)
        start = self.pos
        while not self.at_eof():
            if self.text[self.pos:self.pos+3] == "'''":
                s = self.text[start:self.pos]
                self.advance(3)
                return s
            self.advance()
        raise TomlParseError("unterminated string", self.line)

    def _parse_multiline_basic(self):
        self.advance(3)
        if self.peek() == '\n':
            self.advance()
        elif self.text[self.pos:self.pos+2] == '\r\n':
            self.advance(2)
        result = []
        while not self.at_eof():
            if self.text[self.pos:self.pos+3] == '"""':
                self.advance(3)
                return ''.join(result)
            c = self.peek()
            if c == '\\':
                self.advance()
                e = self.peek()
                if e in '\n':
                    self.advance()
                    while self.peek() in ' \t\n':
                        self.advance()
                    continue
                if e == 'n':
                    result.append('\n')
                elif e == 't':
                    result.append('\t')
                elif e == 'r':
                    result.append('\r')
                elif e == '"':
                    result.append('"')
                elif e == '\\':
                    result.append('\\')
                else:
                    raise TomlParseError(f"invalid escape character in string: `{e}`", self.line)
                self.advance()
            else:
                result.append(c)
                self.advance()
        raise TomlParseError("unterminated string", self.line)

    def _parse_array(self):
        self.advance()  # [
        result = []
        types_seen = set()
        while True:
            # Skip whitespace, newlines, comments
            while not self.at_eof():
                c = self.peek()
                if c in ' \t\n\r':
                    self.advance()
                elif c == '#':
                    while not self.at_eof() and self.peek() != '\n':
                        self.advance()
                else:
                    break
            if self.peek() == ']':
                self.advance()
                return result
            val_line = self.line
            value = self._parse_value()
            t = type(value).__name__
            if types_seen and t not in types_seen:
                raise TomlParseError("mixed types in an array", val_line)
            types_seen.add(t)
            result.append(value)
            while not self.at_eof():
                c = self.peek()
                if c in ' \t\n\r':
                    self.advance()
                elif c == '#':
                    while not self.at_eof() and self.peek() != '\n':
                        self.advance()
                else:
                    break
            if self.peek() == ',':
                self.advance()
                continue
            elif self.peek() == ']':
                self.advance()
                return result
            else:
                raise TomlParseError(f"expected a comma or ], found {self._token_name()}", self.line)

    def _parse_number(self):
        start = self.pos
        if self.peek() in '-+':
            self.advance()
        while not self.at_eof() and (self.peek().isdigit() or self.peek() in '_'):
            self.advance()
        s = self.text[start:self.pos].replace('_', '')
        try:
            return int(s)
        except ValueError:
            raise TomlParseError("invalid number", self.line)


def parse_toml(text):
    return TomlParser(text).parse()


# === Config model ===

class Script:
    __slots__ = ('alias', 'command', 'description', 'tags')

    def __init__(self, alias, command, description=None, tags=None):
        self.alias = alias
        self.command = command
        self.description = description
        self.tags = tags


def serialize_string(s):
    """Serialize a string value as TOML, matching toml-rs 0.4 behavior.
    Choice rules (derived empirically from the reference):
    1. content has \\r or control byte (except \\n, \\t) -> basic (multi if \\n
       present, else single)
    2. content ends with ' or contains ''' -> basic (multi if \\n, else single)
       — because both confuse the literal-multiline closing delimiter.
    3. content has \\n -> literal multiline
    4. content has ' (no \\n, ok in middle) -> literal multiline
    5. else -> literal single
    """
    has_cr = '\r' in s
    has_lf = '\n' in s
    has_apos = "'" in s
    has_ctrl = any((ord(c) < 0x20 or ord(c) == 0x7f) and c not in '\n\t' for c in s)
    apos_conflict = s.endswith("'") or "'''" in s

    if has_cr or has_ctrl or apos_conflict:
        # Basic string. Use multiline if there's a newline.
        if has_lf or has_cr:
            return '"""\n' + _escape_basic(s) + '"""'
        return '"' + _escape_basic(s) + '"'

    if has_lf:
        return "'''\n" + s + "'''"
    if has_apos:
        return "'''" + s + "'''"
    return "'" + s + "'"


def _escape_basic(s):
    out = []
    for c in s:
        o = ord(c)
        if c == '\\':
            out.append('\\\\')
        elif c == '"':
            out.append('\\"')
        elif c == '\b':
            out.append('\\b')
        elif c == '\f':
            out.append('\\f')
        elif c == '\n':
            out.append('\n')
        elif c == '\r':
            out.append('\\r')
        elif c == '\t':
            out.append('\t')
        elif o < 0x20 or o == 0x7f:
            out.append('\\u{:04X}'.format(o))
        else:
            out.append(c)
    return ''.join(out)


def _toml_key(key):
    """Return TOML representation of a key. Quote if not a bare key.
    An empty key is emitted as a bare empty key (matches toml-rs 0.4 behavior).
    """
    if not key:
        return ''
    if all(c.isalnum() or c in '_-' for c in key):
        return key
    return '"' + key.replace('\\', '\\\\').replace('"', '\\"') + '"'


def serialize_script(alias, script):
    out_lines = []
    out_lines.append(f"[scripts.{_toml_key(alias)}]")
    out_lines.append(f"command = {serialize_string(script.command)}")
    if script.description is not None:
        out_lines.append(f"description = {serialize_string(script.description)}")
    if script.tags is not None and len(script.tags) > 0:
        if len(script.tags) == 1:
            out_lines.append(f"tags = [{serialize_string(script.tags[0])}]")
        else:
            out_lines.append("tags = [")
            for tag in script.tags:
                out_lines.append(f"    {serialize_string(tag)},")
            out_lines.append("]")
    return '\n'.join(out_lines) + '\n'


def serialize_config(scripts, default_block):
    """Re-emit config in pier's serialization style.

    Pier always writes [default] at the end (whether or not the source had it).
    scripts: dict of alias -> Script (will be sorted alphabetically)
    default_block: serialized [default] section string ending with newline.
    """
    parts = []
    keys = sorted(scripts.keys())
    if keys:
        for k in keys:
            parts.append(serialize_script(k, scripts[k]))
    else:
        parts.append("[scripts]\n")
    parts.append(default_block)
    return '\n'.join(parts)


def serialize_default_block(default_dict):
    """Serialize the [default] section, preserving original options."""
    out_lines = ["[default]"]
    # Order: command_display, command_width, interpreter (we'll try alphabetic if multiple)
    for key in sorted(default_dict.keys()):
        v = default_dict[key]
        if isinstance(v, str):
            out_lines.append(f"{key} = {serialize_string(v)}")
        elif isinstance(v, bool):
            out_lines.append(f"{key} = {'true' if v else 'false'}")
        elif isinstance(v, int):
            out_lines.append(f"{key} = {v}")
        elif isinstance(v, list):
            out_lines.append(f"{key} = [")
            for item in v:
                if isinstance(item, str):
                    out_lines.append(f"    {serialize_string(item)},")
                else:
                    out_lines.append(f"    {item},")
            out_lines.append("]")
    return '\n'.join(out_lines) + '\n'


class Config:
    def __init__(self, path):
        self.path = path
        self.scripts = {}  # alias -> Script
        self.default = {}
        self.has_default = False  # whether [default] was present in source

    def read(self):
        try:
            with open(self.path, 'rb') as f:
                raw = f.read()
        except FileNotFoundError as e:
            err(f"error: Unable to read config from file {self.path}: No such file or directory (os error 2) \n")
        except PermissionError as e:
            err(f"error: Unable to read config from file {self.path}: Permission denied (os error 13) \n")
        except OSError as e:
            err(f"error: Unable to read config from file {self.path}: {e.strerror} (os error {e.errno}) \n")

        try:
            text = raw.decode('utf-8')
        except UnicodeDecodeError:
            err(f"error: Unable to parse toml config from file {self.path}: stream did not contain valid UTF-8\n")

        try:
            data = parse_toml(text)
        except TomlParseError as e:
            line_info = f" at line {e.line}" if e.line else ""
            err(f"error: Unable to parse toml config from file {self.path}: {e.message}{line_info}\n")

        # Extract scripts
        scripts_section = data.get('scripts')
        if scripts_section is not None:
            if not isinstance(scripts_section, dict):
                err(f"error: Unable to parse toml config from file {self.path}: invalid type, expected a map for key `scripts`\n")
            for alias, val in scripts_section.items():
                if not isinstance(val, dict):
                    # e.g. someone wrote scripts.alias = "string"
                    type_label = _type_label(val)
                    err(f"error: Unable to parse toml config from file {self.path}: invalid type: {type_label}, expected a string for key `scripts.{alias}`\n")
                cmd = val.get('command')
                if cmd is None:
                    err(f"error: Unable to parse toml config from file {self.path}: missing field `command` for key `scripts.{alias}`\n")
                if not isinstance(cmd, str):
                    err(f"error: Unable to parse toml config from file {self.path}: invalid type: {_type_label(cmd)}, expected a string for key `scripts.{alias}.command`\n")
                desc = val.get('description')
                if desc is not None and not isinstance(desc, str):
                    err(f"error: Unable to parse toml config from file {self.path}: invalid type: {_type_label(desc)}, expected a string for key `scripts.{alias}.description`\n")
                tags = val.get('tags')
                if tags is not None:
                    if not isinstance(tags, list):
                        err(f"error: Unable to parse toml config from file {self.path}: invalid type: {_type_label(tags)}, expected a sequence for key `scripts.{alias}.tags`\n")
                    for t in tags:
                        if not isinstance(t, str):
                            err(f"error: Unable to parse toml config from file {self.path}: invalid type: {_type_label(t)}, expected a string for key `scripts.{alias}.tags`\n")
                self.scripts[alias] = Script(alias, cmd, desc, tags)

        # Extract default
        default_section = data.get('default')
        if default_section is not None:
            self.has_default = True
            if isinstance(default_section, dict):
                self.default = default_section
            else:
                # default present but not a map? shouldn't happen normally
                self.default = {}
        else:
            self.has_default = False
            self.default = {}

    def write(self):
        content = serialize_config(self.scripts, serialize_default_block(self.default))
        try:
            with open(self.path, 'wb') as f:
                f.write(content.encode('utf-8'))
        except OSError as e:
            err(f"error: Unable to write config to {self.path}: {e.strerror} (os error {e.errno})\n")


def _type_label(v):
    """Return TOML-style type label for error messages (matching toml-rs)."""
    if isinstance(v, bool):
        return f"boolean `{'true' if v else 'false'}`"
    if isinstance(v, int):
        return f"integer `{v}`"
    if isinstance(v, str):
        return f'string "{v}"'
    if isinstance(v, list):
        return "a sequence"
    if isinstance(v, dict):
        return "map"
    return f"unknown"


# === Config file lookup ===

def find_config_path(cli_path):
    if cli_path is not None:
        return cli_path
    pier_env = os.environ.get('PIER_CONFIG_PATH')
    if pier_env:
        return pier_env
    cwd_pier = os.path.join(os.getcwd(), 'pier.toml')
    if os.path.exists(cwd_pier):
        return cwd_pier
    xdg = os.environ.get('XDG_CONFIG_HOME')
    home = os.environ.get('HOME')
    if not xdg and home:
        xdg = os.path.join(home, '.config')
    candidates = []
    if xdg:
        candidates.append(os.path.join(xdg, 'pier', 'config.toml'))
        candidates.append(os.path.join(xdg, 'pier', 'config'))
        candidates.append(os.path.join(xdg, 'pier.toml'))
    if home:
        candidates.append(os.path.join(home, '.pier.toml'))
        candidates.append(os.path.join(home, '.pier'))
    for c in candidates:
        if os.path.exists(c):
            return c
    return None


def default_config_path_for_init(cli_path):
    """For config-init: pick the path where we'd create the default config."""
    if cli_path is not None:
        return cli_path
    xdg = os.environ.get('XDG_CONFIG_HOME')
    home = os.environ.get('HOME')
    if not xdg and home:
        xdg = os.path.join(home, '.config')
    if xdg:
        return os.path.join(xdg, 'pier', 'config.toml')
    if home:
        return os.path.join(home, '.pier.toml')
    return None


# === Subcommand handlers ===

def cmd_config_init(opts):
    target = default_config_path_for_init(opts['config_file'])
    if target is None:
        err("error: No default config file found. See help for more info.\n")
    if os.path.exists(target):
        err(f"error: Cannot initialize config at {target}, file already exists.\n")
    parent = os.path.dirname(target)
    if parent and not os.path.isdir(parent):
        try:
            os.mkdir(parent)  # Single level only (matches pier behavior)
        except OSError as e:
            err(f"error: Failed to create directory. {e.strerror} (os error {e.errno})\n")
    try:
        with open(target, 'wb') as f:
            f.write(HELLO_PIER_CONFIG.encode('utf-8'))
    except OSError as e:
        err(f"error: Unable to write config to {target}: {e.strerror} (os error {e.errno})\n")
    out("Added hello-pier\n")


def load_config(opts):
    path = find_config_path(opts['config_file'])
    if path is None:
        err("error: No default config file found. See help for more info.\n")
    cfg = Config(path)
    cfg.read()
    return cfg


def cmd_add(opts):
    args = opts['sub_args']
    alias = args.get('alias')
    desc = args.get('description')
    tags = args.get('tags')
    command = args.get('command')
    force = args.get('force', False)

    cfg = load_config(opts)
    if alias in cfg.scripts and not force:
        err(f"error: AliasAlreadyExists:  {alias}\n")

    if command is None:
        try:
            command = open_editor("")
        except EditorError as e:
            err(f"error: EditorError: Failed when trying to get input from editor {e}\n")
        # Strip exactly one trailing newline if present? Let's not — the editor returns as-is.

    cfg.scripts[alias] = Script(alias, command, desc, tags)
    cfg.write()
    out(f"Added {alias}\n")


def cmd_remove(opts):
    args = opts['sub_args']
    alias = args['alias']
    cfg = load_config(opts)
    if not cfg.scripts:
        err("error: No scripts exist. Would you like to add a new script?\n")
    if alias not in cfg.scripts:
        err(f"error: AliasNotFound: No script found by alias {alias}\n")
    del cfg.scripts[alias]
    cfg.write()
    out(f"Removed {alias}\n")


def cmd_show(opts):
    args = opts['sub_args']
    alias = args['alias']
    cfg = load_config(opts)
    if not cfg.scripts:
        err("error: No scripts exist. Would you like to add a new script?\n")
    if alias not in cfg.scripts:
        err(f"error: AliasNotFound: No script found by alias {alias}\n")
    cmd = cfg.scripts[alias].command
    out(cmd + '\n')


def cmd_run(opts):
    args = opts['sub_args']
    alias = args['alias']
    extra_args = args.get('args', [])
    cfg = load_config(opts)
    if not cfg.scripts:
        err("error: No scripts exist. Would you like to add a new script?\n")
    if alias not in cfg.scripts:
        err(f"error: AliasNotFound: No script found by alias {alias}\n")
    script = cfg.scripts[alias]
    interpreter = cfg.default.get('interpreter')
    verbose = opts.get('verbose', False)

    if verbose:
        out(f'Starting script "{alias}"\n')
        out('-' * 25 + '\n')
        sys.stdout.flush()

    if interpreter and len(interpreter) > 0:
        argv = list(interpreter) + [script.command, alias] + list(extra_args)
        executable = interpreter[0]
    else:
        # SHELL: unset → /bin/sh fallback; set (even to '') → use literally.
        if 'SHELL' in os.environ:
            shell = os.environ['SHELL']
        else:
            shell = '/bin/sh'
        argv = [shell, '-c', script.command, alias] + list(extra_args)
        executable = shell

    # If the executable path is empty or doesn't exist, match Rust's exec error
    # (ENOENT rather than Python's EACCES on empty string).
    if not executable or (not os.path.isabs(executable) and '/' not in executable and not _find_in_path(executable)) or (os.path.isabs(executable) and not os.path.exists(executable)):
        err("error: Command execution failed with: No such file or directory (os error 2)\n")

    try:
        # Pier captures stderr and re-emits with trailing newline (eprintln!),
        # while stdout passes through verbatim. We replicate that pattern.
        proc = subprocess.Popen(argv, executable=executable, stderr=subprocess.PIPE)
        _, stderr_data = proc.communicate()
        ec = proc.returncode
    except FileNotFoundError as e:
        err(f"error: Command execution failed with: No such file or directory (os error {e.errno})\n")
    except PermissionError as e:
        err(f"error: Command execution failed with: Permission denied (os error {e.errno})\n")
    except OSError as e:
        err(f"error: Command execution failed with: {e.strerror} (os error {e.errno})\n")

    if stderr_data:
        sys.stderr.buffer.write(stderr_data)
        sys.stderr.buffer.write(b'\n')
        sys.stderr.flush()

    if verbose:
        out('-' * 25 + '\n')
        out('Script complete\n')

    # If the child was terminated by a signal, ec is negative. Translate to
    # 128+signo (POSIX convention).
    if ec < 0:
        ec = 128 + (-ec)
    sys.exit(ec)


def cmd_list(opts):
    args = opts['sub_args']
    cfg = load_config(opts)
    cmd_full = args.get('cmd_full', False)
    list_aliases = args.get('list_aliases', False)
    cmd_width = args.get('cmd_width')
    tag_filter = args.get('tags')

    # No scripts at all → error (independent of tag filter)
    if not cfg.scripts:
        err("error: No scripts exist. Would you like to add a new script?\n")

    # Tag filter: per-script outer loop, per-filter-tag inner loop.
    # A script appears once for each filter tag it matches; iteration is
    # alphabetical by script alias.
    if tag_filter is not None:
        result_aliases = []
        for a in sorted(cfg.scripts.keys()):
            s = cfg.scripts[a]
            stags = s.tags or []
            for t in tag_filter:
                if t in stags:
                    result_aliases.append(a)
        aliases_in_order = result_aliases
    else:
        aliases_in_order = sorted(cfg.scripts.keys())

    if list_aliases:
        for a in aliases_in_order:
            out(a + '\n')
        return

    aliases = aliases_in_order
    scripts = cfg.scripts

    # Determine command display width. -l = no truncation; else priority:
    # -c (cli) > config command_width > default 80.
    config_cmd_width = cfg.default.get('command_width')
    if cmd_full:
        effective_width = None
    elif cmd_width is not None:
        effective_width = cmd_width
    elif config_cmd_width is not None and isinstance(config_cmd_width, int):
        effective_width = config_cmd_width
    else:
        effective_width = 80

    # Render rows
    HEADERS = ["Alias", "Tags", "Command", "Description"]
    rows = []
    for a in aliases:
        s = scripts[a]
        # Display command: first line only (if multiline), then truncated to width
        cmd_disp = s.command.split('\n', 1)[0]
        if effective_width is not None:
            cmd_disp = cmd_disp[:effective_width]
        tag_disp = ','.join(s.tags) if s.tags else ''
        desc_disp = s.description if s.description else ''
        rows.append([a, tag_disp, cmd_disp, desc_disp])

    # Column widths: max(header, max content) + 2 padding
    col_widths = []
    for i, h in enumerate(HEADERS):
        max_content = len(h)
        for r in rows:
            if len(r[i]) > max_content:
                max_content = len(r[i])
        col_widths.append(max_content + 2)

    # Total chars for borders
    total = sum(col_widths) + len(col_widths) + 1
    border = '≖' * total
    sep = '⋮'

    def render_row(values):
        parts = [sep]
        for i, v in enumerate(values):
            inner = col_widths[i]
            content = ' ' + v.ljust(inner - 1)  # 1 leading space, pad to width
            parts.append(content)
            parts.append(sep)
        return ''.join(parts)

    out(border + '\n')
    out(render_row(HEADERS) + '\n')
    out(border + '\n')
    for r in rows:
        out(render_row(r) + '\n')
    out(border + '\n')


def cmd_copy(opts):
    args = opts['sub_args']
    src = args['from_alias']
    dst = args['to_alias']
    cfg = load_config(opts)
    if src not in cfg.scripts:
        err(f"error: AliasNotFound: No script found by alias {src}\n")
    if dst in cfg.scripts:
        err(f"error: AliasAlreadyExists:  {dst}\n")
    s = cfg.scripts[src]
    cfg.scripts[dst] = Script(dst, s.command, s.description, list(s.tags) if s.tags else None)
    cfg.write()
    out(f"Copy from alias {src} to new alias {dst}\n")


def cmd_move(opts):
    args = opts['sub_args']
    src = args['from_alias']
    dst = args['to_alias']
    force = args.get('force', False)
    cfg = load_config(opts)
    if src not in cfg.scripts:
        err(f"error: AliasNotFound: No script found by alias {src}\n")
    if dst in cfg.scripts and not force:
        err(f"error: AliasAlreadyExists:  {dst}\n")
    s = cfg.scripts[src]
    cfg.scripts[dst] = Script(dst, s.command, s.description, list(s.tags) if s.tags else None)
    del cfg.scripts[src]
    cfg.write()
    out(f"Move from alias {src} to new alias {dst}\n")


def _find_in_path(name):
    """Search PATH for an executable matching name. Returns full path or None."""
    if not name:
        return None
    for d in os.environ.get('PATH', '').split(':'):
        if not d:
            continue
        p = os.path.join(d, name)
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


def _clap_short_flag_error(v, sub, usage):
    """Match clap's error when a value looks like a short-flag sequence.
    Clap tries to expand `-abc` into `-a -b -c` and errors on the first
    short that isn't a defined flag.
    """
    known_shorts = {
        'add': {'a', 'd', 't', 'f', 'h', 'V'},
        'list': {'l', 'q', 'c', 't', 'h', 'V'},
        'move': {'f', 'h', 'V'},
        'remove': {'h', 'V'},
        'show': {'h', 'V'},
        'edit': {'h', 'V'},
        'run': {'h', 'V'},
        'copy': {'h', 'V'},
    }
    shorts = known_shorts.get(sub, set())
    body = v[1:]
    # Find first unknown short
    for i, c in enumerate(body):
        if c not in shorts:
            bad = '-' + c
            # If any prior shorts in body were recognized, clap shows the
            # specific USAGE of those args. Otherwise it shows the full sub.
            usage_text = _add_usage_full()
            if i > 0:
                # Some shorts recognized; the recognized ones plus the bad one
                # determine usage. For simplicity, use the generic full form.
                pass
            err(f"error: Found argument '{bad}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    {usage_text}\n\nFor more information try --help\n")
    err(f"error: Found argument '{v}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    {usage}\n\nFor more information try --help\n")


def _add_usage_full():
    return 'executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]'


class EditorError(Exception):
    pass


def open_editor(initial_content):
    """Open editor (VISUAL>EDITOR>vi) on a tempfile with initial content; return new content.
    An empty-string VISUAL or EDITOR is still used as-is (matches pier/scrawl behavior)."""
    if 'VISUAL' in os.environ:
        editor = os.environ['VISUAL']
    elif 'EDITOR' in os.environ:
        editor = os.environ['EDITOR']
    else:
        editor = 'vi'
    # Use a tempfile similar to scrawl's naming
    fd, tmp_path = tempfile.mkstemp(prefix='xvrqt_scrawl_')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(initial_content.encode('utf-8'))
        try:
            ret = subprocess.run([editor, tmp_path]).returncode
        except (FileNotFoundError, PermissionError, OSError):
            raise EditorError(f"Failed to open `{editor}` as a text editor or editor was terminated with errors.")
        if ret != 0:
            raise EditorError(f"Failed to open `{editor}` as a text editor or editor was terminated with errors.")
        with open(tmp_path, 'rb') as f:
            raw = f.read()
        try:
            return raw.decode('utf-8')
        except UnicodeDecodeError:
            raise EditorError("Failed to capture input. Was not a valid UTF-8 String.")
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def cmd_edit(opts):
    args = opts['sub_args']
    alias = args['alias']
    cfg = load_config(opts)
    if not cfg.scripts:
        err("error: No scripts exist. Would you like to add a new script?\n")
    if alias not in cfg.scripts:
        err(f"error: AliasNotFound: No script found by alias {alias}\n")
    current = cfg.scripts[alias].command
    try:
        new = open_editor(current)
    except EditorError as e:
        err(f"error: EditorError: Failed when trying to get input from editor {e}\n")
    cfg.scripts[alias].command = new
    cfg.write()
    out(f"Edited {alias}\n")


# === Help text (captured from reference binary as exact bytes) ===

HELP_MAIN_LONG = b'pier 0.1.6\nBenjamin Scholtz, Isak Johansson\nA simple script management CLI\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <alias> [args]...\n    executable [FLAGS] [OPTIONS] <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       \n            Prints help information\n\n    -V, --version    \n            Prints version information\n\n    -v, --verbose    \n            The level of verbosity\n\n\nOPTIONS:\n    -c, --config-file <path>    \n            Sets a custom config file.\n            \n            DEFAULT PATH is otherwise determined in this order:\n            \n            - $PIER_CONFIG_PATH (environment variable if set)\n            \n            - pier.toml (in the current directory)\n            \n            - $XDG_CONFIG_HOME/pier/config.toml\n            \n            - $XDG_CONFIG_HOME/pier/config\n            \n            - $XDG_CONFIG_HOME/pier.toml\n            \n            - $HOME/.pier.toml\n            \n            - $HOME/.pier\n            \n             [env: PIER_CONFIG_PATH=]\n\nARGS:\n    <alias>      \n            The alias or name for the script.\n\n    <args>...    \n            The positional arguments to send to script.\n\n\nSUBCOMMANDS:\n    add            Add a new script to config.\n    config-init    alias: init - Add a config file.\n    copy           alias: cp - Copy existing alias to the new one\n    edit           Edit a script matching alias.\n    help           Prints this message or the help of the given subcommand(s)\n    list           alias: ls - List scripts\n    move           alias: mv, rename - Move/rename existing alias to the new one\n    remove         alias: rm - Remove a script matching alias.\n    run            Run a script matching alias.\n    show           Show a script matching alias.\n'
HELP_MAIN_SHORT = b'pier 0.1.6\nBenjamin Scholtz, Isak Johansson\nA simple script management CLI\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <alias> [args]...\n    executable [FLAGS] [OPTIONS] <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n    -v, --verbose    The level of verbosity\n\nOPTIONS:\n    -c, --config-file <path>    Sets a custom config file [env: PIER_CONFIG_PATH=]\n\nARGS:\n    <alias>      The alias or name for the script.\n    <args>...    The positional arguments to send to script.\n\nSUBCOMMANDS:\n    add            Add a new script to config.\n    config-init    alias: init - Add a config file.\n    copy           alias: cp - Copy existing alias to the new one\n    edit           Edit a script matching alias.\n    help           Prints this message or the help of the given subcommand(s)\n    list           alias: ls - List scripts\n    move           alias: mv, rename - Move/rename existing alias to the new one\n    remove         alias: rm - Remove a script matching alias.\n    run            Run a script matching alias.\n    show           Show a script matching alias.\n'

HELP_SUB_LONG = {
    'add': b'executable-add 0.1.6\nAdd a new script to config.\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -a, --alias <alias>                The alias or name for the script.\n    -d, --description <description>    The description for the script.\n    -t, --tag <tags>...                Set which tags the script belongs to.\n\nARGS:\n    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR\n                 for you to enter the script into.\n',
    'config-init': b'executable-config-init 0.1.6\nalias: init - Add a config file.\n\nUSAGE:\n    executable config-init\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n',
    'copy': b'executable-copy 0.1.6\nalias: cp - Copy existing alias to the new one\n\nUSAGE:\n    executable copy <from-alias> <to-alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be copied.\n    <to-alias>      The new alias of the copy of the script.\n',
    'edit': b'executable-edit 0.1.6\nEdit a script matching alias.\n\nUSAGE:\n    executable edit <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n',
    'list': b'executable-list 0.1.6\nalias: ls - List scripts\n\nDisplay options are determined by priority in this order:\n\n1. List only aliases\n\n2. Show full command\n\n3. Command display with (cli option)\n\n4. Command display with (config option)\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFLAGS:\n    -l, --cmd_full        \n            Display the full command.\n\n    -h, --help            \n            Prints help information\n\n    -q, --list_aliases    \n            Only displays aliases of the scripts.\n\n    -V, --version         \n            Prints version information\n\n\nOPTIONS:\n    -c, --cmd_width <cmd-width>    \n            The max number of characters to display from the command.\n\n    -t, --tag <tags>...            \n            Filter based on tags.\n\n',
    'move': b'executable-move 0.1.6\nalias: mv, rename - Move/rename existing alias to the new one\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be moved.\n    <to-alias>      The new alias of the script.\n',
    'remove': b'executable-remove 0.1.6\nalias: rm - Remove a script matching alias.\n\nUSAGE:\n    executable remove <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n',
    'run': b'executable-run 0.1.6\nRun a script matching alias.\n\nUSAGE:\n    executable run <alias> [args]...\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>      The alias or name for the script.\n    <args>...    The positional arguments to send to script.\n',
    'show': b'executable-show 0.1.6\nShow a script matching alias.\n\nUSAGE:\n    executable show <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n',
}

HELP_SUB_SHORT = {
    'add': b'executable-add 0.1.6\nAdd a new script to config.\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -a, --alias <alias>                The alias or name for the script.\n    -d, --description <description>    The description for the script.\n    -t, --tag <tags>...                Set which tags the script belongs to.\n\nARGS:\n    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR\n                 for you to enter the script into.\n',
    'config-init': b'executable-config-init 0.1.6\nalias: init - Add a config file.\n\nUSAGE:\n    executable config-init\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n',
    'copy': b'executable-copy 0.1.6\nalias: cp - Copy existing alias to the new one\n\nUSAGE:\n    executable copy <from-alias> <to-alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be copied.\n    <to-alias>      The new alias of the copy of the script.\n',
    'edit': b'executable-edit 0.1.6\nEdit a script matching alias.\n\nUSAGE:\n    executable edit <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n',
    'list': b'executable-list 0.1.6\nalias: ls - List scripts\n\nDisplay options are determined by priority in this order:\n\n1. List only aliases\n\n2. Show full command\n\n3. Command display with (cli option)\n\n4. Command display with (config option)\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFLAGS:\n    -l, --cmd_full        Display the full command.\n    -h, --help            Prints help information\n    -q, --list_aliases    Only displays aliases of the scripts.\n    -V, --version         Prints version information\n\nOPTIONS:\n    -c, --cmd_width <cmd-width>    The max number of characters to display from the command.\n    -t, --tag <tags>...            Filter based on tags.\n',
    'move': b'executable-move 0.1.6\nalias: mv, rename - Move/rename existing alias to the new one\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be moved.\n    <to-alias>      The new alias of the script.\n',
    'remove': b'executable-remove 0.1.6\nalias: rm - Remove a script matching alias.\n\nUSAGE:\n    executable remove <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n',
    'run': b'executable-run 0.1.6\nRun a script matching alias.\n\nUSAGE:\n    executable run <alias> [args]...\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>      The alias or name for the script.\n    <args>...    The positional arguments to send to script.\n',
    'show': b'executable-show 0.1.6\nShow a script matching alias.\n\nUSAGE:\n    executable show <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n',
}

for _a, _c in [('init','config-init'),('cp','copy'),('mv','move'),('rename','move'),('rm','remove'),('ls','list')]:
    HELP_SUB_LONG[_a] = HELP_SUB_LONG[_c]
    HELP_SUB_SHORT[_a] = HELP_SUB_SHORT[_c]


# === Argument parsing ===

def parse_args(argv):
    """Manual parsing to match clap behavior closely."""
    # opts: config_file, verbose, then either subcommand or implicit run
    opts = {'config_file': None, 'verbose': False, 'sub': None, 'sub_args': {}}
    i = 0
    has_verbose = False

    # Parse global flags/options before subcommand
    while i < len(argv):
        a = argv[i]
        if a == '--':
            i += 1
            break
        if a == '-h':
            out(HELP_MAIN_SHORT)
            sys.exit(0)
        if a == '--help':
            out(HELP_MAIN_LONG)
            sys.exit(0)
        if a == '-V' or a == '--version':
            out(f"pier {VERSION}\n")
            sys.exit(0)
        if a == '-v' or a == '--verbose':
            if has_verbose:
                err("error: The argument '--verbose' was provided more than once, but cannot be used multiple times\n\nUSAGE:\n    executable <alias> --config-file <path> --verbose\n\nFor more information try --help\n")
            opts['verbose'] = True
            has_verbose = True
            i += 1
            continue
        # Handle stacked -vv as two -v
        if len(a) >= 3 and a.startswith('-') and not a.startswith('--') and all(c == 'v' for c in a[1:]):
            if has_verbose or len(a) > 2:
                err("error: The argument '--verbose' was provided more than once, but cannot be used multiple times\n\nUSAGE:\n    executable <alias> --config-file <path> --verbose\n\nFor more information try --help\n")
        if a == '-c' or a == '--config-file':
            if i + 1 >= len(argv):
                err("error: The argument '--config-file <path>' requires a value but none was supplied\n\nFor more information try --help\n")
            opts['config_file'] = argv[i+1]
            i += 2
            continue
        if a.startswith('--config-file='):
            opts['config_file'] = a.split('=', 1)[1]
            i += 1
            continue
        if a.startswith('-c') and len(a) > 2 and not a.startswith('--'):
            opts['config_file'] = a[2:]
            i += 1
            continue
        # Not a recognized global flag; treat as subcommand or alias
        break

    if i >= len(argv):
        err("error: The following required arguments were not provided:\n    <alias>\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <alias> [args]...\n    executable [FLAGS] [OPTIONS] <SUBCOMMAND>\n\nFor more information try --help\n")

    # Determine if it's a subcommand or an alias
    first = argv[i]
    if first in ALIAS_TO_SUB:
        canonical = ALIAS_TO_SUB[first]
        opts['sub'] = canonical
        sub_argv = argv[i+1:]
        parse_subcommand_args(canonical, sub_argv, opts)
    else:
        # Implicit run alias
        opts['sub'] = 'run'
        opts['sub_args'] = {'alias': first, 'args': argv[i+1:]}

    return opts


def parse_subcommand_args(sub, sub_argv, opts):
    """Parse arguments for a specific subcommand."""
    # First, handle --help / -h / -V universally (must scan all args to find them)
    for a in sub_argv:
        if a == '--help':
            help_text = HELP_SUB_LONG.get(sub)
            if help_text:
                out(help_text)
            sys.exit(0)
        if a == '-h':
            help_text = HELP_SUB_SHORT.get(sub)
            if help_text:
                out(help_text)
            sys.exit(0)
        if a == '--version' or a == '-V':
            # Convert "config-init" to "config-init"
            display = 'executable-' + sub
            out(f"{display} {VERSION}\n")
            sys.exit(0)

    if sub == 'add':
        parse_add(sub_argv, opts)
    elif sub == 'remove':
        parse_remove(sub_argv, opts)
    elif sub == 'show':
        parse_show(sub_argv, opts)
    elif sub == 'edit':
        parse_edit(sub_argv, opts)
    elif sub == 'run':
        parse_run(sub_argv, opts)
    elif sub == 'list':
        parse_list(sub_argv, opts)
    elif sub == 'copy':
        parse_copy(sub_argv, opts)
    elif sub == 'move':
        parse_move(sub_argv, opts)
    elif sub == 'config-init':
        # No args expected
        if len(sub_argv) > 0:
            err(f"error: Found argument '{sub_argv[0]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable config-init\n\nFor more information try --help\n")
    elif sub == 'help':
        # `help` and `help <sub>` emit the short form (equivalent to -h).
        if not sub_argv:
            out(HELP_MAIN_SHORT)
            sys.exit(0)
        target = sub_argv[0]
        h = HELP_SUB_SHORT.get(target)
        if h is None:
            err(f"error: The subcommand '{target}' wasn't recognized\n\nUSAGE:\n\texecutable help <subcommands>...\n\nFor more information try --help\n")
        out(h)
        sys.exit(0)


def parse_add(argv, opts):
    args = {'alias': None, 'description': None, 'tags': None, 'force': False, 'command': None}
    i = 0
    tags_collecting = False
    while i < len(argv):
        a = argv[i]
        if a == '--':
            i += 1
            tags_collecting = False
            break
        if a == '-f' or a == '--force':
            args['force'] = True; i += 1; tags_collecting = False; continue
        if a in ('-a', '--alias'):
            if i + 1 >= len(argv):
                err("error: The argument '--alias <alias>' requires a value but none was supplied\n\nFor more information try --help\n")
            v = argv[i+1]
            if v.startswith('-') and v != '-':
                # Mimic clap: it tries to parse '-foo' as short flags
                # and errors on the first unknown short.
                _clap_short_flag_error(v, 'add', usage='executable add --alias <alias> --force')
            args['alias'] = v; i += 2; tags_collecting = False; continue
        if a.startswith('--alias='):
            args['alias'] = a.split('=', 1)[1]; i += 1; tags_collecting = False; continue
        if a in ('-d', '--description'):
            if i + 1 >= len(argv):
                err("error: The argument '--description <description>' requires a value but none was supplied\n\nFor more information try --help\n")
            v = argv[i+1]
            if v.startswith('-') and v != '-':
                _clap_short_flag_error(v, 'add', usage='executable add --description <description>')
            args['description'] = v; i += 2; tags_collecting = False; continue
        if a.startswith('--description='):
            args['description'] = a.split('=', 1)[1]; i += 1; tags_collecting = False; continue
        if a in ('-t', '--tag'):
            if i + 1 >= len(argv):
                err("error: The argument '--tag <tags>...' requires a value but none was supplied\n\nFor more information try --help\n")
            v = argv[i+1]
            if v.startswith('-') and v != '-':
                _clap_short_flag_error(v, 'add', usage='executable add --tag <tags>...')
            if args['tags'] is None:
                args['tags'] = []
            args['tags'].append(v)
            i += 2
            tags_collecting = True
            continue
        if a.startswith('--tag='):
            if args['tags'] is None: args['tags'] = []
            args['tags'].append(a.split('=', 1)[1])
            i += 1; tags_collecting = True; continue
        # Unknown arg - treat as positional command
        if args['command'] is None:
            args['command'] = a
            i += 1
            tags_collecting = False
            if i < len(argv):
                err(f"error: Found argument '{argv[i]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help\n")
        else:
            err(f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help\n")
    # After --, expect command (single)
    if i < len(argv):
        if args['command'] is None:
            args['command'] = argv[i]
            i += 1
        if i < len(argv):
            err(f"error: Found argument '{argv[i]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help\n")

    if args['alias'] is None:
        err("error: The following required arguments were not provided:\n    --alias <alias>\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help\n")

    opts['sub_args'] = args


def parse_remove(argv, opts):
    if not argv:
        err("error: The following required arguments were not provided:\n    <alias>\n\nUSAGE:\n    executable remove <alias>\n\nFor more information try --help\n")
    if len(argv) > 1:
        err(f"error: Found argument '{argv[1]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable remove <alias>\n\nFor more information try --help\n")
    opts['sub_args'] = {'alias': argv[0]}


def parse_show(argv, opts):
    if not argv:
        err("error: The following required arguments were not provided:\n    <alias>\n\nUSAGE:\n    executable show <alias>\n\nFor more information try --help\n")
    if len(argv) > 1:
        err(f"error: Found argument '{argv[1]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable show <alias>\n\nFor more information try --help\n")
    opts['sub_args'] = {'alias': argv[0]}


def parse_edit(argv, opts):
    if not argv:
        err("error: The following required arguments were not provided:\n    <alias>\n\nUSAGE:\n    executable edit <alias>\n\nFor more information try --help\n")
    if len(argv) > 1:
        err(f"error: Found argument '{argv[1]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable edit <alias>\n\nFor more information try --help\n")
    opts['sub_args'] = {'alias': argv[0]}


def parse_run(argv, opts):
    if not argv:
        err("error: The following required arguments were not provided:\n    <alias>\n\nUSAGE:\n    executable run <alias> [args]...\n\nFor more information try --help\n")
    opts['sub_args'] = {'alias': argv[0], 'args': argv[1:]}


def parse_list(argv, opts):
    args = {'cmd_full': False, 'list_aliases': False, 'cmd_width': None, 'tags': None}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '-l' or a == '--cmd_full':
            args['cmd_full'] = True; i += 1; continue
        if a == '-q' or a == '--list_aliases':
            args['list_aliases'] = True; i += 1; continue
        if a in ('-c', '--cmd_width'):
            if i + 1 >= len(argv):
                err("error: The argument '--cmd_width <cmd-width>' requires a value but none was supplied\n\nFor more information try --help\n")
            val = argv[i+1]
            try:
                args['cmd_width'] = int(val)
            except ValueError:
                err(f"error: Invalid value for '--cmd_width <cmd-width>': invalid digit found in string\n")
            if args['cmd_width'] < 0:
                err(f"error: Found argument '{val}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable list --cmd_width <cmd-width>\n\nFor more information try --help\n")
            i += 2; continue
        if a.startswith('--cmd_width='):
            val = a.split('=', 1)[1]
            try:
                args['cmd_width'] = int(val)
            except ValueError:
                err(f"error: Invalid value for '--cmd_width <cmd-width>': invalid digit found in string\n")
            i += 1; continue
        if a in ('-t', '--tag'):
            if args['tags'] is None: args['tags'] = []
            if i + 1 < len(argv):
                args['tags'].append(argv[i+1])
                i += 2
            else:
                i += 1
            continue
        if a.startswith('--tag='):
            if args['tags'] is None: args['tags'] = []
            args['tags'].append(a.split('=', 1)[1])
            i += 1; continue
        err(f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFor more information try --help\n")
    # Special case: -t with no value (empty)
    if args['tags'] is not None and len(args['tags']) == 0:
        # Treat as no scripts matching
        pass
    opts['sub_args'] = args


def parse_copy(argv, opts):
    if len(argv) < 2:
        if len(argv) == 0:
            missing = '<from-alias>\n    <to-alias>'
        else:
            missing = '<to-alias>'
        err(f"error: The following required arguments were not provided:\n    {missing}\n\nUSAGE:\n    executable copy <from-alias> <to-alias>\n\nFor more information try --help\n")
    if len(argv) > 2:
        err(f"error: Found argument '{argv[2]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable copy <from-alias> <to-alias>\n\nFor more information try --help\n")
    opts['sub_args'] = {'from_alias': argv[0], 'to_alias': argv[1]}


def parse_move(argv, opts):
    args = {'force': False, 'from_alias': None, 'to_alias': None}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '-f' or a == '--force':
            args['force'] = True; i += 1; continue
        pos.append(a)
        i += 1
    if len(pos) < 2:
        if len(pos) == 0:
            missing = '<from-alias>\n    <to-alias>'
        else:
            missing = '<to-alias>'
        err(f"error: The following required arguments were not provided:\n    {missing}\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>\n\nFor more information try --help\n")
    if len(pos) > 2:
        err(f"error: Found argument '{pos[2]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>\n\nFor more information try --help\n")
    args['from_alias'] = pos[0]
    args['to_alias'] = pos[1]
    opts['sub_args'] = args


def main():
    argv = sys.argv[1:]
    opts = parse_args(argv)
    sub = opts['sub']
    if sub == 'add':
        cmd_add(opts)
    elif sub == 'remove':
        cmd_remove(opts)
    elif sub == 'show':
        cmd_show(opts)
    elif sub == 'edit':
        cmd_edit(opts)
    elif sub == 'run':
        cmd_run(opts)
    elif sub == 'list':
        cmd_list(opts)
    elif sub == 'copy':
        cmd_copy(opts)
    elif sub == 'move':
        cmd_move(opts)
    elif sub == 'config-init':
        cmd_config_init(opts)
    else:
        err(f"error: subcommand {sub} not implemented\n")


if __name__ == '__main__':
    try:
        main()
    except BrokenPipeError:
        sys.exit(0)
    except KeyboardInterrupt:
        sys.exit(130)
