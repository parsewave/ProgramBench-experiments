#!/usr/bin/env python3
"""Differential test runner."""

import json
import os
import re
import subprocess
import sys
from pathlib import Path

REF = "/workspace/executable"
SUT = "/work/work/executable"
GOLDEN_DIR = Path("/work/work/goldens")

TIMESTAMP_RE = re.compile(rb"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ", re.MULTILINE)


def run(bin_path, args_list, input_bytes):
    try:
        r = subprocess.run(
            [bin_path] + args_list,
            input=input_bytes,
            capture_output=True,
            timeout=30,
        )
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        return 124, e.stdout or b'', e.stderr or b''


def normalize_stderr(b):
    return TIMESTAMP_RE.sub(b"[TIMESTAMP ", b)


def parse_args_file(path):
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError:
        return []


def main():
    test_names = sorted(set(p.stem for p in GOLDEN_DIR.glob("*.in")))
    if not test_names:
        print("No tests found", file=sys.stderr)
        return 1

    verbose = os.environ.get("VERBOSE", "0") == "1"
    only_fails = os.environ.get("FAILS_ONLY", "0") == "1"
    filter_re = os.environ.get("FILTER", "")
    check_stderr = os.environ.get("CHECK_STDERR", "0") == "1"

    pass_count = 0
    fail_count = 0
    fail_list = []

    for name in test_names:
        if filter_re and not re.search(filter_re, name):
            continue
        in_path = GOLDEN_DIR / f"{name}.in"
        args_path = GOLDEN_DIR / f"{name}.args.json"

        input_bytes = in_path.read_bytes()
        args = parse_args_file(args_path)

        ref_rc, ref_out, ref_err = run(REF, args, input_bytes)
        sut_rc, sut_out, sut_err = run(SUT, args, input_bytes)

        out_ok = ref_out == sut_out
        rc_ok = ref_rc == sut_rc

        # Optionally check stderr (timestamps stripped)
        err_ok = True
        if check_stderr:
            err_ok = normalize_stderr(ref_err) == normalize_stderr(sut_err)

        if out_ok and rc_ok and err_ok:
            pass_count += 1
            if verbose and not only_fails:
                print(f"PASS: {name}")
        else:
            fail_count += 1
            fail_list.append(name)
            print(f"FAIL: {name}")
            print(f"  args: {args}")
            print(f"  input: {input_bytes[:80]!r}{'...' if len(input_bytes) > 80 else ''}")
            if not rc_ok:
                print(f"  exit: ref={ref_rc} sut={sut_rc}")
            if not out_ok:
                ref_view = ref_out[:300] + (b"..." if len(ref_out) > 300 else b"")
                sut_view = sut_out[:300] + (b"..." if len(sut_out) > 300 else b"")
                print(f"  ref stdout: {ref_view!r}")
                print(f"  sut stdout: {sut_view!r}")
            if check_stderr and not err_ok:
                print(f"  ref stderr: {normalize_stderr(ref_err)[:200]!r}")
                print(f"  sut stderr: {normalize_stderr(sut_err)[:200]!r}")

    print(f"\n== Pass: {pass_count}  Fail: {fail_count}  Total: {pass_count + fail_count} ==")
    if fail_list and not verbose:
        print(f"Failing: {fail_list[:50]}")
    return 0 if fail_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
