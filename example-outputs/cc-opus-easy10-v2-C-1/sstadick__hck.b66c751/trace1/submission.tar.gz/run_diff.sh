#!/bin/bash
# Differential test runner
# Compares /workspace/executable (reference) vs /work/work/executable (impl)
# against golden test cases.

REF=/workspace/executable
SUT=/work/work/executable
GOLDEN_DIR=/work/work/goldens

pass=0
fail=0
fail_names=()

for input_file in "$GOLDEN_DIR"/*.in; do
    name=$(basename "$input_file" .in)
    args_file="$GOLDEN_DIR/${name}.args"
    expected_out="$GOLDEN_DIR/${name}.out"
    expected_exit="$GOLDEN_DIR/${name}.exit"

    # Read args
    args=""
    if [ -s "$args_file" ]; then
        args=$(cat "$args_file")
    fi

    # Run SUT
    actual_out=$(eval "$SUT $args < \"$input_file\" 2>/dev/null")
    actual_exit=$?

    # Read expected
    exp_out=$(cat "$expected_out")
    exp_exit=$(cat "$expected_exit")

    if [ "$actual_out" = "$exp_out" ] && [ "$actual_exit" = "$exp_exit" ]; then
        pass=$((pass + 1))
    else
        fail=$((fail + 1))
        fail_names+=("$name")
        if [ "${VERBOSE:-0}" = "1" ]; then
            echo "=== FAIL: $name ==="
            echo "  args: $args"
            echo "  expected exit=$exp_exit actual exit=$actual_exit"
            if [ "$actual_out" != "$exp_out" ]; then
                echo "  expected stdout:"
                echo "$exp_out" | head -5 | sed 's/^/    /'
                echo "  actual stdout:"
                echo "$actual_out" | head -5 | sed 's/^/    /'
            fi
        fi
    fi
done

echo "Pass: $pass  Fail: $fail  Total: $((pass + fail))"
if [ $fail -gt 0 ] && [ "${VERBOSE:-0}" != "1" ]; then
    echo "Failing: ${fail_names[*]}" | head -c 1500
    echo
fi
