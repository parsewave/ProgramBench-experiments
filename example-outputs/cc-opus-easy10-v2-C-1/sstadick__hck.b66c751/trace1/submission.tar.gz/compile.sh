#!/bin/sh
set -e
cd "$(dirname "$0")"

cat > executable <<'EOF'
#!/bin/sh
exec /usr/bin/env python3 "$(dirname "$0")/hck.py" "$@"
EOF

chmod +x executable
