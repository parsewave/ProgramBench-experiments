#!/usr/bin/env python3
"""hck - cut-like tool with regex delimiters and header selection.

Clean-room reimplementation following observed behavior of reference binary.
"""

import os
import re
import sys
import gzip
import time
import io
from datetime import datetime, timezone


VERSION = "hck git:23bebe8-modified"


# ---- Help text (taken verbatim from reference --help / -h) ----

SHORT_HELP = """\
* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Input files to parse, defaults to stdin

Options:
  -o, --output <OUTPUT>
          Output file to write to, defaults to stdout
  -d, --delimiter <DELIMITER>
          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag [default: \\s+]
  -L, --delim-is-literal
          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
  -I, --use-input-delim
          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
  -D, --output-delimiter <OUTPUT_DELIMITER>
          Delimiter string to use on outputs [default: "\\t"]
  -f, --fields <FIELDS>
          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
  -e, --exclude <EXCLUDE>
          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`
  -E, --exclude-header <EXCLUDE_HEADER>
          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex
  -F, --header-field <HEADER_FIELD>
          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex
  -r, --header-is-regex
          Treat the header_fields as regexs instead of string literals
  -z, --try-decompress
          Try to find the correct decompression method based on the file extensions
  -Z, --try-compress
          Try to gzip compress the output
  -t, --compression-threads <COMPRESSION_THREADS>
          Threads to use for compression, 0 will result in `hck` staying single threaded [default: 4]
  -l, --compression-level <COMPRESSION_LEVEL>
          Compression level [default: 6]
      --no-mmap
          Disallow the possibility of using mmap
      --crlf
          Support CRLF newlines
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

LONG_HELP = """\
* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

## Selection by headers

Instead of specifying fields to output by index ranges (i.e `1-2,4-`), you can specify a regex or string literal to select a headered column to output with the `-F` option. By default `-F` options are treated as string literals. To treat them as regexs add the `-r` flag.

## Ordering of outputs

*Values are written only once*. So for a `fields` value of `4-,1,5-8`, which translates to "print columns 4 through the end and then the last column and then columns 5 through 8", columns 5-8 won't be printed again because they were already consumed by the `4-` range.

If `field-headers` is used as a regex then the headers will be be grouped together in groups that all matched the same regex, and in the order of the regex as specified on the CLI.

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...
          Input files to parse, defaults to stdin.

          If a file has a recognizable file extension indicating that it is compressed, and a local binary to perform decompression is found, decompression will occur automagically. This requires with `-z`.

Options:
  -o, --output <OUTPUT>
          Output file to write to, defaults to stdout

  -d, --delimiter <DELIMITER>
          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag

          [default: \\s+]

  -L, --delim-is-literal
          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters

  -I, --use-input-delim
          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set

  -D, --output-delimiter <OUTPUT_DELIMITER>
          Delimiter string to use on outputs

          [default: "\\t"]

  -f, --fields <FIELDS>
          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive

  -e, --exclude <EXCLUDE>
          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`

  -E, --exclude-header <EXCLUDE_HEADER>
          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex

  -F, --header-field <HEADER_FIELD>
          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex

  -r, --header-is-regex
          Treat the header_fields as regexs instead of string literals

  -z, --try-decompress
          Try to find the correct decompression method based on the file extensions

  -Z, --try-compress
          Try to gzip compress the output

  -t, --compression-threads <COMPRESSION_THREADS>
          Threads to use for compression, 0 will result in `hck` staying single threaded

          [default: 4]

  -l, --compression-level <COMPRESSION_LEVEL>
          Compression level

          [default: 6]

      --no-mmap
          Disallow the possibility of using mmap

      --crlf
          Support CRLF newlines

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


# ---- Error logging (env_logger style) ----

def log_error(msg):
    """Print an env_logger-formatted ERROR line to stderr."""
    # Format: [YYYY-MM-DDTHH:MM:SSZ ERROR hck] msg
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    sys.stderr.write(f"[{ts} ERROR hck] {msg}\n")


def usage_msg():
    return (
        "Usage: executable [OPTIONS] [INPUT]...\n\n"
        "For more information, try '--help'.\n"
    )


def clap_arg_error(msg):
    """Emit a clap-style error to stderr and exit with code 2."""
    sys.stderr.write(f"error: {msg}\n\n")
    sys.stderr.write(usage_msg())
    sys.exit(2)


# ---- Escape interpretation ----

ESCAPE_MAP = {
    'n': b'\n',
    't': b'\t',
    'r': b'\r',
    '0': b'\x00',
    '\\': b'\\',
}


def interpret_escapes(s):
    """Interpret backslash escapes the way hck does.

    Returns bytes. Recognized escapes: \\n, \\t, \\r, \\0, \\\\.
    Other backslash sequences are left as-is.
    """
    if isinstance(s, bytes):
        # Work with bytes directly
        out = bytearray()
        i = 0
        n = len(s)
        while i < n:
            c = s[i:i+1]
            if c == b'\\' and i + 1 < n:
                nxt = s[i+1:i+2].decode('latin-1')
                if nxt in ESCAPE_MAP:
                    out.extend(ESCAPE_MAP[nxt])
                    i += 2
                    continue
            out.extend(c)
            i += 1
        return bytes(out)
    else:
        out = bytearray()
        i = 0
        n = len(s)
        while i < n:
            c = s[i]
            if c == '\\' and i + 1 < n:
                nxt = s[i+1]
                if nxt in ESCAPE_MAP:
                    out.extend(ESCAPE_MAP[nxt])
                    i += 2
                    continue
            out.extend(c.encode('utf-8'))
            i += 1
        return bytes(out)


# ---- Field spec parsing ----

class Range:
    """Represents one entry in a field spec.

    - kind == 'single': single field at `start` (1-based, inclusive).
    - kind == 'closed': closed range [start, end].
    - kind == 'open_high': [start, +inf]. end = None.
    """
    __slots__ = ('kind', 'start', 'end', 'spec_idx')

    def __init__(self, kind, start, end, spec_idx):
        self.kind = kind
        self.start = start
        self.end = end
        self.spec_idx = spec_idx


def parse_field_spec(spec):
    """Parse a field spec like '1,2-4,5-' into a list of Range objects.

    Returns list of Range. Raises ValueError with message describing the failure.
    """
    if not spec:
        # Empty spec — handled at caller level (-f '' is reject by clap)
        raise ValueError("Failed to parse field: ")

    ranges = []
    parts = spec.split(',')
    for i, part in enumerate(parts):
        # Don't strip — preserve whitespace because hck rejects ' 1' or '1 '
        if not part:
            # ",,1" or "1,," etc. -> empty between commas
            raise ValueError(f"Failed to parse field: {part}")

        if '-' in part:
            # Range form: M-N, M-, -N, or just "-"
            if part == '-':
                raise ValueError(f"Failed to parse field: {part}")

            # Find the dash position
            dash_pos = part.index('-')
            low = part[:dash_pos]
            high = part[dash_pos+1:]

            if low == '' and high == '':
                raise ValueError(f"Failed to parse field: {part}")

            if low == '':
                # -N -> 1 to N
                try:
                    n = int(high)
                except ValueError:
                    raise ValueError(f"Failed to parse field: {part}")
                if n < 0:
                    raise ValueError(f"Failed to parse field: {part}")
                if n == 0:
                    raise ZeroFieldError(f"Fields and positions are numbered from 1: 0")
                ranges.append(Range('closed', 1, n, i))
            elif high == '':
                # M-
                try:
                    m = int(low)
                except ValueError:
                    raise ValueError(f"Failed to parse field: {part}")
                if m < 0:
                    raise ValueError(f"Failed to parse field: {part}")
                if m == 0:
                    raise ZeroFieldError(f"Fields and positions are numbered from 1: 0")
                ranges.append(Range('open_high', m, None, i))
            else:
                # M-N
                try:
                    m = int(low)
                    n = int(high)
                except ValueError:
                    raise ValueError(f"Failed to parse field: {part}")
                if m < 0 or n < 0:
                    raise ValueError(f"Failed to parse field: {part}")
                if m == 0 or n == 0:
                    raise ZeroFieldError(f"Fields and positions are numbered from 1: 0")
                if m > n:
                    raise ValueError(f"High end of range less than low end of range: {part}")
                ranges.append(Range('closed', m, n, i))
        else:
            # Single field
            try:
                v = int(part)
            except ValueError:
                raise ValueError(f"Failed to parse field: {part}")
            if v < 0:
                raise ValueError(f"Failed to parse field: {part}")
            if v == 0:
                raise ZeroFieldError(f"Fields and positions are numbered from 1: 0")
            ranges.append(Range('single', v, v, i))

    return ranges


class ZeroFieldError(Exception):
    """Raised when 0 is used as a field index."""
    pass


# ---- Field selection algorithm ----

def resolve_ranges(ranges, num_fields):
    """Given a list of Range objects and the field count of a row,
    return a list of 0-based field indices to emit, in correct order.

    Closed ranges use their declared bounds (independent of num_fields).
    Open ranges (M-) use num_fields as the upper bound.

    Algorithm:
    1. Multiple open_high ranges merge into ONE open range with min(start),
       positioned at the FIRST open range's slot. Other open slots removed.
    2. Each field is assigned to the LAST range (in spec order) that contains it.
    3. Closed range that's a SUBSET of an open range is absorbed.
    4. Output: per range slot in spec order, fields in ascending order.

    Avoids iterating over field numbers; instead computes per-range contributions.
    """
    # Step 1: Find open ranges and merge.
    open_indices = [i for i, r in enumerate(ranges) if r.kind == 'open_high']
    merged_open_pos = None
    open_start = None
    if open_indices:
        merged_open_pos = open_indices[0]
        open_start = min(ranges[i].start for i in open_indices)

    # Step 2: Build effective range list as (kind, start, end) tuples in order
    effective = []
    used_open = False
    for i, r in enumerate(ranges):
        if r.kind == 'open_high':
            if not used_open and i == merged_open_pos:
                effective.append(('open', open_start, None))
                used_open = True
        else:
            effective.append((r.kind, r.start, r.end))

    # Step 3: Absorption
    absorbed = set()
    if open_start is not None:
        for idx, (kind, start, end) in enumerate(effective):
            if kind == 'closed' and start >= open_start:
                absorbed.add(idx)
            elif kind == 'single' and start >= open_start:
                absorbed.add(idx)

    # For each range slot, compute the set of fields it contributes,
    # considering "last-range-wins" for overlapping ranges.
    # We process ranges in REVERSE order. Each range claims fields that haven't
    # been claimed yet by a LATER range.
    n_slots = len(effective)
    claimed = set()  # set of 1-based field indices already claimed
    slot_fields = [[] for _ in range(n_slots)]
    for idx in range(n_slots - 1, -1, -1):
        if idx in absorbed:
            continue
        kind, start, end = effective[idx]
        if kind == 'open':
            # Effective bound is num_fields
            lo, hi = start, num_fields
            if lo > hi:
                continue
        elif kind == 'closed':
            lo, hi = start, end
        else:  # single
            lo = hi = start
        # Iterate fields in this range
        # To avoid huge ranges, cap at some practical max
        if hi - lo > 100_000_000:
            # Safety cap; should not happen in real inputs
            hi = lo + 100_000_000
        for f in range(lo, hi + 1):
            if f not in claimed:
                slot_fields[idx].append(f)
                claimed.add(f)
        # Sort ascending (we iterated ascending so already sorted)

    # Step 5: Emit per slot in effective slot order.
    result = []
    for idx in range(n_slots):
        # slot_fields[idx] was filled ascending
        result.extend(slot_fields[idx])

    return [f - 1 for f in result]


def compute_exclude_set(exclude_ranges, num_fields, max_index):
    """Compute set of 0-based field indices to exclude.

    `max_index` is the largest index (1-based) we care about (set by caller
    based on the union of -f closed bounds and num_fields).

    Returns (excluded_set, e_open_start) where e_open_start is the smallest
    open range start (1-based) or None.
    """
    excluded = set()
    open_starts = []
    for r in exclude_ranges:
        if r.kind == 'open_high':
            open_starts.append(r.start)
            for f in range(r.start, max_index + 1):
                excluded.add(f - 1)
        elif r.kind == 'closed':
            for f in range(r.start, r.end + 1):
                excluded.add(f - 1)
        elif r.kind == 'single':
            excluded.add(r.start - 1)

    e_open_start = min(open_starts) if open_starts else None
    return excluded, e_open_start


# ---- Line splitter ----

def make_splitter(delim_bytes, is_literal):
    """Returns a function (line_bytes) -> list[bytes] of fields.

    For regex splitting we run on Unicode strings so that `\\s`, `\\w`, `\\d`,
    etc., match Unicode characters (mirroring Rust's regex crate defaults).
    Bytes are decoded via UTF-8 + surrogateescape (lossless), then re-encoded.
    """
    if is_literal:
        sep = delim_bytes
        def split_literal(line):
            return line.split(sep)
        return split_literal
    else:
        # Decode delim bytes to str for compilation
        try:
            pattern_str = delim_bytes.decode('utf-8', errors='surrogateescape')
        except Exception:
            pattern_str = delim_bytes.decode('latin-1')

        try:
            pattern = re.compile(pattern_str)
        except re.error as e:
            raise RegexError(str(e), delim_bytes)

        def split_regex(line_bytes):
            try:
                line_str = line_bytes.decode('utf-8', errors='surrogateescape')
                parts = pattern.split(line_str)
                return [p.encode('utf-8', errors='surrogateescape') for p in parts]
            except Exception:
                # Fall back to byte-mode regex
                bp = re.compile(delim_bytes)
                return bp.split(line_bytes)

        return split_regex


class RegexError(Exception):
    def __init__(self, msg, pattern):
        self.msg = msg
        self.pattern = pattern


# ---- Args parser (clap-like preprocessing) ----

class ArgsParser:
    """Parses argv list like clap. Supports combined short flags and short opt
    with attached value (e.g., -Ld',' or -fname).
    """
    # short flag -> long name
    # value-bearing short opts must consume next arg or attached chars

    SHORT_FLAGS = {
        'L': 'delim_is_literal',
        'I': 'use_input_delim',
        'r': 'header_is_regex',
        'z': 'try_decompress',
        'Z': 'try_compress',
        'h': 'help',
        'V': 'version',
    }

    SHORT_VALUE = {
        'o': 'output',
        'd': 'delimiter',
        'D': 'output_delimiter',
        'f': 'fields',
        'e': 'exclude',
        'E': 'exclude_header',
        'F': 'header_field',
        't': 'compression_threads',
        'l': 'compression_level',
    }

    LONG_FLAGS = {
        'delim-is-literal': 'delim_is_literal',
        'use-input-delim': 'use_input_delim',
        'header-is-regex': 'header_is_regex',
        'try-decompress': 'try_decompress',
        'try-compress': 'try_compress',
        'no-mmap': 'no_mmap',
        'crlf': 'crlf',
        'help': 'help',
        'version': 'version',
    }

    LONG_VALUE = {
        'output': 'output',
        'delimiter': 'delimiter',
        'output-delimiter': 'output_delimiter',
        'fields': 'fields',
        'exclude': 'exclude',
        'exclude-header': 'exclude_header',
        'header-field': 'header_field',
        'compression-threads': 'compression_threads',
        'compression-level': 'compression_level',
    }

    # Long-name (with dashes) version for error messages
    LONG_NAME_OF_VALUE_OPT = {
        'output': '--output <OUTPUT>',
        'delimiter': '--delimiter <DELIMITER>',
        'output_delimiter': '--output-delimiter <OUTPUT_DELIMITER>',
        'fields': '--fields <FIELDS>',
        'exclude': '--exclude <EXCLUDE>',
        'exclude_header': '--exclude-header <EXCLUDE_HEADER>',
        'header_field': '--header-field <HEADER_FIELD>',
        'compression_threads': '--compression-threads <COMPRESSION_THREADS>',
        'compression_level': '--compression-level <COMPRESSION_LEVEL>',
    }

    MULTI_VALUE = {'header_field', 'exclude_header'}  # can be repeated

    def __init__(self, argv):
        self.argv = argv
        self.opts = {
            'inputs': [],
            'output': None,
            'delimiter': None,  # raw bytes
            'delim_is_literal': False,
            'use_input_delim': False,
            'output_delimiter': None,
            'fields': None,
            'exclude': None,
            'exclude_header': [],
            'header_field': [],
            'header_is_regex': False,
            'try_decompress': False,
            'try_compress': False,
            'compression_threads': 4,
            'compression_level': 6,
            'no_mmap': False,
            'crlf': False,
            'help': False,
            'help_long': False,  # --help vs -h
            'version': False,
        }
        # Track first occurrence
        self._seen_single_value = set()

    def parse(self):
        i = 0
        argv = self.argv
        n = len(argv)
        after_dash_dash = False

        while i < n:
            arg = argv[i]
            if after_dash_dash:
                self.opts['inputs'].append(arg)
                i += 1
                continue

            if arg == '--':
                after_dash_dash = True
                i += 1
                continue

            if arg.startswith('--'):
                # Long option
                eq_idx = arg.find('=')
                if eq_idx != -1:
                    name = arg[2:eq_idx]
                    value = arg[eq_idx+1:]
                    has_attached = True
                else:
                    name = arg[2:]
                    value = None
                    has_attached = False

                if name in self.LONG_FLAGS:
                    if has_attached:
                        clap_arg_error(f"unexpected value '{value}' for '--{name}' found; no more were expected")
                    attr = self.LONG_FLAGS[name]
                    if attr == 'help':
                        self.opts['help'] = True
                        self.opts['help_long'] = True
                        self._show_help_and_exit()
                    if attr == 'version':
                        self._show_version_and_exit()
                    self.opts[attr] = True
                    i += 1
                elif name in self.LONG_VALUE:
                    attr = self.LONG_VALUE[name]
                    if has_attached:
                        v = value
                    else:
                        if i + 1 >= n:
                            self._missing_value_error(attr)
                        v = argv[i + 1]
                        i += 1
                    self._set_value(attr, v)
                    i += 1
                else:
                    self._unexpected_argument(arg)
            elif arg.startswith('-') and len(arg) > 1 and arg != '-':
                # Short option(s). Could be combined: -Ld',' or -rF name or -h or -frest
                j = 1
                while j < len(arg):
                    c = arg[j]
                    if c in self.SHORT_FLAGS:
                        attr = self.SHORT_FLAGS[c]
                        if attr == 'help':
                            self.opts['help'] = True
                            self.opts['help_long'] = False
                            self._show_help_and_exit()
                        if attr == 'version':
                            self._show_version_and_exit()
                        self.opts[attr] = True
                        j += 1
                    elif c in self.SHORT_VALUE:
                        attr = self.SHORT_VALUE[c]
                        rest = arg[j+1:]
                        if rest:
                            # Attached value (or = sign for clap)
                            if rest.startswith('='):
                                rest = rest[1:]
                            v = rest
                        else:
                            # Need next argv
                            if i + 1 >= n:
                                self._missing_value_error(attr)
                            v = argv[i + 1]
                            i += 1
                        self._set_value(attr, v)
                        j = len(arg)  # consume rest of this arg
                    else:
                        self._unexpected_argument(f"-{c}")
                i += 1
            else:
                # Positional / "-" / bare
                self.opts['inputs'].append(arg)
                i += 1

        return self.opts

    def _set_value(self, attr, value):
        if attr in self.MULTI_VALUE:
            self.opts[attr].append(value)
        else:
            if attr in self._seen_single_value:
                # clap error for duplicate single-value option
                long_name = self.LONG_NAME_OF_VALUE_OPT.get(attr, f"--{attr.replace('_', '-')}")
                clap_arg_error(f"the argument '{long_name}' cannot be used multiple times")
            self._seen_single_value.add(attr)

            # Special validation for compression_threads, compression_level
            if attr == 'compression_threads':
                try:
                    n = int(value)
                    if n < 0:
                        raise ValueError
                    self.opts[attr] = n
                except ValueError:
                    clap_arg_error(f"invalid value '{value}' for '--compression-threads <COMPRESSION_THREADS>': invalid digit found in string")
                return
            if attr == 'compression_level':
                try:
                    n = int(value)
                    if n < 0 or n > 4294967295:
                        clap_arg_error(f"invalid value '{value}' for '--compression-level <COMPRESSION_LEVEL>': {value} is not in 0..=4294967295")
                    self.opts[attr] = n
                except ValueError:
                    clap_arg_error(f"invalid value '{value}' for '--compression-level <COMPRESSION_LEVEL>': invalid digit found in string")
                return

            self.opts[attr] = value

    def _missing_value_error(self, attr):
        long_name = self.LONG_NAME_OF_VALUE_OPT.get(attr, f"--{attr.replace('_', '-')}")
        clap_arg_error(f"a value is required for '{long_name}' but none was supplied")

    def _unexpected_argument(self, arg):
        sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n")
        sys.stderr.write(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n")
        sys.stderr.write(usage_msg())
        sys.exit(2)

    def _show_help_and_exit(self):
        if self.opts.get('help_long'):
            sys.stdout.write(LONG_HELP)
        else:
            sys.stdout.write(SHORT_HELP)
        sys.exit(0)

    def _show_version_and_exit(self):
        sys.stdout.write(VERSION + "\n")
        sys.exit(0)


# ---- Main ----

def open_input(path, try_decompress):
    """Open an input file. Handle decompression if enabled and extension matches."""
    # Detect directory before opening
    if os.path.isdir(path):
        raise IsADirectoryError(21, "Is a directory", path)
    if try_decompress and path.endswith('.gz'):
        return gzip.open(path, 'rb')
    return open(path, 'rb')


def get_open_inputs(paths, try_decompress):
    """Yield file handles for each input path; or stdin if empty."""
    if not paths:
        # stdin
        yield sys.stdin.buffer
        return

    for p in paths:
        if p == '-':
            yield sys.stdin.buffer
        else:
            try:
                yield open_input(p, try_decompress)
            except FileNotFoundError:
                log_error("No such file or directory (os error 2)")
                sys.exit(1)
            except PermissionError:
                log_error("Permission denied (os error 13)")
                sys.exit(1)
            except IsADirectoryError:
                log_error("Is a directory (os error 21)")
                sys.exit(1)


def split_lines_with_endings(data, crlf):
    """Split data into lines.

    Returns a list of (content, terminator) tuples.

    Without --crlf:
      Lines are separated by LF (single \\n). The LF terminator is stripped
      from content. CR is treated as ordinary content.

    With --crlf:
      Lines are separated by LF too, but the line CONTENT keeps the LF
      unless the byte before LF was CR (then both CR and LF are stripped).
      Said differently: only `\\r\\n` is treated as a line terminator;
      bare `\\n` becomes part of content. But we still cut lines at every LF
      because the reference does so via ripline's read_line.
    """
    lines = []
    n = len(data)
    if n == 0:
        return lines
    start = 0
    while start < n:
        nl = data.find(b'\n', start)
        if nl == -1:
            content = data[start:]
            lines.append((content, b''))
            break

        if crlf:
            # Only strip CRLF; if it's lone LF, keep the LF in content.
            if nl > start and data[nl-1:nl] == b'\r':
                content = data[start:nl-1]
            else:
                # Include the LF in content
                content = data[start:nl+1]
        else:
            content = data[start:nl]

        lines.append((content, b''))
        start = nl + 1
    return lines


def read_input_bytes(handles):
    """Concatenate all input handles' bytes."""
    chunks = []
    for h in handles:
        data = h.read()
        chunks.append(data)
    return b''.join(chunks)


def process(args):
    """Run hck with parsed args."""
    # Determine delimiter (bytes)
    if args['delimiter'] is None:
        # Default
        delim_bytes = br'\s+'
        delim_is_default = True
        delim_arg_byte_len = len(br'\s+')
    else:
        delim_arg_str = args['delimiter']
        delim_arg_byte_len = len(
            delim_arg_str.encode('utf-8') if isinstance(delim_arg_str, str)
            else delim_arg_str
        )
        delim_bytes = interpret_escapes(delim_arg_str)
        delim_is_default = False

    is_literal = args['delim_is_literal']

    # Determine output delimiter
    if args['output_delimiter'] is None:
        out_delim = b'\t'
    else:
        out_delim = interpret_escapes(args['output_delimiter'])

    # If -I and -L, use input delim as output delim
    if args['use_input_delim'] and args['delim_is_literal']:
        # Always overrides -D
        out_delim = delim_bytes

    # CRLF
    crlf = args['crlf']
    line_terminator = b'\r\n' if crlf else b'\n'

    # Parse field specs
    fields_ranges = None
    if args['fields'] is not None:
        try:
            fields_ranges = parse_field_spec(args['fields'])
        except ZeroFieldError as e:
            log_error(str(e))
            sys.exit(1)
        except ValueError as e:
            log_error(str(e))
            sys.exit(1)

    exclude_ranges = None
    if args['exclude'] is not None:
        try:
            exclude_ranges = parse_field_spec(args['exclude'])
        except ZeroFieldError as e:
            log_error(str(e))
            sys.exit(1)
        except ValueError as e:
            log_error(str(e))
            sys.exit(1)

    # Headers
    header_fields = args['header_field']
    exclude_headers = args['exclude_header']
    headers_regex = args['header_is_regex']
    use_headers = bool(header_fields) or bool(exclude_headers)

    # Build splitter
    try:
        splitter = make_splitter(delim_bytes, is_literal)
    except RegexError as e:
        # Match the reference error format
        sys.stderr.write(f"Error: regex parse error:\n    {e.pattern.decode('utf-8', errors='replace')}\n    ^\nerror: {e.msg}\n")
        sys.exit(1)

    # Open output
    if args['output']:
        try:
            out_path = args['output']
            if args['try_compress']:
                out_fh = gzip.open(out_path, 'wb', compresslevel=args['compression_level'] if args['compression_level'] <= 9 else 6)
            else:
                out_fh = open(out_path, 'wb')
        except IsADirectoryError:
            sys.stderr.write(f"Error: Failed to open {args['output']} for writing.\n\nCaused by:\n    Is a directory (os error 21)\n")
            sys.exit(1)
        except FileNotFoundError:
            sys.stderr.write(f"Error: Failed to open {args['output']} for writing.\n\nCaused by:\n    No such file or directory (os error 2)\n")
            sys.exit(1)
        except PermissionError:
            sys.stderr.write(f"Error: Failed to open {args['output']} for writing.\n\nCaused by:\n    Permission denied (os error 13)\n")
            sys.exit(1)
    else:
        if args['try_compress']:
            out_fh = gzip.GzipFile(fileobj=sys.stdout.buffer, mode='wb', compresslevel=min(args['compression_level'], 9))
        else:
            out_fh = sys.stdout.buffer

    # Compute whether the spec (post-exclude) appears in "canonical sorted
    # order".  This determines whether the reference uses its single-byte
    # delim fast-path.
    def is_effective_spec_sorted(field_ranges, exclude_ranges):
        """Return True if the effective -f ranges (after dropping those fully
        covered by -e) are in canonical sort order.

        Canonical sort key: (start, 0 if closed/single else 1).
        """
        if field_ranges is None:
            f_list = [Range('open_high', 1, None, 0)]
        else:
            f_list = list(field_ranges)

        # Compute e_open_start and e_closed_set
        e_closed = set()
        e_open_start = None
        if exclude_ranges is not None:
            for r in exclude_ranges:
                if r.kind == 'closed':
                    for v in range(r.start, r.end + 1):
                        e_closed.add(v)
                elif r.kind == 'single':
                    e_closed.add(r.start)
                elif r.kind == 'open_high':
                    if e_open_start is None or r.start < e_open_start:
                        e_open_start = r.start

        # Filter -f ranges
        effective = []
        for r in f_list:
            if r.kind == 'closed':
                # Fully covered if all indices in [start, end] are excluded
                covered = True
                for v in range(r.start, r.end + 1):
                    if v not in e_closed and not (e_open_start is not None and v >= e_open_start):
                        covered = False
                        break
                if not covered:
                    effective.append(r)
            elif r.kind == 'single':
                covered = (r.start in e_closed) or (
                    e_open_start is not None and r.start >= e_open_start
                )
                if not covered:
                    effective.append(r)
            elif r.kind == 'open_high':
                # Open range fully covered if e has an open range starting at <= r.start
                if e_open_start is not None and e_open_start <= r.start:
                    continue
                effective.append(r)

        if not effective:
            return True  # empty is trivially "sorted"

        prev_key = None
        for r in effective:
            kind_marker = 1 if r.kind == 'open_high' else 0
            key = (r.start, kind_marker)
            if prev_key is not None and key < prev_key:
                return False
            prev_key = key
        return True

    # Determine if the effective spec (from -f / -e) can ever emit anything.
    # If not, we can skip processing the input data entirely, which also
    # avoids triggering the single-byte-parser "invalid data" error.
    if not use_headers:
        # Compute as before
        f_closed_set_global = set()
        f_open_start_global = None
        if fields_ranges is not None:
            for r in fields_ranges:
                if r.kind == 'closed':
                    for f in range(r.start, r.end + 1):
                        f_closed_set_global.add(f)
                elif r.kind == 'single':
                    f_closed_set_global.add(r.start)
                elif r.kind == 'open_high':
                    if f_open_start_global is None or r.start < f_open_start_global:
                        f_open_start_global = r.start
        else:
            f_open_start_global = 1

        e_closed_set_global = set()
        e_open_start_global = None
        if exclude_ranges is not None:
            for r in exclude_ranges:
                if r.kind == 'closed':
                    for f in range(r.start, r.end + 1):
                        e_closed_set_global.add(f)
                elif r.kind == 'single':
                    e_closed_set_global.add(r.start)
                elif r.kind == 'open_high':
                    if e_open_start_global is None or r.start < e_open_start_global:
                        e_open_start_global = r.start

        f_closed_after_e_global = set(
            f for f in f_closed_set_global
            if f not in e_closed_set_global
            and not (e_open_start_global is not None and f >= e_open_start_global)
        )
        partial_from_open = False
        if (f_open_start_global is not None and e_open_start_global is not None
                and e_open_start_global > f_open_start_global):
            partial_from_open = True
        open_survives_global = (f_open_start_global is not None and e_open_start_global is None)

        spec_can_emit = bool(f_closed_after_e_global) or partial_from_open or open_survives_global
        spec_is_sorted = is_effective_spec_sorted(fields_ranges, exclude_ranges)
    else:
        # Headers — we determine emission per file based on header line.
        # But still compute spec_can_emit so we can short-circuit when
        # -f/-e produce an empty effective spec (no -F).
        f_closed_set_global = set()
        f_open_start_global = None
        if fields_ranges is not None:
            for r in fields_ranges:
                if r.kind == 'closed':
                    for f in range(r.start, r.end + 1):
                        f_closed_set_global.add(f)
                elif r.kind == 'single':
                    f_closed_set_global.add(r.start)
                elif r.kind == 'open_high':
                    if f_open_start_global is None or r.start < f_open_start_global:
                        f_open_start_global = r.start
        else:
            f_open_start_global = 1
        e_closed_set_global = set()
        e_open_start_global = None
        if exclude_ranges is not None:
            for r in exclude_ranges:
                if r.kind == 'closed':
                    for f in range(r.start, r.end + 1):
                        e_closed_set_global.add(f)
                elif r.kind == 'single':
                    e_closed_set_global.add(r.start)
                elif r.kind == 'open_high':
                    if e_open_start_global is None or r.start < e_open_start_global:
                        e_open_start_global = r.start
        f_closed_after_e_global = set(
            f for f in f_closed_set_global
            if f not in e_closed_set_global
            and not (e_open_start_global is not None and f >= e_open_start_global)
        )
        partial_from_open = False
        if (f_open_start_global is not None and e_open_start_global is not None
                and e_open_start_global > f_open_start_global):
            partial_from_open = True
        open_survives_global = (f_open_start_global is not None and e_open_start_global is None)
        spec_can_emit = bool(f_closed_after_e_global) or partial_from_open or open_survives_global
        spec_is_sorted = True  # not used with headers

    # Read input
    input_handles = list(get_open_inputs(args['inputs'], args['try_decompress']))

    # Track headers selection state
    selected_indices_per_file = None  # for headers, recomputed per file
    # We need to process line-by-line BUT also handle headers (first line of each file).

    # Helper: emit a row of fields given the indices selected.
    # Indices that exceed the row's field count are silently SKIPPED
    # (no empty placeholder is emitted in their place). The line terminator
    # is always emitted as long as this function is called.
    def emit_row(field_values, indices_to_emit, terminator):
        if not indices_to_emit:
            out_fh.write(terminator)
            return
        parts = []
        for idx in indices_to_emit:
            if idx < len(field_values):
                parts.append(field_values[idx])
        out_fh.write(out_delim.join(parts))
        out_fh.write(terminator)

    # Helper: emit a row using "exclude-only" semantics: emit ALL of the row's
    # fields except those at indices in `exclude_set`. Used when -E (or -e) is
    # the only directive given alongside headers.
    def emit_row_exclude(field_values, exclude_set, terminator):
        parts = []
        for idx in range(len(field_values)):
            if idx in exclude_set:
                continue
            parts.append(field_values[idx])
        if not parts:
            out_fh.write(terminator)
            return
        out_fh.write(out_delim.join(parts))
        out_fh.write(terminator)

    def matches_header(header_bytes, pattern_bytes, regex):
        if regex:
            try:
                return re.search(pattern_bytes, header_bytes) is not None
            except re.error:
                return False
        else:
            return header_bytes == pattern_bytes

    # For each input handle, process its lines
    for handle in input_handles:
        try:
            data = handle.read()
        except OSError as e:
            log_error(f"{e}")
            sys.exit(1)
        finally:
            try:
                if handle is not sys.stdin.buffer:
                    handle.close()
            except Exception:
                pass

        # Reference quirks for the single-byte LITERAL delimiter fast-path.
        # Fast-path eligibility uses the ORIGINAL arg byte length (before
        # escape interpretation), not the interpreted delim length.
        #   1. Input must end with a newline; otherwise "invalid data" error.
        #   2. If the FIRST byte of the input is the (interpreted) delimiter
        #      AND field 1 is in the effective emit set, the parser panics.
        # The fast-path is bypassed when --crlf is set or when the effective
        # spec is empty.
        # In header mode the panic is suppressed (header parsing has its own
        # split path), but the "invalid data" check is still applied — only
        # if there is data BEYOND the header line.
        if (
            is_literal
            and delim_arg_byte_len == 1
            and not crlf
            and spec_can_emit
            and spec_is_sorted
            and data
        ):
            if not use_headers:
                # Determine if at least one COMPLETE line (ending with \n)
                # exists in the data. If so, hck would process it via the
                # fast-path; otherwise the "invalid data" error fires.
                has_complete_line = b'\n' in data
                if has_complete_line and data[:1] == delim_bytes:
                    field_one_emitted = (
                        1 in f_closed_set_global
                        or (f_open_start_global is not None and f_open_start_global <= 1)
                    )
                    if field_one_emitted:
                        if 1 in e_closed_set_global:
                            field_one_emitted = False
                        elif e_open_start_global is not None and e_open_start_global <= 1:
                            field_one_emitted = False
                    if field_one_emitted:
                        sys.stderr.write(
                            "\nthread 'main' panicked at "
                            "/workspace/src/lib/single_byte_delim_parser.rs:84:57:\n"
                            "attempted to index slice up to maximum usize\n"
                            "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
                        )
                        sys.exit(101)
                if not data.endswith(b'\n'):
                    log_error("invalid data")
                    sys.exit(1)
            else:
                # Header-mode "invalid data" check: applies only when there
                # is data BEYOND the header line.  Deferred until after
                # header parsing so any header errors take precedence.
                deferred_invalid_data = False
                if not data.endswith(b'\n'):
                    first_nl = data.find(b'\n')
                    if first_nl != -1 and first_nl + 1 < len(data):
                        deferred_invalid_data = True

                # Also: detect "first data line begins with the delim" panic.
                # The check is on the byte immediately after the header's
                # newline.
                first_nl_idx = data.find(b'\n')
                if first_nl_idx != -1 and first_nl_idx + 1 < len(data):
                    if data[first_nl_idx + 1 : first_nl_idx + 2] == delim_bytes:
                        deferred_panic = True
                    else:
                        deferred_panic = False
                else:
                    deferred_panic = False

        # If the effective spec is "always empty", skip processing this file
        # entirely. -F can still add columns, but that's handled separately
        # below; if -F is also given we'll handle empty selection there.
        if not spec_can_emit and not header_fields:
            continue

        # Ensure deferred variables are defined.
        try:
            deferred_invalid_data
        except NameError:
            deferred_invalid_data = False
        try:
            deferred_panic
        except NameError:
            deferred_panic = False

        # Determine line endings & split
        lines = split_lines_with_endings(data, crlf)

        # Determine the per-file output line terminator
        # Based on tests: with --crlf -> always \r\n; without --crlf -> always \n
        # (Actually verified: line terminator is \n without --crlf, \r\n with --crlf.)

        # Determine selected column indices for this file
        header_select = None  # list of 0-based column indices, in order
        header_exclude_set = None  # used when only -E (no -F) is given

        if use_headers:
            if not lines:
                # Empty input is only an error when -F is required to match.
                if header_fields:
                    log_error("No headers matched")
                    sys.exit(1)
                # -E-only with empty input: no-op
                continue
            # First line is the header
            header_content, _ = lines[0]
            try:
                header_fields_split = splitter(header_content)
            except re.error as e:
                log_error(f"regex error: {e}")
                sys.exit(1)

            # Compute set of header positions excluded via -E
            excluded_header_indices = set()
            for pat in exclude_headers:
                pat_b = pat.encode('utf-8') if isinstance(pat, str) else pat
                for idx, h in enumerate(header_fields_split):
                    if matches_header(h, pat_b, headers_regex):
                        excluded_header_indices.add(idx)

            # Also compute -e exclusion indices for header-position checks.
            # Includes both -e closed indices and the open-range threshold,
            # so any header position >= open_start is also excluded.
            e_index_excluded = set()
            e_open_start_hdr = None
            if exclude_ranges is not None:
                e_closed_tmp = set()
                for r in exclude_ranges:
                    if r.kind == 'closed':
                        for v in range(r.start, r.end + 1):
                            e_closed_tmp.add(v)
                    elif r.kind == 'single':
                        e_closed_tmp.add(r.start)
                    elif r.kind == 'open_high':
                        if e_open_start_hdr is None or r.start < e_open_start_hdr:
                            e_open_start_hdr = r.start
                for v in e_closed_tmp:
                    e_index_excluded.add(v - 1)
                # Add indices covered by the open range, bounded by header
                # length.
                if e_open_start_hdr is not None:
                    for v in range(e_open_start_hdr, len(header_fields_split) + 1):
                        e_index_excluded.add(v - 1)

            header_is_empty = (len(header_content) == 0)

            if header_fields or fields_ranges is not None:
                # Positive selection: -F (in spec order) + -f indices.
                # Per-F matches are tracked separately so we can place -f
                # indices "between" -F flags' contributions.
                per_F_matches = []  # list of (pat, [indices])
                any_F_matched = False
                first_failing_pattern = None
                if header_fields:
                    for pat in header_fields:
                        pat_b = pat.encode('utf-8') if isinstance(pat, str) else pat
                        local_matches = []
                        for idx, h in enumerate(header_fields_split):
                            if matches_header(h, pat_b, headers_regex):
                                any_F_matched = True
                                local_matches.append(idx)
                        per_F_matches.append((pat, local_matches))
                        if not local_matches and first_failing_pattern is None:
                            first_failing_pattern = pat
                    if header_fields and not any_F_matched:
                        log_error("No headers matched")
                        sys.exit(1)
                    if first_failing_pattern is not None:
                        log_error(f"Header not found: {first_failing_pattern}")
                        sys.exit(1)

                # -f indices for the header line itself
                if fields_ranges is not None:
                    header_f_indices = resolve_ranges(fields_ranges, len(header_fields_split))
                else:
                    header_f_indices = []

                # Compute the full F_indices set (in spec order, deduped, with
                # excludes applied).
                F_indices = []
                seen = set()
                for pat, matches in per_F_matches:
                    for idx in matches:
                        if idx in seen:
                            continue
                        seen.add(idx)
                        if idx in excluded_header_indices:
                            continue
                        if idx in e_index_excluded:
                            continue
                        F_indices.append(idx)

                # Determine order of header_selected:
                #   If min(-f indices) < min(-F indices) → -f first then -F.
                #   Else → -F's first match, then -f, then rest of -F.
                # All deduped.
                def filter_indices(seq):
                    return [
                        i for i in seq
                        if i not in excluded_header_indices
                        and i not in e_index_excluded
                    ]

                header_selected = []
                hs_seen = set()
                def add(idx):
                    if idx in hs_seen:
                        return
                    hs_seen.add(idx)
                    header_selected.append(idx)

                f_filtered = filter_indices(header_f_indices)
                F_first_idx = next(iter(F_indices), None)
                f_min_idx = min(f_filtered, default=None)

                if F_indices and f_filtered and f_min_idx < F_first_idx:
                    # -f first, then -F
                    for i in f_filtered:
                        add(i)
                    for i in F_indices:
                        add(i)
                elif F_indices and f_filtered:
                    # -F first match, then -f, then rest -F
                    # Process per-F: emit each F's matches in order; after
                    # the first match (overall), emit all -f.
                    f_emitted = False
                    for pat, matches in per_F_matches:
                        for idx in matches:
                            if (idx in excluded_header_indices or
                                    idx in e_index_excluded):
                                continue
                            add(idx)
                            if not f_emitted:
                                for fi in f_filtered:
                                    add(fi)
                                f_emitted = True
                    # Edge case: if no -F matched any visible index, still emit -f
                    if not f_emitted:
                        for fi in f_filtered:
                            add(fi)
                else:
                    # Only -F or only -f
                    for i in F_indices:
                        add(i)
                    for i in f_filtered:
                        add(i)

                # Skip conditions:
                #   1) -F given, F_indices empty, no -f → skip.
                #   2) -F given, F_indices empty, -f given but its spec is empty → skip.
                if header_fields and not F_indices:
                    if fields_ranges is None:
                        continue
                    if not spec_can_emit:
                        continue
                # 3) No -F (only -f / -e / -E), header_selected fully empty,
                #    no chance of recovery per-row (no -f open / no -e open).
                if (not header_fields and not header_selected
                        and fields_ranges is not None):
                    has_open_f = any(r.kind == 'open_high' for r in fields_ranges)
                    if not has_open_f:
                        continue

                # Header parsing succeeded and we will process data.
                # Fire deferred "invalid data" now.
                if deferred_invalid_data:
                    log_error("invalid data")
                    sys.exit(1)

                # If first data line begins with delim and field 1 would be
                # emitted from it, panic AFTER emitting header.
                if deferred_panic:
                    # Determine if field 1 would be in the emit set for the
                    # first data line. Use header column count as a proxy.
                    field_one_in = False
                    if 0 in set(header_selected):
                        field_one_in = True
                    if field_one_in:
                        # First emit the header line, then panic.
                        # The header has been computed; we need to emit it now.
                        if not header_is_empty:
                            emit_row(header_fields_split, header_selected, line_terminator)
                        sys.stderr.write(
                            "\nthread 'main' panicked at "
                            "/workspace/src/lib/single_byte_delim_parser.rs:84:57:\n"
                            "attempted to index slice up to maximum usize\n"
                            "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
                        )
                        sys.exit(101)
                # Emit header line UNLESS it was byte-empty
                if not header_is_empty:
                    emit_row(header_fields_split, header_selected, line_terminator)

                # Stash data needed for per-row recomputation
                header_select_data_recompute = (
                    per_F_matches, fields_ranges,
                    excluded_header_indices, e_index_excluded,
                )
                header_select = "DATA_RECOMPUTE"  # sentinel
            else:
                # -E only (no -F, no -f): exclude-only semantics.
                # Fire deferred "invalid data" if applicable (header parse OK).
                if deferred_invalid_data:
                    log_error("invalid data")
                    sys.exit(1)
                header_exclude_set = excluded_header_indices | e_index_excluded
                # Emit header line UNLESS byte-empty
                if not header_is_empty:
                    emit_row_exclude(
                        header_fields_split, header_exclude_set, line_terminator
                    )

                # Handle deferred panic
                if deferred_panic:
                    # In -E-only mode, field 1 is emitted unless explicitly
                    # excluded by -E or -e.
                    field_one_in = 0 not in header_exclude_set
                    if field_one_in:
                        sys.stderr.write(
                            "\nthread 'main' panicked at "
                            "/workspace/src/lib/single_byte_delim_parser.rs:84:57:\n"
                            "attempted to index slice up to maximum usize\n"
                            "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
                        )
                        sys.exit(101)

            data_lines = lines[1:]
        else:
            data_lines = lines

        for content, _terminator_unused in data_lines:
            try:
                values = splitter(content)
            except re.error as e:
                log_error(f"regex error: {e}")
                sys.exit(1)

            if header_select == "DATA_RECOMPUTE":
                # Per-row recomputation using same ordering logic as the
                # header line.
                (per_F_local, f_ranges_local, excl_hdr_local,
                 e_idx_excl_local) = header_select_data_recompute

                # Filter F_indices by exclusions
                F_indices_row = []
                F_seen = set()
                for pat, matches in per_F_local:
                    for idx in matches:
                        if idx in F_seen:
                            continue
                        F_seen.add(idx)
                        if idx in excl_hdr_local:
                            continue
                        if idx in e_idx_excl_local:
                            continue
                        F_indices_row.append(idx)

                # Compute -f indices for this row
                if f_ranges_local is not None:
                    f_indices_row_raw = resolve_ranges(f_ranges_local, len(values))
                else:
                    f_indices_row_raw = []
                f_filtered_row = [
                    i for i in f_indices_row_raw
                    if i not in excl_hdr_local and i not in e_idx_excl_local
                ]

                # Apply ordering rule
                row_selected = []
                rs_seen = set()
                def add_row(idx):
                    if idx in rs_seen:
                        return
                    rs_seen.add(idx)
                    row_selected.append(idx)

                F_first_row = next(iter(F_indices_row), None)
                f_min_row = min(f_filtered_row, default=None)

                if F_indices_row and f_filtered_row and f_min_row < F_first_row:
                    for i in f_filtered_row:
                        add_row(i)
                    for i in F_indices_row:
                        add_row(i)
                elif F_indices_row and f_filtered_row:
                    f_emitted = False
                    for pat, matches in per_F_local:
                        for idx in matches:
                            if (idx in excl_hdr_local or
                                    idx in e_idx_excl_local):
                                continue
                            add_row(idx)
                            if not f_emitted:
                                for fi in f_filtered_row:
                                    add_row(fi)
                                f_emitted = True
                    if not f_emitted:
                        for fi in f_filtered_row:
                            add_row(fi)
                else:
                    for i in F_indices_row:
                        add_row(i)
                    for i in f_filtered_row:
                        add_row(i)

                # Apply -e open range exclusion for this row
                if exclude_ranges is not None:
                    extra_excluded, _ = compute_exclude_set(
                        exclude_ranges, len(values), max(len(values), 1)
                    )
                    row_selected = [
                        i for i in row_selected if i not in extra_excluded
                    ]
                emit_row(values, row_selected, line_terminator)
            elif header_exclude_set is not None:
                # Apply -e open range to data rows too
                if exclude_ranges is not None:
                    extra_excluded, e_open_dyn = compute_exclude_set(
                        exclude_ranges, len(values), len(values)
                    )
                    combined = header_exclude_set | extra_excluded
                    emit_row_exclude(values, combined, line_terminator)
                else:
                    emit_row_exclude(values, header_exclude_set, line_terminator)
            else:
                # Compute indices based on -f / -e.
                num_fields = len(values)

                # First, compute the "effective spec emptiness".
                # An effective spec is non-empty iff:
                #   - there exists a closed/single index in -f that is NOT
                #     excluded by -e (either via -e closed indices or by being
                #     >= e_open_start), OR
                #   - -f has an open range AND -e has no open range that covers
                #     it.
                if fields_ranges is not None:
                    # explicit closed indices in -f
                    f_closed_set = set()
                    f_open_start = None
                    for r in fields_ranges:
                        if r.kind == 'closed':
                            for f in range(r.start, r.end + 1):
                                f_closed_set.add(f)
                        elif r.kind == 'single':
                            f_closed_set.add(r.start)
                        elif r.kind == 'open_high':
                            if f_open_start is None or r.start < f_open_start:
                                f_open_start = r.start
                else:
                    # Implicit -f 1-
                    f_closed_set = set()
                    f_open_start = 1

                # -e closed and open
                e_closed_set = set()
                e_open_start = None
                if exclude_ranges is not None:
                    for r in exclude_ranges:
                        if r.kind == 'closed':
                            for f in range(r.start, r.end + 1):
                                e_closed_set.add(f)
                        elif r.kind == 'single':
                            e_closed_set.add(r.start)
                        elif r.kind == 'open_high':
                            if e_open_start is None or r.start < e_open_start:
                                e_open_start = r.start

                # Determine if effective spec is non-empty.
                # f closed indices remaining after -e
                f_closed_after_e = set(
                    f for f in f_closed_set
                    if f not in e_closed_set and not (e_open_start is not None and f >= e_open_start)
                )

                # Also: if f_open_start exists and e_open_start exists with
                # e_open_start > f_open_start, then [f_open_start, e_open_start-1]
                # are effectively closed (the partial uncapped portion).
                # Add them to f_closed_after_e for emission purposes.
                if f_open_start is not None and e_open_start is not None and e_open_start > f_open_start:
                    for f in range(f_open_start, e_open_start):
                        if f not in e_closed_set:
                            f_closed_after_e.add(f)

                # Open survives iff f_open_start exists AND e_open_start is None.
                open_survives = (f_open_start is not None and e_open_start is None)

                if not f_closed_after_e and not open_survives:
                    # Effective spec is empty → skip line
                    continue

                # Spec is non-empty. Now compute the actual indices to emit
                # for this row, using normal ordering rules.
                if fields_ranges is not None:
                    base_indices = resolve_ranges(fields_ranges, num_fields)
                else:
                    base_indices = list(range(num_fields))

                if exclude_ranges is not None:
                    excluded, _ = compute_exclude_set(
                        exclude_ranges, num_fields,
                        max(num_fields, max(f_closed_set, default=0))
                    )
                    indices_to_emit = [i for i in base_indices if i not in excluded]
                else:
                    indices_to_emit = base_indices

                emit_row(values, indices_to_emit, line_terminator)

    try:
        if out_fh is not sys.stdout.buffer:
            out_fh.close()
    except Exception:
        pass

    return 0


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    parser = ArgsParser(argv)
    try:
        opts = parser.parse()
    except SystemExit:
        raise

    try:
        rc = process(opts)
        sys.exit(rc)
    except BrokenPipeError:
        # Cleanly handle broken pipe
        try:
            sys.stdout.close()
        except Exception:
            pass
        sys.exit(0)


if __name__ == '__main__':
    main()
