#!/usr/bin/env python3
"""Generate golden tests by running the reference binary and saving results."""
import json
import subprocess
from pathlib import Path

GOLDEN_DIR = Path("/work/work/goldens")
GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
REF = "/workspace/executable"


def save_golden(name, args, stdin_bytes):
    """Run the reference and save inputs+outputs."""
    in_path = GOLDEN_DIR / f"{name}.in"
    args_path = GOLDEN_DIR / f"{name}.args.json"  # JSON list of args
    out_path = GOLDEN_DIR / f"{name}.out"
    err_path = GOLDEN_DIR / f"{name}.err"
    exit_path = GOLDEN_DIR / f"{name}.exit"

    in_path.write_bytes(stdin_bytes)
    args_path.write_text(json.dumps(args))

    r = subprocess.run([REF] + args, input=stdin_bytes, capture_output=True, timeout=20)
    out_path.write_bytes(r.stdout)
    err_path.write_bytes(r.stderr)
    exit_path.write_text(str(r.returncode))


def b(s):
    """Convert string to bytes."""
    if isinstance(s, str):
        return s.encode('utf-8')
    return s


# ---- Test cases ----

# Basic
save_golden("basic", [], b"a b c\n")
save_golden("two_lines", [], b"a b c\nd e f\n")
save_golden("empty", [], b"")
save_golden("one_newline", [], b"\n")
save_golden("two_newlines", [], b"\n\n")
save_golden("no_trailing_nl", [], b"a b c")

# Multi whitespace
save_golden("multi_ws", [], b"a   b   c\n")
save_golden("leading_ws", [], b"  a b c\n")
save_golden("trailing_ws", [], b"a b c  \n")
save_golden("only_ws", [], b"   \n")
save_golden("tab_input", [], b"a\tb\tc\n")
save_golden("mixed_ws", [], b"a\t b\nc d\n")

# -L literal delim
save_golden("literal_comma", ["-Ld,"], b"a,b,c\n")
save_golden("literal_comma_dquote", ["-L", "-d", ","], b"a,b,c\n")
save_golden("literal_two_chars", ["-Ld", "XY"], b"aXYbXYc\n")
save_golden("literal_empty_fields", ["-Ld,"], b"a,,b\n")
save_golden("literal_trailing", ["-Ld,"], b"a,b,\n")
save_golden("literal_only_one", ["-Ld,"], b"abc\n")

# -d regex
save_golden("regex_comma", ["-d,"], b"a,b,c\n")
save_golden("regex_charclass", ["-d", "[;:]"], b"a:b;c\n")
save_golden("regex_alt", ["-d", "x|y"], b"axbyc\n")
save_golden("regex_special_dot", ["-d", "."], b"a.b\n")
save_golden("regex_tab", ["-d", "\\t"], b"a\tb\tc\n")

# -D output delim
save_golden("output_pipe", ["-D", "|"], b"a b c\n")
save_golden("output_XX", ["-D", "XX"], b"a b c\n")
save_golden("output_nl", ["-D", "\\n"], b"a b c\n")
save_golden("output_tab", ["-D", "\\t"], b"a b c\n")
save_golden("output_null", ["-D", "\\0"], b"a b c\n")
save_golden("output_cr", ["-D", "\\r"], b"a b c\n")
save_golden("output_bs", ["-D", "\\\\"], b"a b c\n")
save_golden("output_backslash_a", ["-D", "\\a"], b"a b c\n")
save_golden("output_multi", ["-D", "a\\nb"], b"x y z\n")

# Field selection
save_golden("field_1", ["-f", "1"], b"a b c d e\n")
save_golden("field_range", ["-f", "2-4"], b"a b c d e\n")
save_golden("field_open_high", ["-f", "3-"], b"a b c d e\n")
save_golden("field_open_low", ["-f", "-3"], b"a b c d e\n")
save_golden("field_reorder_simple", ["-f", "3,1,5"], b"a b c d e\n")
save_golden("field_dup", ["-f", "1,1,1"], b"a b c d e\n")
save_golden("field_overlap_inc", ["-f", "1-3,3-5"], b"a b c d e f g h\n")
save_golden("field_overlap_dec", ["-f", "3-5,1-3"], b"a b c d e f g h\n")
save_golden("field_readme", ["-f", "4-,1,5-8"], b"1 2 3 4 5 6 7 8 9 10\n")
save_golden("field_open_open", ["-f", "3-,1-"], b"a b c d e f g h\n")
save_golden("field_open_open2", ["-f", "1-,3-"], b"a b c d e f g h\n")
save_golden("field_3_5open", ["-f", "3,5-"], b"a b c d e f g h\n")
save_golden("field_5open_3", ["-f", "5-,3"], b"a b c d e f g h\n")
save_golden("field_4open_3to5", ["-f", "4-,3-5"], b"a b c d e f g h\n")
save_golden("field_3to5_4open", ["-f", "3-5,4-"], b"a b c d e f g h\n")
save_golden("field_subset_absorb", ["-f", "5-,4-5"], b"a b c d e f g h\n")
save_golden("field_open_absorb", ["-f", "4-,5-6"], b"a b c d e f g h\n")
save_golden("field_5open_4", ["-f", "5-,4"], b"a b c d e f g h\n")
save_golden("field_complex_5open_4open_3", ["-f", "5-,4-,3"], b"a b c d e f g h\n")

# Excludes
save_golden("exclude_one", ["-e", "3"], b"a b c d e\n")
save_golden("exclude_range", ["-e", "2-4"], b"a b c d e\n")
save_golden("exclude_open", ["-e", "1-"], b"a b c d e\n")
save_golden("exclude_closed_all", ["-e", "1-5"], b"a b c d e\n")
save_golden("exclude_with_field", ["-f", "1-5", "-e", "3"], b"a b c d e\n")
save_golden("exclude_open_with_field", ["-f", "1-", "-e", "1-"], b"a b c d e\n")
save_golden("exclude_open_partial", ["-f", "1-", "-e", "2-"], b"a b c d e\n")
save_golden("exclude_too_high", ["-e", "10"], b"a b c\n")

# Errors
save_golden("field_zero", ["-f", "0"], b"a b c\n")
save_golden("field_neg", ["-f", "-0"], b"a b c\n")
save_golden("field_reverse", ["-f", "3-1"], b"a b c\n")
save_golden("field_empty_comma", ["-f", ",1"], b"a b c\n")
save_golden("field_trailing_comma", ["-f", "1,"], b"a b c\n")
save_golden("field_letters", ["-f", "abc"], b"a b c\n")
save_golden("field_huge", ["-f", "999999999999999999"], b"a b c\n")
save_golden("field_oob_high", ["-f", "100"], b"a b c\n")

# Headers
save_golden("header_select", ["-F", "name", "-F", "city"], b"name age city\nalice 30 NYC\nbob 25 LA\n")
save_golden("header_reorder", ["-F", "city", "-F", "name"], b"name age city\nalice 30 NYC\n")
save_golden("header_exclude", ["-E", "age"], b"name age city\nalice 30 NYC\n")
save_golden("header_regex", ["-r", "-F", "a.*"], b"abc abd cde def\n1 2 3 4\n")
save_golden("header_regex_anchored", ["-r", "-F", "^a"], b"abc xab def\n1 2 3\n")
save_golden("header_regex_partial", ["-r", "-F", "b"], b"abc xab def\n1 2 3\n")
save_golden("header_missing_lit", ["-F", "missing"], b"name age city\nalice 30 NYC\n")
save_golden("header_F_E", ["-F", "a", "-E", "a"], b"a b c\n1 2 3\n")
save_golden("header_E_only", ["-E", "a", "-E", "b"], b"a b c d\n1 2 3 4\n")
save_golden("header_multi_match_regex", ["-r", "-F", "a.*", "-F", "z.*"], b"name age city zip\n1 2 3 4\n")

# CRLF
save_golden("crlf_no_flag", [], b"a b c\r\nd e f\r\n")
save_golden("crlf_yes_flag", ["--crlf"], b"a b c\r\nd e f\r\n")
save_golden("crlf_lf_input", ["--crlf"], b"a b c\nd e f\n")
save_golden("crlf_no_term", ["--crlf"], b"a b c")
save_golden("crlf_mixed", ["--crlf"], b"a b c\r\nd e f\n")

# -I
save_golden("input_delim_use", ["-Ld,", "-I"], b"a,b,c\n")
save_golden("input_delim_use_dquote", ["-Ld", ",", "-I", "-D", "|"], b"a,b,c\n")

# Version / help
save_golden("version", ["--version"], b"")
save_golden("version_short", ["-V"], b"")
# Skip help — long output, less useful

# Misc
save_golden("nonexistent_file", [], b"")  # only meaningful w/ args
# Skip mmap / no_mmap

# Multi-line tests with headers
save_golden("multi_line_headers", ["-F", "name"], b"name age\nalice 30\nbob 25\ncharlie 22\n")
save_golden("multi_line_excl_headers", ["-E", "age"], b"name age city\nalice 30 NYC\nbob 25 LA\n")

# Misc edges
save_golden("empty_line_in_middle", [], b"a b c\n\nd e f\n")
save_golden("only_blank_lines", [], b"\n\n\n")

# Long input
save_golden("many_fields", ["-f", "5"], b"a1 a2 a3 a4 a5 a6 a7 a8 a9 a10\n")
save_golden("many_rows", [], b"".join(f"r{i} c{i}\n".encode() for i in range(20)))

# Tab as delim
save_golden("tab_regex_delim", ["-d", "\\t"], b"a\tb\tc\n")
save_golden("tab_literal_delim", ["-Ld", "\\t"], b"a\tb\tc\n")

# Combinations
save_golden("rF_combo", ["-rF", "name"], b"name age\nalice 30\n")
save_golden("Lfd_combo", ["-Lf", "1-2", "-d", ","], b"a,b,c\n")
save_golden("Ld_combo", ["-Ld", ","], b"a,b,c\n")

# UTF-8
save_golden("utf8_input", [], b"\xc3\xa9 b c\n")
save_golden("utf8_field_sep", ["-d", "x"], b"a\xc3\xa9bxc\n")

print("Goldens generated.")
