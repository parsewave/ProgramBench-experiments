# hck Behavior Map

## Identity
- Name: `hck git:23bebe8-modified`
- Rust binary; `cut`-like with regex delimiters, header-based column selection.
- Built atop clap, regex, ripline, gzp.

## CLI / Arg parsing
- Standard clap parsing. Short flags combinable: `-Ld','`, `-rF name`, etc.
- Long options: `--delimiter`, `--fields`, etc. Both `--name VALUE` and `--name=VALUE` work.
- `--help`/`-h` (`-h` shows summary, `--help` full).
- `-V`/`--version` -> `hck git:23bebe8-modified\n`.
- Unknown flag -> exit 2, message: `error: unexpected argument '--xyz' found\n\n  tip: to pass '--xyz' as a value, use '-- --xyz'\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n`
- Missing value -> exit 2, `error: a value is required for '...'`
- Numeric overflow on -l (u32) / -t (usize) -> exit 2.

## Input
- Positional `[INPUT]...`. Multiple files. Stdin if absent. `-` means... probably stdin (no diff vs no arg).
- `--` ends option parsing.
- Compressed input: `-z` flag enables auto-decompression by extension (.gz).
- Errors:
  - File not found -> `[YYYY-MM-DDTHH:MM:SSZ ERROR hck] No such file or directory (os error 2)`, exit 1.

## Delimiter
- Default delim: `\s+` REGEX.
- `-d <DELIM>` overrides delim (still regex by default).
- `-L` flag: treat delim as literal substring.
- Escape interpretation in `-d` and `-D` and `-Ld`:
  - `\n` → LF (0x0A)
  - `\t` → TAB (0x09)
  - `\r` → CR (0x0D)
  - `\0` → NUL (0x00)
  - `\\` → `\`
  - Other backslash sequences left as-is (`\a` → `\a`, `\s` → `\s`).
- Note: -d for regex feeds the string to the regex engine after escape interpretation. So `-d '\t'` (2 chars `\t`) → regex matches actual TAB.

## Output
- Default output delim: `\t` (TAB).
- `-D <DELIM>` overrides output delim with same escape rules.
- `-I` flag (with `-L`): use input delim as output delim. Overrides `-D` if set.
- Each output line ends with `\n` (or `\r\n` with `--crlf`), even when input lacked terminator.
- `-o FILE`: write output to FILE. Error if dir or no permission.
- `-Z`: gzip-compress the output (concatenated pgzf format from gzp library).

## CRLF
- Without `--crlf`: line ending = LF. CR stays attached to last field if present.
- With `--crlf`: line ending = CRLF. Input CRLF-terminated lines have `\r\n` stripped, LF-only lines keep their `\n` (becomes content). Output line ending always `\r\n`.

## Field syntax (`-f`, `-e`)
- Comma-separated list of ranges.
- Range forms: `N` (single), `M-N` (closed range), `M-` (open right), `-N` (closed `1-N`).
- 1-based, inclusive.
- 0 → error `Fields and positions are numbered from 1: 0`, exit 1.
- Reverse range (M-N where M>N) → error `High end of range less than low end of range: M-N`, exit 1.
- Parse failure → error `Failed to parse field: <spec>`, exit 1.
- Out-of-bounds field silently produces empty.
- Numeric overflow (e.g. `99999999999999999999`) → `Failed to parse field: ...`, exit 1.

## Field selection algorithm
- Each field is emitted AT MOST ONCE per row.
- Ordering rule: a field is emitted by the LAST range (in spec order) that contains it.
- Multiple open ranges (`M-, P-`) merge into ONE open range with start `min(M, P, …)`. Position in spec: position of the FIRST open range.
- A closed range that is a SUBSET of an open range gets absorbed (no separate emission).
- Closed range that overlaps open range partially stays distinct.
- Empty row emitted (just `\n`) when row has columns to emit but all empty.

## Exclude (`-e`)
- Same syntax as `-f`. Excludes have precedence over `-f`.
- Combination with `-f`: take `-f` ranges, remove excluded fields, output remaining in `-f` order.
- Without `-f`: implicit `-f1-` (all fields).
- Edge case: `-e1-` (open exclude covering everything) → suppresses entire LINE (no `\n` output).
- `-e1-N` (closed) excluding everything → empty `\n` per line.

## Header field (`-F`, `-E`)
- Reads first line of input as header. Splits by current delim. Each token is a header name.
- `-F <header>`: select column whose header matches. Literal by default.
- `-E <header>`: exclude column whose header matches.
- `-r` flag: treat `-F`/`-E` args as Rust regex; semantics is unanchored `re.search`.
- Per `-F`, multiple matches emitted in INPUT (header) order.
- Across multiple `-F` flags, the order follows `-F` spec order (with input order within each `-F`).
- `-E` overrides `-F` (excluded headers won't appear).
- No matches → error `No headers matched`, exit 1.
- Empty input + `-F` → `No headers matched`, exit 1.
- Header line not emitted itself when fields selected; but when nothing selected, lines pass through... actually no, when -F is used, header line is treated as data and emitted with selected columns.

## Errors / Logging
- env_logger format on stderr: `[YYYY-MM-DDTHH:MM:SSZ ERROR hck] <msg>` (timestamp varies per run!).
- anyhow errors (non-logger): formatted as `Error: ...\n\nCaused by:\n    ...\n`.
- Exit codes:
  - 0 success
  - 1 logic / IO error (file not found, no headers, parse error, etc.)
  - 2 clap arg error

## Misc
- `--no-mmap`: disables mmap. No observable diff in output.
- `-t`, `-l`: compression options.

## Bugs in reference (single_byte_delim_parser panic)
- `-Ld'<single_byte>'` with input where the line STARTS WITH the delim → panics ("attempted to index slice up to maximum usize"), exit 101.
- Same panic if input is JUST the delim.
- We will NOT replicate this bug; we'll handle gracefully.
