#!/usr/bin/env python3
"""Fuzz with more variety: headers, regex delim, more args."""

import random
import subprocess
import sys

REF = "/workspace/executable"
SUT = "/work/work/executable"


def run(bin_path, args, stdin):
    try:
        return subprocess.run(
            [bin_path] + args,
            input=stdin,
            capture_output=True,
            timeout=15,
        )
    except subprocess.TimeoutExpired:
        return None


def differ(a, b):
    if a is None or b is None:
        return False
    return a.returncode != b.returncode or a.stdout != b.stdout


def gen_input():
    n_lines = random.randint(0, 8)
    delims = [b' ', b'\t', b',', b';', b':', b'|']
    delim = random.choice(delims)
    has_header = random.random() < 0.5
    lines = []
    if has_header:
        # Generate header line with fixed names
        names = ['name', 'age', 'city', 'zip', 'country', 'email', 'phone', 'id']
        n = random.randint(2, 6)
        header_fields = random.sample(names, n)
        lines.append(delim.join(f.encode() for f in header_fields))
    for _ in range(n_lines):
        n_fields = random.randint(0, 8)
        fields = []
        for j in range(n_fields):
            t = random.random()
            if t < 0.4:
                fields.append(f"f{random.randint(0, 99)}".encode())
            elif t < 0.6:
                fields.append(b"")
            elif t < 0.8:
                fields.append(random.choice([b"hello", b"world", b"abc", b"x"]))
            else:
                fields.append(f"{random.randint(0, 999)}".encode())
        lines.append(delim.join(fields))
    return b"\n".join(lines) + (b"\n" if n_lines > 0 and random.random() < 0.85 else b"")


def gen_args():
    args = []
    delim_choices = [",", " ", "\\t", ";", ":", "|", "x"]
    if random.random() < 0.5:
        args.extend(["-d", random.choice(delim_choices)])
    if random.random() < 0.4:
        args.append("-L")
    if random.random() < 0.4:
        args.extend(["-D", random.choice(["|", ",", "\\t", "X", "\\n", "_"])])
    spec_choices = [
        "1", "2", "3", "1-2", "2-3", "1-", "2-", "-2", "-3",
        "1,3", "2,3,5", "1-2,4", "1-3,2-4", "3-,1", "1,3-",
    ]
    # Either -f or -F (mutually exclusive sometimes)
    mode = random.random()
    if mode < 0.4:
        args.extend(["-f", random.choice(spec_choices)])
    if random.random() < 0.3:
        args.extend(["-e", random.choice(spec_choices)])

    header_choices = ["name", "age", "city", "zip", "country", "id", "missing"]
    if random.random() < 0.3:
        args.extend(["-F", random.choice(header_choices)])
    if random.random() < 0.2:
        args.extend(["-E", random.choice(header_choices)])

    if random.random() < 0.2:
        args.extend(["-F", random.choice(header_choices)])
        args.append("-r")

    if random.random() < 0.2:
        args.append("--crlf")
    if random.random() < 0.1:
        args.append("-I")
    return args


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 42
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 200
    random.seed(seed)
    fails = 0
    for i in range(n):
        stdin = gen_input()
        args = gen_args()
        ref = run(REF, args, stdin)
        sut = run(SUT, args, stdin)
        if differ(ref, sut):
            fails += 1
            print(f"DIFF #{i} args={args} input={stdin[:200]!r}")
            print(f"  REF rc={ref.returncode} out={ref.stdout[:200]!r}")
            print(f"  SUT rc={sut.returncode} out={sut.stdout[:200]!r}")
            if fails > 5:
                print("Stopping at 6 fails")
                break
    print(f"\nTotal: {n}  Fails: {fails}")


if __name__ == "__main__":
    main()
