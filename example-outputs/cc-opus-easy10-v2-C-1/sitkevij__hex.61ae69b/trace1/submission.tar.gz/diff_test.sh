#!/bin/bash
# Differential test driver: compare /workspace/executable (REF) vs ./executable (SUT)
# Reads probe specs from frames.jsonl-style lines.

set -uo pipefail

REF=/workspace/executable
SUT=/work/work/executable
FAIL=0
PASS=0
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

run_diff() {
    local label="$1"
    shift
    local stdin_data="$1"  # base64-encoded
    shift
    # Remaining args are passed to both binaries
    local ref_stdout ref_stderr ref_exit
    local sut_stdout sut_stderr sut_exit

    if [ -z "$stdin_data" ]; then
        ref_stdout=$($REF "$@" 2>"$TMPDIR/ref_err"); ref_exit=$?
        sut_stdout=$($SUT "$@" 2>"$TMPDIR/sut_err"); sut_exit=$?
    else
        ref_stdout=$(printf "%s" "$stdin_data" | base64 -d | $REF "$@" 2>"$TMPDIR/ref_err"); ref_exit=$?
        sut_stdout=$(printf "%s" "$stdin_data" | base64 -d | $SUT "$@" 2>"$TMPDIR/sut_err"); sut_exit=$?
    fi

    ref_stderr=$(cat "$TMPDIR/ref_err")
    sut_stderr=$(cat "$TMPDIR/sut_err")

    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_stderr" = "$sut_stderr" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
        # echo "PASS: $label"
    else
        FAIL=$((FAIL+1))
        echo "FAIL: $label"
        echo "  args: $*"
        if [ -n "$stdin_data" ]; then
            echo "  stdin: $(printf "%s" "$stdin_data" | base64 -d | od -An -tx1 -c | head -3)"
        fi
        if [ "$ref_exit" != "$sut_exit" ]; then
            echo "  exit: REF=$ref_exit SUT=$sut_exit"
        fi
        if [ "$ref_stdout" != "$sut_stdout" ]; then
            echo "  stdout DIFFER:"
            diff <(printf "%s" "$ref_stdout" | od -An -c | head -20) <(printf "%s" "$sut_stdout" | od -An -c | head -20) | head -20
        fi
        if [ "$ref_stderr" != "$sut_stderr" ]; then
            echo "  stderr DIFFER:"
            diff <(printf "%s" "$ref_stderr" | od -An -c | head -20) <(printf "%s" "$sut_stderr" | od -An -c | head -20) | head -20
        fi
    fi
}

# Helper to base64-encode stdin payload
b() { printf "%s" "$1" | base64 -w0; }

echo "=== Simple hex dump ==="
run_diff "empty stdin" ""
run_diff "single byte" "$(b A)"
run_diff "10 bytes" "$(b 0123456789)"
run_diff "11 bytes" "$(b 01234567890)"
run_diff "hello with newline" "$(printf 'hello\n' | base64 -w0)"
run_diff "control bytes" "$(printf '\x00\x01\x02\x7f\x80\xff' | base64 -w0)"

echo "=== Format variations ==="
run_diff "format=o" "$(b ABCD)" -f o
run_diff "format=x" "$(b ABCD)" -f x
run_diff "format=X" "$(b ABCD)" -f X
run_diff "format=b" "$(b ABCD)" -f b
run_diff "format=X with non-ASCII" "$(printf '\xab\xcd' | base64 -w0)" -f X

echo "=== Cols variations ==="
run_diff "cols=1" "$(b ABCD)" -c 1
run_diff "cols=2" "$(b ABCDE)" -c 2
run_diff "cols=3 6bytes" "$(b ABCDEF)" -c 3
run_diff "cols=3 7bytes" "$(b ABCDEFG)" -c 3
run_diff "cols=0 with bytes" "$(b ABC)" -c 0
run_diff "cols=0 empty" "" -c 0
run_diff "cols=20" "$(b ABCDEFGHIJKLMNOPQRSTUVWXYZ)" -c 20
run_diff "cols=100" "$(b ABC)" -c 100

echo "=== Len variations ==="
run_diff "len=3" "$(b 0123456789)" -l 3
run_diff "len=0" "$(b ABC)" -l 0
run_diff "len=100 short" "$(b ABCDE)" -l 100

echo "=== Color variations ==="
run_diff "color=1" "$(b ABC)" -t 1
run_diff "color=0" "$(b ABC)" -t 0
run_diff "color=1 with format=X" "$(b ABC)" -t 1 -f X

echo "=== Prefix variations ==="
run_diff "prefix=0" "$(b ABC)" -r 0
run_diff "prefix=1" "$(b ABC)" -r 1
run_diff "prefix=0 format=b" "$(b AB)" -r 0 -f b
run_diff "prefix=0 format=o" "$(b AB)" -r 0 -f o

echo "=== Array variations ==="
run_diff "array=r" "$(b ABCD)" -a r
run_diff "array=c" "$(b ABCD)" -a c
run_diff "array=g" "$(b ABCD)" -a g
run_diff "array=p" "$(b ABCD)" -a p
run_diff "array=k" "$(b ABCD)" -a k
run_diff "array=j" "$(b ABCD)" -a j
run_diff "array=s" "$(b ABCD)" -a s
run_diff "array=f" "$(b ABCD)" -a f
run_diff "array=r empty" "" -a r
run_diff "array=g cols=3 6b" "$(b ABCDEF)" -a g -c 3
run_diff "array=r cols=3 6b" "$(b ABCDEF)" -a r -c 3
run_diff "array=r cols=3 7b" "$(b ABCDEFG)" -a r -c 3
run_diff "array=g cols=3 3b" "$(b ABC)" -a g -c 3
run_diff "array=r large" "$(b 0123456789ABCDEF)" -a r -c 5

echo "=== Function mode ==="
run_diff "func=1" "" --func 1
run_diff "func=5" "" --func 5
run_diff "func=9" "" --func 9
run_diff "func=10" "" --func 10
run_diff "func=11" "" --func 11
run_diff "func=20" "" --func 20
run_diff "func=25" "" --func 25
run_diff "func=0" "" --func 0
run_diff "func=5 places=2" "" --func 5 -p 2
run_diff "func=10 places=1" "" --func 10 -p 1
run_diff "func=5 places=9" "" --func 5 -p 9
run_diff "func=5 places=0" "" --func 5 -p 0
run_diff "func + array (func wins)" "$(b ABC)" --func 3 -a r
run_diff "func + cols (cols irrelevant)" "" --func 15 -c 3
run_diff "func + len" "$(b ABCD)" --func 3 -l 2

echo "=== Error cases ==="
run_diff "invalid format" "$(b A)" -f z
run_diff "invalid color" "$(b A)" -t 5
run_diff "invalid prefix" "$(b A)" -r 2
run_diff "invalid array" "$(b A)" -a z
run_diff "two positional args" "" /tmp/x /tmp/y
run_diff "len=abc parse error" "$(b A)" -l abc
run_diff "cols=abc parse error" "$(b A)" -c abc
run_diff "places=abc parse error" "" -u 1 -p abc
run_diff "func=abc parse error" "" -u abc
run_diff "missing file" "" /tmp/definitely-not-here-X
run_diff "unrecognized flag" "" -Z
run_diff "single dash" "$(b A)" -

echo "=== Help/version ==="
run_diff "version --version" "" --version
run_diff "version -V" "" -V
run_diff "help --help" "" --help
run_diff "help -h" "" -h

echo "=== Edge cases ==="
run_diff "double dash" "$(b ABC)" --
run_diff "color overrides NO_COLOR=1" "$(b A)" -t 1

# stdin with broken pipe? probably hard to test here
# special chars
run_diff "0x20 space byte" "$(printf ' ' | base64 -w0)"
run_diff "long input" "$(printf '%.0sxyz' {1..50} | base64 -w0)" -c 5
run_diff "tab byte" "$(printf '\t' | base64 -w0)"

echo ""
echo "==============================="
echo "PASS: $PASS"
echo "FAIL: $FAIL"
echo "==============================="
[ "$FAIL" = "0" ] && exit 0 || exit 1
