use clap::{Arg, ArgAction, Command};
use std::io::{self, BufRead, Read, Write};
use std::num::ParseIntError;
use std::process::ExitCode;

const DEFAULT_COLS: usize = 10;
const DEFAULT_PLACES: usize = 4;
const FUNC_WRAP: usize = 10;

#[derive(Clone, Copy, Debug)]
enum Format {
    Octal,
    LowerHex,
    UpperHex,
    Binary,
}

impl Format {
    fn from_str(s: &str) -> Option<Self> {
        match s {
            "o" => Some(Format::Octal),
            "x" => Some(Format::LowerHex),
            "X" => Some(Format::UpperHex),
            "b" => Some(Format::Binary),
            _ => None,
        }
    }

    fn render(self, byte: u8, prefix: bool) -> String {
        match self {
            Format::Octal => {
                if prefix {
                    format!("0o{:04o}", byte)
                } else {
                    format!("{:04o}", byte)
                }
            }
            Format::LowerHex => {
                if prefix {
                    format!("0x{:02x}", byte)
                } else {
                    format!("{:02x}", byte)
                }
            }
            Format::UpperHex => {
                if prefix {
                    format!("0x{:02X}", byte)
                } else {
                    format!("{:02X}", byte)
                }
            }
            Format::Binary => {
                if prefix {
                    format!("0b{:08b}", byte)
                } else {
                    format!("{:08b}", byte)
                }
            }
        }
    }
}

#[derive(Clone, Copy, Debug)]
enum Array {
    Rust,
    C,
    Golang,
    Python,
    Kotlin,
    Java,
    Swift,
    Fsharp,
}

impl Array {
    fn from_str(s: &str) -> Option<Self> {
        match s {
            "r" => Some(Array::Rust),
            "c" => Some(Array::C),
            "g" => Some(Array::Golang),
            "p" => Some(Array::Python),
            "k" => Some(Array::Kotlin),
            "j" => Some(Array::Java),
            "s" => Some(Array::Swift),
            "f" => Some(Array::Fsharp),
            _ => None,
        }
    }
}

fn build_command() -> Command {
    Command::new("hx")
        .bin_name("executable")
        .version("0.7.0")
        .about("Futuristic take on hexdump, made in Rust.\n")
        .disable_help_flag(true)
        .disable_version_flag(true)
        .arg(
            Arg::new("INPUTFILE")
                .help("Pass file path as an argument, or input data may be passed via stdin")
                .index(1),
        )
        .arg(
            Arg::new("cols")
                .short('c')
                .long("cols")
                .value_name("columns")
                .help("Set column length"),
        )
        .arg(
            Arg::new("len")
                .short('l')
                .long("len")
                .value_name("len")
                .help("Set <len> bytes to read"),
        )
        .arg(
            Arg::new("format")
                .short('f')
                .long("format")
                .value_name("format")
                .help("Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b)")
                .value_parser(["o", "x", "X", "b"]),
        )
        .arg(
            Arg::new("color")
                .short('t')
                .long("color")
                .value_name("color")
                .help("Set color tint terminal output. 0 to disable, 1 to enable")
                .value_parser(["0", "1"]),
        )
        .arg(
            Arg::new("array")
                .short('a')
                .long("array")
                .value_name("array_format")
                .help(
                    "Set source code format output: rust (r), C (c), golang (g), python (p), \
                     kotlin (k), java (j), swift (s), fsharp (f)",
                )
                .value_parser(["r", "c", "g", "p", "k", "j", "s", "f"]),
        )
        .arg(
            Arg::new("func")
                .short('u')
                .long("func")
                .value_name("func_length")
                .help("Set function wave length"),
        )
        .arg(
            Arg::new("places")
                .short('p')
                .long("places")
                .value_name("func_places")
                .help("Set function wave output decimal places"),
        )
        .arg(
            Arg::new("prefix")
                .short('r')
                .long("prefix")
                .value_name("prefix")
                .help("Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable")
                .value_parser(["0", "1"]),
        )
        .arg(
            Arg::new("help")
                .short('h')
                .long("help")
                .help("Print help")
                .action(ArgAction::Help),
        )
        .arg(
            Arg::new("version")
                .short('V')
                .long("version")
                .help("Print version")
                .action(ArgAction::Version),
        )
}

fn parse_int_arg(matches: &clap::ArgMatches, name: &str, flag_msg: &str) -> Option<usize> {
    matches.get_one::<String>(name).map(|s| {
        s.parse::<i64>().unwrap_or_else(|e: ParseIntError| {
            eprintln!("{} {:?}", flag_msg, e);
            eprintln!("error: {}", e);
            std::process::exit(1);
        }) as usize
    })
}

fn parse_int_arg_negallowed(
    matches: &clap::ArgMatches,
    name: &str,
    flag_msg: &str,
) -> Option<i64> {
    matches.get_one::<String>(name).map(|s| {
        s.parse::<i64>().unwrap_or_else(|e: ParseIntError| {
            eprintln!("{} {:?}", flag_msg, e);
            eprintln!("error: {}", e);
            std::process::exit(1);
        })
    })
}

fn ascii_char(b: u8) -> char {
    if (0x20..=0x7e).contains(&b) {
        b as char
    } else {
        '.'
    }
}

fn color_for(byte: u8) -> String {
    let n = if byte == 0 { 22 } else { byte as u32 };
    format!("\x1b[38;5;{}m", n)
}

const ANSI_RESET: &str = "\x1b[0m";

const EMPTY_SLOT_WIDTH: usize = 5;

fn hex_dump(bytes: &[u8], cols: usize, fmt: Format, color: bool, prefix: bool) -> io::Result<()> {
    let stdout = io::stdout();
    let mut out = stdout.lock();

    let total = bytes.len();
    let mut offset: usize = 0;
    let step = std::cmp::max(cols, 1);

    loop {
        let end = std::cmp::min(offset + step, total);
        let chunk = &bytes[offset..end];

        // header: "0xNNNNNN: "
        write!(out, "0x{:06x}: ", offset)?;

        // byte slots — at least cols slots, but also at least chunk.len()
        // (this matters only for cols=0 which still renders one slot per byte)
        let slots = std::cmp::max(cols, chunk.len());
        for i in 0..slots {
            if i < chunk.len() {
                let b = chunk[i];
                let token = fmt.render(b, prefix);
                if color {
                    write!(out, "{}{}{}", color_for(b), token, ANSI_RESET)?;
                } else {
                    write!(out, "{}", token)?;
                }
                // trailing space separator (width-1 chars of value + 1 space, except just space here)
                write!(out, " ")?;
            } else {
                // empty slot: always 5 chars (regardless of format)
                write!(out, "{}", " ".repeat(EMPTY_SLOT_WIDTH))?;
            }
        }

        // ASCII section (only print for filled bytes; no trailing whitespace)
        for b in chunk {
            let c = ascii_char(*b);
            if color {
                write!(out, "{}{}{}", color_for(*b), c, ANSI_RESET)?;
            } else {
                write!(out, "{}", c)?;
            }
        }

        writeln!(out)?;

        offset += step;
        if offset > total {
            break;
        }
    }

    writeln!(out, "   bytes: {}", total)?;
    Ok(())
}

fn array_dump(bytes: &[u8], cols: usize, arr: Array) -> io::Result<()> {
    let stdout = io::stdout();
    let mut out = stdout.lock();
    let n = bytes.len();

    // Header
    match arr {
        Array::Rust => writeln!(out, "let ARRAY: [u8; {}] = [", n)?,
        Array::C => writeln!(out, "unsigned char ARRAY[{}] = {{", n)?,
        Array::Golang => writeln!(out, "a := [{}]byte{{", n)?,
        Array::Python => writeln!(out, "a = [")?,
        Array::Kotlin => writeln!(out, "val a = byteArrayOf(")?,
        Array::Java => writeln!(out, "byte[] a = new byte[]{{")?,
        Array::Swift => writeln!(out, "let a: [UInt8] = [")?,
        Array::Fsharp => writeln!(out, "let a = [|")?,
    }

    // item-rendering closure
    let item = |b: u8| -> String {
        match arr {
            Array::Fsharp => format!("0x{:02x}uy", b),
            _ => format!("0x{:02x}", b),
        }
    };

    // Separator between items
    let sep = match arr {
        Array::Fsharp => "; ",
        _ => ", ",
    };

    // For Go: every item (including last) gets the separator
    let trailing_on_last = matches!(arr, Array::Golang);

    // Effective cols for wrapping
    let eff_cols = if cols == 0 { 1 } else { cols };

    if n == 0 {
        // empty body
        writeln!(out, "    ")?;
    } else {
        let mut printed = 0;
        for chunk in bytes.chunks(eff_cols) {
            write!(out, "    ")?;
            for (i, b) in chunk.iter().enumerate() {
                let abs = printed + i;
                write!(out, "{}", item(*b))?;
                if abs < n - 1 || trailing_on_last {
                    write!(out, "{}", sep)?;
                }
            }
            writeln!(out)?;
            printed += chunk.len();
        }
        if n % eff_cols == 0 {
            writeln!(out, "    ")?;
        }
    }

    // Footer
    match arr {
        Array::Rust => writeln!(out, "];")?,
        Array::C => writeln!(out, "}};")?,
        Array::Golang => writeln!(out, "}}")?,
        Array::Python => writeln!(out, "]")?,
        Array::Kotlin => writeln!(out, ")")?,
        Array::Java => writeln!(out, "}};")?,
        Array::Swift => writeln!(out, "]")?,
        Array::Fsharp => writeln!(out, "|]")?,
    }

    Ok(())
}

fn func_dump(n: usize, places: usize) -> io::Result<()> {
    let stdout = io::stdout();
    let mut out = stdout.lock();

    for i in 0..n {
        let v = (std::f64::consts::PI * (i as f64) / (2.0 * n as f64)).sin();
        write!(out, "{:.*},", places, v)?;
        if (i + 1) % FUNC_WRAP == 0 {
            writeln!(out)?;
        }
    }
    writeln!(out)?;
    Ok(())
}

fn read_input(file: Option<&String>) -> io::Result<Box<dyn BufRead>> {
    match file {
        Some(path) => {
            let f = std::fs::File::open(path)?;
            Ok(Box::new(io::BufReader::new(f)))
        }
        None => {
            let stdin = io::stdin();
            Ok(Box::new(io::BufReader::new(stdin)))
        }
    }
}

fn read_bytes(reader: &mut dyn BufRead, len: Option<usize>) -> io::Result<Vec<u8>> {
    let mut buf = Vec::new();
    match len {
        Some(n) if n > 0 => {
            let mut limited = reader.take(n as u64);
            limited.read_to_end(&mut buf)?;
        }
        _ => {
            reader.read_to_end(&mut buf)?;
        }
    }
    Ok(buf)
}

fn should_color(color_arg: Option<&String>) -> bool {
    if let Some(v) = color_arg {
        return v == "1";
    }
    // No explicit flag — honor NO_COLOR (any value), else use TTY detection
    if std::env::var_os("NO_COLOR").is_some() {
        return false;
    }
    use std::io::IsTerminal;
    io::stdout().is_terminal()
}

fn main() -> ExitCode {
    let cmd = build_command();
    let matches = cmd.get_matches();

    // Function mode (highest priority)
    if matches.contains_id("func") {
        let n = parse_int_arg(&matches, "func", "-u, --func <integer> expected.").unwrap();
        let places = matches
            .get_one::<String>("places")
            .map(|s| {
                s.parse::<usize>().unwrap_or_else(|e: ParseIntError| {
                    eprintln!("-p, --places <integer> expected. {:?}", e);
                    eprintln!("error: {}", e);
                    std::process::exit(1);
                })
            })
            .unwrap_or(DEFAULT_PLACES);
        if let Err(e) = func_dump(n, places) {
            // Broken pipe etc.
            eprintln!("error: {}", e);
            return ExitCode::from(1);
        }
        return ExitCode::from(0);
    }

    // Now we need input
    let infile = matches.get_one::<String>("INPUTFILE");
    let len = parse_int_arg_negallowed(&matches, "len", "-l, --len <integer> expected.");
    let cols = parse_int_arg(&matches, "cols", "-c, --cols <integer> expected.")
        .unwrap_or(DEFAULT_COLS);

    let mut reader = match read_input(infile) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("error: {}", e);
            return ExitCode::from(1);
        }
    };

    let bytes = match read_bytes(&mut *reader, len.map(|x| x as usize)) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("error: {}", e);
            return ExitCode::from(1);
        }
    };

    // Array mode
    if let Some(arr_s) = matches.get_one::<String>("array") {
        let arr = Array::from_str(arr_s).expect("clap validated array value");
        if let Err(e) = array_dump(&bytes, cols, arr) {
            eprintln!("error: {}", e);
            return ExitCode::from(1);
        }
        return ExitCode::from(0);
    }

    // Hex dump mode
    let fmt = matches
        .get_one::<String>("format")
        .map(|s| Format::from_str(s).expect("clap validated"))
        .unwrap_or(Format::LowerHex);
    let color_arg = matches.get_one::<String>("color");
    let prefix = matches
        .get_one::<String>("prefix")
        .map(|s| s == "1")
        .unwrap_or(true);
    let color = should_color(color_arg);

    if let Err(e) = hex_dump(&bytes, cols, fmt, color, prefix) {
        eprintln!("error: {}", e);
        return ExitCode::from(1);
    }
    ExitCode::from(0)
}
