#!/usr/bin/env python3
"""Aggressive differential testing against the reference binary."""
import subprocess
import random
import os
import sys

REF = "/workspace/executable"
SUT = "/work/work/executable"

def run(binary, args, stdin_bytes):
    """Run binary, return (stdout, stderr, returncode)."""
    result = subprocess.run(
        [binary] + list(args),
        input=stdin_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.stdout, result.stderr, result.returncode


PASS = 0
FAIL = 0
FAILS = []


def diff(name, args, stdin_bytes, verbose=False):
    global PASS, FAIL
    r_out, r_err, r_rc = run(REF, args, stdin_bytes)
    s_out, s_err, s_rc = run(SUT, args, stdin_bytes)
    if r_out == s_out and r_err == s_err and r_rc == s_rc:
        PASS += 1
        return True
    else:
        FAIL += 1
        FAILS.append((name, args, stdin_bytes, r_out, r_err, r_rc, s_out, s_err, s_rc))
        if verbose:
            print(f"FAIL: {name}")
            print(f"  args: {args}")
            print(f"  stdin (first 80 bytes): {stdin_bytes[:80]!r}")
            print(f"  ref_rc={r_rc} sut_rc={s_rc}")
            if r_out != s_out:
                print(f"  ref_out (first 100): {r_out[:100]!r}")
                print(f"  sut_out (first 100): {s_out[:100]!r}")
            if r_err != s_err:
                print(f"  ref_err: {r_err[:200]!r}")
                print(f"  sut_err: {s_err[:200]!r}")
        return False


def main():
    rng = random.Random(42)

    # Test 1: Random ASCII content
    for i in range(50):
        n_lines = rng.randint(0, 10)
        lines = []
        for _ in range(n_lines):
            length = rng.randint(0, 40)
            chars = []
            for _ in range(length):
                c = rng.choice([
                    rng.choice('abcdefghijklmnopqrstuvwxyz0123456789'),
                    ' ', ' ', ' ',  # weighted toward space
                    '\t', '!@#$%^&*()'[rng.randint(0, 9)],
                ])
                chars.append(c)
            lines.append(''.join(chars))
        stdin_b = '\n'.join(lines).encode('utf-8')
        if rng.random() < 0.5:
            stdin_b += b'\n'
        # Random args
        args = []
        if rng.random() < 0.3:
            args.extend(['-H', str(rng.uniform(0.1, 3.0))[:5]])
        if rng.random() < 0.3:
            args.extend(['-V', str(rng.uniform(0.1, 3.0))[:5]])
        if rng.random() < 0.3:
            args.extend(['--padding', str(rng.randint(0, 20))])
        diff(f"random-ascii-{i}", args, stdin_b)

    # Test 2: Random UTF-8 content
    for i in range(20):
        n_lines = rng.randint(0, 5)
        lines = []
        for _ in range(n_lines):
            chars = []
            length = rng.randint(0, 30)
            for _ in range(length):
                cp = rng.choice([
                    chr(rng.randint(32, 126)),
                    chr(rng.randint(0xa0, 0xff)),
                    '你', '好', '中', '文', '日', '本',
                    'é', 'à', 'ö', 'ñ', 'ç',
                    '😀', '🎉', '🌟',
                ])
                chars.append(cp)
            lines.append(''.join(chars))
        stdin_b = '\n'.join(lines).encode('utf-8') + b'\n'
        args = []
        if rng.random() < 0.5:
            args.extend(['-H', str(rng.uniform(0.1, 3.0))[:5]])
        if rng.random() < 0.5:
            args.extend(['-V', str(rng.uniform(0.1, 3.0))[:5]])
        diff(f"random-utf8-{i}", args, stdin_b)

    # Test 3: Edge cases
    edge_cases = [
        ("empty", b""),
        ("just-newline", b"\n"),
        ("just-space", b" \n"),
        ("just-tab", b"\t\n"),
        ("tab-newline", b"\t"),
        ("a-newline", b"a\n"),
        ("a", b"a"),
        ("space-a-space", b" a "),
        ("crlf", b"a\r\n"),
        ("cr-only", b"a\r"),
        ("nul", b"\x00\n"),
        ("backslash-n-literal", b"\\n\n"),
        ("long-line", b"x" * 200 + b"\n"),
        ("many-newlines", b"\n" * 20),
        ("ten-empty-lines", b"\n" * 10),
        ("mix1", b"abc\n\n  \n  def\n   "),
        ("trailing-cr", b"abc\r\nfoo\r"),
        ("unicode-bom", b"\xef\xbb\xbfabc\n"),
        ("bidi", b"abc\xe2\x80\x8dxyz\n"),
        ("rtl", b"\xd9\x85\xd8\xb1\xd8\xad\xd8\xa8\xd8\xa7\n"),
    ]

    for name, content in edge_cases:
        diff(name, [], content)
        diff(f"{name}-h05", ['-H', '0.5'], content)
        diff(f"{name}-h2", ['-H', '2'], content)
        diff(f"{name}-v05", ['-V', '0.5'], content)
        diff(f"{name}-v2", ['-V', '2'], content)
        diff(f"{name}-pad5", ['--padding', '5'], content)

    # Test 4: file vs stdin
    for name, content in [("file-test1", b"abc\ndef\n"), ("file-test2", b"abc\n")]:
        with open(f"/tmp/{name}", 'wb') as f:
            f.write(content)
        # Read from file
        r_out, r_err, r_rc = run(REF, [f"/tmp/{name}"], b"")
        s_out, s_err, s_rc = run(SUT, [f"/tmp/{name}"], b"")
        global PASS, FAIL
        if r_out == s_out and r_err == s_err and r_rc == s_rc:
            PASS += 1
        else:
            FAIL += 1
            FAILS.append((f"file-{name}", [f"/tmp/{name}"], content, r_out, r_err, r_rc, s_out, s_err, s_rc))

    # Test 5: Various encoding tests
    invalid_utf8 = [
        ("invalid1", b"\xff\xfe\n"),
        ("invalid2", b"abc\xc2\n"),  # truncated 2-byte
        ("invalid3", b"abc\xe4\xbd\n"),  # truncated 3-byte
        ("invalid4", b"\xed\xa0\x80\n"),  # surrogate
    ]
    for name, content in invalid_utf8:
        diff(name + "-lossy", [], content)
        diff(name + "-strict", ['--encoding', 'utf8'], content)

    print(f"\nTotal: {PASS+FAIL}  Pass: {PASS}  Fail: {FAIL}")
    if FAIL > 0:
        print("\nFirst 5 failures:")
        for fail in FAILS[:5]:
            name, args, inp, r_out, r_err, r_rc, s_out, s_err, s_rc = fail
            print(f"  {name}: args={args}")
            print(f"    input (first 60): {inp[:60]!r}")
            print(f"    ref_rc={r_rc} sut_rc={s_rc}")
            if r_out != s_out:
                print(f"    ref_out: {r_out[:80]!r}")
                print(f"    sut_out: {s_out[:80]!r}")
            if r_err != s_err:
                print(f"    ref_err: {r_err[:200]!r}")
                print(f"    sut_err: {s_err[:200]!r}")


if __name__ == '__main__':
    main()
