#!/bin/bash
# Differential test: compare reference vs reimplementation
REF=/workspace/executable
SUT=/work/work/executable
PASS=0
FAIL=0
FAILS=()

run() {
    local name="$1"
    shift
    local input="$1"
    shift
    # Run both with same args ($@) and same stdin
    local ref_out=$(printf "%s" "$input" | "$REF" "$@" 2>&1)
    local ref_rc=$?
    local sut_out=$(printf "%s" "$input" | "$SUT" "$@" 2>&1)
    local sut_rc=$?
    if [ "$ref_out" = "$sut_out" ] && [ "$ref_rc" = "$sut_rc" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        FAILS+=("$name")
        if [ -z "$QUIET" ]; then
            echo "FAIL: $name"
            echo "  args: $@"
            echo "  input: $(printf "%q" "$input")"
            echo "  ref_rc=$ref_rc sut_rc=$sut_rc"
            diff <(printf "%s" "$ref_out" | od -An -c | head -5) <(printf "%s" "$sut_out" | od -An -c | head -5)
        fi
    fi
}

run_raw() {
    # Variant where input is raw bytes (from a file)
    local name="$1"
    shift
    local infile="$1"
    shift
    local ref_out=$("$REF" "$@" < "$infile" 2>&1)
    local ref_rc=$?
    local sut_out=$("$SUT" "$@" < "$infile" 2>&1)
    local sut_rc=$?
    if [ "$ref_out" = "$sut_out" ] && [ "$ref_rc" = "$sut_rc" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        FAILS+=("$name")
        if [ -z "$QUIET" ]; then
            echo "FAIL: $name (raw)"
            echo "  args: $@"
            echo "  ref_rc=$ref_rc sut_rc=$sut_rc"
            diff <(printf "%s" "$ref_out" | od -An -c | head -5) <(printf "%s" "$sut_out" | od -An -c | head -5)
        fi
    fi
}

# Basic tests
run "empty" ""
run "hello" "hello"
run "hello-with-newline" "hello\n"
run "ten lines" "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n"
run "16 lines" "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n"
run "multiword" "hello world\nthis is a test\nline 3\nline 4\n"

# Scale tests
run "H 2.0" "abc\n" -H 2.0
run "H 0.5" "abc\n" -H 0.5
run "V 2.0" "1\n2\n3\n4\n5\n6\n7\n8\n" -V 2.0
run "V 0.5" "1\n2\n3\n4\n5\n6\n7\n8\n" -V 0.5
run "H 0" "abc\n" -H 0
run "H large" "abc\n" -H 10.0

# Padding tests
run "padding 5" "abc\n" --padding 5
run "padding 10" "abc\n" --padding 10
run "padding empty" "\n" --padding 3

# Multi-line
run "varied lines" "a\nab\nabc\nabcd\nabcde\nabcdef\n" --padding 6

# Empty/whitespace
run "newline only" "\n"
run "5 newlines" "\n\n\n\n\n"
run "ws line" " \n"
run "mixed empty" "ab\n\ncd\n"
run "mixed ws" "ab\n  \ncd\n"

# Subcommands
run "help" "" --help
run "version" "" --version
run "h flag" "" -h
run "completion bash" "" completion bash
run "completion fish" "" completion fish
run "completion zsh" "" completion zsh
run "completion elvish" "" completion elvish
run "completion powershell" "" completion powershell
run "completion no shell" "" completion
run "completion bad shell" "" completion notashell

# Error cases
run "bogus flag" "" --bogus
run "bad H value" "" -H abc
run "empty H" "" -H ""
run "dash filename" "" -

# Encoding
run "utf8 valid" "héllo\n" --encoding utf8
run "utf8 strict" $'\xff\xfe' --encoding utf8

# Multibyte
run "chinese" "你好\n"
run "single chinese" "你\n"
run "mixed multibyte" "你b\n"
run "mixed multibyte 2" "b你\n"
run "héllo" "héllo\n"
run "héllo no nl" "héllo"

echo ""
echo "Total: $((PASS + FAIL))  Pass: $PASS  Fail: $FAIL"
if [ ${#FAILS[@]} -gt 0 ]; then
    echo "Failures:"
    printf '  %s\n' "${FAILS[@]}"
fi
