#!/bin/bash
# More aggressive differential testing
REF=/workspace/executable
SUT=/work/work/executable
PASS=0
FAIL=0
FAILS=()

run_bytes() {
    local name="$1"
    shift
    local infile="$1"
    shift
    local ref_out_f=$(mktemp)
    local sut_out_f=$(mktemp)
    "$REF" "$@" < "$infile" > "$ref_out_f" 2>&1
    local ref_rc=$?
    "$SUT" "$@" < "$infile" > "$sut_out_f" 2>&1
    local sut_rc=$?
    if cmp -s "$ref_out_f" "$sut_out_f" && [ "$ref_rc" = "$sut_rc" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        FAILS+=("$name")
        if [ -z "$QUIET" ]; then
            echo "FAIL: $name"
            echo "  args: $@"
            echo "  ref_rc=$ref_rc sut_rc=$sut_rc"
            echo "  input: $(od -An -c "$infile" | head -3)"
            echo "  ref: $(od -An -c "$ref_out_f" | head -3)"
            echo "  sut: $(od -An -c "$sut_out_f" | head -3)"
        fi
    fi
    rm -f "$ref_out_f" "$sut_out_f"
}

# Various char sets
T=/tmp/fzt
rm -rf $T; mkdir -p $T

# ASCII single-line
for s in "" "a" "ab" "abc" "abcd" "abcde" "abcdef" "abcdefg" "abcdefgh" "abcdefghi" "12345"; do
    printf "%s" "$s" > $T/in.txt
    run_bytes "ASCII single '$s' nonl" $T/in.txt
    printf "%s\n" "$s" > $T/in.txt
    run_bytes "ASCII single '$s' nl" $T/in.txt
done

# ASCII multi-line
for n in 1 2 3 4 5 8 16 17 33; do
    > $T/in.txt
    for ((i=1; i<=$n; i++)); do
        printf "line $i\n" >> $T/in.txt
    done
    run_bytes "ASCII $n lines" $T/in.txt
done

# Empty lines
for combo in '\n' '\n\n' '\n\n\n' '\n\n\n\n' 'a\n\n' '\n\nb' 'a\n\nb' 'a\nb\n\nc' '\nabc\n\ndef\n'; do
    printf "$combo" > $T/in.txt
    run_bytes "empty combo: $combo" $T/in.txt
done

# Whitespace variations
for ws in ' ' '  ' '\t' '\t\t' '\v' '\f' ' \t' '\t ' ' a ' '  abc  ' 'abc  def' 'abc\tdef'; do
    printf "$ws\n" > $T/in.txt
    run_bytes "ws: $ws" $T/in.txt
done

# Scale variations
printf "abcdefghij\n" > $T/in.txt
for h in 0.1 0.25 0.33 0.5 0.7 0.9 1.0 1.1 1.5 2.0 2.5 3.0 10.0; do
    run_bytes "abcdefghij H=$h" $T/in.txt -H $h
done
for v in 0.1 0.25 0.33 0.5 0.7 0.9 1.0 1.1 1.5 2.0 2.5 3.0; do
    > $T/in.txt
    for ((i=1; i<=20; i++)); do
        printf "line $i\n" >> $T/in.txt
    done
    run_bytes "20 lines V=$v" $T/in.txt -V $v
done

# Padding
printf "abc\n" > $T/in.txt
for p in 0 1 2 3 5 10 100; do
    run_bytes "abc padding=$p" $T/in.txt --padding $p
done

# H=0 + padding combinations
for p in 0 3 5; do
    printf "abc\n" > $T/in.txt
    run_bytes "abc H=0 padding=$p" $T/in.txt -H 0 --padding $p
done

# UTF-8 chars
printf "héllo\n" > $T/in.txt; run_bytes "héllo" $T/in.txt
printf "你好\n" > $T/in.txt; run_bytes "你好" $T/in.txt
printf "你\n" > $T/in.txt; run_bytes "你 alone" $T/in.txt
printf "你b\n" > $T/in.txt; run_bytes "你b" $T/in.txt
printf "b你\n" > $T/in.txt; run_bytes "b你" $T/in.txt
printf "héllo 你好 abc\n" > $T/in.txt; run_bytes "mixed multi" $T/in.txt
printf "😀\n" > $T/in.txt; run_bytes "emoji alone" $T/in.txt
printf "a😀b\n" > $T/in.txt; run_bytes "emoji mid" $T/in.txt
printf "\xc2\xa0\n" > $T/in.txt; run_bytes "NBSP only" $T/in.txt
printf "a\xc2\xa0b\n" > $T/in.txt; run_bytes "NBSP mid" $T/in.txt
printf "abc\xc2\xa0\n" > $T/in.txt; run_bytes "NBSP trail" $T/in.txt

# CR / CRLF
printf "abc\r\n" > $T/in.txt; run_bytes "CRLF" $T/in.txt
printf "abc\rdef\n" > $T/in.txt; run_bytes "CR mid" $T/in.txt
printf "abc\r\ndef\r\n" > $T/in.txt; run_bytes "2 CRLF lines" $T/in.txt
printf "abc\r" > $T/in.txt; run_bytes "trailing CR" $T/in.txt

# Tabs, control chars
printf "a\tb\tc\n" > $T/in.txt; run_bytes "tabs" $T/in.txt
printf "abc\b\n" > $T/in.txt; run_bytes "backspace" $T/in.txt

# Long lines
python3 -c 'print("x"*1000)' > $T/in.txt; run_bytes "1000 chars" $T/in.txt
python3 -c 'print("x"*5000)' > $T/in.txt; run_bytes "5000 chars" $T/in.txt

# Many lines
python3 -c 'print("\n".join("x"*i for i in range(1, 51)))' > $T/in.txt
run_bytes "50 varied lines" $T/in.txt
python3 -c 'print("\n".join("x"*i for i in range(1, 51)))' > $T/in.txt
run_bytes "50 lines V 0.5" $T/in.txt -V 0.5
run_bytes "50 lines V 2.0" $T/in.txt -V 2.0
run_bytes "50 lines H 0.5" $T/in.txt -H 0.5
run_bytes "50 lines H 2.0" $T/in.txt -H 2.0

# Edge: floats with weird formats
printf "abc\n" > $T/in.txt
for v in 1 1.0 1.5 .5 0.5 -0 1e0 1e1 inf nan NaN INF -inf -0.5 -1 -1.0 +1.0; do
    run_bytes "float $v" $T/in.txt -H "$v"
done

# Subcommand variants
run_bytes "completion-bash" /dev/null completion bash
run_bytes "completion-fish" /dev/null completion fish
run_bytes "completion-zsh" /dev/null completion zsh
run_bytes "completion-elvish" /dev/null completion elvish
run_bytes "completion-powershell" /dev/null completion powershell
run_bytes "completion-help" /dev/null completion --help

# Error cases
run_bytes "unknown-flag" /dev/null --bogus
run_bytes "bad-H" /dev/null -H abc
run_bytes "missing-H" /dev/null -H
run_bytes "no-file" /dev/null nonexistent.txt

# Help variants
run_bytes "help" /dev/null --help
run_bytes "help-cmd" /dev/null help
run_bytes "help-completion" /dev/null help completion

echo ""
echo "Total: $((PASS + FAIL))  Pass: $PASS  Fail: $FAIL"
if [ ${#FAILS[@]} -gt 0 ]; then
    echo "Failures:"
    printf '  %s\n' "${FAILS[@]}" | head -30
fi
