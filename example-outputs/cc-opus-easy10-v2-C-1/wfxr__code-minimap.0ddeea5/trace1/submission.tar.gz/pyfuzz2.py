#!/usr/bin/env python3
"""More aggressive fuzzing with realistic inputs."""
import subprocess
import random
import os
import sys

REF = "/workspace/executable"
SUT = "/work/work/executable"

PASS = 0
FAIL = 0
FAILS = []


def run(binary, args, stdin_bytes):
    result = subprocess.run(
        [binary] + list(args),
        input=stdin_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.stdout, result.stderr, result.returncode


def diff(name, args, stdin_bytes, verbose=False):
    global PASS, FAIL
    r_out, r_err, r_rc = run(REF, args, stdin_bytes)
    s_out, s_err, s_rc = run(SUT, args, stdin_bytes)
    if r_out == s_out and r_err == s_err and r_rc == s_rc:
        PASS += 1
        return True
    else:
        FAIL += 1
        FAILS.append((name, args, stdin_bytes, r_out, r_err, r_rc, s_out, s_err, s_rc))
        if verbose:
            print(f"FAIL: {name}")
            print(f"  args: {args}")
            print(f"  stdin (first 80 bytes): {stdin_bytes[:80]!r}")
            print(f"  ref_rc={r_rc} sut_rc={s_rc}")
            if r_out != s_out:
                print(f"  ref_out: {r_out[:200]!r}")
                print(f"  sut_out: {s_out[:200]!r}")
            if r_err != s_err:
                print(f"  ref_err: {r_err[:300]!r}")
                print(f"  sut_err: {s_err[:300]!r}")
        return False


def main():
    rng = random.Random()

    # 1. Real-looking code snippets
    code_snippets = [
        b"def hello():\n    print('world')\n",
        b"function foo() {\n  return 42;\n}\n",
        b"class Bar(object):\n  def __init__(self):\n    self.x = 1\n",
        b"<html>\n  <body>\n    <p>Hi</p>\n  </body>\n</html>\n",
        b"# Header\n## Sub\n- list 1\n- list 2\n",
        b"import sys\nimport os\n\ndef main():\n  pass\n\nif __name__ == '__main__':\n  main()\n",
    ]
    scales = [None, '0.1', '0.5', '1.0', '1.5', '2.0', '3.0']
    paddings = [None, '0', '3', '10', '50']
    for i, code in enumerate(code_snippets):
        for h in scales:
            for v in scales:
                for p in paddings:
                    args = []
                    if h: args.extend(['-H', h])
                    if v: args.extend(['-V', v])
                    if p: args.extend(['--padding', p])
                    diff(f"code-{i}-h={h}-v={v}-p={p}", args, code)

    # 2. Lines of varying length
    for n_lines in [1, 2, 3, 4, 5, 8, 15, 32, 64]:
        for line_len_max in [1, 5, 20, 100]:
            content = b""
            for j in range(n_lines):
                content += b"x" * (j % line_len_max + 1) + b"\n"
            for h in ['0.5', '1.0', '2.0']:
                for v in ['0.5', '1.0', '2.0']:
                    args = ['-H', h, '-V', v]
                    diff(f"shape-n{n_lines}-max{line_len_max}-h{h}-v{v}", args, content)

    # 3. Random byte sequences (may include invalid UTF-8)
    for i in range(20):
        n_bytes = rng.randint(0, 200)
        content = bytes(rng.randint(0, 255) for _ in range(n_bytes))
        diff(f"random-bytes-{i}", [], content)
        diff(f"random-bytes-{i}-utf8strict", ['--encoding', 'utf8'], content)

    # 4. Many short lines
    short_lines = ('\n'.join(rng.choice('abcXY ') * rng.randint(0, 5) for _ in range(50)) + '\n').encode()
    diff("many-short-lines-v05", ['-V', '0.5'], short_lines)
    diff("many-short-lines-v2", ['-V', '2'], short_lines)
    diff("many-short-lines-v33", ['-V', '0.33'], short_lines)
    diff("many-short-lines-v01", ['-V', '0.1'], short_lines)

    # 5. Trailing whitespace variations
    for trail in [b'', b' ', b'  ', b'\t', b' \t', b'\t ', b'\v', b'\f', b'\xc2\xa0']:
        for non_trail in [b'abc', b'', b' a ']:
            content = non_trail + trail + b'\n' + b'def\n'
            diff(f"trail-{trail!r}-content-{non_trail!r}", [], content)

    # 6. UTF-8 multi-line with various char widths
    contents = [
        "你好\n世界\n".encode('utf-8'),
        "中文\n日本語\n한국어\n".encode('utf-8'),
        "héllo\nwörld\n".encode('utf-8'),
        "😀😀😀\n🎉🎉\n".encode('utf-8'),
        "𝕒𝕓𝕔\n".encode('utf-8'),  # math chars
        "→ ← ↑ ↓\n".encode('utf-8'),  # arrows
        "Здравствуй\nМир\n".encode('utf-8'),  # Russian
    ]
    for i, c in enumerate(contents):
        for h in ['0.5', '1.0', '2.0']:
            args = ['-H', h]
            diff(f"utf8-{i}-h{h}", args, c)

    # 7. Long lines
    for length in [100, 500, 1000, 2000]:
        content = (b'x' * length + b'\n') * 3
        diff(f"long-{length}", [], content)

    # 8. CRLF line endings
    crlf_content = b"line 1\r\nline 2\r\nline 3\r\n"
    diff("crlf", [], crlf_content)
    diff("crlf-h2", ['-H', '2'], crlf_content)

    # 9. file argument tests
    global PASS, FAIL
    for name, content in [
        ("simple", b"abc\n"),
        ("multi", b"abc\ndef\nghi\n"),
        ("empty", b""),
        ("ws-line", b"   \n"),
    ]:
        path = f"/tmp/pyfuzz_{name}.txt"
        with open(path, 'wb') as f:
            f.write(content)
        r_out, r_err, r_rc = run(REF, [path], b"")
        s_out, s_err, s_rc = run(SUT, [path], b"")
        if r_out == s_out and r_err == s_err and r_rc == s_rc:
            PASS += 1
        else:
            FAIL += 1
            FAILS.append((f"file-{name}", [path], content, r_out, r_err, r_rc, s_out, s_err, s_rc))

    print(f"\nTotal: {PASS+FAIL}  Pass: {PASS}  Fail: {FAIL}")
    if FAIL > 0:
        print("\nFirst 5 failures:")
        for fail in FAILS[:5]:
            name, args, inp, r_out, r_err, r_rc, s_out, s_err, s_rc = fail
            print(f"  {name}: args={args}")
            print(f"    input (first 60): {inp[:60]!r}")
            print(f"    ref_rc={r_rc} sut_rc={s_rc}")
            if r_out != s_out:
                print(f"    ref_out: {r_out[:100]!r}")
                print(f"    sut_out: {s_out[:100]!r}")
            if r_err != s_err:
                print(f"    ref_err: {r_err[:200]!r}")
                print(f"    sut_err: {s_err[:200]!r}")


if __name__ == '__main__':
    main()
