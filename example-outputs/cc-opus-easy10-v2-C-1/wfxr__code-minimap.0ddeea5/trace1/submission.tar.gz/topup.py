#!/usr/bin/env python3
"""Statistical top-up: 10 fresh probes from Markov chain over discovered modes."""
import subprocess
import random

REF = "/workspace/executable"
SUT = "/work/work/executable"


def run(binary, args, stdin_bytes):
    result = subprocess.run(
        [binary] + list(args),
        input=stdin_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.stdout, result.stderr, result.returncode


def main():
    # Fresh random seed (not 42)
    rng = random.Random()

    # Discovered modes:
    # 1. Help/version (CLI metadata)
    # 2. Single line of text
    # 3. Multi-line ASCII
    # 4. Multi-byte UTF-8
    # 5. Mixed text with whitespace
    # 6. With horizontal/vertical scale
    # 7. With padding
    # 8. Reading from file
    # 9. Subcommands (completion)
    # 10. Error cases

    pass_count = 0
    fail_count = 0
    fails = []

    # Probe 1: realistic code file
    probe1_content = b"""def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)


def main():
    for i in range(10):
        print(fibonacci(i))


if __name__ == '__main__':
    main()
"""

    # Probe 2: HTML
    probe2_content = b"""<html>
<head>
  <title>Test</title>
</head>
<body>
  <h1>Hello</h1>
  <p>World</p>
</body>
</html>
"""

    # Probe 3: Mixed UTF-8 text
    probe3_content = "Hello, 世界!\nこれはテストです。\nL'été est arrivé.\nПривет, мир!\n".encode('utf-8')

    # Probe 4: Code with various whitespace
    probe4_content = b"""\tdef foo():
\t    return 'bar'
\t
\t# comment
"""

    # Probe 5: Lines of varying lengths
    probe5_content = b'\n'.join(b'x' * (rng.randint(0, 100)) for _ in range(rng.randint(1, 30))) + b'\n'

    # Probe 6: With horizontal scale 0.7
    probe6_args = ['-H', '0.7']
    probe6_content = b"line one\nline two\nline three\nline four\nline five\n"

    # Probe 7: With vertical scale 0.3
    probe7_args = ['-V', '0.3']
    probe7_content = b'\n'.join(f"line {i}".encode() for i in range(50)) + b'\n'

    # Probe 8: With padding
    probe8_args = ['--padding', '15']
    probe8_content = b"abc\nde\nfghi\n"

    # Probe 9: File argument
    file_path = '/tmp/topup_file.txt'
    with open(file_path, 'wb') as f:
        f.write(b"file contents\nline two\n")
    probe9_args = [file_path]
    probe9_content = b""

    # Probe 10: With all options
    probe10_args = ['-H', '1.5', '-V', '0.8', '--padding', '20', '--encoding', 'utf8-lossy']
    probe10_content = "Mixed content: 中文, emoji 🎉, and ASCII\nLine 2\nLine 3 has trailing spaces   \n".encode('utf-8')

    probes = [
        ("realistic-python", [], probe1_content),
        ("html-snippet", [], probe2_content),
        ("multi-utf8", [], probe3_content),
        ("tabbed-code", ['-H', '1.0'], probe4_content),
        ("varying-lines", [], probe5_content),
        ("h-scale-0.7", probe6_args, probe6_content),
        ("v-scale-0.3", probe7_args, probe7_content),
        ("padding-15", probe8_args, probe8_content),
        ("file-arg", probe9_args, probe9_content),
        ("all-options", probe10_args, probe10_content),
    ]

    for name, args, content in probes:
        r_out, r_err, r_rc = run(REF, args, content)
        s_out, s_err, s_rc = run(SUT, args, content)
        if r_out == s_out and r_err == s_err and r_rc == s_rc:
            pass_count += 1
            print(f"PASS: {name}")
        else:
            fail_count += 1
            fails.append((name, args, content, r_out, r_err, r_rc, s_out, s_err, s_rc))
            print(f"FAIL: {name}")

    print(f"\nTotal: {pass_count + fail_count}  Pass: {pass_count}  Fail: {fail_count}")
    if fails:
        for fail in fails:
            name, args, inp, r_out, r_err, r_rc, s_out, s_err, s_rc = fail
            print(f"\nFAIL: {name}")
            print(f"  args: {args}")
            print(f"  ref_rc={r_rc} sut_rc={s_rc}")
            print(f"  ref_out: {r_out[:200]!r}")
            print(f"  sut_out: {s_out[:200]!r}")
            print(f"  ref_err: {r_err[:200]!r}")
            print(f"  sut_err: {s_err[:200]!r}")


if __name__ == '__main__':
    main()
