#!/usr/bin/env python3
"""code-minimap 0.6.8 reimplementation."""
import sys
import os
import io
import math

# Embedded reference outputs
HELP_TEXT = b"""A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
"""

VERSION_TEXT = b"code-minimap 0.6.8\n"

COMPLETION_HELP = b"""Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
"""

HELP_HELP = b"""Print this message or the help of the given subcommand(s)

Usage: executable help [COMMAND]...

Arguments:
  [COMMAND]...
          Print help for the subcommand(s)
"""

# Completion script outputs (loaded at runtime to keep this file small)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def is_whitespace(ch):
    """Match Rust's char::is_whitespace (Unicode White_Space property)."""
    # Rust's `is_whitespace` returns true for these:
    # https://doc.rust-lang.org/std/primitive.char.html#method.is_whitespace
    cp = ord(ch)
    if cp == 0x20 or 0x09 <= cp <= 0x0D:
        return True
    if cp == 0x85 or cp == 0xA0:
        return True
    if cp == 0x1680:
        return True
    if 0x2000 <= cp <= 0x200A:
        return True
    if cp == 0x2028 or cp == 0x2029:
        return True
    if cp == 0x202F or cp == 0x205F:
        return True
    if cp == 0x3000:
        return True
    return False


def rstrip_ws(s):
    """Rust-style trim_end using is_whitespace."""
    i = len(s)
    while i > 0 and is_whitespace(s[i - 1]):
        i -= 1
    return s[:i]


def _scale_to_usize(x, hscale):
    """Compute floor(x * hscale) with Rust's 'as usize' semantics:
    - NaN -> 0
    - negative -> 0
    - +inf -> saturating; we exit 101 to mimic capacity overflow panic
    """
    import math
    v = x * hscale
    if math.isnan(v):
        return 0
    if v <= 0:
        return 0
    if math.isinf(v):
        sys.stderr.write(f"thread 'main' ({os.getpid()}) panicked at library/alloc/src/raw_vec/mod.rs:28:5:\ncapacity overflow\nnote: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n")
        sys.exit(101)
    return int(v)


def line_to_cells(line, hscale):
    """Compute the cells (Vec<bool>) for a single input line.
    Returns a list[bool]."""
    trimmed = rstrip_ws(line)
    if not trimmed:
        # Empty line: use raw_cols = 1 as the minimum
        bitmap_cols = _scale_to_usize(1, hscale)
        return [False] * bitmap_cols
    # Compute byte positions of each char
    char_positions = []  # list of (byte_pos, char_len_utf8, is_ws)
    bp = 0
    for ch in trimmed:
        char_bytes = ch.encode('utf-8')
        char_positions.append((bp, len(char_bytes), is_whitespace(ch)))
        bp += len(char_bytes)
    # Find first non-whitespace position
    first_non_ws = None
    for p, _l, is_ws in char_positions:
        if not is_ws:
            first_non_ws = p
            break
    if first_non_ws is None:
        # Should not happen since trim_end was applied
        bitmap_cols = _scale_to_usize(1, hscale)
        return [False] * bitmap_cols
    last_byte_pos = char_positions[-1][0]
    raw_cols = last_byte_pos + 1
    bitmap_cols = _scale_to_usize(raw_cols, hscale)
    if bitmap_cols == 0:
        return []
    cells = [False] * bitmap_cols
    for i, (p, plen, _is_ws) in enumerate(char_positions):
        if p < first_non_ws:
            continue
        target_start = _scale_to_usize(p, hscale)
        if i + 1 < len(char_positions):
            next_p = char_positions[i + 1][0]
        else:
            next_p = p + 1  # last char fills only 1 byte
        target_end = _scale_to_usize(next_p, hscale)
        if target_end > bitmap_cols:
            target_end = bitmap_cols
        for col in range(target_start, target_end):
            cells[col] = True
    return cells


def read_lines(input_bytes, encoding):
    """Read lines from input bytes. Returns list of decoded strings (no trailing \\n)."""
    if encoding == 'utf8':
        # Strict: error on invalid UTF-8
        try:
            text = input_bytes.decode('utf-8')
        except UnicodeDecodeError:
            sys.stderr.write("code-minimap: stream did not contain valid UTF-8\n")
            sys.exit(1)
    else:
        # utf8-lossy
        text = input_bytes.decode('utf-8', errors='replace')
    # Split on \n (BufRead::lines behavior: no trailing empty line)
    if not text:
        return []
    lines = text.split('\n')
    if lines and lines[-1] == '':
        lines.pop()
    return lines


def render(input_bytes, hscale, vscale, padding, encoding):
    """Render input bytes to braille minimap output bytes."""
    lines = read_lines(input_bytes, encoding)
    if not lines:
        return b''
    # Per-line cells
    all_cells = [line_to_cells(line, hscale) for line in lines]
    # Group by floor(idx * vscale)
    groups = []
    current_key = None
    current_group = []
    for idx, cells in enumerate(all_cells):
        key = int(idx * vscale)
        if current_key is None or key != current_key:
            if current_group:
                groups.append(current_group)
            current_group = [cells]
            current_key = key
        else:
            current_group.append(cells)
    if current_group:
        groups.append(current_group)
    # Each group -> 1 bitmap row (OR of cells)
    bitmap_rows = []
    for grp in groups:
        max_len = max(len(c) for c in grp)
        combined = [False] * max_len
        for cells in grp:
            for col in range(len(cells)):
                if cells[col]:
                    combined[col] = True
        bitmap_rows.append(combined)
    # Each braille row = 4 bitmap rows
    out = bytearray()
    n_braille_rows = (len(bitmap_rows) + 3) // 4
    for br in range(n_braille_rows):
        rows_in_braille = bitmap_rows[br * 4:(br + 1) * 4]
        max_cols = max(len(r) for r in rows_in_braille)
        n_braille_chars = (max_cols + 1) // 2
        line_bytes = bytearray()
        chars_written = 0
        for bc in range(n_braille_chars):
            # Encode 8 dots
            code = 0
            for sub_row in range(len(rows_in_braille)):
                row = rows_in_braille[sub_row]
                col_a = bc * 2
                col_b = bc * 2 + 1
                a = col_a < len(row) and row[col_a]
                b = col_b < len(row) and row[col_b]
                # Dot bit mapping:
                # sub_row 0: dot1(bit0)=col_a, dot4(bit3)=col_b
                # sub_row 1: dot2(bit1)=col_a, dot5(bit4)=col_b
                # sub_row 2: dot3(bit2)=col_a, dot6(bit5)=col_b
                # sub_row 3: dot7(bit6)=col_a, dot8(bit7)=col_b
                if sub_row == 0:
                    if a: code |= 0x01
                    if b: code |= 0x08
                elif sub_row == 1:
                    if a: code |= 0x02
                    if b: code |= 0x10
                elif sub_row == 2:
                    if a: code |= 0x04
                    if b: code |= 0x20
                elif sub_row == 3:
                    if a: code |= 0x40
                    if b: code |= 0x80
            braille_codepoint = 0x2800 + code
            line_bytes += chr(braille_codepoint).encode('utf-8')
            chars_written += 1
        # Padding
        if padding is not None and chars_written < padding:
            line_bytes += b' ' * (padding - chars_written)
        line_bytes += b'\n'
        out += line_bytes
    return bytes(out)


def consume_value(argv, i, flag_name, possible_values=None):
    """Consume the next arg as value for flag_name. Handle = syntax inside flag_name not needed (caller already split).
    If next arg starts with '-' (and isn't just '-'), treat as missing value (per clap)."""
    if i >= len(argv):
        err_missing_value(flag_name, possible_values)
    val = argv[i]
    if val.startswith('-') and val != '-':
        # clap treats this as flag-like; error
        err_unexpected_arg(val)
    return val


def parse_args(argv):
    """Parse argv. Return dict with parsed values, or print error and exit."""
    args = {
        'hscale': 1.0,
        'vscale': 1.0,
        'padding': None,
        'encoding': 'utf8-lossy',
        'file': None,
        'subcommand': None,
        'subcommand_args': [],
    }
    seen = set()

    def split_eq(a):
        """If a contains =, return (key, value). Else (a, None)."""
        if '=' in a:
            return a.split('=', 1)
        return (a, None)

    i = 0
    after_dd = False
    positional = []
    while i < len(argv):
        a = argv[i]
        if not after_dd:
            if a == '--':
                after_dd = True
                i += 1
                continue
            # Handle long options with =
            key, eq_val = split_eq(a)
            if key in ('-h', '--help'):
                sys.stdout.buffer.write(HELP_TEXT)
                sys.exit(0)
            if key == '--version':
                sys.stdout.buffer.write(VERSION_TEXT)
                sys.exit(0)
            if key in ('-H', '--horizontal-scale'):
                if 'hscale' in seen:
                    err_duplicate('--horizontal-scale <HSCALE>')
                if eq_val is not None:
                    val = eq_val
                    i += 1
                else:
                    val = consume_value(argv, i + 1, '--horizontal-scale <HSCALE>')
                    i += 2
                seen.add('hscale')
                args['hscale'] = parse_float(val, '--horizontal-scale <HSCALE>')
                continue
            if key in ('-V', '--vertical-scale'):
                if 'vscale' in seen:
                    err_duplicate('--vertical-scale <VSCALE>')
                if eq_val is not None:
                    val = eq_val
                    i += 1
                else:
                    val = consume_value(argv, i + 1, '--vertical-scale <VSCALE>')
                    i += 2
                seen.add('vscale')
                args['vscale'] = parse_float(val, '--vertical-scale <VSCALE>')
                continue
            if key == '--padding':
                if 'padding' in seen:
                    err_duplicate('--padding <PADDING>')
                if eq_val is not None:
                    val = eq_val
                    i += 1
                else:
                    val = consume_value(argv, i + 1, '--padding <PADDING>')
                    i += 2
                seen.add('padding')
                args['padding'] = parse_uint(val, '--padding <PADDING>')
                continue
            if key == '--encoding':
                if 'encoding' in seen:
                    err_duplicate('--encoding <ENCODING>')
                if eq_val is not None:
                    val = eq_val
                    i += 1
                else:
                    val = consume_value(argv, i + 1, '--encoding <ENCODING>', possible_values='[possible values: utf8-lossy, utf8]')
                    i += 2
                seen.add('encoding')
                if val == '':
                    sys.stderr.write("error: a value is required for '--encoding <ENCODING>' but none was supplied\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.\n")
                    sys.exit(2)
                if val not in ('utf8-lossy', 'utf8'):
                    err_invalid_value(val, '--encoding <ENCODING>', '[possible values: utf8-lossy, utf8]')
                args['encoding'] = val
                continue
            # Check for unknown flags
            if a.startswith('-') and a != '-':
                err_unexpected_arg(a)
            # Positional - check for subcommand
            if a == 'completion':
                args['subcommand'] = 'completion'
                args['subcommand_args'] = argv[i + 1:]
                return args
            if a == 'help':
                args['subcommand'] = 'help'
                args['subcommand_args'] = argv[i + 1:]
                return args
            # FILE positional
            if a == '':
                err_empty_value('[FILE]')
            positional.append(a)
            i += 1
            continue
        else:
            # After --
            if a == '':
                err_empty_value('[FILE]')
            positional.append(a)
            i += 1
            continue
    if len(positional) > 1:
        err_unexpected_arg(positional[1])
    if positional:
        args['file'] = positional[0]
    return args


def parse_float(val, name):
    """Parse a float with Rust's strict f64::from_str semantics."""
    if val == '':
        sys.stderr.write(f"error: invalid value '' for '{name}': cannot parse float from empty string\n\nFor more information, try '--help'.\n")
        sys.exit(2)
    # Rust f64::from_str rejects values with whitespace or other extras
    if not _is_valid_rust_float(val):
        sys.stderr.write(f"error: invalid value '{val}' for '{name}': invalid float literal\n\nFor more information, try '--help'.\n")
        sys.exit(2)
    try:
        return float(val)
    except ValueError:
        sys.stderr.write(f"error: invalid value '{val}' for '{name}': invalid float literal\n\nFor more information, try '--help'.\n")
        sys.exit(2)


def _is_valid_rust_float(s):
    """Check if s parses as a Rust f64 literal (strict).
    Rust accepts: optional sign, [digits][.[digits]] or .digits, optional eEsign+digits.
    Also accepts inf, infinity, nan (case-insensitive).
    Does NOT accept: whitespace, underscores, hex.
    """
    if not s:
        return False
    s_low = s.lower()
    if s_low in ('inf', 'infinity', 'nan', '+inf', '+infinity', '+nan', '-inf', '-infinity', '-nan'):
        return True
    # Check for whitespace
    if s.strip() != s:
        return False
    # Check for underscore or hex prefix
    if '_' in s or '0x' in s_low or '0o' in s_low or '0b' in s_low:
        return False
    # Pattern: optional sign, then [digits].[digits] or .digits or digits.,
    # optional exponent e+/-digits
    import re
    pattern = r'^[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$'
    return bool(re.match(pattern, s))


def parse_uint(val, name):
    if val == '':
        sys.stderr.write(f"error: invalid value '' for '{name}': cannot parse integer from empty string\n\nFor more information, try '--help'.\n")
        sys.exit(2)
    # Rust u32::from_str: no whitespace, no signs (for u32), no extras
    if val.strip() != val or any(not c.isdigit() for c in val):
        sys.stderr.write(f"error: invalid value '{val}' for '{name}': invalid digit found in string\n\nFor more information, try '--help'.\n")
        sys.exit(2)
    try:
        n = int(val)
        if n > 4294967295:
            sys.stderr.write(f"error: invalid value '{val}' for '{name}': number too large to fit in target type\n\nFor more information, try '--help'.\n")
            sys.exit(2)
        return n
    except ValueError:
        sys.stderr.write(f"error: invalid value '{val}' for '{name}': invalid digit found in string\n\nFor more information, try '--help'.\n")
        sys.exit(2)


def err_unexpected_arg(arg):
    """Match clap's error format for unexpected arguments.
    For short flag clusters like -0.5 or -inf, clap reports only the first short flag '-X'."""
    if arg.startswith('--'):
        # Long flag
        report = arg
        msg = f"error: unexpected argument '{report}' found\n\n"
        similar = find_similar_flag(arg)
        if similar:
            msg += f"  tip: a similar argument exists: '{similar}'\n\n"
            if similar == '--help':
                msg += "Usage: executable --help [FILE]\n\n"
            elif similar == '--version':
                msg += "Usage: executable --version [FILE]\n\n"
            else:
                msg += "Usage: executable <FILE|--horizontal-scale <HSCALE>|--vertical-scale <VSCALE>|--padding <PADDING>|--encoding <ENCODING>|--version>\n\n"
        else:
            msg += f"  tip: to pass '{report}' as a value, use '-- {report}'\n\n"
            msg += "Usage: executable [OPTIONS] [FILE] [COMMAND]\n\n"
        msg += "For more information, try '--help'.\n"
    elif arg.startswith('-') and len(arg) > 1:
        # Short flag cluster: report just '-X' where X is first char
        report = arg[:2]
        msg = f"error: unexpected argument '{report}' found\n\n"
        msg += f"  tip: to pass '{report}' as a value, use '-- {report}'\n\n"
        msg += "Usage: executable [OPTIONS] [FILE] [COMMAND]\n\n"
        msg += "For more information, try '--help'.\n"
    else:
        # Just a positional arg that wasn't expected
        msg = f"error: unexpected argument '{arg}' found\n\n"
        msg += "Usage: executable [OPTIONS] [FILE] [COMMAND]\n\n"
        msg += "For more information, try '--help'.\n"
    sys.stderr.write(msg)
    sys.exit(2)


def find_similar_flag(arg):
    # Naive prefix-based similarity
    flags = ['--horizontal-scale', '--vertical-scale', '--padding', '--encoding', '--version', '--help']
    arg_stripped = arg.lstrip('-')
    for f in flags:
        fs = f.lstrip('-')
        if fs.startswith(arg_stripped) or arg_stripped.startswith(fs[:3]):
            return f
    return None


def err_missing_value(name, possible_values=None):
    msg = f"error: a value is required for '{name}' but none was supplied\n"
    if possible_values:
        msg += f"  {possible_values}\n"
    msg += "\nFor more information, try '--help'.\n"
    sys.stderr.write(msg)
    sys.exit(2)


def err_duplicate(name):
    sys.stderr.write(f"error: the argument '{name}' cannot be used multiple times\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n")
    sys.exit(2)


def err_invalid_value(val, name, extra=''):
    msg = f"error: invalid value '{val}' for '{name}'"
    if extra:
        msg += f"\n  {extra}"
    msg += "\n\nFor more information, try '--help'.\n"
    sys.stderr.write(msg)
    sys.exit(2)


def err_empty_value(name):
    sys.stderr.write(f"error: a value is required for '{name}' but none was supplied\n\nFor more information, try '--help'.\n")
    sys.exit(2)


def handle_completion(sub_args):
    from completions import COMPLETIONS
    shells = ['bash', 'elvish', 'fish', 'powershell', 'zsh']
    # If --help or -h appears anywhere, print completion help (clap order: --help wins)
    for a in sub_args:
        if a in ('-h', '--help'):
            sys.stdout.buffer.write(COMPLETION_HELP)
            sys.exit(0)
    if not sub_args:
        sys.stderr.write("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completion <SHELL>\n\nFor more information, try '--help'.\n")
        sys.exit(2)
    shell = sub_args[0]
    if shell == '':
        # Empty value treated as not supplied
        sys.stderr.write("error: a value is required for '<SHELL>' but none was supplied\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n")
        sys.exit(2)
    if shell not in shells:
        msg = f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n"
        similar = find_similar(shell, shells)
        if similar:
            msg += f"\n  tip: a similar value exists: '{similar}'\n"
        msg += "\nFor more information, try '--help'.\n"
        sys.stderr.write(msg)
        sys.exit(2)
    sys.stdout.buffer.write(COMPLETIONS[shell])
    sys.exit(0)


def find_similar(target, candidates):
    """Find a similar string using Jaro-Winkler-style heuristic (clap uses strsim)."""
    if not candidates:
        return None
    target = target.lower()
    best = None
    best_score = 0.0
    for c in candidates:
        s = jaro_winkler(target, c.lower())
        if s > best_score:
            best_score = s
            best = c
    # clap's strsim DEFAULT_MIN_SIMILARITY is 0.7
    if best_score >= 0.7:
        return best
    return None


def jaro_similarity(s1, s2):
    if s1 == s2:
        return 1.0
    if not s1 or not s2:
        return 0.0
    len1, len2 = len(s1), len(s2)
    match_distance = max(len1, len2) // 2 - 1
    if match_distance < 0:
        match_distance = 0
    s1_matches = [False] * len1
    s2_matches = [False] * len2
    matches = 0
    for i in range(len1):
        start = max(0, i - match_distance)
        end = min(i + match_distance + 1, len2)
        for j in range(start, end):
            if s2_matches[j]:
                continue
            if s1[i] != s2[j]:
                continue
            s1_matches[i] = True
            s2_matches[j] = True
            matches += 1
            break
    if matches == 0:
        return 0.0
    transpositions = 0
    k = 0
    for i in range(len1):
        if not s1_matches[i]:
            continue
        while not s2_matches[k]:
            k += 1
        if s1[i] != s2[k]:
            transpositions += 1
        k += 1
    transpositions //= 2
    return (matches / len1 + matches / len2 + (matches - transpositions) / matches) / 3


def jaro_winkler(s1, s2):
    j = jaro_similarity(s1, s2)
    # Prefix scaling factor
    prefix = 0
    for i in range(min(len(s1), len(s2), 4)):
        if s1[i] == s2[i]:
            prefix += 1
        else:
            break
    return j + prefix * 0.1 * (1 - j)


def handle_help_cmd(sub_args):
    """`help` subcommand."""
    if not sub_args:
        sys.stdout.buffer.write(HELP_TEXT)
        sys.exit(0)
    sub = sub_args[0]
    if sub == 'completion':
        sys.stdout.buffer.write(COMPLETION_HELP)
        sys.exit(0)
    if sub == 'help':
        sys.stdout.buffer.write(HELP_HELP)
        sys.exit(0)
    # Unrecognized subcommand - clap uses parent usage
    sys.stderr.write(f"error: unrecognized subcommand '{sub}'\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n")
    sys.exit(2)


def main():
    args = parse_args(sys.argv[1:])
    if args['subcommand'] == 'completion':
        handle_completion(args['subcommand_args'])
    if args['subcommand'] == 'help':
        handle_help_cmd(args['subcommand_args'])
    # Read input
    if args['file']:
        try:
            with open(args['file'], 'rb') as f:
                data = f.read()
        except (IOError, OSError) as e:
            errno_val = e.errno if e.errno else 2
            sys.stderr.write(f"code-minimap: {os.strerror(errno_val)} (os error {errno_val})\n")
            sys.exit(1)
    else:
        data = sys.stdin.buffer.read()
    output = render(data, args['hscale'], args['vscale'], args['padding'], args['encoding'])
    sys.stdout.buffer.write(output)


if __name__ == '__main__':
    main()
