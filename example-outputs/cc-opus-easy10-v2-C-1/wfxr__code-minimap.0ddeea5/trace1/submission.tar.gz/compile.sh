#!/bin/sh
# Build script: produces ./executable in current dir
set -e
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
cd "$SCRIPT_DIR"

# The executable is just a wrapper that invokes python3 on main.py
cat > executable <<'EOF'
#!/bin/sh
exec python3 "$(dirname "$0")/main.py" "$@"
EOF
chmod +x executable
chmod +x main.py
