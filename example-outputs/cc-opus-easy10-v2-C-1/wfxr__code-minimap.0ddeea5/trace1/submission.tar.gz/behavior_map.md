# code-minimap 0.6.8 — Behavior Map

## Identity
- Binary: `code-minimap` v0.6.8 (Rust). https://github.com/wfxr/code-minimap
- Uses crates: clap 4.5, clap_complete 4.5, itertools 0.13, anyhow 1
- Renders text/code files to compact Braille-Unicode minimaps

## CLI Surface

```
Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion   Generate shell completion file
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]   File to read

Options:
  -H, --horizontal-scale <HSCALE>   Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>     Specify vertical scale factor [default: 1.0]
      --padding <PADDING>           Specify padding width
      --encoding <ENCODING>         Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version                     Print version
  -h, --help                        Print help
```

## I/O Model
- Reads FILE if provided, else stdin.
- `-` is NOT treated as stdin; it's a literal filename → "No such file or directory" error.
- File-not-found: stderr `code-minimap: No such file or directory (os error 2)`, exit 1.
- No file provided AND stdin closed: probably empty output (verified empty stdin → empty output).
- Output: braille chars + optional space padding + `\n` for each braille row.
- Empty stdin: NO output at all.

## Algorithm (per line)
1. Read line (no trailing `\n`).
2. Strip trailing whitespace via Unicode `is_whitespace` (covers space, tab, NBSP U+00A0, etc.).
3. If the trimmed line is empty → cells = `vec![false]` (length 1, no dot). Render as ⠀ braille row.
4. Else, compute:
   - last_byte_pos = byte index of the last char in trimmed line
   - raw_cols = last_byte_pos + 1
   - bitmap_cols = floor(raw_cols * hscale)
   - cells = `[false] * bitmap_cols`
   - first_non_ws_pos = byte index of first non-whitespace char
   - For each char at byte_pos `p` where `p >= first_non_ws_pos`:
     - target_start = floor(p * hscale)
     - next_p = byte position of next char (or p+1 if this is the last char)
     - target_end = floor(next_p * hscale)
     - cells[target_start .. min(target_end, bitmap_cols)] = true
5. The line's `cells` Vec<bool> becomes one "input row".

KEY: each char fills the byte range it occupies; for non-last char the range is to the next char's byte_pos; for the last char it's just 1 byte. This explains why "你" alone produces 1 col, "héllo" produces 6 cols, "你b" produces 4 cols.

## Vertical Grouping (vscale)
- For input line index `idx`, compute `key = floor(idx * vscale)`.
- Group consecutive lines with same `key` (itertools::ChunkBy).
- Within a group, cells are OR'd together (extending shorter with `false`).
- Each group → 1 bitmap row.

When vscale >= 1.0, each line maps to its own row (keys are distinct).
When vscale < 1.0, multiple lines compress into one row.

## Braille Encoding
- Each braille char = 2 cols × 4 rows of bitmap (8 dots).
- 4 bitmap rows per braille row.
- Number of braille rows = ceil(num_bitmap_rows / 4).
- Number of braille chars per braille row = ceil(max_cols_in_braille_row / 2), where max_cols is the maximum cell-vec length across the (up to 4) groups in that row.
- Dot bits: dot1=0x01, dot2=0x02, dot3=0x04, dot4=0x08, dot5=0x10, dot6=0x20, dot7=0x40, dot8=0x80. Char = U+2800 + dots.
- Dot layout per braille char:
  ```
  col0/row0 col1/row0   = dot1, dot4
  col0/row1 col1/row1   = dot2, dot5
  col0/row2 col1/row2   = dot3, dot6
  col0/row3 col1/row3   = dot7, dot8
  ```

## Edge Cases
- Empty input (no bytes): no output (not even a `\n`).
- 1 input line "\n": output `⠀\n` (1 braille char + newline).
- Line with H=0 and content: output just `\n` (no braille char), but padding still applies (`   \n`).
- Trailing-only-whitespace lines: don't extend output rows (e.g., `abc\n  \n` → 2 lines, 2nd is empty).
- A braille row whose all groups are "empty cells" (each has cells `[false]`): renders as `⠀` (1 braille char).
- A braille row whose max cells length is 0 (all groups had bitmap_cols=0 due to hscale): renders as 0 braille chars + `\n`.

## Padding
- `--padding N`: each output row must be ≥ N visible chars.
- Pad with ASCII spaces (0x20) after the braille chars to reach N visible chars.
- "Visible char" = each braille char counts as 1 char (regardless of byte length).

## Encoding
- Default: `utf8-lossy` (LossyReader replaces invalid UTF-8 with U+FFFD).
- `utf8`: strict; errors with `code-minimap: stream did not contain valid UTF-8` (exit 1) on invalid.

## Error Cases
- `--bogus` (unknown flag): clap error to stderr, exit 2.
- Invalid float for `-H`/`-V`: clap error "invalid float literal" or "cannot parse float from empty string", exit 2.
- `-`: treated as literal filename `-`, fails open, exit 1.
- `<file>` not found: exit 1, stderr "code-minimap: No such file or directory (os error 2)".
- Empty file arg `""`: clap error "a value is required for '[FILE]' but none was supplied", exit 2.
- `-H 1 -H 2`: error "argument can't be used multiple times", exit 2.
- Bad `--encoding`: clap error with possible values, exit 2.

## Subcommands
- `completion <SHELL>`: generates completion script for SHELL ∈ {bash, elvish, fish, powershell, zsh}.
- `completion` w/o SHELL: clap error, exit 2.
- `help`: prints same as `--help`, exit 0.
- `help <subcommand>`: prints subcommand's help.

## Bitmap Padding Counter
- For padding, the count is "visible chars" of the output line (each braille char = 1 visible char).
- Padding never reduces width — it only adds spaces if current width < padding.
