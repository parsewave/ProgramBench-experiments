#!/usr/bin/env python3
"""Random byte fuzzing - try to find edge cases."""
import subprocess
import random
import os

REF = "/workspace/executable"
SUT = "/work/work/executable"


def run(binary, args, stdin_bytes):
    result = subprocess.run(
        [binary] + list(args),
        input=stdin_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.stdout, result.stderr, result.returncode


PASS = 0
FAIL = 0
FAILS = []


def diff(name, args, stdin_bytes):
    global PASS, FAIL
    r_out, r_err, r_rc = run(REF, args, stdin_bytes)
    s_out, s_err, s_rc = run(SUT, args, stdin_bytes)
    if r_out == s_out and r_err == s_err and r_rc == s_rc:
        PASS += 1
        return True
    else:
        FAIL += 1
        FAILS.append((name, args, stdin_bytes, r_out, r_err, r_rc, s_out, s_err, s_rc))
        return False


def main():
    rng = random.Random()
    N_TESTS = 500
    for i in range(N_TESTS):
        # Random input bytes
        size = rng.randint(0, 300)
        # Mix of strategies
        strategy = rng.choice(['ascii', 'mixed', 'utf8', 'binary'])
        if strategy == 'ascii':
            data = bytes(rng.choice(b' \t!abcXYZ0\n') for _ in range(size))
        elif strategy == 'mixed':
            data = bytes(rng.randint(0, 127) for _ in range(size))
        elif strategy == 'utf8':
            text = ''.join(rng.choice('abcXYZ 你好éñ\n\t') for _ in range(size))
            data = text.encode('utf-8')
        else:  # binary
            data = bytes(rng.randint(0, 255) for _ in range(size))

        # Random args
        args = []
        if rng.random() < 0.4:
            args.extend(['-H', str(round(rng.uniform(0.1, 3.0), 2))])
        if rng.random() < 0.4:
            args.extend(['-V', str(round(rng.uniform(0.1, 3.0), 2))])
        if rng.random() < 0.2:
            args.extend(['--padding', str(rng.randint(0, 30))])
        if rng.random() < 0.1:
            args.extend(['--encoding', rng.choice(['utf8-lossy', 'utf8'])])

        diff(f"random-{i}", args, data)

    print(f"\nTotal: {PASS+FAIL}  Pass: {PASS}  Fail: {FAIL}")
    if FAIL > 0:
        print("\nFirst 10 failures:")
        for fail in FAILS[:10]:
            name, args, inp, r_out, r_err, r_rc, s_out, s_err, s_rc = fail
            print(f"  {name}: args={args}")
            print(f"    input (first 60): {inp[:60]!r}")
            print(f"    ref_rc={r_rc} sut_rc={s_rc}")
            if r_out != s_out:
                print(f"    ref_out: {r_out[:80]!r}")
                print(f"    sut_out: {s_out[:80]!r}")
            if r_err != s_err:
                print(f"    ref_err: {r_err[:200]!r}")
                print(f"    sut_err: {s_err[:200]!r}")


if __name__ == '__main__':
    main()
