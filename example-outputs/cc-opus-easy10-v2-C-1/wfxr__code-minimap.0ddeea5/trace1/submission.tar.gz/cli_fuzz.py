#!/usr/bin/env python3
"""CLI argument fuzzing."""
import subprocess

REF = "/workspace/executable"
SUT = "/work/work/executable"


def run(binary, args, stdin_bytes=b""):
    result = subprocess.run(
        [binary] + list(args),
        input=stdin_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.stdout, result.stderr, result.returncode


PASS = 0
FAIL = 0
FAILS = []


def diff(name, args, stdin_bytes=b""):
    global PASS, FAIL
    r_out, r_err, r_rc = run(REF, args, stdin_bytes)
    s_out, s_err, s_rc = run(SUT, args, stdin_bytes)
    if r_out == s_out and r_err == s_err and r_rc == s_rc:
        PASS += 1
        return True
    else:
        FAIL += 1
        FAILS.append((name, args, stdin_bytes, r_out, r_err, r_rc, s_out, s_err, s_rc))
        return False


def main():
    # Various CLI patterns
    tests = [
        # Help variants
        ("help-1", ["--help"]),
        ("help-2", ["-h"]),
        ("help-cmd", ["help"]),
        ("help-help", ["help", "help"]),
        ("help-completion", ["help", "completion"]),

        # Version
        ("version", ["--version"]),

        # Flag combinations
        ("h-only", ["-H", "1.0"]),
        ("v-only", ["-V", "1.0"]),
        ("h-v", ["-H", "1.0", "-V", "1.0"]),
        ("h-v-p", ["-H", "1.0", "-V", "1.0", "--padding", "5"]),
        ("h-eq", ["-H=1.0"]),
        ("h-long-eq", ["--horizontal-scale=1.0"]),

        # Errors
        ("unknown-long", ["--bogus"]),
        ("unknown-short", ["-Z"]),
        ("missing-h", ["-H"]),
        ("missing-v", ["-V"]),
        ("missing-pad", ["--padding"]),
        ("missing-enc", ["--encoding"]),
        ("h-empty", ["-H", ""]),
        ("v-empty", ["-V", ""]),
        ("pad-empty", ["--padding", ""]),
        ("enc-empty", ["--encoding", ""]),
        ("bad-h", ["-H", "abc"]),
        ("bad-v", ["-V", "abc"]),
        ("bad-pad", ["--padding", "abc"]),
        ("bad-enc", ["--encoding", "abc"]),
        ("dup-h", ["-H", "1", "-H", "2"]),
        ("dup-h-long", ["--horizontal-scale", "1", "--horizontal-scale", "2"]),
        ("dup-v", ["-V", "1", "-V", "2"]),
        ("dup-pad", ["--padding", "1", "--padding", "2"]),

        # Edge cases
        ("dash-file", ["-"]),
        ("dashdash-empty", ["--"]),
        ("file-arg", ["/dev/null"]),
        ("missing-file", ["nonexistent_file.xyz"]),
        ("two-files", ["a.txt", "b.txt"]),
        ("flag-after-dd", ["--", "-H", "1.0"]),

        # Completion
        ("comp-bash", ["completion", "bash"]),
        ("comp-fish", ["completion", "fish"]),
        ("comp-zsh", ["completion", "zsh"]),
        ("comp-elvish", ["completion", "elvish"]),
        ("comp-powershell", ["completion", "powershell"]),
        ("comp-no-shell", ["completion"]),
        ("comp-bad", ["completion", "csh"]),
        ("comp-empty", ["completion", ""]),
        ("comp-help", ["completion", "--help"]),
        ("comp-h", ["completion", "-h"]),
        ("comp-help-bash", ["completion", "bash", "--help"]),

        # Float edge cases
        ("dot-5", ["-H", ".5"]),
        ("5-dot", ["-H", "5."]),
        ("1e0", ["-H", "1e0"]),
        ("1e-0", ["-H", "1e-0"]),
        ("1e10", ["-H", "1e10"]),
        ("1E5", ["-H", "1E5"]),
        ("plus-1", ["-H", "+1"]),
        ("two-dots", ["-H", "1.0.0"]),
        ("space-num", ["-H", "1 "]),

        # Subcommand position
        ("cmd-then-flag", ["help", "-h"]),
        ("flag-then-cmd", ["-H", "1.0", "completion", "bash"]),
        ("help-after-flag", ["-H", "1.0", "help"]),

        # Partial matching
        ("partial-flag", ["--horiz"]),
        ("partial-flag-2", ["--padd"]),
        ("partial-flag-3", ["--encod"]),
        ("partial-flag-help", ["--hel"]),

        # Mixed
        ("h-with-stdin", ["-H", "2.0"]),
        ("multi-args", ["--padding", "5", "-V", "0.5", "-H", "2.0"]),
    ]

    for name, args in tests:
        # Use stdin for some, file for others
        stdin = b"abc\n" if "stdin" in name or "h-" in name or "v-" in name or "pad" in name else b""
        diff(name, args, stdin)

    print(f"\nTotal: {PASS+FAIL}  Pass: {PASS}  Fail: {FAIL}")
    if FAIL > 0:
        print("\nFailures:")
        for fail in FAILS[:20]:
            name, args, inp, r_out, r_err, r_rc, s_out, s_err, s_rc = fail
            print(f"  {name}: args={args}")
            print(f"    ref_rc={r_rc} sut_rc={s_rc}")
            if r_out != s_out:
                print(f"    ref_out: {r_out[:100]!r}")
                print(f"    sut_out: {s_out[:100]!r}")
            if r_err != s_err:
                print(f"    ref_err: {r_err[:250]!r}")
                print(f"    sut_err: {s_err[:250]!r}")


if __name__ == '__main__':
    main()
