# sd v1.0.0 behavior map

Reference: `sd` v1.0.0 (search & displace), Rust binary using clap_builder 4.4.6, regex 1.10.2, regex-bytes (likely).

## CLI surface

```
Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Options:
  -p, --preview
  -F, --fixed-strings
  -n, --max-replacements <LIMIT>   [default: 0 = unlimited]
  -f, --flags <FLAGS>              combinable: c|e|i|m|s|w
  -h, --help
  -V, --version
```

- Program name in errors uses argv[0] basename (clap default)
- `-V` and `--version` print: `sd 1.0.0\n`
- `-h` prints short help, `--help` long help. First flag wins when both used.
- Unknown flags → exit 2 with clap-style "unexpected argument 'X' found\n\n  tip: ..."
- Missing required → exit 2; Usage line includes the OPTIONS the user passed (e.g. `Usage: executable --preview <FIND>...`)
- `-n` cannot repeat; clap auto-detects this. Same for `-f`.
- `-n` value: parses as usize; empty=err "cannot parse integer from empty string"; non-digit "invalid digit found in string"; too large "number too large to fit in target type".

## Behavior

### Modes

- 0 files + tty stdin: read entire stdin, replace, write to stdout
- 0 files + pipe stdin: same
- 1+ files (no -p): in-place edit each file
- 1+ files (-p): print modified content to stdout. Single file: just content. Multiple files: `----- FILE <name> -----\n<content>` per file.

### Regex semantics

- `regex::bytes::Regex` (byte-level — preserves invalid UTF-8 and NUL bytes)
- Default flags: `multi_line=true`, `case_sensitive` (no `unicode` opt-out)
- `-f` letter map (each iteration updates a builder; subsequent calls override):
  - `c` → case_insensitive(false)
  - `i` → case_insensitive(true)
  - `m` → multi_line(true) — no-op (default)
  - `e` → multi_line(false)
  - `s` → dot_matches_new_line(true)
  - `w` → wrap pattern with word boundary: `\b(?:pattern)\b`
- Last among `c`/`i` wins. `e` always disables multi-line regardless of `m` ordering since `m` is the default.
- `-F` (fixed-strings): escapes pattern via `regex::escape`, applies word boundary wrap if `-f w`. Replacement text is treated literal: NO escape processing of `$1`, `\n`, etc.

### Replacement string (regex mode)

- `$1`, `${1}` indexed captures
- `$name`, `${name}` named captures (regex crate's interpolation)
- `$$` → literal `$`
- Backslash escapes: `\n` → LF, `\r` → CR, `\t` → tab, `\\` → `\`. Others left literal.
- Unknown captures replaced with empty string

### Errors

- invalid regex: `error: invalid regex regex parse error:\n    <pat>\n    ^\nerror: <msg>\n` exit 1
- invalid path (nonexistent): `error: invalid path: <path>\n` exit 1
- mmap fail (e.g. `/dev/null`): `error: No such device (os error 19)\n` exit 1

### Preview format

Single file with `-p`: just the modified content.
Multiple files with `-p`: 
```
----- FILE <path1> -----
<content1>----- FILE <path2> -----
<content2>
```

Each `----- FILE <path> -----` followed by a newline, then content of file (with its own trailing structure).

### Examples

- `echo "abc abc" | sd a x` → `xbc xbc\n`
- `sd -n 1 a x` → first match only
- Empty FIND, regex mode: matches between every char and at boundaries
- Trailing newlines: preserved (whatever stdin has)
- Binary/invalid UTF-8: passes through

## Implementation choice: Rust 1.92 + vendored crates from `/usr/local/cargo/registry/cache/`
