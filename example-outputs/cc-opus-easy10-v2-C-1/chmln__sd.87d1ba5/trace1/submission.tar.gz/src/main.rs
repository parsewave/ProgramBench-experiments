use clap::Parser;
use memmap2::Mmap;
use regex::bytes::{Regex, RegexBuilder};
use std::fs;
use std::io::{self, Read, Write};
use std::path::PathBuf;
use std::process::ExitCode;

#[derive(Parser, Debug)]
#[command(
    name = "sd",
    version = "1.0.0",
    author,
    about = "An intuitive find & replace CLI",
    help_template = "{before-help}{name} v{version}\n{about}\n\n{usage-heading} {usage}\n\n{all-args}{after-help}"
)]
struct Cli {
    /// Display changes in a human reviewable format (the specifics of the format are likely to change in the future)
    #[arg(short = 'p', long = "preview")]
    preview: bool,

    /// Treat FIND and REPLACE_WITH args as literal strings
    #[arg(short = 'F', long = "fixed-strings", alias = "string-mode")]
    literal_mode: bool,

    /// Limit the number of replacements that can occur per file. 0 indicates unlimited replacements
    #[arg(short = 'n', long = "max-replacements", value_name = "LIMIT", default_value_t = 0)]
    replacements: usize,

    #[arg(
        short = 'f',
        long = "flags",
        value_name = "FLAGS",
        help = "Regex flags. May be combined (like `-f mc`).",
        long_help = "Regex flags. May be combined (like `-f mc`).\n\nc - case-sensitive\n\ne - disable multi-line matching\n\ni - case-insensitive\n\nm - multi-line matching\n\ns - make `.` match newlines\n\nw - match full words only"
    )]
    flags: Option<String>,

    /// The regexp or string (if using `-F`) to search for
    find: String,

    /// What to replace each match with. Unless in string mode, you may use captured values like $1, $2, etc
    replace_with: String,

    /// The path to file(s). This is optional - sd can also read from STDIN.
    ///
    /// Note: sd modifies files in-place by default. See documentation for examples.
    files: Vec<PathBuf>,
}

#[derive(Debug)]
enum Error {
    InvalidRegex(regex::Error),
    InvalidPath(String),
    Io(io::Error),
}

impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Error::InvalidRegex(e) => write!(f, "invalid regex {}", e),
            Error::InvalidPath(p) => write!(f, "invalid path: {}", p),
            Error::Io(e) => write!(f, "{}", e),
        }
    }
}

impl From<io::Error> for Error {
    fn from(e: io::Error) -> Self {
        Error::Io(e)
    }
}

fn build_regex(cli: &Cli) -> Result<Regex, Error> {
    let mut pattern = if cli.literal_mode {
        regex::escape(&cli.find)
    } else {
        cli.find.clone()
    };

    // Defaults: multi_line = true, case_sensitive
    let mut case_insensitive = false;
    let mut multi_line = true;
    let mut dot_matches_new_line = false;

    if let Some(flags) = &cli.flags {
        for c in flags.chars() {
            match c {
                'c' => case_insensitive = false,
                'i' => case_insensitive = true,
                'm' => {} // no-op: multi-line is the default
                'e' => multi_line = false,
                's' => dot_matches_new_line = true,
                'w' => {
                    // Wrap pattern with word boundaries (no grouping — alternation binds higher
                    // than \b in regex precedence) and reset accumulated flag state
                    pattern = format!(r"\b{}\b", pattern);
                    case_insensitive = false;
                    multi_line = true;
                    dot_matches_new_line = false;
                }
                _ => {} // unrecognized flags silently ignored
            }
        }
    }

    RegexBuilder::new(&pattern)
        .case_insensitive(case_insensitive)
        .multi_line(multi_line)
        .dot_matches_new_line(dot_matches_new_line)
        .build()
        .map_err(Error::InvalidRegex)
}

/// Process backslash escapes in replacement string (regex mode only)
/// Supported: \n, \r, \t, \\. Others kept literal.
fn process_replacement_escapes(s: &str) -> Vec<u8> {
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'\\' && i + 1 < bytes.len() {
            match bytes[i + 1] {
                b'n' => {
                    out.push(b'\n');
                    i += 2;
                    continue;
                }
                b'r' => {
                    out.push(b'\r');
                    i += 2;
                    continue;
                }
                b't' => {
                    out.push(b'\t');
                    i += 2;
                    continue;
                }
                b'\\' => {
                    out.push(b'\\');
                    i += 2;
                    continue;
                }
                _ => {
                    out.push(bytes[i]);
                    i += 1;
                    continue;
                }
            }
        }
        out.push(bytes[i]);
        i += 1;
    }
    out
}

fn replace_bytes(regex: &Regex, input: &[u8], replacement: &[u8], literal_mode: bool, limit: usize) -> Vec<u8> {
    // In literal mode, replacement is just literal bytes (no $1 expansion).
    // In regex mode, regex crate's replace_all handles $1, $name, $$.
    // We also need to support \n, \r, \t, \\ in replacement for regex mode.
    if literal_mode {
        // Use NoExpand to avoid $ interpolation
        if limit == 0 {
            regex
                .replace_all(input, regex::bytes::NoExpand(replacement))
                .into_owned()
        } else {
            regex
                .replacen(input, limit, regex::bytes::NoExpand(replacement))
                .into_owned()
        }
    } else {
        if limit == 0 {
            regex.replace_all(input, replacement).into_owned()
        } else {
            regex.replacen(input, limit, replacement).into_owned()
        }
    }
}

fn run() -> Result<(), Error> {
    let cli = Cli::parse();

    let regex = build_regex(&cli)?;

    // Compute replacement bytes
    let replacement_bytes = if cli.literal_mode {
        cli.replace_with.as_bytes().to_vec()
    } else {
        process_replacement_escapes(&cli.replace_with)
    };

    if cli.files.is_empty() {
        // stdin → stdout
        let mut input = Vec::new();
        io::stdin().read_to_end(&mut input)?;
        let output = replace_bytes(&regex, &input, &replacement_bytes, cli.literal_mode, cli.replacements);
        io::stdout().write_all(&output)?;
        return Ok(());
    }

    // Validate all paths exist before doing anything
    for path in &cli.files {
        if !path.exists() {
            return Err(Error::InvalidPath(path.display().to_string()));
        }
    }

    let multi = cli.files.len() > 1;
    let mut stdout = io::stdout().lock();

    for path in &cli.files {
        // Read file via mmap (matches "No such device" behavior on /dev/null etc.)
        let input = read_file_mmap(path)?;
        let output = replace_bytes(&regex, &input, &replacement_bytes, cli.literal_mode, cli.replacements);

        if cli.preview {
            if multi {
                stdout.write_all(b"----- FILE ")?;
                stdout.write_all(path.display().to_string().as_bytes())?;
                stdout.write_all(b" -----\n")?;
            }
            stdout.write_all(&output)?;
        } else {
            // In-place edit using atomic rename via tempfile in same directory
            write_atomic(path, &output)?;
        }
    }

    Ok(())
}

fn read_file_mmap(path: &PathBuf) -> Result<Vec<u8>, Error> {
    let file = fs::File::open(path)?;
    let mmap = unsafe { Mmap::map(&file)? };
    Ok(mmap.to_vec())
}

fn write_atomic(path: &PathBuf, content: &[u8]) -> Result<(), Error> {
    let parent = path.parent().unwrap_or_else(|| std::path::Path::new("."));
    let mut tempfile = tempfile::NamedTempFile::new_in(parent)?;
    tempfile.write_all(content)?;
    tempfile.persist(path).map_err(|e| Error::Io(e.error))?;
    Ok(())
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::from(0),
        Err(e) => {
            eprintln!("error: {}", e);
            ExitCode::from(1)
        }
    }
}
