#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

export PATH=/usr/local/cargo/bin:$PATH
export CARGO_NET_OFFLINE=true

cargo build --release --offline

cp target/release/executable ./executable
chmod +x ./executable
