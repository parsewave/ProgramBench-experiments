#!/bin/bash
set -e
cd "$(dirname "$0")"
cp -f b3sum_prebuilt executable
chmod +x executable
