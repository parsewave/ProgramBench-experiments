# cmatrix behavior map

## Binary identification

- Source: cmatrix (abishekvashok/cmatrix)
- Version reported: `2.0`
- Compile-time string in `-V` output: `19:59:42, Apr 17 2026`
- Linked against: libncursesw.so.6, libtinfo.so.6, libc.so.6
- getopt string: `abBcfhlLnrosmxkVM:u:C:t:`

## Argument parsing

Uses POSIX `getopt` with the option string above. Behavior:
- All getopt parsing happens up-front. `-V`, `-h`, `-?`, and any unknown option immediately exit during the parse loop.
- Order matters: whichever exit-causing option is hit first wins.

## Deterministic outputs (must match exactly)

### `-V` (and on first occurrence) — exit 0
stdout (131 bytes, leading space, trailing newlines):
```
 CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
```

### `-h` / `-?` / unknown short option / missing arg for `M:`/`u:`/`C:`/`t:` — exit 0
stdout (972 bytes, every line begins with a space):
```
 Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
```

### `-C <invalid>` (color not in list, case-insensitive) — exit 0
After processing all options up to the `-C`, prints to **stderr** (101 bytes):
```
 Invalid color selection
 Valid colors are green, red, blue, white, yellow, cyan, magenta and black.
```
- Empty string is invalid.
- Case-insensitive on valid colors: green, red, blue, white, yellow, cyan, magenta, black.

### `-t <path>` where fopen fails — exit 1
Stderr (printf format): `cmatrix: error: '%s' couldn't be opened: %s.\n` where `%s` are the path and `strerror(errno)`.

Example (`-t /nonexistent`):
```
cmatrix: error: '/nonexistent' couldn't be opened: No such file or directory.
```
The tty fopen happens AFTER the full getopt loop; if `-V`/`-h`/`-?` was also given, that wins.

### TERM-related ncurses init failure — exit 1
When `newterm()` fails (TERM unset, empty, or unknown), ncurses prints to **stderr**:
```
Error opening terminal: <TERMNAME>.
```
Where `<TERMNAME>` is the TERM value, or literal `unknown` if TERM is empty or unset.

### `-l` (Linux console mode without console tools) — exit 0
Initializes ncurses, then prints to stderr (59 bytes):
```
 Unable to use both "setfont" and "consolechars".
```
Then performs `endwin()` and exits 0.
- On a regular xterm, this happens regardless of console availability.
- With `-V` or `-h` ahead of `-l`, the exit-on-loop happens first.

### `-f` flag
Sets `TERM=linux` in the environment before ncurses init. With `-fl` combined, fewer escape codes are produced (linux term).

## Animation modes (runs until quit/signal)

When given valid options and TERM, the program enters the matrix animation loop.

- Process model: runs until 'q' is pressed (default), any key (in `-s` mode), or a signal (SIGINT, SIGQUIT exit 0; SIGTERM kills).
- `-L` (lock): ignores all keystrokes; only signals exit. `-s` takes precedence over `-L`.
- `-s` (screensaver): any keystroke exits.
- Output: continuous ANSI escape sequences. Each "frame" is the full screen.
- Exit on 'q' or any (-s) key: cleanly via `endwin()` producing ncurses reset bytes (~125 bytes of cleanup).

## Other observations

- The output is byte-deterministic for the first ~17KB across runs (suggests no `srand(time(NULL))` call, or fixed seed).
- `-u`: takes int; out-of-range or non-numeric becomes 0 (fastest).
- Options not affecting argument parsing fall through: -a, -b, -B, -c, -n, -o, -r, -m, -k, -x set internal flags.
- Help text is printed via `puts()` calls (each line followed by newline).
- Version is printed via `__printf_chk` with format using `__TIME__` and `__DATE__` macros.

## Goldens captured in /work/work/goldens/

- `V.{stdout,stderr,exit}`: version output
- `h.{stdout,stderr,exit}`: -h help
- `question.{stdout,stderr,exit}`: -? help (same as -h)
- `Z.{stdout,stderr,exit}`: -Z unknown (same help)
- `M_no_arg.{stdout,stderr,exit}`: -M missing arg (same help)
- `Cxxx.{stdout,stderr,exit}`: -C xxx invalid color
- `tbad.{stdout,stderr,exit}`: -t /nonexistent tty error
- `no_term.{stdout,stderr,exit}`: TERM unset, no args, terminal error
