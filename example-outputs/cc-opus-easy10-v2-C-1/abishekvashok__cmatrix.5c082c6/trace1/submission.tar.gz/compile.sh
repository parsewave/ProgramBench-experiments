#!/bin/sh
set -e
cd "$(dirname "$0")"
gcc -O2 -Wall -Wno-unused -Wno-unused-result \
    -o executable cmatrix.c \
    -lncursesw -ltinfo
