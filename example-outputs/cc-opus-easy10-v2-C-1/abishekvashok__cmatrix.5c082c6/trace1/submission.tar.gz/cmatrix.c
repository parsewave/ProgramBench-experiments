/*
 * cmatrix clean-room reimplementation
 * Matches behavior of abishekvashok/cmatrix v2.0
 */

#define _GNU_SOURCE
#include <ncurses.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <locale.h>
#include <errno.h>
#include <wchar.h>
#include <wctype.h>

static SCREEN *current_screen = NULL;
static FILE *tty_file = NULL;
static int g_lock = 0;
static int g_screensaver = 0;

static const char USAGE_TEXT[] =
    " Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n"
    " -a: Asynchronous scroll\n"
    " -b: Bold characters on\n"
    " -B: All bold characters (overrides -b)\n"
    " -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n"
    " -f: Force the linux $TERM type to be on\n"
    " -l: Linux mode (uses matrix console font)\n"
    " -L: Lock mode (can be closed from another terminal)\n"
    " -o: Use old-style scrolling\n"
    " -h: Print usage and exit\n"
    " -n: No bold characters (overrides -b and -B, default)\n"
    " -s: \"Screensaver\" mode, exits on first keystroke\n"
    " -x: X window mode, use if your xterm is using mtx.pcf\n"
    " -V: Print version information and exit\n"
    " -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n"
    " -u delay (0 - 10, default 4): Screen update delay\n"
    " -C [color]: Use this color for matrix (default green)\n"
    " -r: rainbow mode\n"
    " -m: lambda mode\n"
    " -k: Characters change while scrolling. (Works without -o opt.)\n"
    " -t [tty]: Set tty to use\n";

static void usage(void) {
    /* Use fwrite to write exact bytes, no trailing manipulation */
    fwrite(USAGE_TEXT, 1, sizeof(USAGE_TEXT) - 1, stdout);
    fflush(stdout);
}

static void version(void) {
    fputs(" CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)\n", stdout);
    fputs("Email: abishekvashok@gmail.com\n", stdout);
    fputs("Web: https://github.com/abishekvashok/cmatrix\n", stdout);
    fflush(stdout);
}

static void finish(void) {
    curs_set(1);
    wclear(stdscr);
    wrefresh(stdscr);
    endwin();
    if (current_screen) {
        delscreen(current_screen);
        current_screen = NULL;
    }
    if (tty_file) {
        fclose(tty_file);
        tty_file = NULL;
    }
    exit(0);
}

static void sighandler(int s) {
    (void)s;
    finish();
}

/* Per-column state for the matrix animation */
typedef struct {
    int length;     /* current visible length */
    int spaces;     /* spaces above the head */
    int update;     /* update counter modulo */
    short color;    /* color index 1..7 */
} column_t;

/* simple inline random helpers using rand() */
static int rnd_range(int lo, int hi) {
    if (hi <= lo) return lo;
    return lo + (rand() % (hi - lo + 1));
}

/* Choose a printable matrix character */
static int matrix_char(int lambda, int japanese, int kchange) {
    (void)kchange;
    if (lambda) return 'l';
    if (japanese) return '?';
    /* Range similar to original cmatrix: printable ascii 33..126 + some */
    int r = rand() % 95;
    return 33 + r;
}

int main(int argc, char *argv[]) {
    int opt;
    int async = 0, bold = 0, oldstyle = 0, rainbow = 0;
    int lambda = 0, japanese = 0, kchange = 0;
    int xwindow = 0, force = 0, console = 0;
    int color = COLOR_GREEN;
    int update = 4;
    const char *msg = NULL;
    const char *tty_path = NULL;

    setlocale(LC_ALL, "");

    opterr = 0; /* suppress getopt's automatic error messages */

    while ((opt = getopt(argc, argv, "abBcfhlLnrosmxkVM:u:C:t:")) != -1) {
        switch (opt) {
            case 'a': async = 1; break;
            case 'b': bold = 1; break;
            case 'B': bold = 2; break;
            case 'c': japanese = 1; break;
            case 'f': force = 1; break;
            case 'l': console = 1; break;
            case 'L': g_lock = 1; break;
            case 'n': bold = 0; break;
            case 'r': rainbow = 1; break;
            case 'o': oldstyle = 1; break;
            case 's': g_screensaver = 1; break;
            case 'm': lambda = 1; break;
            case 'x': xwindow = 1; break;
            case 'k': kchange = 1; break;
            case 'M': msg = optarg; break;
            case 'u': update = (int)strtol(optarg, NULL, 10); break;
            case 'h':
            case '?':
                usage();
                exit(0);
            case 'V':
                version();
                exit(0);
            case 'C':
                if (!optarg) {
                    fprintf(stderr, " Invalid color selection\n Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n");
                    exit(0);
                } else if (strcasecmp(optarg, "green") == 0) {
                    color = COLOR_GREEN;
                } else if (strcasecmp(optarg, "red") == 0) {
                    color = COLOR_RED;
                } else if (strcasecmp(optarg, "blue") == 0) {
                    color = COLOR_BLUE;
                } else if (strcasecmp(optarg, "white") == 0) {
                    color = COLOR_WHITE;
                } else if (strcasecmp(optarg, "yellow") == 0) {
                    color = COLOR_YELLOW;
                } else if (strcasecmp(optarg, "cyan") == 0) {
                    color = COLOR_CYAN;
                } else if (strcasecmp(optarg, "magenta") == 0) {
                    color = COLOR_MAGENTA;
                } else if (strcasecmp(optarg, "black") == 0) {
                    color = COLOR_BLACK;
                } else {
                    fprintf(stderr, " Invalid color selection\n Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n");
                    exit(0);
                }
                break;
            case 't':
                tty_path = optarg;
                break;
        }
    }

    if (force) {
        setenv("TERM", "linux", 1);
    }

    /* If -L (lock) is given without -M, default message is "Computer locked." */
    if (g_lock && msg == NULL) {
        msg = "Computer locked.";
    }

    /* Try to open the tty if requested */
    if (tty_path) {
        tty_file = fopen(tty_path, "r+");
        if (!tty_file) {
            fprintf(stderr, "cmatrix: error: '%s' couldn't be opened: %s.\n",
                    tty_path, strerror(errno));
            exit(1);
        }
        current_screen = newterm(NULL, tty_file, tty_file);
        if (!current_screen) {
            exit(1);
        }
        set_term(current_screen);
    } else {
        /* initscr() prints "Error opening terminal: ..." and exits on failure */
        initscr();
    }

    /* Install signal handlers AFTER terminal init */
    signal(SIGINT, sighandler);
    signal(SIGQUIT, sighandler);

    /* If console mode requested but no setfont/consolechars available */
    if (console) {
        fprintf(stderr, " Unable to use both \"setfont\" and \"consolechars\".\n");
        finish();
        return 0;
    }

    nonl();
    cbreak();
    noecho();
    curs_set(0);
    leaveok(stdscr, TRUE);
    wtimeout(stdscr, 0);

    if (has_colors()) {
        start_color();
        use_default_colors();
        init_pair(1, color, -1);
        init_pair(2, COLOR_WHITE, -1);
        init_pair(3, COLOR_YELLOW, -1);
        init_pair(4, COLOR_RED, -1);
        init_pair(5, COLOR_BLUE, -1);
        init_pair(6, COLOR_MAGENTA, -1);
        init_pair(7, COLOR_CYAN, -1);
        init_pair(8, COLOR_BLACK, -1);
    }

    /* Allocate column state */
    int cols = COLS;
    int lines = LINES;
    if (cols < 1) cols = 80;
    if (lines < 1) lines = 24;

    column_t *col_state = calloc(cols, sizeof(column_t));
    if (!col_state) {
        endwin();
        fprintf(stderr, "CMatrix: malloc: out of memory!\n");
        exit(1);
    }

    /* Initialize each column with a random starting position */
    for (int c = 0; c < cols; c++) {
        col_state[c].length = rnd_range(3, lines / 2 + 1);
        col_state[c].spaces = rnd_range(0, lines);
        col_state[c].update = rnd_range(1, 9);
        col_state[c].color = (rainbow) ? (short)(1 + (rand() % 7)) : 1;
    }

    /* Draw buffer: track what character is at each cell */
    int *cells = calloc(cols * lines, sizeof(int));
    if (!cells) {
        free(col_state);
        endwin();
        fprintf(stderr, "CMatrix: malloc: out of memory!\n");
        exit(1);
    }
    /* head position per column */
    int *heads = calloc(cols, sizeof(int));
    if (!heads) {
        free(col_state);
        free(cells);
        endwin();
        fprintf(stderr, "CMatrix: malloc: out of memory!\n");
        exit(1);
    }
    for (int c = 0; c < cols; c++) heads[c] = -1;

    /* Update sleep in ms */
    int sleep_ms = (update >= 0 && update <= 10) ? (update * 10) : 0;
    if (sleep_ms < 0) sleep_ms = 0;

    /* Animation loop */
    int tick = 0;
    while (1) {
        int ch = wgetch(stdscr);
        if (ch != ERR) {
            if (g_screensaver) {
                finish();
            } else if (!g_lock) {
                if (ch == 'q') finish();
            }
            /* else ignored */
        }

        /* Re-read terminal dimensions in case of resize */
        if (LINES != lines || COLS != cols) {
            free(col_state);
            free(cells);
            free(heads);
            cols = COLS;
            lines = LINES;
            if (cols < 1) cols = 80;
            if (lines < 1) lines = 24;
            col_state = calloc(cols, sizeof(column_t));
            cells = calloc(cols * lines, sizeof(int));
            heads = calloc(cols, sizeof(int));
            if (!col_state || !cells || !heads) {
                finish();
            }
            for (int c = 0; c < cols; c++) {
                col_state[c].length = rnd_range(3, lines / 2 + 1);
                col_state[c].spaces = rnd_range(0, lines);
                col_state[c].update = rnd_range(1, 9);
                col_state[c].color = rainbow ? (short)(1 + (rand() % 7)) : 1;
                heads[c] = -1;
            }
        }

        /* Update each column */
        for (int c = 0; c < cols; c++) {
            if (col_state[c].spaces > 0) {
                col_state[c].spaces--;
                /* Erase head cell if there is one */
                if (heads[c] >= 0 && heads[c] < lines) {
                    wmove(stdscr, heads[c], c);
                    waddch(stdscr, ' ');
                    heads[c]++;
                    if (heads[c] - col_state[c].length >= 0 && heads[c] - col_state[c].length < lines) {
                        wmove(stdscr, heads[c] - col_state[c].length, c);
                        waddch(stdscr, ' ');
                    }
                }
            } else {
                if (heads[c] < 0) heads[c] = 0;

                /* Draw white head */
                if (heads[c] >= 0 && heads[c] < lines) {
                    int ch = matrix_char(lambda, japanese, kchange);
                    wmove(stdscr, heads[c], c);
                    wattr_on(stdscr, COLOR_PAIR(2) | (bold == 2 ? A_BOLD : 0), NULL);
                    waddch(stdscr, ch);
                    wattr_off(stdscr, COLOR_PAIR(2) | (bold == 2 ? A_BOLD : 0), NULL);
                }
                /* Draw colored cell behind head */
                if (heads[c] - 1 >= 0 && heads[c] - 1 < lines) {
                    int ch = matrix_char(lambda, japanese, kchange);
                    short pair = col_state[c].color;
                    wmove(stdscr, heads[c] - 1, c);
                    int attr = (bold == 2 || (bold == 1 && (rand() & 1))) ? A_BOLD : 0;
                    wattr_on(stdscr, COLOR_PAIR(pair) | attr, NULL);
                    waddch(stdscr, ch);
                    wattr_off(stdscr, COLOR_PAIR(pair) | attr, NULL);
                }
                /* Erase tail */
                int tail = heads[c] - col_state[c].length;
                if (tail >= 0 && tail < lines) {
                    wmove(stdscr, tail, c);
                    waddch(stdscr, ' ');
                }

                heads[c]++;
                if (heads[c] - col_state[c].length >= lines) {
                    /* Column finished - restart */
                    heads[c] = -1;
                    col_state[c].length = rnd_range(3, lines / 2 + 1);
                    col_state[c].spaces = rnd_range(1, lines);
                    if (rainbow) col_state[c].color = (short)(1 + (rand() % 7));
                }
            }
        }

        /* Optionally display the message in the center */
        if (msg && *msg) {
            int mlen = (int)strlen(msg);
            int mrow = lines / 2;
            int mcol = (cols - mlen) / 2;
            if (mcol < 0) mcol = 0;
            wmove(stdscr, mrow, mcol);
            wattr_on(stdscr, COLOR_PAIR(2) | A_BOLD, NULL);
            waddnstr(stdscr, msg, cols - mcol);
            wattr_off(stdscr, COLOR_PAIR(2) | A_BOLD, NULL);
        }

        wmove(stdscr, lines - 1, cols - 1);
        wrefresh(stdscr);

        if (sleep_ms > 0) napms(sleep_ms);
        tick++;
    }

    free(col_state);
    free(cells);
    free(heads);
    finish();
    return 0;
}
