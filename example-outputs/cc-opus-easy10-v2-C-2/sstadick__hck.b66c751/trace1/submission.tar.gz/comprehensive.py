#!/usr/bin/env python3
"""Comprehensive differential testing with random sampling."""
import subprocess
import random
import sys
import os

REF = "/workspace/executable"
SUT = "/work/work/executable"

PASS = 0
FAIL = 0
FAIL_DETAILS = []

def run(binary, args, stdin):
    """Run binary with args and stdin (bytes). Returns (exit, stdout_bytes, stderr_bytes)."""
    p = subprocess.Popen([binary] + args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate(stdin)
    return p.returncode, out, err

def normalize_err(err):
    """Strip timestamps from error output."""
    import re
    return re.sub(rb'\[[0-9TZ:.-]+ ERROR hck\]', b'[TS ERROR hck]', err)

def diff_test(desc, args, stdin):
    global PASS, FAIL
    if isinstance(stdin, str):
        stdin = stdin.encode('utf-8', errors='surrogateescape')
    ref_exit, ref_out, ref_err = run(REF, args, stdin)
    sut_exit, sut_out, sut_err = run(SUT, args, stdin)
    if ref_out == sut_out and ref_exit == sut_exit and normalize_err(ref_err) == normalize_err(sut_err):
        PASS += 1
    else:
        FAIL += 1
        if len(FAIL_DETAILS) < 25:
            FAIL_DETAILS.append(f"=== FAIL: {desc}")
            FAIL_DETAILS.append(f"    args: {args}")
            FAIL_DETAILS.append(f"    input: {stdin[:80]!r}")
            FAIL_DETAILS.append(f"    REF exit={ref_exit} stdout={ref_out[:200]!r} stderr={ref_err[:200]!r}")
            FAIL_DETAILS.append(f"    SUT exit={sut_exit} stdout={sut_out[:200]!r} stderr={sut_err[:200]!r}")

# Test cases
TESTS = []

# Basic field selection
TESTS.append((['-f1'], 'a b c\n'))
TESTS.append((['-f2'], 'a b c\n'))
TESTS.append((['-f1,3'], 'a b c\n'))
TESTS.append((['-f1-3'], 'a b c\n'))
TESTS.append((['-f-2'], 'a b c\n'))
TESTS.append((['-f2-'], 'a b c\n'))
TESTS.append((['-f1-'], 'a b c\n'))
TESTS.append((['-f-'], 'a b c\n'))
TESTS.append((['-f5,3,1'], 'a b c d e\n'))
TESTS.append((['-f3,1,5,2'], 'a b c d e\n'))

# Delimiters
TESTS.append((['-d', ','], 'a,b,c\n'))
TESTS.append((['-d', ',', '-f2'], 'a,b,c\n'))
TESTS.append((['-L', '-d', ','], 'a,b,c\n'))
TESTS.append((['-L', '-d', ',', '-f2'], 'a,b,c\n'))
TESTS.append((['-d', '\\t'], 'a\tb\tc\n'))
TESTS.append((['-L', '-d', '\\t'], 'a\tb\tc\n'))
TESTS.append((['-D', '|'], 'a b c\n'))
TESTS.append((['-D', '\\t'], 'a b c\n'))
TESTS.append((['-D', '\\n'], 'a b c\n'))

# Exclusion
TESTS.append((['-e1'], 'a b c d e\n'))
TESTS.append((['-e2,4'], 'a b c d e\n'))
TESTS.append((['-e1-3'], 'a b c d e\n'))
TESTS.append((['-f1-5', '-e2'], 'a b c d e\n'))

# Headers
TESTS.append((['-F', 'name'], 'name age\nalice 25\n'))
TESTS.append((['-F', 'age', '-F', 'name'], 'name age\nalice 25\n'))
TESTS.append((['-r', '-F', '.*'], 'name age\nalice 25\n'))
TESTS.append((['-r', '-F', '^a'], 'name age\nalice 25\n'))
TESTS.append((['-E', 'name'], 'name age height\nalice 25 170\n'))
TESTS.append((['-F', 'a', '-F', 'b', '-F', 'c'], 'a b c\n'))
TESTS.append((['-F', 'c', '-F', 'a'], 'a b c\n'))

# CRLF
TESTS.append((['--crlf'], 'a b c\r\n'))
TESTS.append((['--crlf'], 'a b c\n'))
TESTS.append((['--crlf'], 'a\r\nb\r\n'))

# Edge cases
TESTS.append(([], ''))
TESTS.append(([], 'abc\n'))
TESTS.append(([], '\n'))
TESTS.append(([], '\n\n\n'))
TESTS.append((['-f5'], 'a b\n'))
TESTS.append((['-f3,5'], 'a b c\n'))

# Versions/help
TESTS.append((['-V'], ''))
TESTS.append((['-h'], ''))
TESTS.append((['--help'], ''))
TESTS.append((['--version'], ''))

# Errors
TESTS.append((['-f0'], ''))
TESTS.append((['-f5-3'], ''))
TESTS.append((['-d', '['], 'a b\n'))
TESTS.append((['-d', '(', '-f1'], 'a b\n'))
TESTS.append((['--bogus'], ''))
TESTS.append((['-X'], ''))
TESTS.append((['-d', ',', '-d', ','], 'a b\n'))

# Special inputs
TESTS.append((['-L', '-d', ','], 'abc'))  # no trailing newline
TESTS.append((['-L', '-d', ','], ',a,b\n'))  # leading delim - panic case

# Combined
TESTS.append((['-F', 'a', '-f3'], 'a b c\n1 2 3\n'))
TESTS.append((['-F', 'a', '-F', 'b', '-f3'], 'a b c\n1 2 3\n'))

# Unicode
TESTS.append(([], 'café résumé\n'))

# Output to file (just ensure exit codes match)
# (skip for now)

# Run all tests
for i, (args, stdin) in enumerate(TESTS):
    diff_test(f"test_{i}", args, stdin)

# Random fuzzing
random.seed(42)
for _ in range(200):
    # Random input
    if random.random() < 0.1:
        stdin = ''
    elif random.random() < 0.2:
        stdin = '\n' * random.randint(1, 5)
    else:
        n_lines = random.randint(1, 5)
        lines = []
        for _ in range(n_lines):
            n_fields = random.randint(1, 8)
            fields = [str(random.randint(1, 100)) for _ in range(n_fields)]
            sep = random.choice([' ', ',', ';', '\t'])
            lines.append(sep.join(fields))
        stdin = '\n'.join(lines) + ('\n' if random.random() > 0.5 else '')

    # Random args
    args = []
    if random.random() < 0.3:
        args.extend(['-d', random.choice([',', ';', ':', '\\t', ' ', '\\s+'])])
    if random.random() < 0.3:
        args.append('-L')
    if random.random() < 0.3:
        args.extend(['-D', random.choice(['|', '+', '\\t', ' '])])
    if random.random() < 0.5:
        f_arg = ','.join(random.choice(['1', '2', '3', '1-2', '2-', '-3', '1,3', '3,1']) for _ in range(random.randint(1, 2)))
        args.extend(['-f', f_arg])
    if random.random() < 0.2:
        args.append('--crlf')
    if random.random() < 0.1:
        args.extend(['-F', random.choice(['1', '2', '3', 'a', 'name'])])

    diff_test(f"fuzz_{_}", args, stdin)

print(f"\n===== Results: {PASS} passed, {FAIL} failed =====")
for d in FAIL_DETAILS:
    print(d)
