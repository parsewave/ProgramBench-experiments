#!/bin/bash
# Differential testing: run a probe against both reference and SUT, compare outputs.
# Usage: diff_test.sh "<args>" "<stdin_hex_or_text>"
# Or just run the embedded test cases.

REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAIL_DETAILS=()

run_test() {
    local desc="$1"
    shift
    local input="$1"
    shift
    local args=("$@")

    local ref_out ref_err ref_exit
    local sut_out sut_err sut_exit

    # Use process substitution + diff
    ref_out=$(printf '%s' "$input" | "$REF" "${args[@]}" 2>/tmp/ref_err)
    ref_exit=$?
    ref_err=$(cat /tmp/ref_err)
    sut_out=$(printf '%s' "$input" | "$SUT" "${args[@]}" 2>/tmp/sut_err)
    sut_exit=$?
    sut_err=$(cat /tmp/sut_err)

    if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        FAIL_DETAILS+=("=== FAIL: $desc")
        FAIL_DETAILS+=("    args: ${args[*]}")
        FAIL_DETAILS+=("    input (hex): $(printf '%s' "$input" | od -An -tx1 | head -2 | tr -s ' ')")
        FAIL_DETAILS+=("    REF exit=$ref_exit stdout=$(printf '%s' "$ref_out" | od -An -c | head -3 | tr -s ' ')")
        FAIL_DETAILS+=("    SUT exit=$sut_exit stdout=$(printf '%s' "$sut_out" | od -An -c | head -3 | tr -s ' ')")
    fi
}

# Tests
run_test "basic 1"   $'a b c\n1 2 3\n'
run_test "basic 2"   $'a b c\n1 2 3\n'   -f1,3
run_test "basic 3"   $'a b c\n1 2 3\n'   -f1-2
run_test "basic 4"   $'a b c\n1 2 3\n'   -f-2
run_test "basic 5"   $'a b c\n1 2 3\n'   -f2-
run_test "basic 6"   $'a b c\n1 2 3\n'   -f3,1
run_test "basic 7"   $'a b c\n1 2 3\n'   -e2
run_test "reorder 1" $'a b c d e\n1 2 3 4 5\n'   -f5,4,3,2,1
run_test "complex"   $'a b c d e f g h\n'   -f4-,1,5-8
run_test "complex2"  $'a b c d e f g h\n'   -f3-5,2-4
run_test "complex3"  $'a b c d e f g h\n'   -f1-3,5-7,2-6
run_test "csv lit"   $'a,b,c\n1,2,3\n'   -L -d, -f1,3
run_test "csv regex" $'a,b,c\n1,2,3\n'   -d, -f1,3
run_test "outputD"   $'a,b,c\n1,2,3\n'   -L -d, -D'|' -f1,3
run_test "outputI"   $'a,b,c\n1,2,3\n'   -L -d, -I -f1,3
run_test "tabin"     $'a\tb\tc\n'   -d'\t' -f1
run_test "tabout"    $'a b c\n'   -D'\t' -f1,3
run_test "header"    $'name age height\nalice 25 170\n'   -F name
run_test "header2"   $'name age height\nalice 25 170\n'   -F name -F height
run_test "header3"   $'name age height\nalice 25 170\n'   -r -F '^a.*'
run_test "exclH"     $'name age height\nalice 25 170\n'   -E age
run_test "version"   ""   -V
run_test "version2"  ""   --version
run_test "empty"     ""
run_test "newlines"  $'\n\n\n'
run_test "abc"       "abc"
run_test "leading"   "  leading spaces"$'\n'
run_test "trailing"  "trailing  "$'\n'
run_test "crlf1"     $'a b c\r\n'   --crlf
run_test "crlf2"     $'a b c\n'   --crlf
run_test "outRange"  $'a b\n'   -f5
run_test "outRange2" $'a b\n'   -f3,1
run_test "outRange3" $'a b c\n'   -f2,5,3
run_test "missing"   $'a b c\n1 2 3\n'   -f-
run_test "dash"      $'a b c\n'   -

echo
echo "===== Results: $PASS passed, $FAIL failed ====="
if [ "$FAIL" -gt 0 ]; then
    printf '%s\n' "${FAIL_DETAILS[@]}"
fi
