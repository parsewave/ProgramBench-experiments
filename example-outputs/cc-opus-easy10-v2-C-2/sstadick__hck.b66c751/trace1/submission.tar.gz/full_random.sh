#!/bin/bash
# Comprehensive random test with diverse inputs and arg combinations
REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAIL_DETAILS=()

run_test() {
    local desc="$1"
    shift
    local input="$1"
    shift
    local args=("$@")

    local ref_out ref_err ref_exit
    local sut_out sut_err sut_exit

    ref_out=$(printf '%s' "$input" | "$REF" "${args[@]}" 2>/tmp/ref_err)
    ref_exit=$?
    ref_err=$(cat /tmp/ref_err)
    sut_out=$(printf '%s' "$input" | "$SUT" "${args[@]}" 2>/tmp/sut_err)
    sut_exit=$?
    sut_err=$(cat /tmp/sut_err)

    # Strip timestamps from stderr for comparison
    ref_err_norm=$(echo "$ref_err" | sed -E 's/\[[0-9TZ:.\-]+ ERROR hck\]/[TS ERROR hck]/g')
    sut_err_norm=$(echo "$sut_err" | sed -E 's/\[[0-9TZ:.\-]+ ERROR hck\]/[TS ERROR hck]/g')

    if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ] && [ "$ref_err_norm" = "$sut_err_norm" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        if [ ${#FAIL_DETAILS[@]} -lt 30 ]; then
            FAIL_DETAILS+=("=== FAIL: $desc")
            FAIL_DETAILS+=("    args: ${args[*]}")
            FAIL_DETAILS+=("    input: $(printf '%s' "$input" | head -c 100 | od -An -c | head -3 | tr -s ' ')")
            FAIL_DETAILS+=("    REF stdout: $(printf '%s' "$ref_out" | head -c 200 | od -An -c | head -3 | tr -s ' ')")
            FAIL_DETAILS+=("    SUT stdout: $(printf '%s' "$sut_out" | head -c 200 | od -An -c | head -3 | tr -s ' ')")
            FAIL_DETAILS+=("    REF stderr: $(echo "$ref_err_norm" | head -3)")
            FAIL_DETAILS+=("    SUT stderr: $(echo "$sut_err_norm" | head -3)")
            FAIL_DETAILS+=("    REF/SUT exit: $ref_exit / $sut_exit")
        fi
    fi
}

# Generate diverse inputs
declare -a INPUTS
INPUTS+=("")
INPUTS+=($'\n')
INPUTS+=("a"$'\n')
INPUTS+=("a b"$'\n')
INPUTS+=("a b c"$'\n')
INPUTS+=("a b c d e f g h i j"$'\n')
INPUTS+=("a b c"$'\n'"1 2 3"$'\n'"x y z"$'\n')
INPUTS+=("a,b,c"$'\n')
INPUTS+=("a,b,c"$'\n'"1,2,3"$'\n')
INPUTS+=($'a\tb\tc\n')
INPUTS+=($'a;b;c\n1;2;3\n')
INPUTS+=($'a:b:c\n')
INPUTS+=("name age height"$'\n'"alice 25 170"$'\n')
INPUTS+=("  leading"$'\n')
INPUTS+=("trailing  "$'\n')
INPUTS+=($'\n\n\n')
INPUTS+=($'a b\nc d\ne f\ng h\n')
INPUTS+=($'a b c\r\n1 2 3\r\n')
INPUTS+=($'a b c\n')
INPUTS+=($'abc')
INPUTS+=($'a b c\n,d,e\n')

# Generate diverse arg sets
declare -a ARGS_SETS
ARGS_SETS+=("")
ARGS_SETS+=("-f1")
ARGS_SETS+=("-f2")
ARGS_SETS+=("-f1,2")
ARGS_SETS+=("-f1-3")
ARGS_SETS+=("-f-2")
ARGS_SETS+=("-f2-")
ARGS_SETS+=("-f3,1")
ARGS_SETS+=("-f5,3,1")
ARGS_SETS+=("-e1")
ARGS_SETS+=("-e2")
ARGS_SETS+=("-e1-2")
ARGS_SETS+=("-f1- -e2")
ARGS_SETS+=("-d,")
ARGS_SETS+=("-d, -f2")
ARGS_SETS+=("-d; -f1,3")
ARGS_SETS+=("-L -d,")
ARGS_SETS+=("-L -d, -f2")
ARGS_SETS+=("-L -d; -f1")
ARGS_SETS+=("-Ld\;")
ARGS_SETS+=("-D|")
ARGS_SETS+=("-D '\t'")
ARGS_SETS+=("--crlf")
ARGS_SETS+=("-f1 --crlf")
ARGS_SETS+=("-F a")
ARGS_SETS+=("-F name")
ARGS_SETS+=("-F name -F height")
ARGS_SETS+=("-r -F .*")
ARGS_SETS+=("-r -F ^a")
ARGS_SETS+=("-E age")
ARGS_SETS+=("-V")
ARGS_SETS+=("-h")

i=0
for inp in "${INPUTS[@]}"; do
    for args in "${ARGS_SETS[@]}"; do
        i=$((i + 1))
        # Use eval-like splitting
        eval "set -- $args"
        run_test "rand$i" "$inp" "$@"
    done
done

echo
echo "===== Results: $PASS passed, $FAIL failed ====="
if [ "$FAIL" -gt 0 ]; then
    printf '%s\n' "${FAIL_DETAILS[@]}"
fi
