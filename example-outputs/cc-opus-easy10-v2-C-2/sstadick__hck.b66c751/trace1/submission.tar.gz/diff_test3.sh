#!/bin/bash
# Test multiple files, output files, UTF-8, etc.

REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAIL_DETAILS=()

run_test_files() {
    local desc="$1"
    shift
    # First arg is "<stdin_text_or_- >", rest are args
    local stdin="$1"
    shift
    local args=("$@")

    local ref_out sut_out ref_exit sut_exit

    if [ "$stdin" = "-" ]; then
        ref_out=$("$REF" "${args[@]}" 2>/tmp/ref_err)
        ref_exit=$?
        sut_out=$("$SUT" "${args[@]}" 2>/tmp/sut_err)
        sut_exit=$?
    else
        ref_out=$(printf '%s' "$stdin" | "$REF" "${args[@]}" 2>/tmp/ref_err)
        ref_exit=$?
        sut_out=$(printf '%s' "$stdin" | "$SUT" "${args[@]}" 2>/tmp/sut_err)
        sut_exit=$?
    fi

    if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        FAIL_DETAILS+=("=== FAIL: $desc")
        FAIL_DETAILS+=("    args: ${args[*]}")
        FAIL_DETAILS+=("    REF exit=$ref_exit stdout=$(printf '%s' "$ref_out" | head -c 200 | od -An -c | head -3 | tr -s ' ')")
        FAIL_DETAILS+=("    SUT exit=$sut_exit stdout=$(printf '%s' "$sut_out" | head -c 200 | od -An -c | head -3 | tr -s ' ')")
    fi
}

# Multi-file tests
printf 'a b\nc d\n' > /tmp/f1.txt
printf 'e f\ng h\n' > /tmp/f2.txt
printf 'name age\nalice 25\n' > /tmp/h1.txt
printf 'name age\nbob 30\n' > /tmp/h2.txt
printf 'a b c\n1 2 3\n' | gzip > /tmp/g1.txt.gz

run_test_files "twofiles" "-" /tmp/f1.txt /tmp/f2.txt
run_test_files "twofiles_F" "-" /tmp/h1.txt /tmp/h2.txt -F name
run_test_files "twofiles_F2" "-" /tmp/h1.txt /tmp/h2.txt -F age
run_test_files "stdin_dash" $'a b c\n' -
run_test_files "decompress_gz" "-" -z /tmp/g1.txt.gz
run_test_files "decompress_gz2" "-" -z /tmp/g1.txt.gz -f1

# Multiple files with header selection
printf 'a b c\n1 2 3\n' > /tmp/f3.txt
printf 'b a c\n4 5 6\n' > /tmp/f4.txt
run_test_files "diff_hdr_order" "-" -F a /tmp/f3.txt /tmp/f4.txt
run_test_files "diff_hdr_two" "-" -F a -F c /tmp/f3.txt /tmp/f4.txt

# UTF-8 and special characters
run_test_files "utf8_1" $'café naïve\nresumé\n'
run_test_files "utf8_2" $'a✓b c\n1 2 3\n' -f1
run_test_files "binary" $'\x01\x02 abc\n' -f1
run_test_files "ansi" $'\x1b[31mred\x1b[0m blue\n'

# Empty cases
run_test_files "empty_lines" $'\n\n\n' -f1
run_test_files "empty_fields" $'a,,c\n' -L -d, -f2
run_test_files "trailing_delim" $'a,b,c,\n' -L -d, -f4
run_test_files "leading_delim" $',a,b\n' -L -d, -f1

# Compound short options
run_test_files "bundled" $'a,b,c\n' -Ld, -f1

# Empty file
printf '' > /tmp/empty.txt
run_test_files "empty_file" "-" /tmp/empty.txt
run_test_files "empty_file_F" "-" /tmp/empty.txt -F a

# Long line
LONG=$(python3 -c "print(' '.join('field' + str(i) for i in range(100)))")
run_test_files "longline" "$LONG"$'\n' -f50,75
run_test_files "longline2" "$LONG"$'\n' -f100,1

# Regex with classes
run_test_files "regex_digit" $'a123b456c\n' -d '[0-9]+'
run_test_files "regex_word" $'hello world\n' -d ' '

# Output delim with escapes
run_test_files "outD_n" $'a b c\n' -D '\n'
run_test_files "outD_r" $'a b c\n' -D '\r'
run_test_files "outD_t" $'a b c\n' -D '\t'

echo
echo "===== Results: $PASS passed, $FAIL failed ====="
if [ "$FAIL" -gt 0 ]; then
    printf '%s\n' "${FAIL_DETAILS[@]}"
fi
