#!/bin/sh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
cat > executable <<'PYEOF'
#!/usr/bin/env python3
PYEOF
cat hck.py >> executable
chmod +x executable
