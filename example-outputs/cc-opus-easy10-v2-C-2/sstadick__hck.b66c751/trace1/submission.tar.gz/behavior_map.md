# hck behavior map

## Overview
The reference binary is `hck`, a cut(1)-like utility. It splits input lines on a 
delimiter (regex by default, literal with -L) and outputs selected fields.

## CLI surface
```
Usage: executable [OPTIONS] [INPUT]...
```

Options:
- `-o, --output <OUTPUT>`: write to file (default stdout)
- `-d, --delimiter <DELIMITER>`: input delimiter (default `\s+`, regex by default)
- `-L, --delim-is-literal`: treat -d as literal substring
- `-I, --use-input-delim`: use input delim as output delim if literal & no -D set
- `-D, --output-delimiter <OUTPUT_DELIMITER>`: output delim (default `\t`)
- `-f, --fields <FIELDS>`: select fields, 1-based, comma-separated, ranges with `-`
- `-e, --exclude <EXCLUDE>`: exclude fields
- `-E, --exclude-header <EXCLUDE_HEADER>`: exclude by header literal/regex (CAN repeat)
- `-F, --header-field <HEADER_FIELD>`: select by header literal/regex (CAN repeat)
- `-r, --header-is-regex`: treat -F/-E as regex
- `-z, --try-decompress`: decompress input by extension
- `-Z, --try-compress`: gzip output
- `-t, --compression-threads`: 0..N (default 4)
- `-l, --compression-level`: default 6
- `--no-mmap`: disable mmap
- `--crlf`: support CRLF
- `-h, --help`: short help
- `--help`: long help
- `-V, --version`: prints `hck git:23bebe8-modified`

## Default behavior
- Input: stdin (or files), each line split on `\s+` regex.
- Output: joined with `\t`, terminated with `\n`.
- Files: concatenated; multiple inputs OK.
- `-` arg → stdin.

## Single-occurrence flags (clap error if repeated)
- `-d`, `-f`, `-e`, `-o`, `-D` cannot be specified multiple times.

## Repeatable flags
- `-F`, `-E` can be repeated.

## Delimiter modes
- Regex (default): Rust `regex::Regex`. Escapes via regex (e.g. `\s+`, `\t`, `\n`, `\r`).
- Literal `-L`: string match. Escape processing for `\t`, `\n`, `\r`, `\\`.
- Empty delim `-d ''`: splits every position → each char becomes separate field, with empty prefix/suffix.

## Field selectors syntax
- `N`: single field (1-based)
- `N-M`: range inclusive
- `N-`: open-ended (N to last)
- `-N`: 1 to N (equivalent to `1-N`)
- Comma-separated list
- Error: field 0 → "Fields and positions are numbered from 1: 0"
- Error: range with M < N → "High end of range less than low end of range: N-M"
- Error: unparseable → "Failed to parse field: X"
- Selectors out of range (e.g. -f5 on 3-field input) → empty output, no error
- For each line, missing fields are SKIPPED entirely (no padding/separator)

### Reduction algorithm for -f selectors (CRITICAL)
Each selector is a range. Process selectors in order:
- If new range is FULLY CONTAINED in any existing range → DROP new range.
- Else, for each existing range that OVERLAPS the new range, REMOVE the overlap from the existing range (which may truncate or empty it). Then append the new range.
- Output: ranges in list order; each range's fields in numeric order.

Examples:
- `4-,1,5-8` (8 fields) → "4-,1" (5-8 dropped, subset of 4-) → 4,5,6,7,8,1
- `3,2-4` → "(empty),2-4" → 2,3,4
- `3-5,2-4` → "[5],2-4" → 5,2,3,4
- `5,4,3,2,1` (no overlap) → 5,4,3,2,1
- `2-7,4-5` → "2-7" → 2,3,4,5,6,7
- `4-6,2-5` → "[6],2-5" → 6,2,3,4,5

## Exclude selectors `-e`
- Same syntax as -f
- Excludes by index; combines with -f (exclude has precedence)
- If no -f given, defaults to "all fields"

## Header selection `-F`
- Each file's first line is the header (consumed AND output)
- Each -F selector applied to that file's header
- Matches: literal (string equality) or regex if -r set
- ORDER: selector order; regex matches grouped per-regex in input order
- Duplicates dropped (later match for same field skipped)
- If a file's header yields zero matches → "No headers matched" error, exit 1
- Empty file → "No headers matched" error

## Exclude header `-E`
- Same syntax as -F (literal/regex with -r)
- Excludes any header field matching
- Non-matching name → no exclusion, OK

## CRLF mode `--crlf`
- Output uses `\r\n` line terminator
- Input: line split still on `\n` boundary
  - If line ends with `\r` (i.e., input had `\r\n`): strip both → line content ends clean
  - If line ends with just `\n` (no `\r`): KEEP the `\n` in line content
- Without `--crlf`: standard `\n` line splitting, `\r` (if present) stays in content

## File I/O
- Files concatenated; lines processed independently per file.
- `.gz` (and `.bz2`, `.zst`, `.xz`?) extensions → with `-z` decompress.
- Without `-z`, `.gz` file read as binary.
- `-o FILE` writes to file.

## Errors
- Invalid regex → `Error: regex parse error: ...` exit 1
- Invalid field → `[TIMESTAMP ERROR hck] Failed to parse field: X` exit 1
- Field 0 → `[TIMESTAMP ERROR hck] Fields and positions are numbered from 1: 0` exit 1
- High < low → `[TIMESTAMP ERROR hck] High end of range less than low end of range: 5-3` exit 1
- No header match → `[TIMESTAMP ERROR hck] No headers matched` exit 1
- File not found → `[TIMESTAMP ERROR hck] No such file or directory (os error 2)` exit 1
- Clap errors → exit 2 with `error: ...` format
- File panic on single-byte literal delim + line starts with delim → exit 101 with panic stack

## Output details
- Trailing newline always added (input "abc" → "abc\n")
- No trailing newline appended if input ends with explicit \n already

## Version
- `hck git:23bebe8-modified` (just one line)

## Goldens dir
See `/work/work/goldens/` for frozen reference frames (exit, stdout, stderr).
