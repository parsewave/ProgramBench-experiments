#!/bin/bash
# Random differential testing: generate diverse inputs and compare.

REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAIL_DETAILS=()

run_test() {
    local desc="$1"
    shift
    local input="$1"
    shift
    local args=("$@")

    local ref_out ref_err ref_exit
    local sut_out sut_err sut_exit

    ref_out=$(printf '%s' "$input" | "$REF" "${args[@]}" 2>/tmp/ref_err)
    ref_exit=$?
    sut_out=$(printf '%s' "$input" | "$SUT" "${args[@]}" 2>/tmp/sut_err)
    sut_exit=$?

    if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        if [ ${#FAIL_DETAILS[@]} -lt 20 ]; then
            FAIL_DETAILS+=("=== FAIL: $desc")
            FAIL_DETAILS+=("    args: ${args[*]}")
            FAIL_DETAILS+=("    input: $(printf '%s' "$input" | head -c 80 | od -An -c | head -3 | tr -s ' ')")
            FAIL_DETAILS+=("    REF exit=$ref_exit stdout=$(printf '%s' "$ref_out" | head -c 200 | od -An -c | head -3 | tr -s ' ')")
            FAIL_DETAILS+=("    SUT exit=$sut_exit stdout=$(printf '%s' "$sut_out" | head -c 200 | od -An -c | head -3 | tr -s ' ')")
        fi
    fi
}

# Random Markov-chain-like sampling. We have 'modes' of operation:
# - Field selection: -f, -e, -F, -E
# - Delimiters: regex, literal, default
# - Output: stdout, file, -Z
# - Special: --crlf, multiple files
# - Edge cases: empty, very long, special chars

# Random inputs
INPUTS=(
    "a b c"$'\n'
    "a b c"$'\n'"1 2 3"$'\n'
    "x y z w v"$'\n'"1 2 3 4 5"$'\n'
    "a,b,c,d"$'\n'
    "name age height"$'\n'"alice 25 170"$'\n'"bob 30 180"$'\n'
    ""
    $'\n'
    "single"$'\n'
    "  leading"$'\n'
    "trailing  "$'\n'
    "  spaces  everywhere  "$'\n'
    $'a\tb\tc\n'
    $'a\r\nb\r\nc\r\n'
    "abc"
    $'\n\n\n'
)

ARGS_SETS=(
    ""
    "-f1"
    "-f2"
    "-f1,3"
    "-f3-"
    "-f-2"
    "-f1-2,4-5"
    "-e1"
    "-e2-3"
    "-d ,"
    "-d , -f2"
    "-L -d ,"
    "-L -d , -f2"
    "-D ;"
    "-D | -f1,3"
    "--crlf"
    "-f1 --crlf"
    "-f1- -e3"
    "-F a"
    "-F a -F b"
    "-r -F .*"
    "-E a"
    "-V"
    "-h"
    "-f5,3,1"
    "-d \\s+ -f1"
    "-L -d ; -f1"
    "-L -d : -f1,2"
)

i=0
for inp in "${INPUTS[@]}"; do
    for args in "${ARGS_SETS[@]}"; do
        # Split args into array
        IFS=' ' read -r -a arg_array <<< "$args"
        i=$((i + 1))
        run_test "rand$i" "$inp" "${arg_array[@]}"
    done
done

echo
echo "===== Results: $PASS passed, $FAIL failed ====="
if [ "$FAIL" -gt 0 ]; then
    printf '%s\n' "${FAIL_DETAILS[@]}"
fi
