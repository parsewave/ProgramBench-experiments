#!/bin/bash
# More thorough differential testing.

REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAIL_DETAILS=()

run_test() {
    local desc="$1"
    shift
    local input="$1"
    shift
    local args=("$@")

    local ref_out ref_err ref_exit
    local sut_out sut_err sut_exit

    ref_out=$(printf '%s' "$input" | "$REF" "${args[@]}" 2>/tmp/ref_err)
    ref_exit=$?
    ref_err=$(cat /tmp/ref_err)
    sut_out=$(printf '%s' "$input" | "$SUT" "${args[@]}" 2>/tmp/sut_err)
    sut_exit=$?
    sut_err=$(cat /tmp/sut_err)

    # Strip timestamps from stderr for comparison
    ref_err_norm=$(echo "$ref_err" | sed -E 's/\[[0-9TZ:.\-]+ ERROR hck\]/[TS ERROR hck]/g')
    sut_err_norm=$(echo "$sut_err" | sed -E 's/\[[0-9TZ:.\-]+ ERROR hck\]/[TS ERROR hck]/g')

    if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        FAIL_DETAILS+=("=== FAIL: $desc")
        FAIL_DETAILS+=("    args: ${args[*]}")
        FAIL_DETAILS+=("    input: $(printf '%s' "$input" | head -c 80 | od -An -c | tr -s ' ')")
        FAIL_DETAILS+=("    REF exit=$ref_exit stdout=$(printf '%s' "$ref_out" | head -c 80 | od -An -c | tr -s ' ')")
        FAIL_DETAILS+=("    SUT exit=$sut_exit stdout=$(printf '%s' "$sut_out" | head -c 80 | od -An -c | tr -s ' ')")
        if [ "$ref_err_norm" != "$sut_err_norm" ]; then
            FAIL_DETAILS+=("    REF stderr: $(echo "$ref_err_norm" | head -3)")
            FAIL_DETAILS+=("    SUT stderr: $(echo "$sut_err_norm" | head -3)")
        fi
    fi
}

# Algorithm edge cases
run_test "alg1"  $'a b c d e f g h\n'  -f3,2-4
run_test "alg2"  $'a b c d e f g h\n'  -f3-5,2-4
run_test "alg3"  $'a b c d e f g h\n'  -f4-6,2-5
run_test "alg4"  $'a b c d e f g h\n'  -f2-7,4-5
run_test "alg5"  $'a b c d e f g h\n'  -f2-3,4-7
run_test "alg6"  $'a b c d e f g h\n'  -f2-4,4-6
run_test "alg7"  $'a b c d e f g h\n'  -f1-3,5-7,2-6
run_test "alg8"  $'a b c d e f g h\n'  -f1-3,5-7,3-6
run_test "alg9"  $'a b c d e f g h\n'  -f1-3,5-7,6
run_test "alg10" $'a b c d e f g h\n'  -f4-,1
run_test "alg11" $'a b c d e f g h\n'  -f4-,1,5-8
run_test "alg12" $'a b c d e f g h\n'  -f1,1,2
run_test "alg13" $'a b c d e f g h\n'  -f3,3,3
run_test "alg14" $'a b c d e f g h\n'  -f3,3,2
run_test "alg15" $'a b c d e f g h\n'  -f5,4,3,2,1
run_test "alg16" $'a b c d e f g h\n'  -f2-3,1-

# Exclude tests
run_test "exc1"  $'a b c d e\n'  -e2,4
run_test "exc2"  $'a b c d e\n'  -e3
run_test "exc3"  $'a b c d e\n'  -f1-3 -e2
run_test "exc4"  $'a b c d e\n'  -e1-2
run_test "exc5"  $'a b c d e\n'  -e3-
run_test "exc6"  $'a b c d e\n'  -e1,3,5
run_test "exc7"  $'a b c d e\n'  -f3,1,5 -e1

# Header tests
run_test "hdr1"  $'a b c\nA B C\n'  -F a
run_test "hdr2"  $'name age height\nalice 25 170\n'  -F name
run_test "hdr3"  $'name age height\nalice 25 170\n'  -F age
run_test "hdr4"  $'name age height\nalice 25 170\n'  -F name -F height
run_test "hdr5"  $'name age height\nalice 25 170\n'  -r -F '^a.*'
run_test "hdr6"  $'name age height\nalice 25 170\n'  -r -F '.*'
run_test "hdr7"  $'name age height\nalice 25 170\n'  -E name
run_test "hdr8"  $'name age height\nalice 25 170\n'  -E age -E name
run_test "hdr9"  $'name age height\nalice 25 170\n'  -r -E '^h.*'
run_test "hdr10" $'aaa bbb ccc\n1 2 3\n'  -r -F '.*' -F 'a.*'
run_test "hdr11" $'a b c\n'  -F a -F b -F a
run_test "hdr12" $'a b c\n'  -F nonexistent
run_test "hdr13" $'a b c\n1 2 3\n'  -F a
run_test "hdr14" $'name,age,height\nalice,25,170\n'  -d, -F name -F age
run_test "hdr15" $'name,age,height\nalice,25,170\n'  -L -d, -F name -F age
run_test "hdr16" $'name\tage\theight\nalice\t25\t170\n'  -F name -F age
run_test "hdr17" $'name age height\nalice 25 170\n'  -r -F '.*e.*' -F '.*g.*'

# Empty input cases
run_test "emp1" "" -f1
run_test "emp2" "" -E nonexistent
run_test "emp3" $'\n' -f1

# CRLF tests
run_test "crlf1" $'a b c\r\n' --crlf
run_test "crlf2" $'a b c\n' --crlf
run_test "crlf3" $'a\nb\nc\n' --crlf
run_test "crlf4" $'a\r\nb\r\nc\r\n' --crlf
run_test "crlf5" $'aaa\r\nbbb\nccc\r\n' --crlf
run_test "crlf6" 'a b c' --crlf
run_test "crlf7" $'a\nb' --crlf
run_test "crlf8" $'a,b\nc,d\n' -L -d, --crlf
run_test "crlf9" $'a,b\r\nc,d\r\n' -L -d, --crlf
run_test "crlf10" $'a b c\n1 2 3\n' -f1 --crlf

# Without --crlf
run_test "nocrlf1" $'a b c\r\n'
run_test "nocrlf2" $'a\r\nb\r\nc\r\n'

# Output delimiter
run_test "outD1" $'a b c\n' -D'|'
run_test "outD2" $'a b c\n' -D'\t'
run_test "outD3" $'a b c\n' -D' '
run_test "outD4" $'a b c\n' -D''
run_test "outD5" $'a\tb\tc\n' -L -d'\t' -I
run_test "outD6" $'a,b,c\n' -L -d, -I
run_test "outD7" $'a,b,c\n' -d, -I

# Empty delim
run_test "edelim1" $'abc\n' -L -d ''
run_test "edelim2" $'abc\n' -d ''

# Out of range
run_test "oor1" $'a b\n' -f3
run_test "oor2" $'a b\n' -f3,1
run_test "oor3" $'a b\n' -f4,5,6
run_test "oor4" $'a b c\n' -f1,3,5
run_test "oor5" $'a b c\n' -f2,5,3
run_test "oor6" $'a b c d\n' -f1-5

# Special: leading/trailing whitespace
run_test "ws1" $'  leading\n'
run_test "ws2" $'trailing  \n'
run_test "ws3" $'  a  b  c  \n'
run_test "ws4" $'  a  b  c  \n' -f1
run_test "ws5" $'  a  b  c  \n' -f2

# Version and help
run_test "ver1" "" -V
run_test "ver2" "" --version
run_test "help1" "" -h
run_test "help2" "" --help

# Errors
run_test "err1" $'a b c\n' -f0
run_test "err2" $'a b c\n' -f5-3
run_test "err3" $'a b c\n' -f'a-b'
run_test "err4" $'a b c\n' -fa
run_test "err5" $'a b c\n' -d '['
run_test "err6" $'a b c\n' --bogus
run_test "err7" $'a b c\n' -f

# Range edge cases
run_test "rng1" $'a b c\n' -f1-
run_test "rng2" $'a b c\n' -f-3
run_test "rng3" $'a b c\n' -f5
run_test "rng4" $'a b c\n' -f5-7

# Newline edge cases
run_test "nl1" $'abc'
run_test "nl2" $'abc\n'
run_test "nl3" $'abc\n\n'
run_test "nl4" $'\nabc\n'

echo
echo "===== Results: $PASS passed, $FAIL failed ====="
if [ "$FAIL" -gt 0 ]; then
    printf '%s\n' "${FAIL_DETAILS[@]}"
fi
