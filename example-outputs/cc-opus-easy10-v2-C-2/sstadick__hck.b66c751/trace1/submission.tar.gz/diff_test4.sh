#!/bin/bash
# Edge case tests
REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAIL_DETAILS=()

run_test() {
    local desc="$1"
    shift
    local input="$1"
    shift
    local args=("$@")

    local ref_out ref_err ref_exit
    local sut_out sut_err sut_exit

    ref_out=$(printf '%s' "$input" | "$REF" "${args[@]}" 2>/tmp/ref_err)
    ref_exit=$?
    sut_out=$(printf '%s' "$input" | "$SUT" "${args[@]}" 2>/tmp/sut_err)
    sut_exit=$?

    if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        FAIL_DETAILS+=("=== FAIL: $desc")
        FAIL_DETAILS+=("    args: ${args[*]}")
        FAIL_DETAILS+=("    input: $(printf '%s' "$input" | head -c 100 | od -An -c | head -3 | tr -s ' ')")
        FAIL_DETAILS+=("    REF exit=$ref_exit stdout=$(printf '%s' "$ref_out" | head -c 200 | od -An -c | head -3 | tr -s ' ')")
        FAIL_DETAILS+=("    SUT exit=$sut_exit stdout=$(printf '%s' "$sut_out" | head -c 200 | od -An -c | head -3 | tr -s ' ')")
    fi
}

# More edge cases
run_test "hdr_notfound1" $'a b c\n1 2 3\n' -F a -F x
run_test "hdr_notfound2" $'a b c\n1 2 3\n' -F x -F a
run_test "hdr_notfound3" $'a b c\n1 2 3\n' -F x -F y -F z
run_test "hdr_notfound4" $'a b c\n1 2 3\n' -F a -F b -F x
run_test "hdr_empty_regex" "" -r -F '.*'
run_test "hdr_empty_regex2" "" -r -F 'a*'
run_test "hdr_empty_regex3" "" -r -F 'a+'
run_test "hdr_empty_lit" "" -F a

# -L invalid data
run_test "L_no_nl" "abc" -L -d ,
run_test "L_with_nl" $'abc\n' -L -d ,
run_test "L_empty" "" -L -d ,
run_test "L_just_nl" $'\n' -L -d ,

# Field selection
run_test "f_str" $'a b c\n' -f1-3
run_test "f_dash" $'a b c\n' -f-
run_test "f_dashN" $'a b c\n' -f-100
run_test "f_Nrev" $'a b c d e\n' -f5-2

# Various delim handling
run_test "delim_special" $'a;;b\n' -L -d ';;' -f1
run_test "delim_special2" $'a;;b\n' -d ';;' -f1
run_test "delim_dot" $'a.b.c\n' -L -d '.' -f2
run_test "delim_dot_re" $'a.b.c\n' -d '.' -f2

# Output delim
run_test "od_nl" $'a b c\n' -D'\n'
run_test "od_tab" $'a b c\n' -D'\t'
run_test "od_back" $'a b c\n' -D'\\\\'

# Combinations
run_test "ff_combo" $'a b c d e\n' -f1,3 -e2
run_test "fF_combo1" $'a b c\n1 2 3\n' -F a -f3
run_test "fF_combo2" $'a b c\n1 2 3\n' -F a -F b -f3
run_test "fF_combo3" $'a b c d e\n1 2 3 4 5\n' -F b -F a -f3

# Numeric edge cases
run_test "neg_field" $'a b c\n' -f-1

# Long lines
LONG=""
for i in $(seq 1 100); do LONG+=" $i"; done
LONG+=$'\n'
run_test "long_line1" "$LONG" -f1,50,100
run_test "long_line2" "$LONG" -f-50
run_test "long_line3" "$LONG" -f60-

echo
echo "===== Results: $PASS passed, $FAIL failed ====="
if [ "$FAIL" -gt 0 ]; then
    printf '%s\n' "${FAIL_DETAILS[@]}"
fi
