
import sys
import os
import re
import gzip
import datetime
import io


VERSION_TEXT = "hck git:23bebe8-modified\n"

USAGE_TEXT = "Usage: executable [OPTIONS] [INPUT]...\n"

USAGE_FOOTER = "\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n"


SHORT_HELP = """* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Input files to parse, defaults to stdin

Options:
  -o, --output <OUTPUT>
          Output file to write to, defaults to stdout
  -d, --delimiter <DELIMITER>
          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag [default: \\s+]
  -L, --delim-is-literal
          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
  -I, --use-input-delim
          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
  -D, --output-delimiter <OUTPUT_DELIMITER>
          Delimiter string to use on outputs [default: "\\t"]
  -f, --fields <FIELDS>
          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
  -e, --exclude <EXCLUDE>
          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`
  -E, --exclude-header <EXCLUDE_HEADER>
          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex
  -F, --header-field <HEADER_FIELD>
          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex
  -r, --header-is-regex
          Treat the header_fields as regexs instead of string literals
  -z, --try-decompress
          Try to find the correct decompression method based on the file extensions
  -Z, --try-compress
          Try to gzip compress the output
  -t, --compression-threads <COMPRESSION_THREADS>
          Threads to use for compression, 0 will result in `hck` staying single threaded [default: 4]
  -l, --compression-level <COMPRESSION_LEVEL>
          Compression level [default: 6]
      --no-mmap
          Disallow the possibility of using mmap
      --crlf
          Support CRLF newlines
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

_SP10 = "          "
LONG_HELP = ("* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`\n"
"\n"
"## Selection by headers\n"
"\n"
"Instead of specifying fields to output by index ranges (i.e `1-2,4-`), you can specify a regex or string literal to select a headered column to output with the `-F` option. By default `-F` options are treated as string literals. To treat them as regexs add the `-r` flag.\n"
"\n"
"## Ordering of outputs\n"
"\n"
'*Values are written only once*. So for a `fields` value of `4-,1,5-8`, which translates to "print columns 4 through the end and then the last column and then columns 5 through 8", columns 5-8 won\'t be printed again because they were already consumed by the `4-` range.\n'
"\n"
"If `field-headers` is used as a regex then the headers will be be grouped together in groups that all matched the same regex, and in the order of the regex as specified on the CLI.\n"
"\n"
"Usage: executable [OPTIONS] [INPUT]...\n"
"\n"
"Arguments:\n"
"  [INPUT]...\n"
"          Input files to parse, defaults to stdin.\n"
+ _SP10 + "\n"
"          If a file has a recognizable file extension indicating that it is compressed, and a local binary to perform decompression is found, decompression will occur automagically. This requires with `-z`.\n"
"\n"
"Options:\n"
"  -o, --output <OUTPUT>\n"
"          Output file to write to, defaults to stdout\n"
"\n"
"  -d, --delimiter <DELIMITER>\n"
"          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag\n"
+ _SP10 + "\n"
"          [default: \\s+]\n"
"\n"
"  -L, --delim-is-literal\n"
"          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters\n"
"\n"
"  -I, --use-input-delim\n"
"          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set\n"
"\n"
"  -D, --output-delimiter <OUTPUT_DELIMITER>\n"
"          Delimiter string to use on outputs\n"
+ _SP10 + "\n"
'          [default: "\\t"]\n'
"\n"
"  -f, --fields <FIELDS>\n"
"          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive\n"
"\n"
"  -e, --exclude <EXCLUDE>\n"
"          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`\n"
"\n"
"  -E, --exclude-header <EXCLUDE_HEADER>\n"
"          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex\n"
"\n"
"  -F, --header-field <HEADER_FIELD>\n"
"          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex\n"
"\n"
"  -r, --header-is-regex\n"
"          Treat the header_fields as regexs instead of string literals\n"
"\n"
"  -z, --try-decompress\n"
"          Try to find the correct decompression method based on the file extensions\n"
"\n"
"  -Z, --try-compress\n"
"          Try to gzip compress the output\n"
"\n"
"  -t, --compression-threads <COMPRESSION_THREADS>\n"
"          Threads to use for compression, 0 will result in `hck` staying single threaded\n"
+ _SP10 + "\n"
"          [default: 4]\n"
"\n"
"  -l, --compression-level <COMPRESSION_LEVEL>\n"
"          Compression level\n"
+ _SP10 + "\n"
"          [default: 6]\n"
"\n"
"      --no-mmap\n"
"          Disallow the possibility of using mmap\n"
"\n"
"      --crlf\n"
"          Support CRLF newlines\n"
"\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n"
"\n"
"  -V, --version\n"
"          Print version\n"
)


def would_panic_on_leading_delim(data, delim_byte, args, use_headers, field_ranges, exclude_ranges):
    """Check if the reference would panic on this input (best-effort emulation).
    Conditions:
    - Single-byte literal delim
    - First non-empty line starts with delim
    - Header mode (-F) is NOT being used (REF takes a different path in header mode)
    - The output would include the leading empty field
    """
    if use_headers:
        return False
    # Find the first non-empty line
    start = 0
    L = len(data)
    while start < L:
        if data[start:start+1] == b'\n':
            start += 1
            continue
        # Non-empty line found
        if data[start] == delim_byte:
            # Would the output include field 1 (the empty leading)?
            if field_ranges is None and exclude_ranges is None:
                return True  # Print all fields
            # If field_ranges includes field 1 → panic
            if field_ranges is not None:
                for (s, e) in field_ranges:
                    if s is None:
                        continue
                    if s == 1:
                        return True
            # If exclude_ranges and field 1 not excluded → panic
            if exclude_ranges is not None:
                excludes_1 = False
                for (s, e) in exclude_ranges:
                    if s is None:
                        continue
                    if s == 1:
                        excludes_1 = True
                        break
                    if e is not None and s <= 1 <= e:
                        excludes_1 = True
                        break
                if not excludes_1 and field_ranges is None:
                    return True
        return False
    return False


def format_os_error(e):
    """Format OSError in Rust style: 'No such file or directory (os error 2)'."""
    if hasattr(e, 'errno') and e.errno is not None:
        msg_map = {
            2: "No such file or directory",
            13: "Permission denied",
            21: "Is a directory",
            17: "File exists",
            5: "Input/output error",
        }
        msg = msg_map.get(e.errno, e.strerror or "Error")
        return f"{msg} (os error {e.errno})"
    return str(e)


def translate_regex_error(py_msg, pattern):
    """Translate Python re error message to Rust-like message."""
    py_msg_lower = py_msg.lower()
    if "unterminated subpattern" in py_msg_lower or "missing )" in py_msg_lower:
        return "unclosed group"
    if "unterminated character set" in py_msg_lower or "missing ]" in py_msg_lower:
        return "unclosed character class"
    if "nothing to repeat" in py_msg_lower:
        return "repetition operator missing expression"
    if "bad escape" in py_msg_lower:
        return "invalid escape sequence"
    if "unbalanced parenthesis" in py_msg_lower:
        return "unclosed group"
    return py_msg


def err_log(msg):
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    sys.stderr.write(f"[{now} ERROR hck] {msg}\n")


def clap_error(msg, tip=None, with_usage=True):
    sys.stderr.write(f"error: {msg}\n")
    if tip:
        sys.stderr.write(f"\n  tip: {tip}\n")
    if with_usage:
        sys.stderr.write(USAGE_FOOTER)
    else:
        sys.stderr.write("\nFor more information, try '--help'.\n")
    sys.exit(2)


def process_escape(s):
    """Process \\t, \\n, \\r, \\\\ escapes (matches Rust's literal processing)."""
    result = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == '\\' and i + 1 < len(s):
            nxt = s[i + 1]
            if nxt == 't':
                result.append('\t')
                i += 2
                continue
            elif nxt == 'n':
                result.append('\n')
                i += 2
                continue
            elif nxt == 'r':
                result.append('\r')
                i += 2
                continue
            elif nxt == '\\':
                result.append('\\')
                i += 2
                continue
        result.append(c)
        i += 1
    return ''.join(result)


class Args:
    def __init__(self):
        self.output = None
        self.delimiter = None
        self.delim_is_literal = False
        self.use_input_delim = False
        self.output_delimiter = None
        self.fields = None
        self.exclude = None
        self.exclude_header = []
        self.header_field = []
        self.header_is_regex = False
        self.try_decompress = False
        self.try_compress = False
        self.compression_threads = 4
        self.compression_level = 6
        self.no_mmap = False
        self.crlf = False
        self.inputs = []


# Maps short option to its full clap representation
LONG_NAMES = {
    'o': '--output <OUTPUT>',
    'd': '--delimiter <DELIMITER>',
    'L': '--delim-is-literal',
    'I': '--use-input-delim',
    'D': '--output-delimiter <OUTPUT_DELIMITER>',
    'f': '--fields <FIELDS>',
    'e': '--exclude <EXCLUDE>',
    'E': '--exclude-header <EXCLUDE_HEADER>',
    'F': '--header-field <HEADER_FIELD>',
    'r': '--header-is-regex',
    'z': '--try-decompress',
    'Z': '--try-compress',
    't': '--compression-threads <COMPRESSION_THREADS>',
    'l': '--compression-level <COMPRESSION_LEVEL>',
    'h': '--help',
    'V': '--version',
}

LONG_OPTS = {
    'output': ('o', True),
    'delimiter': ('d', True),
    'delim-is-literal': ('L', False),
    'use-input-delim': ('I', False),
    'output-delimiter': ('D', True),
    'fields': ('f', True),
    'exclude': ('e', True),
    'exclude-header': ('E', True),
    'header-field': ('F', True),
    'header-is-regex': ('r', False),
    'try-decompress': ('z', False),
    'try-compress': ('Z', False),
    'compression-threads': ('t', True),
    'compression-level': ('l', True),
    'no-mmap': ('NO_MMAP', False),
    'crlf': ('CRLF', False),
    'help': ('HELP_LONG', False),
    'version': ('V', False),
}


SHORT_OPTS = {
    'o': ('o', True),
    'd': ('d', True),
    'L': ('L', False),
    'I': ('I', False),
    'D': ('D', True),
    'f': ('f', True),
    'e': ('e', True),
    'E': ('E', True),
    'F': ('F', True),
    'r': ('r', False),
    'z': ('z', False),
    'Z': ('Z', False),
    't': ('t', True),
    'l': ('l', True),
    'h': ('h', False),
    'V': ('V', False),
}


def parse_args(argv):
    args = Args()
    seen = set()
    after_double_dash = False
    inputs = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if after_double_dash:
            inputs.append(arg)
            i += 1
            continue
        if arg == '--':
            after_double_dash = True
            i += 1
            continue
        if arg.startswith('--') and len(arg) > 2:
            # Long option
            eq_idx = arg.find('=')
            if eq_idx >= 0:
                name = arg[2:eq_idx]
                value = arg[eq_idx+1:]
                has_inline = True
            else:
                name = arg[2:]
                value = None
                has_inline = False

            if name not in LONG_OPTS:
                tip = f"to pass '{arg}' as a value, use '-- {arg}'"
                clap_error(f"unexpected argument '{arg}' found", tip)

            key, takes_value = LONG_OPTS[name]

            if takes_value:
                if has_inline:
                    val = value
                else:
                    if i + 1 >= len(argv):
                        formatted = format_long_name(key, name)
                        clap_error(f"a value is required for '{formatted}' but none was supplied", with_usage=False)
                    val = argv[i + 1]
                    i += 1
                set_arg_value(args, key, val, seen, name, key)
            else:
                if has_inline:
                    # Special clap behavior: --help=foo gives a specific error
                    sys.stderr.write(f"error: unexpected value '{value}' for '--{name}' found; no more were expected\n")
                    sys.stderr.write(f"\nUsage: executable --{name} [INPUT]...\n")
                    sys.stderr.write(f"\nFor more information, try '--help'.\n")
                    sys.exit(2)
                set_arg_flag(args, key, seen, name, key)
        elif arg.startswith('-') and len(arg) > 1 and arg != '-':
            # Could be bundle of short options or short with value
            j = 1
            while j < len(arg):
                c = arg[j]
                if c not in SHORT_OPTS:
                    full_arg = arg  # the whole arg as user typed
                    tip = f"to pass '{full_arg}' as a value, use '-- {full_arg}'"
                    clap_error(f"unexpected argument '{full_arg}' found", tip)
                key, takes_value = SHORT_OPTS[c]
                if takes_value:
                    # Rest of arg (if any) is value, else take next arg
                    val = arg[j+1:]
                    if val == '':
                        if i + 1 >= len(argv):
                            formatted = format_short_name(key, c)
                            clap_error(f"a value is required for '{formatted}' but none was supplied", with_usage=False)
                        val = argv[i + 1]
                        i += 1
                    set_arg_value(args, key, val, seen, c, key)
                    break
                else:
                    set_arg_flag(args, key, seen, c, key)
                    j += 1
        else:
            inputs.append(arg)
        i += 1

    args.inputs = inputs
    return args


def format_long_name(key, name):
    """Format the long name for clap-style error messages."""
    name_map = {
        'output': '--output <OUTPUT>',
        'delimiter': '--delimiter <DELIMITER>',
        'delim-is-literal': '--delim-is-literal',
        'use-input-delim': '--use-input-delim',
        'output-delimiter': '--output-delimiter <OUTPUT_DELIMITER>',
        'fields': '--fields <FIELDS>',
        'exclude': '--exclude <EXCLUDE>',
        'exclude-header': '--exclude-header <EXCLUDE_HEADER>',
        'header-field': '--header-field <HEADER_FIELD>',
        'header-is-regex': '--header-is-regex',
        'try-decompress': '--try-decompress',
        'try-compress': '--try-compress',
        'compression-threads': '--compression-threads <COMPRESSION_THREADS>',
        'compression-level': '--compression-level <COMPRESSION_LEVEL>',
        'no-mmap': '--no-mmap',
        'crlf': '--crlf',
        'help': '--help',
        'version': '--version',
    }
    return name_map.get(name, f"--{name}")


def format_short_name(key, c):
    """Format short option for error messages (used as long form)."""
    name_to_long = {
        'o': '--output <OUTPUT>',
        'd': '--delimiter <DELIMITER>',
        'D': '--output-delimiter <OUTPUT_DELIMITER>',
        'f': '--fields <FIELDS>',
        'e': '--exclude <EXCLUDE>',
        'E': '--exclude-header <EXCLUDE_HEADER>',
        'F': '--header-field <HEADER_FIELD>',
        't': '--compression-threads <COMPRESSION_THREADS>',
        'l': '--compression-level <COMPRESSION_LEVEL>',
    }
    return name_to_long.get(c, f"-{c}")


def set_arg_value(args, key, val, seen, name_seen, k):
    """Set a value-bearing argument. Track duplicates for single-only flags."""
    if key == 'o':
        if 'o' in seen:
            clap_error(f"the argument '--output <OUTPUT>' cannot be used multiple times")
        args.output = val
        seen.add('o')
    elif key == 'd':
        if 'd' in seen:
            clap_error(f"the argument '--delimiter <DELIMITER>' cannot be used multiple times")
        args.delimiter = val
        seen.add('d')
    elif key == 'D':
        if 'D' in seen:
            clap_error(f"the argument '--output-delimiter <OUTPUT_DELIMITER>' cannot be used multiple times")
        args.output_delimiter = val
        seen.add('D')
    elif key == 'f':
        if 'f' in seen:
            clap_error(f"the argument '--fields <FIELDS>' cannot be used multiple times")
        args.fields = val
        seen.add('f')
    elif key == 'e':
        if 'e' in seen:
            clap_error(f"the argument '--exclude <EXCLUDE>' cannot be used multiple times")
        args.exclude = val
        seen.add('e')
    elif key == 'E':
        args.exclude_header.append(val)
    elif key == 'F':
        args.header_field.append(val)
    elif key == 't':
        if 't' in seen:
            clap_error(f"the argument '--compression-threads <COMPRESSION_THREADS>' cannot be used multiple times")
        try:
            args.compression_threads = int(val)
        except ValueError:
            clap_error(f"invalid value '{val}' for '--compression-threads <COMPRESSION_THREADS>': invalid digit found in string", with_usage=False)
        seen.add('t')
    elif key == 'l':
        if 'l' in seen:
            clap_error(f"the argument '--compression-level <COMPRESSION_LEVEL>' cannot be used multiple times")
        try:
            args.compression_level = int(val)
        except ValueError:
            clap_error(f"invalid value '{val}' for '--compression-level <COMPRESSION_LEVEL>': invalid digit found in string", with_usage=False)
        seen.add('l')


def set_arg_flag(args, key, seen, name_seen, k):
    if key == 'L':
        args.delim_is_literal = True
    elif key == 'I':
        args.use_input_delim = True
    elif key == 'r':
        args.header_is_regex = True
    elif key == 'z':
        args.try_decompress = True
    elif key == 'Z':
        args.try_compress = True
    elif key == 'NO_MMAP':
        args.no_mmap = True
    elif key == 'CRLF':
        args.crlf = True
    elif key == 'h':
        sys.stdout.write(SHORT_HELP)
        sys.exit(0)
    elif key == 'HELP_LONG':
        sys.stdout.write(LONG_HELP)
        sys.exit(0)
    elif key == 'V':
        sys.stdout.write(VERSION_TEXT)
        sys.exit(0)


# === Field selector parsing ===

def parse_field_selector(s):
    """Parse a string like '1,2-4,6-' into a list of (start, end) tuples.
    end=None means open-ended. Both 1-based.
    Raises ValueError on bad input."""
    if not s:
        raise ValueError(f"Failed to parse field: ")
    parts = s.split(',')
    ranges = []
    for part in parts:
        if part == '':
            raise ValueError(f"Failed to parse field: ")
        if '-' in part:
            left, right = part.split('-', 1)
            if '-' in right:
                # malformed like 1-2-3
                raise ValueError(f"Failed to parse field: {part}")
            if left == '' and right == '':
                raise ValueError(f"Failed to parse field: ")
            if left == '':
                # -N
                try:
                    end = int(right)
                except ValueError:
                    raise ValueError(f"Failed to parse field: {part}")
                if end == 0:
                    raise ValueError(f"ZERO:0")
                ranges.append((1, end))
            elif right == '':
                # N-
                try:
                    start = int(left)
                except ValueError:
                    raise ValueError(f"Failed to parse field: {part}")
                if start == 0:
                    raise ValueError(f"ZERO:0")
                ranges.append((start, None))
            else:
                try:
                    start = int(left)
                    end = int(right)
                except ValueError:
                    raise ValueError(f"Failed to parse field: {part}")
                if start == 0 or end == 0:
                    raise ValueError(f"ZERO:0")
                if end < start:
                    raise ValueError(f"HIGHLOW:{part}")
                ranges.append((start, end))
        else:
            try:
                n = int(part)
            except ValueError:
                raise ValueError(f"Failed to parse field: {part}")
            if n == 0:
                raise ValueError(f"ZERO:0")
            ranges.append((n, n))
    return ranges


INF = float('inf')


def _range_end(r):
    return INF if r[1] is None else r[1]


def reduce_ranges(ranges):
    """Process ranges in order. When a new range overlaps an existing range:
      - if identical -> the new range is dropped
      - if new.start <= existing.start -> new wins; existing loses the overlap
      - if new.start > existing.start  -> existing wins; new loses the overlap
    A range that becomes empty is kept as (None, None) to preserve list position.

    Returns list of (start, end) tuples; end=None means open-ended. (None, None) is empty.
    """
    result = []
    for (ns, ne) in ranges:
        new_existing = []
        new_start = ns
        new_end = ne
        for (es, ee) in result:
            if es is None or new_start is None:
                new_existing.append((es, ee))
                continue
            e_end = INF if ee is None else ee
            n_end = INF if new_end is None else new_end
            ovl_start = max(es, new_start)
            ovl_end = min(e_end, n_end)
            if ovl_start > ovl_end:
                new_existing.append((es, ee))
                continue

            # Winner = lower start; tie -> lower end; tie -> existing (new dropped).
            identical = (es == new_start and e_end == n_end)
            if not identical:
                if new_start < es:
                    new_wins = True
                elif new_start > es:
                    new_wins = False
                else:
                    new_wins = (n_end < e_end)
            if identical:
                # New range dropped; existing kept intact.
                new_start = None
                new_end = None
                new_existing.append((es, ee))
            elif new_wins:
                # New wins; existing loses the overlap (may split or empty).
                pieces = []
                if es < ovl_start:
                    pieces.append((es, ovl_start - 1))
                if ovl_end < e_end:
                    pieces.append((ovl_end + 1, (None if ee is None else ee)))
                if not pieces:
                    new_existing.append((None, None))
                else:
                    new_existing.extend(pieces)
            else:
                # Existing wins; new loses the overlap.
                pieces = []
                if new_start < ovl_start:
                    pieces.append((new_start, ovl_start - 1))
                if ovl_end < n_end:
                    pieces.append((ovl_end + 1, (None if new_end is None else new_end)))
                if not pieces:
                    new_start = None
                    new_end = None
                else:
                    new_start, new_end = pieces[0]
                new_existing.append((es, ee))
        result = new_existing
        if new_start is None:
            result.append((None, None))
        else:
            result.append((new_start, new_end))
    return result


def normalize_intervals(ranges):
    """Merge a list of (start, end) ranges (end=None means infinity) into a
    sorted, disjoint interval set. Ignores (None, None) empties."""
    intervals = []
    for (s, e) in ranges:
        if s is None:
            continue
        end = INF if e is None else e
        if s > end:
            continue
        intervals.append((s, end))
    intervals.sort()
    merged = []
    for (s, e) in intervals:
        if merged and s <= merged[-1][1] + 1:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
    return merged


def subtract_intervals(a, b):
    """Subtract interval set b from interval set a. Both normalized. Returns normalized."""
    result = []
    for (s, e) in a:
        cur = [(s, e)]
        for (bs, be) in b:
            nxt = []
            for (cs, ce) in cur:
                # cs..ce minus bs..be
                if be < cs or bs > ce:
                    nxt.append((cs, ce))
                    continue
                if bs > cs:
                    nxt.append((cs, min(bs - 1, ce)))
                if be < ce:
                    nxt.append((max(be + 1, cs), ce))
            cur = nxt
        result.extend(cur)
    return normalize_intervals([(s, (None if e == INF else e)) for (s, e) in result])


def keep_set_is_empty(F_list, field_ranges, exclude_ranges, exclude_header_set):
    """Determine if the effective output field set is structurally empty.
    F_list: 0-based header indices (or None). field_ranges: -f ranges (or None).
    exclude_ranges: -e ranges (or None). exclude_header_set: 0-based -E indices."""
    # Build selected interval set (1-based)
    sel = []
    if field_ranges is not None:
        for (s, e) in field_ranges:
            if s is None:
                continue
            sel.append((s, e))
    if F_list is not None:
        for idx in F_list:
            sel.append((idx + 1, idx + 1))
    if field_ranges is None and F_list is None:
        sel.append((1, None))
    selected = normalize_intervals(sel)

    # Build excluded interval set (1-based)
    exc = []
    if exclude_ranges is not None:
        for (s, e) in exclude_ranges:
            if s is None:
                continue
            exc.append((s, e))
    if exclude_header_set:
        for idx in exclude_header_set:
            exc.append((idx + 1, idx + 1))
    excluded = normalize_intervals(exc)

    keep = subtract_intervals(selected, excluded)
    return len(keep) == 0


def ranges_to_indices(ranges, n_fields):
    """Given the reduced ranges and the actual number of fields, return the
    flat list of 0-based field indices to output in order. Skips out-of-range."""
    indices = []
    for (s, e) in ranges:
        if s is None:
            continue  # empty range
        if e is None:
            # open-ended
            real_end = n_fields
        else:
            real_end = min(e, n_fields)
        if s > n_fields:
            continue
        for f in range(s, real_end + 1):
            indices.append(f - 1)
    return indices


def exclude_indices(field_indices, exclude_ranges, n_fields):
    """Remove indices that are in exclude_ranges (1-based)."""
    excluded = set()
    for (s, e) in exclude_ranges:
        if s is None:
            continue
        if e is None:
            real_end = n_fields
        else:
            real_end = min(e, n_fields) if e <= n_fields else n_fields
            # Actually for exclude, we want to exclude the actual range, even if out of bounds
            # but we only have n_fields fields anyway
        if s > n_fields:
            continue
        end_to_use = real_end if e is None else min(e, n_fields)
        for f in range(s, (end_to_use) + 1):
            excluded.add(f - 1)
    return [i for i in field_indices if i not in excluded]


# === Line processing ===

def split_literal_bytes(line, delim_bytes):
    if delim_bytes == b'':
        # Empty delim: split between each byte; produces [b''] + [each byte] + [b'']
        if not line:
            return [b'', b'']
        result = [b'']
        for b in line:
            result.append(bytes([b]))
        result.append(b'')
        return result
    return line.split(delim_bytes)


def split_line(line, delim_re, delim_lit):
    if delim_re is not None:
        return delim_re.split(line)
    else:
        return split_literal_bytes(line, delim_lit)


def select_headers(header_fields, header_field_selectors, is_regex):
    """Given headers (list of strings) and -F selectors, return (indices, error).
    indices: list of 0-based indices to output.
    error: None if OK, or a tuple ('not_found', selector_string) if a literal selector didn't match
           when at least one other selector did.
    """
    selected = []
    seen = set()
    matched_selectors = []
    unmatched_selectors = []
    for sel in header_field_selectors:
        sel_matched = False
        if is_regex:
            try:
                pat = re.compile(sel)
                pat_ok = True
            except re.error:
                pat = None
                pat_ok = False
            group = []
            if pat is not None:
                for idx, h in enumerate(header_fields):
                    if pat.search(h):
                        sel_matched = True
                        if idx not in seen:
                            group.append(idx)
                            seen.add(idx)
            else:
                for idx, h in enumerate(header_fields):
                    if h == sel:
                        sel_matched = True
                        if idx not in seen:
                            group.append(idx)
                            seen.add(idx)
            selected.extend(group)
        else:
            for idx, h in enumerate(header_fields):
                if h == sel:
                    sel_matched = True
                    if idx not in seen:
                        selected.append(idx)
                        seen.add(idx)
        if sel_matched:
            matched_selectors.append(sel)
        else:
            unmatched_selectors.append(sel)

    err = None
    if matched_selectors and unmatched_selectors:
        err = ('not_found', unmatched_selectors[0])
    return selected, err


def exclude_headers(header_fields, exclude_header_selectors, is_regex):
    """Return set of indices to exclude."""
    excluded = set()
    for sel in exclude_header_selectors:
        if is_regex:
            try:
                pat = re.compile(sel)
                for idx, h in enumerate(header_fields):
                    if pat.search(h):
                        excluded.add(idx)
            except re.error:
                for idx, h in enumerate(header_fields):
                    if h == sel:
                        excluded.add(idx)
        else:
            for idx, h in enumerate(header_fields):
                if h == sel:
                    excluded.add(idx)
    return excluded


def open_input(path, try_decompress):
    """Open input file in text mode, handling decompression by extension."""
    if try_decompress:
        if path.endswith('.gz'):
            return gzip.open(path, 'rb')
        elif path.endswith('.bz2'):
            import bz2
            return bz2.open(path, 'rb')
        elif path.endswith('.xz'):
            import lzma
            return lzma.open(path, 'rb')
    return open(path, 'rb')


def read_lines_from_bytes(data, crlf):
    """Yield lines from raw bytes.
    If crlf: strip \\r\\n if line ends with \\r\\n, else keep \\n in content.
    Else: strip just \\n.
    Last line without terminator: yielded as-is (content may include trailing chars)."""
    if not data:
        return
    start = 0
    L = len(data)
    while start < L:
        idx = data.find(b'\n', start)
        if idx == -1:
            yield data[start:]
            break
        if crlf:
            if idx > start and data[idx - 1:idx] == b'\r':
                yield data[start:idx - 1]
            else:
                yield data[start:idx + 1]
        else:
            yield data[start:idx]
        start = idx + 1


def main():
    argv = sys.argv[1:]
    args = parse_args(argv)

    # Determine delimiter
    if args.delimiter is not None:
        delim_input = args.delimiter
    else:
        delim_input = r'\s+'

    if args.delim_is_literal:
        delim_lit_bytes = process_escape(delim_input).encode('utf-8', errors='surrogateescape')
        delim_re_compiled = None
    else:
        # Treat as regex.
        try:
            delim_re_compiled = re.compile(delim_input.encode('utf-8', errors='surrogateescape'))
        except re.error as e:
            rust_msg = translate_regex_error(str(e), delim_input)
            sys.stderr.write(f"Error: regex parse error:\n    {delim_input}\n    ^\nerror: {rust_msg}\n")
            sys.exit(1)
        delim_lit_bytes = None

    # Determine output delimiter
    if args.output_delimiter is not None:
        out_delim = process_escape(args.output_delimiter).encode('utf-8', errors='surrogateescape')
    elif args.use_input_delim and args.delim_is_literal:
        out_delim = delim_lit_bytes
    else:
        out_delim = b'\t'

    # Determine line terminator
    line_term = b'\r\n' if args.crlf else b'\n'

    # Parse field selectors
    field_ranges = None
    field_ranges_raw = None
    if args.fields is not None:
        try:
            field_ranges_raw = parse_field_selector(args.fields)
        except ValueError as e:
            msg = str(e)
            if msg.startswith("ZERO:"):
                val = msg.split(":", 1)[1]
                err_log(f"Fields and positions are numbered from 1: {val}")
            elif msg.startswith("HIGHLOW:"):
                val = msg.split(":", 1)[1]
                err_log(f"High end of range less than low end of range: {val}")
            else:
                err_log(str(e))
            sys.exit(1)
        field_ranges = reduce_ranges(field_ranges_raw)

    exclude_ranges = None
    if args.exclude is not None:
        try:
            exclude_ranges = parse_field_selector(args.exclude)
        except ValueError as e:
            msg = str(e)
            if msg.startswith("ZERO:"):
                val = msg.split(":", 1)[1]
                err_log(f"Fields and positions are numbered from 1: {val}")
            elif msg.startswith("HIGHLOW:"):
                val = msg.split(":", 1)[1]
                err_log(f"High end of range less than low end of range: {val}")
            else:
                err_log(str(e))
            sys.exit(1)

    # Open output
    if args.output is not None:
        try:
            out_raw = open(args.output, 'wb')
        except OSError as e:
            err_log(format_os_error(e))
            sys.exit(1)
    else:
        out_raw = sys.stdout.buffer

    out_close_raw = (out_raw is not sys.stdout.buffer)
    # Buffer all output in memory; flush at the end. Mirrors REF's BufWriter behavior
    # where small outputs aren't visible if the program errors out.
    out_buffer = io.BytesIO()
    if args.try_compress:
        out = gzip.GzipFile(fileobj=out_buffer, mode='wb', compresslevel=args.compression_level)
    else:
        out = out_buffer

    # Determine inputs
    input_files = args.inputs
    if not input_files:
        input_files = [None]  # stdin

    use_headers = bool(args.header_field) or bool(args.exclude_header)

    for inp in input_files:
        if inp is None or inp == '-':
            stream = sys.stdin.buffer
        else:
            try:
                stream = open_input(inp, args.try_decompress)
            except OSError as e:
                err_log(format_os_error(e))
                sys.exit(1)

        try:
            try:
                data = stream.read()
            except (gzip.BadGzipFile, EOFError) as e:
                err_log("unexpected end of file")
                sys.exit(1)
            except OSError as e:
                err_log(format_os_error(e))
                sys.exit(1)
            except Exception as e:
                err_log(str(e))
                sys.exit(1)

            if isinstance(data, str):
                data = data.encode('utf-8', errors='surrogateescape')

            raw_delim_len = len(delim_input.encode('utf-8', errors='surrogateescape'))
            single_byte_lit = (args.delim_is_literal and raw_delim_len == 1)

            # Determine body portion (data after the header line, if -F/-E used)
            if use_headers:
                first_nl = data.find(b'\n')
                if first_nl == -1:
                    body_data = b''
                else:
                    body_data = data[first_nl + 1:]
            else:
                body_data = data

            # The fast single-byte parser is used only when the output field order
            # is ascending (no reordering). That parser has the "invalid data" bug.
            # The ascending check uses the RAW selectors (before range reduction).
            output_is_ascending = True
            if field_ranges_raw is not None:
                last_start = 0
                for (s, e) in field_ranges_raw:
                    if s is None:
                        continue
                    if s < last_start:
                        output_is_ascending = False
                        break
                    last_start = s

            def check_body_errors():
                # -L single-byte literal delim, non-CRLF, ascending output:
                # the fast parser requires a trailing \n on non-empty body.
                if (single_byte_lit and not args.crlf and output_is_ascending
                        and len(body_data) > 0 and not body_data.endswith(b'\n')):
                    err_log("invalid data")
                    sys.exit(1)
                # Reference-specific panic: -L single-byte delim, ascending output,
                # non-CRLF, body starts with delim.
                if (single_byte_lit and not args.crlf and output_is_ascending
                        and len(body_data) > 0
                        and would_panic_on_leading_delim(body_data, delim_lit_bytes[0], args,
                                                          False, field_ranges, exclude_ranges)):
                    sys.stderr.write("\nthread 'main' panicked at /workspace/src/lib/single_byte_delim_parser.rs:84:57:\nattempted to index slice up to maximum usize\nnote: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n")
                    sys.stderr.flush()
                    if args.try_compress:
                        out.close()
                    out_raw.write(out_buffer.getvalue())
                    out_raw.flush()
                    sys.exit(101)

            if not use_headers:
                check_body_errors()

            lines = read_lines_from_bytes(data, args.crlf)

            # Process per-file header if needed
            file_F_list = None
            file_excl_header_set = set()

            if use_headers:
                # Read first line as header
                try:
                    header_line = next(lines)
                except StopIteration:
                    if args.header_field:
                        # If regex mode and any pattern matches the empty string, treat as OK
                        if args.header_is_regex:
                            any_matches_empty = False
                            for sel in args.header_field:
                                try:
                                    if re.compile(sel).search(""):
                                        any_matches_empty = True
                                        break
                                except re.error:
                                    pass
                            if any_matches_empty:
                                continue
                        err_log("No headers matched")
                        sys.exit(1)
                    continue

                # Split header line
                if delim_re_compiled is not None:
                    header_fields_bytes = delim_re_compiled.split(header_line)
                else:
                    header_fields_bytes = split_literal_bytes(header_line, delim_lit_bytes)

                header_fields = [b.decode('utf-8', errors='surrogateescape') for b in header_fields_bytes]

                # Determine field indices
                if args.header_field:
                    selected, sel_err = select_headers(header_fields, args.header_field, args.header_is_regex)
                    if sel_err is not None:
                        kind, val = sel_err
                        if kind == 'not_found':
                            err_log(f"Header not found: {val}")
                            sys.exit(1)
                    if not selected:
                        err_log("No headers matched")
                        sys.exit(1)
                else:
                    # Use all
                    selected = list(range(len(header_fields)))

                # Apply exclude headers
                if args.exclude_header:
                    excluded = exclude_headers(header_fields, args.exclude_header, args.header_is_regex)
                    selected = [i for i in selected if i not in excluded]

                # Determine indices for this file (saved for body lines).
                file_F_list = selected if args.header_field else None
                file_excl_header_set = set()
                if args.exclude_header:
                    file_excl_header_set = exclude_headers(header_fields, args.exclude_header, args.header_is_regex)

                # After the header line passes, check body-data errors (-L invalid data / panic)
                check_body_errors()

                # If the effective output field set is structurally empty, emit nothing.
                if keep_set_is_empty(file_F_list, field_ranges, exclude_ranges, file_excl_header_set):
                    continue

                # Write the header line (an empty header line is consumed but not echoed)
                if len(header_line) > 0:
                    indices = compute_indices(
                        n_fields=len(header_fields_bytes),
                        F_list=file_F_list,
                        field_ranges=field_ranges,
                        exclude_ranges=exclude_ranges,
                        exclude_header_set=file_excl_header_set,
                    )
                    write_fields(out, header_fields_bytes, indices, out_delim, line_term)
            else:
                # No headers: check static emptiness once
                if keep_set_is_empty(None, field_ranges, exclude_ranges, set()):
                    continue

            for raw_line in lines:
                if delim_re_compiled is not None:
                    fields_bytes = delim_re_compiled.split(raw_line)
                else:
                    fields_bytes = split_literal_bytes(raw_line, delim_lit_bytes)

                n = len(fields_bytes)
                indices = compute_indices(
                    n_fields=n,
                    F_list=(file_F_list if use_headers else None),
                    field_ranges=field_ranges,
                    exclude_ranges=exclude_ranges,
                    exclude_header_set=(file_excl_header_set if use_headers else set()),
                )

                write_fields(out, fields_bytes, indices, out_delim, line_term)
        finally:
            if stream is not sys.stdin.buffer:
                stream.close()

    if args.try_compress:
        out.close()
    # Flush buffered output to the real destination
    out_raw.write(out_buffer.getvalue())
    out_raw.flush()
    if out_close_raw:
        out_raw.close()


def write_fields(out, fields_bytes, indices, out_delim, line_term):
    """Write the selected fields joined by out_delim, then line_term."""
    n = len(fields_bytes)
    parts = []
    for i in indices:
        if 0 <= i < n:
            parts.append(fields_bytes[i])
    out.write(out_delim.join(parts))
    out.write(line_term)


def compute_indices(n_fields, F_list=None, field_ranges=None, exclude_ranges=None, exclude_header_set=None):
    """Compute the 0-based output indices for a line of n_fields fields.
    F_list: list of 0-based header indices in -F selector order (None if -F not used).
    field_ranges: list of reduced (start, end) ranges from -f (None if -f not used).
    exclude_ranges: list of (start, end) ranges from -e (None if -e not used).
    exclude_header_set: set of 0-based indices to exclude from -E.
    """
    if exclude_header_set is None:
        exclude_header_set = set()

    # Build the f_list (0-based) from field_ranges
    if field_ranges is not None:
        f_indices_1based = ranges_to_indices(field_ranges, n_fields)
        f_list = [i for i in f_indices_1based]  # already 0-based via ranges_to_indices
    else:
        f_list = None

    # Build exclude set (from -e)
    exclude_set = set()
    if exclude_ranges is not None:
        e_indices = ranges_to_indices(exclude_ranges, n_fields)
        exclude_set = set(e_indices)
    # Add exclude_header_set
    exclude_set |= exclude_header_set

    # Case: no -F, no -f
    if F_list is None and f_list is None:
        # Output all fields (minus excludes)
        result = [i for i in range(n_fields) if i not in exclude_set]
        return result

    # Case: -F only (no -f)
    if F_list is not None and f_list is None:
        return [i for i in F_list if i < n_fields and i not in exclude_set]

    # Case: -f only (no -F)
    if F_list is None and f_list is not None:
        return [i for i in f_list if i not in exclude_set]

    # Case: both -F and -f
    F_set = set(F_list)
    f_set = set(f_list) - F_set
    F_pos = 0
    f_pos = 0
    printed = set()
    output = []

    for i in range(n_fields):
        if i in exclude_set:
            continue
        if i in F_set:
            # Skip already-printed F items
            while F_pos < len(F_list) and (F_list[F_pos] in printed or F_list[F_pos] in exclude_set):
                F_pos += 1
            if F_pos < len(F_list) and F_list[F_pos] == i:
                output.append(i)
                printed.add(i)
                F_pos += 1
        elif i in f_set:
            while f_pos < len(f_list) and (f_list[f_pos] in printed or f_list[f_pos] in exclude_set or f_list[f_pos] in F_set):
                f_pos += 1
            if f_pos < len(f_list) and f_list[f_pos] == i:
                output.append(i)
                printed.add(i)
                f_pos += 1

    # Remaining F items
    while F_pos < len(F_list):
        idx = F_list[F_pos]
        if idx < n_fields and idx not in printed and idx not in exclude_set:
            output.append(idx)
            printed.add(idx)
        F_pos += 1

    # Remaining f items
    while f_pos < len(f_list):
        idx = f_list[f_pos]
        if idx < n_fields and idx not in printed and idx not in exclude_set and idx not in F_set:
            output.append(idx)
            printed.add(idx)
        f_pos += 1

    return output


if __name__ == '__main__':
    try:
        main()
    except BrokenPipeError:
        try:
            sys.stdout.flush()
        except BrokenPipeError:
            pass
        sys.exit(0)
    except KeyboardInterrupt:
        sys.exit(130)
