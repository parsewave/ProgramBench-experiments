#!/bin/sh
set -e
cd "$(dirname "$0")"
gcc -O2 -std=c99 -Wall -Wextra -Wno-unused-parameter -o executable main.c blake3.c
