#!/bin/bash
# Big differential sweep
REF=/workspace/executable
SUT=./executable
PASS=0
FAIL=0
FAILS=""

# Test runner: compares stdout, stderr, exit code separately
diff_cmd() {
    local desc="$1"
    shift
    local stdin_file="$1"
    shift
    local ref_stdout sut_stdout ref_stderr sut_stderr ref_exit sut_exit
    if [ -z "$stdin_file" ]; then stdin_file=/dev/null; fi
    $REF "$@" < "$stdin_file" 1>/tmp/refout 2>/tmp/referr
    ref_exit=$?
    $SUT "$@" < "$stdin_file" 1>/tmp/sutout 2>/tmp/suterr
    sut_exit=$?
    ref_stdout=$(cat /tmp/refout)
    sut_stdout=$(cat /tmp/sutout)
    ref_stderr=$(cat /tmp/referr)
    sut_stderr=$(cat /tmp/suterr)
    local ok=1
    if ! cmp -s /tmp/refout /tmp/sutout; then ok=0; fi
    if ! cmp -s /tmp/referr /tmp/suterr; then ok=0; fi
    if [ "$ref_exit" != "$sut_exit" ]; then ok=0; fi
    if [ $ok -eq 1 ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILS="$FAILS\n=== $desc ($*) ==="
        if ! cmp -s /tmp/refout /tmp/sutout; then
            FAILS="$FAILS\n  STDOUT diff (- ref, + sut):"
            FAILS="$FAILS\n$(diff /tmp/refout /tmp/sutout | head -10)"
        fi
        if ! cmp -s /tmp/referr /tmp/suterr; then
            FAILS="$FAILS\n  STDERR diff (- ref, + sut):"
            FAILS="$FAILS\n$(diff /tmp/referr /tmp/suterr | head -10)"
        fi
        if [ "$ref_exit" != "$sut_exit" ]; then FAILS="$FAILS\n  EXIT diff: ref=$ref_exit sut=$sut_exit"; fi
    fi
}

# === Hash mode ===
diff_cmd "no args empty stdin" /dev/null
diff_cmd "abc stdin" <(printf 'abc') /dev/stdin
echo "abc" > /tmp/stdin_abc
diff_cmd "abc stdin via file" /tmp/stdin_abc

# Boundary sizes from goldens
for size in 0 1 2 3 63 64 65 127 128 255 256 511 512 1023 1024 1025 2047 2048 2049 4096 8192 8193 16383 16384 16385 65536; do
  diff_cmd "size=$size" "" goldens/inputs/sz_$size.bin
done

# Multi-file
diff_cmd "two files" "" goldens/inputs/sz_0.bin goldens/inputs/sz_1024.bin
diff_cmd "three files" "" goldens/inputs/sz_0.bin goldens/inputs/sz_1.bin goldens/inputs/sz_64.bin
diff_cmd "missing files" "" /nope1 /nope2
diff_cmd "mix existence" "" goldens/inputs/sz_64.bin /nope goldens/inputs/sz_1.bin

# Flags: --no-names, --tag, --length, --seek
diff_cmd "--no-names" "" --no-names goldens/inputs/sz_64.bin
diff_cmd "--tag" "" --tag goldens/inputs/sz_64.bin
diff_cmd "--length 1" "" --length 1 goldens/inputs/sz_64.bin
diff_cmd "--length 0" "" --length 0 goldens/inputs/sz_64.bin
diff_cmd "--length 64" "" --length 64 goldens/inputs/sz_64.bin
diff_cmd "--length 1000" "" --length 1000 goldens/inputs/sz_64.bin
diff_cmd "--seek 32 length 32" "" --seek 32 --length 32 goldens/inputs/sz_64.bin
diff_cmd "--seek 999999 length 100" "" --seek 999999 --length 100 goldens/inputs/sz_64.bin
diff_cmd "--no-names --tag" "" --no-names --tag goldens/inputs/sz_64.bin
diff_cmd "--tag --no-names" "" --tag --no-names goldens/inputs/sz_64.bin
diff_cmd "-l 16" "" -l 16 goldens/inputs/sz_64.bin
diff_cmd "-l16" "" -l16 goldens/inputs/sz_64.bin
diff_cmd "--length=16" "" --length=16 goldens/inputs/sz_64.bin

# --raw
diff_cmd "--raw single" "" --raw goldens/inputs/sz_64.bin
diff_cmd "--raw stdin" "/dev/null" --raw
diff_cmd "--raw two files (err)" "" --raw goldens/inputs/sz_64.bin goldens/inputs/sz_1.bin
diff_cmd "--raw --length 16" "" --raw --length 16 goldens/inputs/sz_64.bin

# --keyed
KEY=/tmp/zerokey32.bin
head -c 32 /dev/zero > $KEY
diff_cmd "--keyed zerokey" "$KEY" --keyed goldens/inputs/sz_64.bin
diff_cmd "--keyed 1024" "$KEY" --keyed goldens/inputs/sz_1024.bin
diff_cmd "--keyed empty" "$KEY" --keyed goldens/inputs/sz_0.bin

# keyed errors
echo "" > /tmp/empty.bin
diff_cmd "--keyed no key" "/tmp/empty.bin" --keyed goldens/inputs/sz_64.bin
head -c 16 /dev/zero > /tmp/short_key.bin
diff_cmd "--keyed short" "/tmp/short_key.bin" --keyed goldens/inputs/sz_64.bin
head -c 40 /dev/zero > /tmp/long_key.bin
diff_cmd "--keyed long" "/tmp/long_key.bin" --keyed goldens/inputs/sz_64.bin
diff_cmd "--keyed no file" "$KEY" --keyed

# --derive-key
printf 'material' > /tmp/material.bin
diff_cmd "--derive-key ctx file" "" --derive-key "BLAKE3" /tmp/material.bin
diff_cmd "--derive-key empty file" "" --derive-key "" /tmp/material.bin
diff_cmd "--derive-key from stdin" "/tmp/material.bin" --derive-key "ctx"
diff_cmd "--derive-key=ctx" "/tmp/material.bin" --derive-key=ctx

# --check
$REF /tmp/abc.txt > /tmp/sums_abc.txt
diff_cmd "--check OK" "" -c /tmp/sums_abc.txt
diff_cmd "-c OK" "" -c /tmp/sums_abc.txt
diff_cmd "--check --quiet" "" -c --quiet /tmp/sums_abc.txt
printf '0000000000000000000000000000000000000000000000000000000000000000  /tmp/abc.txt\n' > /tmp/sums_wrong.txt
diff_cmd "--check mismatch" "" -c /tmp/sums_wrong.txt
printf '6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85  /tmp/no_such\n' > /tmp/sums_missing.txt
diff_cmd "--check missing" "" -c /tmp/sums_missing.txt
printf 'XXXX  /tmp/abc.txt\n' > /tmp/sums_short.txt
diff_cmd "--check short hash" "" -c /tmp/sums_short.txt
printf 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  /tmp/abc.txt\n' > /tmp/sums_badhex.txt
diff_cmd "--check badhex" "" -c /tmp/sums_badhex.txt
printf '\n' > /tmp/sums_empty.txt
diff_cmd "--check empty line" "" -c /tmp/sums_empty.txt
printf 'asdf\n' > /tmp/sums_bad.txt
diff_cmd "--check bad fmt" "" -c /tmp/sums_bad.txt
$REF --tag /tmp/abc.txt > /tmp/sums_tag.txt
diff_cmd "--check tag fmt" "" -c /tmp/sums_tag.txt
diff_cmd "--check via stdin" "/tmp/sums_abc.txt" -c
diff_cmd "--check via -" "/tmp/sums_abc.txt" -c -
diff_cmd "--check empty stdin" "/dev/null" -c
diff_cmd "--check missing checkfile" "" -c /tmp/sums_no_such_file_xyz
diff_cmd "--check directory" "" -c /tmp

# Error cases
diff_cmd "--bogus" "" --bogus
diff_cmd "-X" "" -X
diff_cmd "--length missing" "" --length
diff_cmd "--length=empty" "" --length=
diff_cmd "--length -1" "" --length -1
diff_cmd "--length 1.5" "" --length 1.5
diff_cmd "--length 18446744073709551616" "" --length 18446744073709551616
diff_cmd "directory file" "" /tmp
diff_cmd "--check conflict --length" "" --check --length 16 /tmp/sums_abc.txt
diff_cmd "--length first then check" "" --length 16 --check /tmp/sums_abc.txt
diff_cmd "--check + --raw" "" -c --raw /tmp/sums_abc.txt
diff_cmd "--keyed + --derive-key" "" --keyed --derive-key x /tmp/abc.txt
diff_cmd "--quiet alone" "" --quiet
diff_cmd "--check + --no-names" "" -c --no-names /tmp/sums_abc.txt
diff_cmd "--check + --tag" "" -c --tag /tmp/sums_abc.txt
diff_cmd "--length twice" "" --length 16 --length 32 /tmp/abc.txt

# Help/version
diff_cmd "--help" "" --help
diff_cmd "-h" "" -h
diff_cmd "--version" "" --version
diff_cmd "-V" "" -V

# Special filenames
printf 'data' > "/tmp/\backslash"
diff_cmd "filename with backslash" "" "/tmp/\backslash"
rm "/tmp/\backslash"
printf 'data' > "/tmp/newline"$'\n'"name"
diff_cmd "filename with newline" "" "/tmp/newline"$'\n'"name"

# stdin marker variations
diff_cmd "abc | b3sum -" "/tmp/abc.txt" -
diff_cmd "no args, content" "/tmp/abc.txt"

echo "PASS=$PASS  FAIL=$FAIL"
echo -e "$FAILS" | head -100
