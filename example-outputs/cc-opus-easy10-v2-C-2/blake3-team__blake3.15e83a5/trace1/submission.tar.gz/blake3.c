#include "blake3.h"
#include <string.h>

static const uint32_t BLAKE3_IV[8] = {
    0x6A09E667u, 0xBB67AE85u, 0x3C6EF372u, 0xA54FF53Au,
    0x510E527Fu, 0x9B05688Cu, 0x1F83D9ABu, 0x5BE0CD19u,
};

static const uint8_t BLAKE3_MSG_SCHEDULE[7][16] = {
    { 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15},
    { 2,  6,  3, 10,  7,  0,  4, 13,  1, 11, 12,  5,  9, 14, 15,  8},
    { 3,  4, 10, 12, 13,  2,  7, 14,  6,  5,  9,  0, 11, 15,  8,  1},
    {10,  7, 12,  9, 14,  3, 13, 15,  4,  0, 11,  2,  5,  8,  1,  6},
    {12, 13,  9, 11, 15, 10, 14,  8,  7,  2,  5,  3,  0,  1,  6,  4},
    { 9, 14, 11,  5,  8, 12, 15,  1, 13,  3,  0, 10,  2,  6,  4,  7},
    {11, 15,  5,  0,  1,  9,  8,  6, 14, 10,  2, 12,  3,  4,  7, 13},
};

static inline uint32_t rotr32(uint32_t x, unsigned n) {
    return (x >> n) | (x << (32 - n));
}

static inline uint32_t load32_le(const uint8_t *p) {
    return (uint32_t)p[0] |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

static inline void store32_le(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

static void g(uint32_t *state, unsigned a, unsigned b, unsigned c, unsigned d,
              uint32_t mx, uint32_t my) {
    state[a] = state[a] + state[b] + mx;
    state[d] = rotr32(state[d] ^ state[a], 16);
    state[c] = state[c] + state[d];
    state[b] = rotr32(state[b] ^ state[c], 12);
    state[a] = state[a] + state[b] + my;
    state[d] = rotr32(state[d] ^ state[a], 8);
    state[c] = state[c] + state[d];
    state[b] = rotr32(state[b] ^ state[c], 7);
}

static void round_fn(uint32_t state[16], const uint32_t *msg, int round) {
    const uint8_t *s = BLAKE3_MSG_SCHEDULE[round];
    g(state, 0, 4,  8, 12, msg[s[0]],  msg[s[1]]);
    g(state, 1, 5,  9, 13, msg[s[2]],  msg[s[3]]);
    g(state, 2, 6, 10, 14, msg[s[4]],  msg[s[5]]);
    g(state, 3, 7, 11, 15, msg[s[6]],  msg[s[7]]);
    g(state, 0, 5, 10, 15, msg[s[8]],  msg[s[9]]);
    g(state, 1, 6, 11, 12, msg[s[10]], msg[s[11]]);
    g(state, 2, 7,  8, 13, msg[s[12]], msg[s[13]]);
    g(state, 3, 4,  9, 14, msg[s[14]], msg[s[15]]);
}

static void compress_pre(uint32_t state[16], const uint32_t cv[8],
                         const uint8_t block[BLAKE3_BLOCK_LEN], uint8_t block_len,
                         uint64_t counter, uint8_t flags) {
    uint32_t msg[16];
    for (int i = 0; i < 16; i++) {
        msg[i] = load32_le(block + i * 4);
    }
    for (int i = 0; i < 8; i++) state[i] = cv[i];
    state[8]  = BLAKE3_IV[0];
    state[9]  = BLAKE3_IV[1];
    state[10] = BLAKE3_IV[2];
    state[11] = BLAKE3_IV[3];
    state[12] = (uint32_t)counter;
    state[13] = (uint32_t)(counter >> 32);
    state[14] = (uint32_t)block_len;
    state[15] = (uint32_t)flags;
    for (int r = 0; r < 7; r++) {
        round_fn(state, msg, r);
    }
}

static void compress_in_place(uint32_t cv[8], const uint8_t block[BLAKE3_BLOCK_LEN],
                              uint8_t block_len, uint64_t counter, uint8_t flags) {
    uint32_t state[16];
    compress_pre(state, cv, block, block_len, counter, flags);
    for (int i = 0; i < 8; i++) cv[i] = state[i] ^ state[i + 8];
}

static void compress_xof(const uint32_t cv[8], const uint8_t block[BLAKE3_BLOCK_LEN],
                         uint8_t block_len, uint64_t counter, uint8_t flags,
                         uint8_t out[BLAKE3_BLOCK_LEN]) {
    uint32_t state[16];
    compress_pre(state, cv, block, block_len, counter, flags);
    for (int i = 0; i < 8; i++) {
        state[i]     ^= state[i + 8];
        state[i + 8] ^= cv[i];
    }
    for (int i = 0; i < 16; i++) {
        store32_le(out + i * 4, state[i]);
    }
}

static void chunk_state_init(blake3_chunk_state *self, const uint32_t key[8], uint8_t flags) {
    memcpy(self->cv, key, 32);
    self->chunk_counter = 0;
    memset(self->buf, 0, BLAKE3_BLOCK_LEN);
    self->buf_len = 0;
    self->blocks_compressed = 0;
    self->flags = flags;
}

static uint8_t chunk_state_maybe_start_flag(const blake3_chunk_state *self) {
    return self->blocks_compressed == 0 ? B3_FLAG_CHUNK_START : 0;
}

static size_t chunk_state_len(const blake3_chunk_state *self) {
    return (size_t)BLAKE3_BLOCK_LEN * (size_t)self->blocks_compressed + (size_t)self->buf_len;
}

static size_t chunk_state_fill_buf(blake3_chunk_state *self, const uint8_t *input, size_t input_len) {
    size_t take = BLAKE3_BLOCK_LEN - (size_t)self->buf_len;
    if (take > input_len) take = input_len;
    memcpy(self->buf + self->buf_len, input, take);
    self->buf_len += (uint8_t)take;
    return take;
}

static void chunk_state_update(blake3_chunk_state *self, const uint8_t *input, size_t input_len) {
    if (self->buf_len > 0) {
        size_t take = chunk_state_fill_buf(self, input, input_len);
        input += take;
        input_len -= take;
        if (input_len > 0) {
            compress_in_place(self->cv, self->buf, BLAKE3_BLOCK_LEN, self->chunk_counter,
                              self->flags | chunk_state_maybe_start_flag(self));
            self->blocks_compressed++;
            self->buf_len = 0;
            memset(self->buf, 0, BLAKE3_BLOCK_LEN);
        }
    }
    while (input_len > BLAKE3_BLOCK_LEN) {
        compress_in_place(self->cv, input, BLAKE3_BLOCK_LEN, self->chunk_counter,
                          self->flags | chunk_state_maybe_start_flag(self));
        self->blocks_compressed++;
        input += BLAKE3_BLOCK_LEN;
        input_len -= BLAKE3_BLOCK_LEN;
    }
    if (input_len > 0) {
        memcpy(self->buf + self->buf_len, input, input_len);
        self->buf_len += (uint8_t)input_len;
    }
}

static void chunk_state_finalize_cv(const blake3_chunk_state *self, uint8_t out_cv[32]) {
    uint32_t cv[8];
    memcpy(cv, self->cv, 32);
    uint8_t flags = self->flags | chunk_state_maybe_start_flag(self) | B3_FLAG_CHUNK_END;
    compress_in_place(cv, self->buf, self->buf_len, self->chunk_counter, flags);
    for (int i = 0; i < 8; i++) store32_le(out_cv + i * 4, cv[i]);
}

static void chunk_state_get_output_params(const blake3_chunk_state *self,
                                          uint32_t cv_out[8],
                                          uint8_t block_out[BLAKE3_BLOCK_LEN],
                                          uint8_t *block_len_out,
                                          uint64_t *counter_out,
                                          uint8_t *flags_out) {
    memcpy(cv_out, self->cv, 32);
    memcpy(block_out, self->buf, BLAKE3_BLOCK_LEN);
    *block_len_out = self->buf_len;
    *counter_out = self->chunk_counter;
    *flags_out = self->flags | chunk_state_maybe_start_flag(self) | B3_FLAG_CHUNK_END;
}

static void parent_cv(const uint8_t left_child[32], const uint8_t right_child[32],
                      const uint32_t key[8], uint8_t base_flags, uint8_t out[32]) {
    uint8_t block[BLAKE3_BLOCK_LEN];
    memcpy(block, left_child, 32);
    memcpy(block + 32, right_child, 32);
    uint32_t cv[8];
    memcpy(cv, key, 32);
    compress_in_place(cv, block, BLAKE3_BLOCK_LEN, 0, base_flags | B3_FLAG_PARENT);
    for (int i = 0; i < 8; i++) store32_le(out + i * 4, cv[i]);
}

static void parent_output_params(const uint8_t left_child[32], const uint8_t right_child[32],
                                  const uint32_t key[8], uint8_t base_flags,
                                  uint32_t cv_out[8],
                                  uint8_t block_out[BLAKE3_BLOCK_LEN],
                                  uint8_t *block_len_out,
                                  uint64_t *counter_out,
                                  uint8_t *flags_out) {
    memcpy(cv_out, key, 32);
    memcpy(block_out, left_child, 32);
    memcpy(block_out + 32, right_child, 32);
    *block_len_out = BLAKE3_BLOCK_LEN;
    *counter_out = 0;
    *flags_out = base_flags | B3_FLAG_PARENT;
}

static void hasher_init_internal(blake3_hasher *self, const uint32_t key[8], uint8_t flags) {
    memcpy(self->key, key, 32);
    chunk_state_init(&self->chunk, key, flags);
    self->cv_stack_len = 0;
}

void blake3_hasher_init(blake3_hasher *self) {
    hasher_init_internal(self, BLAKE3_IV, 0);
}

void blake3_hasher_init_keyed(blake3_hasher *self, const uint8_t key[32]) {
    uint32_t key_words[8];
    for (int i = 0; i < 8; i++) key_words[i] = load32_le(key + i * 4);
    hasher_init_internal(self, key_words, B3_FLAG_KEYED_HASH);
}

void blake3_hasher_init_derive_key(blake3_hasher *self, const char *context) {
    blake3_hasher_init_derive_key_raw(self, context, strlen(context));
}

void blake3_hasher_init_derive_key_raw(blake3_hasher *self, const void *context, size_t context_len) {
    blake3_hasher ctx_hasher;
    hasher_init_internal(&ctx_hasher, BLAKE3_IV, B3_FLAG_DERIVE_KEY_CONTEXT);
    blake3_hasher_update(&ctx_hasher, context, context_len);
    uint8_t context_key[32];
    blake3_hasher_finalize(&ctx_hasher, context_key, 32);

    uint32_t key_words[8];
    for (int i = 0; i < 8; i++) key_words[i] = load32_le(context_key + i * 4);
    hasher_init_internal(self, key_words, B3_FLAG_DERIVE_KEY_MATERIAL);
}

static void hasher_push_cv_and_merge(blake3_hasher *self, const uint8_t cv[32],
                                     uint64_t total_chunks_after) {
    memcpy(self->cv_stack + (size_t)self->cv_stack_len * 32, cv, 32);
    self->cv_stack_len++;

    uint64_t t = total_chunks_after;
    uint8_t base_flags = (uint8_t)(self->chunk.flags &
        (B3_FLAG_KEYED_HASH | B3_FLAG_DERIVE_KEY_CONTEXT | B3_FLAG_DERIVE_KEY_MATERIAL));
    while ((t & 1) == 0 && self->cv_stack_len >= 2) {
        uint8_t parent[32];
        const uint8_t *left = self->cv_stack + ((size_t)self->cv_stack_len - 2) * 32;
        const uint8_t *right = self->cv_stack + ((size_t)self->cv_stack_len - 1) * 32;
        parent_cv(left, right, self->key, base_flags, parent);
        memcpy(self->cv_stack + ((size_t)self->cv_stack_len - 2) * 32, parent, 32);
        self->cv_stack_len--;
        t >>= 1;
    }
}

void blake3_hasher_update(blake3_hasher *self, const void *input, size_t input_len) {
    const uint8_t *bytes = (const uint8_t *)input;

    while (input_len > 0) {
        if (chunk_state_len(&self->chunk) == BLAKE3_CHUNK_LEN) {
            uint8_t cv[32];
            chunk_state_finalize_cv(&self->chunk, cv);
            uint64_t completed = self->chunk.chunk_counter;
            uint8_t saved_flags = self->chunk.flags;
            chunk_state_init(&self->chunk, self->key, saved_flags);
            self->chunk.chunk_counter = completed + 1;
            hasher_push_cv_and_merge(self, cv, completed + 1);
        }
        size_t take = BLAKE3_CHUNK_LEN - chunk_state_len(&self->chunk);
        if (take > input_len) take = input_len;
        chunk_state_update(&self->chunk, bytes, take);
        bytes += take;
        input_len -= take;
    }
}

void blake3_hasher_finalize(const blake3_hasher *self, uint8_t *out, size_t out_len) {
    blake3_hasher_finalize_seek(self, 0, out, out_len);
}

void blake3_hasher_finalize_seek(const blake3_hasher *self, uint64_t seek, uint8_t *out, size_t out_len) {
    uint32_t root_cv[8];
    uint8_t root_block[BLAKE3_BLOCK_LEN];
    uint8_t root_block_len;
    uint64_t root_counter;
    uint8_t root_flags;
    uint8_t base_flags = (uint8_t)(self->chunk.flags &
        (B3_FLAG_KEYED_HASH | B3_FLAG_DERIVE_KEY_CONTEXT | B3_FLAG_DERIVE_KEY_MATERIAL));

    if (self->cv_stack_len == 0) {
        chunk_state_get_output_params(&self->chunk, root_cv, root_block, &root_block_len,
                                      &root_counter, &root_flags);
    } else {
        uint8_t current_cv[32];
        chunk_state_finalize_cv(&self->chunk, current_cv);

        for (int i = (int)self->cv_stack_len - 1; i > 0; i--) {
            uint8_t parent[32];
            const uint8_t *left = self->cv_stack + (size_t)i * 32;
            parent_cv(left, current_cv, self->key, base_flags, parent);
            memcpy(current_cv, parent, 32);
        }
        parent_output_params(self->cv_stack, current_cv, self->key, base_flags,
                             root_cv, root_block, &root_block_len, &root_counter, &root_flags);
    }

    root_flags |= B3_FLAG_ROOT;

    if (out_len == 0) return;

    uint64_t block_counter = seek / (uint64_t)BLAKE3_BLOCK_LEN;
    size_t byte_in_block = (size_t)(seek % (uint64_t)BLAKE3_BLOCK_LEN);
    while (out_len > 0) {
        uint8_t block_out[BLAKE3_BLOCK_LEN];
        compress_xof(root_cv, root_block, root_block_len, block_counter, root_flags, block_out);
        size_t avail = BLAKE3_BLOCK_LEN - byte_in_block;
        size_t take = (avail > out_len) ? out_len : avail;
        memcpy(out, block_out + byte_in_block, take);
        out += take;
        out_len -= take;
        byte_in_block = 0;
        block_counter++;
    }
}
