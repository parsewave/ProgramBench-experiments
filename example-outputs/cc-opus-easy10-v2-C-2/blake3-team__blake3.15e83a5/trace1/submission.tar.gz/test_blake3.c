#include "blake3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void print_hex(const uint8_t *buf, size_t n) {
    for (size_t i = 0; i < n; i++) printf("%02x", buf[i]);
    printf("\n");
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s file [length=32] [seek=0]\n", argv[0]);
        return 1;
    }
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror(argv[1]); return 1; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t *buf = (uint8_t *)malloc(sz > 0 ? sz : 1);
    if (sz > 0) fread(buf, 1, sz, f);
    fclose(f);

    size_t length = argc >= 3 ? (size_t)strtoul(argv[2], NULL, 10) : 32;
    uint64_t seek  = argc >= 4 ? strtoull(argv[3], NULL, 10) : 0;

    blake3_hasher h;
    blake3_hasher_init(&h);
    blake3_hasher_update(&h, buf, (size_t)sz);
    uint8_t *out = (uint8_t *)malloc(length > 0 ? length : 1);
    blake3_hasher_finalize_seek(&h, seek, out, length);
    print_hex(out, length);

    free(buf);
    free(out);
    return 0;
}
