# b3sum 1.8.4 — behavior map

## Modes (mutually exclusive groups)
- HASH (default): hash files or stdin → hex output + filename
- --keyed: same but with 32-byte key from stdin (no longer can read input from stdin)
- --derive-key CTX: derive key from material (input)
- --check / -c: verify checksums from checkfiles
  - --quiet: suppress OK lines (only failures)

## Output formatting flags
- --no-names: omit filename (just hash)
- --raw: write raw output bytes (no hex, no name); only one input allowed; implies --no-names
- --tag: BSD-style `BLAKE3 (FILE) = HASH` format

## Hash output flags
- -l, --length N: number of output bytes (u64; 0 to u64::MAX; default 32)
- --seek N: starting byte offset before hex encoding (u64; default 0)

## Other flags
- --num-threads N: int; ignored at runtime since we're single-threaded
- --no-mmap: ignored
- -h / --help / -V / --version

## CLI conflict matrix (errors with exit 2):
- --keyed + --derive-key
- --check + --keyed
- --check + --derive-key
- --check + --length
- --check + --raw
- --check + --tag
- --check + --no-names
- --quiet without --check
- --raw + multiple inputs (Error: "Only one filename can be provided when using --raw", exit 1)

## Default output format
- normal: `HEXHASH  FILENAME\n` (two spaces between)
- stdin: filename is `-`
- multiple files: one line each
- file with `\` or `\n` or `\r`: line prefixed with `\`, name has `\\`, `\n`, `\r` escapes (tab passes through unchanged)

## Tag output format
- `BLAKE3 (FILENAME) = HEXHASH\n`
- when filename has special chars, line is prefixed with `\` and name is escaped

## --check parsing
- two-space format: `^[\\]?HEX64  FILENAME$`
- BSD/tag format: `^[\\]?BLAKE3 (FILENAME) = HEX64$`
- Hash MUST be exactly 64 hex chars (32 bytes). Other lengths → "Invalid hash length"
- If line starts with `\`, decode `\\`, `\n`, `\r` in filename
- Empty lines: "Empty line" warning (counts as mismatch)
- Parse failures: "Invalid check line format", "Invalid hash length", "Invalid hex", "Empty line"
- CRLF: \r is stripped (also LF, since BufRead lines() strips it)

## --check output
- Match: `FILENAME: OK\n` (FILENAME = raw checkfile filename including `\` prefix and escapes)
- Mismatch (hash wrong): `FILENAME: FAILED\n`
- File read error: `FILENAME: FAILED (Read msg (os error N))\n`
- Each parse error: print "b3sum: ERRORMSG\n" to stderr, counts as a mismatch
- Trailing summary if any mismatches: `b3sum: WARNING: N computed checksum(s) did NOT match\n` (singular if N=1)
- --quiet: skip OK lines, keep FAILED + summary

## Error messages (stderr)
- Per-file error (hash mode): `b3sum: PATH: STRERROR (os error N)`
- Top-level error (check mode load): `Error: STRERROR`
- --keyed short key: `Error: expected 32 key bytes from stdin, found N`
- --keyed long key: `Error: read more than 32 key bytes from stdin`
- --raw multi: `Error: Only one filename can be provided when using --raw`

## Exit codes
- 0: success (or top-level help/version)
- 1: any per-file or check failure (one or more)
- 2: clap argument parse error

## Empty / boundary inputs
- empty: `af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262`
- "abc": `6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85`
- chunks boundary: 1024, 2048, etc. produce different but well-defined hashes
- --length 0: empty hex + 2 spaces + filename (or empty for raw)
- --seek N with N > output: produces correct XOF bytes (no error)
- --seek + --length: emit length bytes starting at seek
- u64::MAX bounds for both length and seek

## Process model
- One-shot: process all args, write output, exit
- No streaming/animation
- Default reads up to EOF on stdin

## Argv[0] handling
- The binary's program name in help/error messages is "executable" (matches argv[0] basename)
- Note: there's no `b3sum` name unless we configured it; this matches what clap does with cmd_name absent

## File reading
- Regular file: read all contents
- "-" or no args (in hash mode): read stdin
- Directory: per-file error "Is a directory (os error 21)" exit 1
- Missing: "No such file or directory (os error 2)" exit 1
