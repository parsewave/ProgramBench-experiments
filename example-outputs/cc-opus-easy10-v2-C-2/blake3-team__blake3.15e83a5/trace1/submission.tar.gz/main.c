#define _GNU_SOURCE
#include "blake3.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

static const char *PROG_NAME = "executable";

static const char *HELP_SHORT =
"Usage: executable [OPTIONS] [FILE]...\n"
"\n"
"Arguments:\n"
"  [FILE]...  Files to hash, or checkfiles to check\n"
"\n"
"Options:\n"
"      --keyed                 Use the keyed mode, reading the 32-byte key from stdin\n"
"      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string\n"
"  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]\n"
"      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]\n"
"      --num-threads <NUM>     The maximum number of threads to use\n"
"      --no-mmap               Disable memory mapping\n"
"      --no-names              Omit filenames in the output\n"
"      --raw                   Write raw output bytes to stdout, rather than hex\n"
"      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n"
"  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them\n"
"      --quiet                 Skip printing OK for each checked file\n"
"  -h, --help                  Print help (see more with '--help')\n"
"  -V, --version               Print version\n";

static const char *HELP_LONG =
"Usage: executable [OPTIONS] [FILE]...\n"
"\n"
"Arguments:\n"
"  [FILE]...\n"
"          Files to hash, or checkfiles to check\n"
"          \n"
"          When no file is given, or when - is given, read standard input.\n"
"\n"
"Options:\n"
"      --keyed\n"
"          Use the keyed mode, reading the 32-byte key from stdin\n"
"\n"
"      --derive-key <CONTEXT>\n"
"          Use the key derivation mode, with the given context string\n"
"          \n"
"          Cannot be used with --keyed.\n"
"\n"
"  -l, --length <LEN>\n"
"          The number of output bytes, before hex encoding\n"
"          \n"
"          [default: 32]\n"
"\n"
"      --seek <SEEK>\n"
"          The starting output byte offset, before hex encoding\n"
"          \n"
"          [default: 0]\n"
"\n"
"      --num-threads <NUM>\n"
"          The maximum number of threads to use\n"
"          \n"
"          By default, this is the number of logical cores. If this flag is omitted, or if its value\n"
"          is 0, RAYON_NUM_THREADS is also respected.\n"
"\n"
"      --no-mmap\n"
"          Disable memory mapping\n"
"          \n"
"          Currently this also disables multithreading.\n"
"\n"
"      --no-names\n"
"          Omit filenames in the output\n"
"\n"
"      --raw\n"
"          Write raw output bytes to stdout, rather than hex\n"
"          \n"
"          --no-names is implied. In this case, only a single input is allowed.\n"
"\n"
"      --tag\n"
"          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n"
"\n"
"  -c, --check\n"
"          Read BLAKE3 sums from the [FILE]s and check them\n"
"\n"
"      --quiet\n"
"          Skip printing OK for each checked file\n"
"          \n"
"          Must be used with --check.\n"
"\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n"
"\n"
"  -V, --version\n"
"          Print version\n";

static const char *VERSION = "b3sum 1.8.4\n";

/* ---------- Flag bookkeeping for argument parser ---------- */
typedef struct {
    int seen;
    int order;   /* argv index when first encountered */
    const char *value;
} flag_state;

typedef struct {
    flag_state keyed;
    flag_state derive_key;
    flag_state length;
    flag_state seek;
    flag_state num_threads;
    flag_state no_mmap;
    flag_state no_names;
    flag_state raw;
    flag_state tag;
    flag_state check;
    flag_state quiet;
    flag_state help;
    flag_state version;
    int help_is_long; /* 1 if first --help was the long form */

    char **files;
    size_t n_files;
    size_t cap_files;
} args_t;

static void add_file(args_t *a, char *f) {
    if (a->n_files == a->cap_files) {
        a->cap_files = a->cap_files ? a->cap_files * 2 : 4;
        a->files = (char **)realloc(a->files, a->cap_files * sizeof(char *));
    }
    a->files[a->n_files++] = f;
}

/* Long flag descriptors. */
typedef struct {
    const char *name;          /* the long option, e.g. "length" */
    int takes_value;           /* 1 if requires a value */
    const char *value_name;    /* e.g. "<LEN>" */
    flag_state *state;
} long_opt;

/* Get pretty name for error messages */
static const char *opt_pretty(const char *name, const char *value_name) {
    static char buf[64];
    if (value_name) {
        snprintf(buf, sizeof(buf), "--%s %s", name, value_name);
    } else {
        snprintf(buf, sizeof(buf), "--%s", name);
    }
    return buf;
}

/* For --keyed (no value): "--keyed". For --length: "--length <LEN>". */
static char* state_pretty(const char *name, const char *value_name, char *buf, size_t buflen) {
    if (value_name) snprintf(buf, buflen, "--%s %s", name, value_name);
    else            snprintf(buf, buflen, "--%s", name);
    return buf;
}

static void print_usage_short(FILE *f) {
    fprintf(f, "Usage: %s [OPTIONS] [FILE]...\n\n", PROG_NAME);
    fprintf(f, "For more information, try '--help'.\n");
}

static void print_usage_for_flag(FILE *f, const char *flag_pretty, const char *file_part) {
    fprintf(f, "Usage: %s %s %s\n\n", PROG_NAME, flag_pretty, file_part);
    fprintf(f, "For more information, try '--help'.\n");
}

static void parse_error_exit(const char *msg) {
    fprintf(stderr, "error: %s\n\n", msg);
    print_usage_short(stderr);
    exit(2);
}

static void parse_error_argument(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    fprintf(stderr, "Usage: %s [OPTIONS] [FILE]...\n\n", PROG_NAME);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

static void parse_error_dup(const char *name, const char *value_name) {
    char p[64];
    state_pretty(name, value_name, p, sizeof(p));
    fprintf(stderr, "error: the argument '%s' cannot be used multiple times\n\n", p);
    print_usage_short(stderr);
    exit(2);
}

static void parse_error_missing_value(const char *name, const char *value_name) {
    char p[64];
    state_pretty(name, value_name, p, sizeof(p));
    fprintf(stderr, "error: a value is required for '%s' but none was supplied\n\n", p);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

static void parse_error_invalid_int(const char *name, const char *value_name,
                                    const char *value, const char *kind) {
    char p[64];
    state_pretty(name, value_name, p, sizeof(p));
    fprintf(stderr, "error: invalid value '%s' for '%s': %s\n\n", value, p, kind);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

static void parse_error_conflict(const char *first_name, const char *first_value,
                                 const char *second_name, const char *second_value) {
    char p1[64], p2[64];
    state_pretty(first_name, first_value, p1, sizeof(p1));
    state_pretty(second_name, second_value, p2, sizeof(p2));
    fprintf(stderr, "error: the argument '%s' cannot be used with '%s'\n\n", p1, p2);
    print_usage_for_flag(stderr, p1, "<FILE>...");
    exit(2);
}

static int set_flag(flag_state *st, int order, const char *value,
                    const char *name, const char *value_name) {
    if (st->seen) {
        parse_error_dup(name, value_name);
    }
    st->seen = 1;
    st->order = order;
    st->value = value;
    return 0;
}

/* Parse unsigned 64-bit, like Rust's u64::from_str. Strict: digits 0-9 only, no sign, no whitespace. */
static int parse_u64(const char *s, uint64_t *out) {
    if (!s || !*s) return -1; /* empty */
    if (s[0] == '+' || s[0] == '-') return -2; /* sign */
    uint64_t v = 0;
    for (const char *p = s; *p; p++) {
        if (*p < '0' || *p > '9') return -3; /* invalid digit */
        uint64_t d = (uint64_t)(*p - '0');
        if (v > (UINT64_MAX - d) / 10) return -4; /* overflow */
        v = v * 10 + d;
    }
    *out = v;
    return 0;
}

static void parse_int_or_die(const char *value, const char *name, const char *value_name,
                             uint64_t *out) {
    if (!value || !*value) {
        parse_error_invalid_int(name, value_name, value ? value : "", "cannot parse integer from empty string");
    }
    if (value[0] == '+' || value[0] == '-') {
        parse_error_invalid_int(name, value_name, value, "invalid digit found in string");
    }
    uint64_t v = 0;
    for (const char *p = value; *p; p++) {
        if (*p < '0' || *p > '9') {
            parse_error_invalid_int(name, value_name, value, "invalid digit found in string");
        }
        uint64_t d = (uint64_t)(*p - '0');
        if (v > (UINT64_MAX - d) / 10) {
            parse_error_invalid_int(name, value_name, value, "number too large to fit in target type");
        }
        v = v * 10 + d;
    }
    *out = v;
}

/* Long options table */
static const long_opt LONG_OPTS_TEMPLATE[] = {
    /* name,           takes_value, value_name,   state-offset (set in setup) */
    { "keyed",          0, NULL,        NULL },
    { "derive-key",     1, "<CONTEXT>", NULL },
    { "length",         1, "<LEN>",     NULL },
    { "seek",           1, "<SEEK>",    NULL },
    { "num-threads",    1, "<NUM>",     NULL },
    { "no-mmap",        0, NULL,        NULL },
    { "no-names",       0, NULL,        NULL },
    { "raw",            0, NULL,        NULL },
    { "tag",            0, NULL,        NULL },
    { "check",          0, NULL,        NULL },
    { "quiet",          0, NULL,        NULL },
    { "help",           0, NULL,        NULL },
    { "version",        0, NULL,        NULL },
    { NULL, 0, NULL, NULL }
};

static void setup_long_opts(long_opt opts[], args_t *args) {
    memcpy(opts, LONG_OPTS_TEMPLATE, sizeof(LONG_OPTS_TEMPLATE));
    /* Wire up state pointers */
    opts[0].state  = &args->keyed;
    opts[1].state  = &args->derive_key;
    opts[2].state  = &args->length;
    opts[3].state  = &args->seek;
    opts[4].state  = &args->num_threads;
    opts[5].state  = &args->no_mmap;
    opts[6].state  = &args->no_names;
    opts[7].state  = &args->raw;
    opts[8].state  = &args->tag;
    opts[9].state  = &args->check;
    opts[10].state = &args->quiet;
    opts[11].state = &args->help;
    opts[12].state = &args->version;
}

static const long_opt *find_long_opt(const long_opt *opts, const char *name) {
    for (int i = 0; opts[i].name; i++) {
        if (strcmp(opts[i].name, name) == 0) return &opts[i];
    }
    return NULL;
}

/* Determine if a given argv token looks like a known short flag (single letter we recognize). */
static int is_known_short(char c) {
    return c == 'h' || c == 'V' || c == 'c' || c == 'l';
}

/* Check if next argv token can be consumed as a flag value or if it's a flag attempt.
 * Returns: 0 = take as value
 *          1 = looks like recognized flag (missing value error)
 *          2 = looks like unknown flag (unexpected argument error)
 */
static int classify_next_value(const long_opt *opts, const char *tok) {
    if (!tok) return 1; /* no next arg */
    if (tok[0] != '-') return 0;
    if (tok[1] == '\0') return 0; /* bare '-' is a value */
    if (tok[0] == '-' && tok[1] == '-') {
        if (tok[2] == '\0') return 1; /* '--' is a separator */
        /* long flag */
        const char *eq = strchr(tok, '=');
        char buf[128];
        size_t nlen = eq ? (size_t)(eq - (tok + 2)) : strlen(tok + 2);
        if (nlen >= sizeof(buf)) return 2;
        memcpy(buf, tok + 2, nlen);
        buf[nlen] = '\0';
        return find_long_opt(opts, buf) ? 1 : 2;
    }
    /* short flag form: -X... */
    return is_known_short(tok[1]) ? 1 : 2;
}

static void parse_long(const long_opt *opts, char **argv, int *idx_ptr, int argc, args_t *args, int *post_dash_dash) {
    char *arg = argv[*idx_ptr];
    /* "--" alone terminates options */
    if (arg[2] == '\0') {
        *post_dash_dash = 1;
        return;
    }
    char *eq = strchr(arg, '=');
    char namebuf[128];
    const char *value = NULL;
    if (eq) {
        size_t nlen = (size_t)(eq - (arg + 2));
        if (nlen >= sizeof(namebuf)) parse_error_argument(arg);
        memcpy(namebuf, arg + 2, nlen);
        namebuf[nlen] = '\0';
        value = eq + 1;
    } else {
        size_t nlen = strlen(arg + 2);
        if (nlen >= sizeof(namebuf)) parse_error_argument(arg);
        memcpy(namebuf, arg + 2, nlen);
        namebuf[nlen] = '\0';
    }

    const long_opt *opt = find_long_opt(opts, namebuf);
    if (!opt) parse_error_argument(arg);

    /* Special handling for help and version: allow duplicates, track form */
    int is_help_or_version = (opt->state == &args->help || opt->state == &args->version);

    if (opt->takes_value) {
        if (!value) {
            /* Take next argv if it's a valid value */
            const char *next = (*idx_ptr + 1 < argc) ? argv[*idx_ptr + 1] : NULL;
            int cls = classify_next_value(opts, next);
            if (cls == 1) {
                parse_error_missing_value(opt->name, opt->value_name);
            } else if (cls == 2) {
                parse_error_argument(next);
            }
            (*idx_ptr)++;
            value = argv[*idx_ptr];
        }
        set_flag(opt->state, *idx_ptr, value, opt->name, opt->value_name);
    } else {
        if (value) {
            /* Booleans don't take values: error */
            char p[64];
            state_pretty(opt->name, NULL, p, sizeof(p));
            fprintf(stderr, "error: unexpected value '%s' for '%s' found; no more were expected\n\n", value, p);
            print_usage_for_flag(stderr, p, "[FILE]...");
            exit(2);
        }
        if (is_help_or_version && opt->state->seen) {
            /* Don't error on duplicates of help/version */
            return;
        }
        set_flag(opt->state, *idx_ptr, NULL, opt->name, opt->value_name);
        if (opt->state == &args->help) {
            args->help_is_long = 1;
        }
    }
}

/* Short option parser. Handles: -h, -V, -c, -l VALUE, -lVALUE.
 * Combined: '-cl3' -> -c -l 3 */
static void parse_short(const long_opt *opts, char **argv, int *idx_ptr, int argc, args_t *args) {
    char *arg = argv[*idx_ptr];
    int j = 1;
    while (arg[j]) {
        char c = arg[j];
        const long_opt *opt = NULL;
        switch (c) {
            case 'h': opt = find_long_opt(opts, "help"); break;
            case 'V': opt = find_long_opt(opts, "version"); break;
            case 'c': opt = find_long_opt(opts, "check"); break;
            case 'l': opt = find_long_opt(opts, "length"); break;
            default: {
                char tmp[4] = {'-', c, 0, 0};
                parse_error_argument(tmp);
            }
        }
        if (opt->takes_value) {
            /* Rest of this argv (after the letter) is the value, or take next argv */
            const char *value;
            if (arg[j + 1]) {
                value = arg + j + 1;
                set_flag(opt->state, *idx_ptr, value, opt->name, opt->value_name);
                return; /* consumed rest of this arg */
            } else {
                const char *next = (*idx_ptr + 1 < argc) ? argv[*idx_ptr + 1] : NULL;
                int cls = classify_next_value(opts, next);
                if (cls == 1) {
                    parse_error_missing_value(opt->name, opt->value_name);
                } else if (cls == 2) {
                    parse_error_argument(next);
                }
                (*idx_ptr)++;
                value = argv[*idx_ptr];
                set_flag(opt->state, *idx_ptr, value, opt->name, opt->value_name);
                return;
            }
        } else {
            int is_help_or_version = (opt->state == &args->help || opt->state == &args->version);
            if (!(is_help_or_version && opt->state->seen)) {
                set_flag(opt->state, *idx_ptr, NULL, opt->name, opt->value_name);
                /* short forms of help (-h) imply short help */
            }
            j++;
        }
    }
}

static void parse_args(int argc, char **argv, args_t *args) {
    long_opt opts[sizeof(LONG_OPTS_TEMPLATE) / sizeof(LONG_OPTS_TEMPLATE[0])];
    setup_long_opts(opts, args);

    int post_dash_dash = 0;
    for (int i = 1; i < argc; i++) {
        char *arg = argv[i];
        if (post_dash_dash) {
            add_file(args, arg);
            continue;
        }
        if (arg[0] == '-' && arg[1] == '-') {
            parse_long(opts, argv, &i, argc, args, &post_dash_dash);
        } else if (arg[0] == '-' && arg[1] != '\0') {
            /* Bare "-" is a positional, otherwise short flag */
            parse_short(opts, argv, &i, argc, args);
        } else {
            /* Positional or "-" */
            add_file(args, arg);
        }
    }
}

/* ---------- Conflict checks (in seen-order, like clap) ---------- */
typedef struct {
    flag_state *first;
    flag_state *second;
    const char *first_name;
    const char *first_value;
    const char *second_name;
    const char *second_value;
} conflict_pair;

static void check_conflict(flag_state *a, const char *an, const char *av,
                           flag_state *b, const char *bn, const char *bv) {
    if (!a->seen || !b->seen) return;
    /* The argument seen first is named first */
    if (a->order < b->order) {
        parse_error_conflict(an, av, bn, bv);
    } else {
        parse_error_conflict(bn, bv, an, av);
    }
}

static void validate(args_t *args) {
    /* --quiet requires --check */
    if (args->quiet.seen && !args->check.seen) {
        fprintf(stderr, "error: the following required arguments were not provided:\n");
        fprintf(stderr, "  --check\n\n");
        if (args->n_files > 0) {
            fprintf(stderr, "Usage: %s --check --quiet <FILE>...\n\n", PROG_NAME);
        } else {
            fprintf(stderr, "Usage: %s --check --quiet [FILE]...\n\n", PROG_NAME);
        }
        fprintf(stderr, "For more information, try '--help'.\n");
        exit(2);
    }

    /* --keyed requires FILE arg (no implicit stdin allowed) */
    if (args->keyed.seen && args->n_files == 0 && !args->check.seen) {
        fprintf(stderr, "error: the following required arguments were not provided:\n");
        fprintf(stderr, "  <FILE>...\n\n");
        fprintf(stderr, "Usage: %s --keyed <FILE>...\n\n", PROG_NAME);
        fprintf(stderr, "For more information, try '--help'.\n");
        exit(2);
    }

    /* Conflicts: --keyed vs --derive-key */
    check_conflict(&args->keyed, "keyed", NULL,
                   &args->derive_key, "derive-key", "<CONTEXT>");

    /* --check conflicts */
    check_conflict(&args->check, "check", NULL, &args->keyed, "keyed", NULL);
    check_conflict(&args->check, "check", NULL, &args->derive_key, "derive-key", "<CONTEXT>");
    check_conflict(&args->check, "check", NULL, &args->length, "length", "<LEN>");
    check_conflict(&args->check, "check", NULL, &args->raw, "raw", NULL);
    check_conflict(&args->check, "check", NULL, &args->tag, "tag", NULL);
    check_conflict(&args->check, "check", NULL, &args->no_names, "no-names", NULL);
}

/* ---------- Filename escaping (for output) ---------- */
static int filename_needs_escape(const char *name) {
    for (const char *p = name; *p; p++) {
        if (*p == '\\' || *p == '\n' || *p == '\r') return 1;
    }
    return 0;
}

static void print_escaped_filename(FILE *f, const char *name) {
    for (const char *p = name; *p; p++) {
        switch (*p) {
            case '\\': fputs("\\\\", f); break;
            case '\n': fputs("\\n", f); break;
            case '\r': fputs("\\r", f); break;
            default: fputc(*p, f);
        }
    }
}

/* ---------- File reading ---------- */
static int read_all_from_fd(int fd, uint8_t **out, size_t *out_len) {
    size_t cap = 65536, len = 0;
    uint8_t *buf = (uint8_t *)malloc(cap);
    if (!buf) return -1;
    for (;;) {
        if (len == cap) {
            cap *= 2;
            uint8_t *nb = (uint8_t *)realloc(buf, cap);
            if (!nb) { free(buf); return -1; }
            buf = nb;
        }
        ssize_t n = read(fd, buf + len, cap - len);
        if (n == 0) break;
        if (n < 0) {
            if (errno == EINTR) continue;
            free(buf);
            return -1;
        }
        len += (size_t)n;
    }
    *out = buf;
    *out_len = len;
    return 0;
}

/* Returns 0 on success, -1 on error (errno set or set_errno). */
static int hash_file_via_path(const char *path, blake3_hasher *h) {
    /* Special-case empty path? clap will pass through whatever was given. */
    struct stat st;
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    if (fstat(fd, &st) == 0 && S_ISDIR(st.st_mode)) {
        close(fd);
        errno = EISDIR;
        return -1;
    }
    uint8_t buf[65536];
    for (;;) {
        ssize_t n = read(fd, buf, sizeof(buf));
        if (n == 0) break;
        if (n < 0) {
            if (errno == EINTR) continue;
            int saved = errno;
            close(fd);
            errno = saved;
            return -1;
        }
        blake3_hasher_update(h, buf, (size_t)n);
    }
    close(fd);
    return 0;
}

static int hash_fd(int fd, blake3_hasher *h) {
    uint8_t buf[65536];
    for (;;) {
        ssize_t n = read(fd, buf, sizeof(buf));
        if (n == 0) return 0;
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        blake3_hasher_update(h, buf, (size_t)n);
    }
}

/* ---------- Output formatting ---------- */
static void emit_hex(FILE *f, const uint8_t *buf, size_t n) {
    static const char hexchars[] = "0123456789abcdef";
    for (size_t i = 0; i < n; i++) {
        fputc(hexchars[(buf[i] >> 4) & 0xf], f);
        fputc(hexchars[buf[i] & 0xf], f);
    }
}

static void emit_line(const char *name, const uint8_t *hash, size_t hash_len,
                      int tag_mode, int no_names) {
    if (no_names) {
        emit_hex(stdout, hash, hash_len);
        fputc('\n', stdout);
        return;
    }
    if (tag_mode) {
        if (filename_needs_escape(name)) fputc('\\', stdout);
        fputs("BLAKE3 (", stdout);
        print_escaped_filename(stdout, name);
        fputs(") = ", stdout);
        emit_hex(stdout, hash, hash_len);
        fputc('\n', stdout);
    } else {
        if (filename_needs_escape(name)) fputc('\\', stdout);
        emit_hex(stdout, hash, hash_len);
        fputs("  ", stdout);
        print_escaped_filename(stdout, name);
        fputc('\n', stdout);
    }
}

/* ---------- Modes ---------- */
static void init_hasher_from_mode(blake3_hasher *h, const args_t *args, const uint8_t key32[32]) {
    if (args->keyed.seen) {
        blake3_hasher_init_keyed(h, key32);
    } else if (args->derive_key.seen) {
        blake3_hasher_init_derive_key(h, args->derive_key.value ? args->derive_key.value : "");
    } else {
        blake3_hasher_init(h);
    }
}

static int read_key_from_stdin(uint8_t key[32]) {
    size_t total = 0;
    uint8_t buf[40];
    while (total < 33) {
        ssize_t n = read(0, buf + total, 33 - total);
        if (n == 0) break;
        if (n < 0) {
            if (errno == EINTR) continue;
            fprintf(stderr, "Error: %s\n", strerror(errno));
            return -1;
        }
        total += (size_t)n;
    }
    if (total > 32) {
        fprintf(stderr, "Error: read more than 32 key bytes from stdin\n");
        return -1;
    }
    if (total < 32) {
        fprintf(stderr, "Error: expected 32 key bytes from stdin, found %zu\n", total);
        return -1;
    }
    memcpy(key, buf, 32);
    return 0;
}

static int do_hash_mode(const args_t *args) {
    uint8_t key[32];
    if (args->keyed.seen) {
        if (read_key_from_stdin(key) < 0) return 1;
    }

    uint64_t length = 32;
    if (args->length.seen) parse_int_or_die(args->length.value, "length", "<LEN>", &length);

    uint64_t seek = 0;
    if (args->seek.seen) parse_int_or_die(args->seek.value, "seek", "<SEEK>", &seek);

    if (args->num_threads.seen) {
        uint64_t nt;
        parse_int_or_die(args->num_threads.value, "num-threads", "<NUM>", &nt);
        /* Ignored at runtime. */
        (void)nt;
    }

    int tag_mode = args->tag.seen;
    int no_names = args->no_names.seen || args->raw.seen;
    int raw = args->raw.seen;

    /* --raw allows only one input */
    if (raw) {
        size_t inputs = args->n_files;
        if (inputs == 0) inputs = 1; /* stdin */
        if (inputs > 1) {
            fprintf(stderr, "Error: Only one filename can be provided when using --raw\n");
            return 1;
        }
    }

    int rc = 0;

    if (args->n_files == 0) {
        /* Read stdin */
        blake3_hasher h;
        init_hasher_from_mode(&h, args, key);
        if (hash_fd(0, &h) < 0) {
            fprintf(stderr, "Error: %s\n", strerror(errno));
            return 1;
        }
        if (raw) {
            uint8_t *out = (uint8_t *)malloc(length > 0 ? (size_t)length : 1);
            blake3_hasher_finalize_seek(&h, seek, out, (size_t)length);
            fwrite(out, 1, (size_t)length, stdout);
            free(out);
        } else {
            size_t out_len = (size_t)length;
            uint8_t *out = (uint8_t *)malloc(out_len > 0 ? out_len : 1);
            blake3_hasher_finalize_seek(&h, seek, out, out_len);
            emit_line("-", out, out_len, tag_mode, no_names);
            free(out);
        }
    } else {
        for (size_t i = 0; i < args->n_files; i++) {
            const char *path = args->files[i];
            blake3_hasher h;
            init_hasher_from_mode(&h, args, key);
            const char *display = path;
            int from_stdin = (strcmp(path, "-") == 0);
            int err = 0;
            if (from_stdin) {
                if (hash_fd(0, &h) < 0) err = errno;
            } else {
                if (hash_file_via_path(path, &h) < 0) err = errno;
            }
            if (err) {
                fprintf(stderr, "%s: %s: %s (os error %d)\n",
                        "b3sum", path, strerror(err), err);
                rc = 1;
                continue;
            }
            if (raw) {
                uint8_t *out = (uint8_t *)malloc(length > 0 ? (size_t)length : 1);
                blake3_hasher_finalize_seek(&h, seek, out, (size_t)length);
                fwrite(out, 1, (size_t)length, stdout);
                free(out);
            } else {
                uint8_t *out = (uint8_t *)malloc((size_t)length > 0 ? (size_t)length : 1);
                blake3_hasher_finalize_seek(&h, seek, out, (size_t)length);
                emit_line(display, out, (size_t)length, tag_mode, no_names);
                free(out);
            }
        }
    }

    return rc;
}

/* ---------- Checkfile parsing & checking ---------- */
static int hexval(int c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

typedef enum {
    LINE_OK_TWO_SPACE,
    LINE_OK_TAG,
    LINE_ERR_EMPTY,
    LINE_ERR_INVALID_FORMAT,
    LINE_ERR_INVALID_HEX,
    LINE_ERR_INVALID_LENGTH,
} parse_result;

/* Parse a single checkfile line.
 * Strips trailing \r if present. Mutates none.
 * Outputs:
 *   - is_escaped (1 if line started with \)
 *   - hash_out: 32 bytes
 *   - file_raw: pointer to encoded filename inside line
 *   - file_decoded: decoded filename (caller must free)
 */
static parse_result parse_check_line(const char *line, size_t line_len,
                                     int *is_escaped_out,
                                     uint8_t hash_out[32],
                                     char **file_decoded_out,
                                     const char **file_raw_start_out,
                                     size_t *file_raw_len_out) {
    /* Drop \r at end */
    if (line_len > 0 && line[line_len - 1] == '\r') line_len--;

    if (line_len == 0) return LINE_ERR_EMPTY;

    int is_escaped = 0;
    size_t off = 0;
    if (line[0] == '\\') { is_escaped = 1; off = 1; }

    *is_escaped_out = is_escaped;

    /* Try tag format first if it starts with "BLAKE3 (" */
    const char *body = line + off;
    size_t body_len = line_len - off;

    int is_tag = (body_len >= 8 && memcmp(body, "BLAKE3 (", 8) == 0);

    const char *hash_str = NULL;
    size_t hash_len = 0;
    const char *fname_start = NULL;
    size_t fname_len = 0;

    if (is_tag) {
        /* find ") = " from the end */
        /* Last occurrence of ") = " followed by hex chars to end */
        if (body_len < 8 + 4 + 1) return LINE_ERR_INVALID_FORMAT;

        /* Search for the LAST occurrence of ") = " in the string.
         * Filename can contain ") = " safely if the suffix doesn't look like hex. */
        ssize_t found_pos = -1;
        for (ssize_t i = (ssize_t)body_len - 4; i >= 8; i--) {
            if (body[i] == ')' && body[i+1] == ' ' && body[i+2] == '=' && body[i+3] == ' ') {
                found_pos = i;
                break;
            }
        }
        if (found_pos < 0) return LINE_ERR_INVALID_FORMAT;

        fname_start = body + 8;
        fname_len = (size_t)found_pos - 8;
        hash_str = body + found_pos + 4;
        hash_len = body_len - (size_t)found_pos - 4;
    } else {
        /* two-space format: HEX64  FILENAME */
        /* Find first "  " (two spaces) */
        ssize_t found_pos = -1;
        for (size_t i = 0; i + 1 < body_len; i++) {
            if (body[i] == ' ' && body[i+1] == ' ') { found_pos = (ssize_t)i; break; }
        }
        if (found_pos < 0) return LINE_ERR_INVALID_FORMAT;

        hash_str = body;
        hash_len = (size_t)found_pos;
        fname_start = body + found_pos + 2;
        fname_len = body_len - (size_t)found_pos - 2;
    }

    /* Validate hash */
    if (hash_len != 64) {
        /* Maybe it's invalid hex char in the hash region? Need to distinguish.
         * The reference says "Invalid hash length" if length not 64, "Invalid hex" if length 64 but non-hex.
         * But what if length is wrong AND content has non-hex? Reference checks length first. */
        return LINE_ERR_INVALID_LENGTH;
    }
    for (size_t i = 0; i < 64; i++) {
        if (hexval((unsigned char)hash_str[i]) < 0) return LINE_ERR_INVALID_HEX;
    }
    for (int i = 0; i < 32; i++) {
        hash_out[i] = (uint8_t)((hexval((unsigned char)hash_str[i*2]) << 4) |
                                hexval((unsigned char)hash_str[i*2 + 1]));
    }

    /* Decode filename: handle escapes if is_escaped */
    char *decoded = (char *)malloc(fname_len + 1);
    if (!decoded) return LINE_ERR_INVALID_FORMAT;
    size_t k = 0;
    if (is_escaped) {
        for (size_t i = 0; i < fname_len; i++) {
            if (fname_start[i] == '\\' && i + 1 < fname_len) {
                char c = fname_start[i+1];
                if (c == '\\') { decoded[k++] = '\\'; i++; }
                else if (c == 'n') { decoded[k++] = '\n'; i++; }
                else if (c == 'r') { decoded[k++] = '\r'; i++; }
                else decoded[k++] = fname_start[i];
            } else {
                decoded[k++] = fname_start[i];
            }
        }
    } else {
        memcpy(decoded, fname_start, fname_len);
        k = fname_len;
    }
    decoded[k] = '\0';

    *file_decoded_out = decoded;
    *file_raw_start_out = fname_start;
    *file_raw_len_out = fname_len;

    return is_tag ? LINE_OK_TAG : LINE_OK_TWO_SPACE;
}

/* For check output: print the raw filename as it appeared in the checkfile (including \ prefix and escapes) */
static void print_raw_filename(FILE *f, int is_escaped, const char *raw, size_t len) {
    if (is_escaped) fputc('\\', f);
    fwrite(raw, 1, len, f);
}

/* Read entire file content via FILE pointer (or stdin) into buffer */
static int read_file_to_buf(const char *path, uint8_t **out, size_t *out_len) {
    int fd;
    int from_stdin = (path == NULL) || (strcmp(path, "-") == 0);
    if (from_stdin) {
        fd = 0;
    } else {
        fd = open(path, O_RDONLY);
        if (fd < 0) return -1;
        struct stat st;
        if (fstat(fd, &st) == 0 && S_ISDIR(st.st_mode)) {
            close(fd);
            errno = EISDIR;
            return -1;
        }
    }
    int rc = read_all_from_fd(fd, out, out_len);
    if (!from_stdin) close(fd);
    return rc;
}

/* Process one checkfile (or stdin if path is "-" or NULL). Returns # of mismatches. */
static int process_checkfile(const char *path, int quiet, int *total_mismatches) {
    uint8_t *contents = NULL;
    size_t total = 0;
    int rc;
    if (path == NULL || strcmp(path, "-") == 0) {
        rc = read_all_from_fd(0, &contents, &total);
        if (rc < 0) {
            int saved = errno;
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(saved), saved);
            return -1;
        }
    } else {
        int fd = open(path, O_RDONLY);
        if (fd < 0) {
            int saved = errno;
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(saved), saved);
            return -1;
        }
        struct stat st;
        if (fstat(fd, &st) == 0 && S_ISDIR(st.st_mode)) {
            close(fd);
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(EISDIR), EISDIR);
            return -1;
        }
        rc = read_all_from_fd(fd, &contents, &total);
        if (rc < 0) {
            int saved = errno;
            close(fd);
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(saved), saved);
            return -1;
        }
        close(fd);
    }

    /* Validate UTF-8: simplified — accept anything ASCII-ish.
     * For matching Rust's strict UTF-8 check, we'd need a full validator.
     * Reference rejects invalid UTF-8 with "Error: stream did not contain valid UTF-8".
     * We'll do a quick check. */
    {
        size_t i = 0;
        while (i < total) {
            unsigned char c = contents[i];
            if (c < 0x80) { i++; continue; }
            int extra;
            if ((c & 0xE0) == 0xC0) extra = 1;
            else if ((c & 0xF0) == 0xE0) extra = 2;
            else if ((c & 0xF8) == 0xF0) extra = 3;
            else { fprintf(stderr, "Error: stream did not contain valid UTF-8\n"); free(contents); return -1; }
            if (i + extra >= total) {
                fprintf(stderr, "Error: stream did not contain valid UTF-8\n"); free(contents); return -1;
            }
            for (int j = 1; j <= extra; j++) {
                if ((contents[i+j] & 0xC0) != 0x80) {
                    fprintf(stderr, "Error: stream did not contain valid UTF-8\n"); free(contents); return -1;
                }
            }
            i += extra + 1;
        }
    }

    /* Iterate lines */
    size_t pos = 0;
    while (pos < total) {
        size_t end = pos;
        while (end < total && contents[end] != '\n') end++;

        const char *line = (const char *)contents + pos;
        size_t line_len = end - pos;

        int is_escaped = 0;
        uint8_t expected[32];
        char *file_decoded = NULL;
        const char *raw_fname = NULL;
        size_t raw_fname_len = 0;

        parse_result pr = parse_check_line(line, line_len, &is_escaped, expected,
                                           &file_decoded, &raw_fname, &raw_fname_len);
        switch (pr) {
            case LINE_ERR_EMPTY:
                fprintf(stderr, "b3sum: Empty line\n");
                (*total_mismatches)++;
                break;
            case LINE_ERR_INVALID_FORMAT:
                fprintf(stderr, "b3sum: Invalid check line format\n");
                (*total_mismatches)++;
                break;
            case LINE_ERR_INVALID_HEX:
                fprintf(stderr, "b3sum: Invalid hex\n");
                (*total_mismatches)++;
                break;
            case LINE_ERR_INVALID_LENGTH:
                fprintf(stderr, "b3sum: Invalid hash length\n");
                (*total_mismatches)++;
                break;
            case LINE_OK_TWO_SPACE:
            case LINE_OK_TAG: {
                if (file_decoded[0] == '\0') {
                    fprintf(stderr, "b3sum: empty file path\n");
                    (*total_mismatches)++;
                    free(file_decoded);
                    break;
                }
                /* Hash the file at file_decoded */
                blake3_hasher h;
                blake3_hasher_init(&h);
                int err = 0;
                int from_stdin = (strcmp(file_decoded, "-") == 0);
                if (from_stdin) {
                    if (hash_fd(0, &h) < 0) err = errno;
                } else {
                    if (hash_file_via_path(file_decoded, &h) < 0) err = errno;
                }

                if (err) {
                    /* FAILED with reason */
                    print_raw_filename(stdout, is_escaped, raw_fname, raw_fname_len);
                    printf(": FAILED (%s (os error %d))\n", strerror(err), err);
                    (*total_mismatches)++;
                } else {
                    uint8_t got[32];
                    blake3_hasher_finalize(&h, got, 32);
                    if (memcmp(got, expected, 32) == 0) {
                        if (!quiet) {
                            print_raw_filename(stdout, is_escaped, raw_fname, raw_fname_len);
                            printf(": OK\n");
                        }
                    } else {
                        print_raw_filename(stdout, is_escaped, raw_fname, raw_fname_len);
                        printf(": FAILED\n");
                        (*total_mismatches)++;
                    }
                }
                free(file_decoded);
                break;
            }
        }

        pos = end < total ? end + 1 : end;
    }

    free(contents);
    return 0;
}

static int do_check_mode(const args_t *args) {
    int total_mismatches = 0;
    int load_error = 0;
    int quiet = args->quiet.seen;

    if (args->n_files == 0) {
        if (process_checkfile(NULL, quiet, &total_mismatches) < 0) {
            load_error = 1;
        }
    } else {
        for (size_t i = 0; i < args->n_files; i++) {
            if (process_checkfile(args->files[i], quiet, &total_mismatches) < 0) {
                load_error = 1;
                break;
            }
        }
    }

    if (load_error) return 1;

    if (total_mismatches > 0) {
        if (total_mismatches == 1) {
            fprintf(stderr, "b3sum: WARNING: 1 computed checksum did NOT match\n");
        } else {
            fprintf(stderr, "b3sum: WARNING: %d computed checksums did NOT match\n", total_mismatches);
        }
        return 1;
    }
    return 0;
}

/* ---------- Main ---------- */
int main(int argc, char *argv[]) {
    setvbuf(stdout, NULL, _IOLBF, 0);

    args_t args;
    memset(&args, 0, sizeof(args));

    parse_args(argc, argv, &args);

    if (args.help.seen && args.version.seen) {
        if (args.help.order < args.version.order) {
            fputs(args.help_is_long ? HELP_LONG : HELP_SHORT, stdout);
            return 0;
        }
        fputs(VERSION, stdout);
        return 0;
    }
    if (args.help.seen) {
        fputs(args.help_is_long ? HELP_LONG : HELP_SHORT, stdout);
        return 0;
    }
    if (args.version.seen) {
        fputs(VERSION, stdout);
        return 0;
    }

    validate(&args);

    if (args.check.seen) {
        return do_check_mode(&args);
    }
    return do_hash_mode(&args);
}
