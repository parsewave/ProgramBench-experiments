#include "blake3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void print_hex(const uint8_t *buf, size_t n) {
    for (size_t i = 0; i < n; i++) printf("%02x", buf[i]);
    printf("\n");
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s keyed|derive arg file\n", argv[0]);
        return 1;
    }
    FILE *f = fopen(argv[3], "rb");
    if (!f) { perror(argv[3]); return 1; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t *buf = (uint8_t *)malloc(sz > 0 ? sz : 1);
    if (sz > 0) fread(buf, 1, sz, f);
    fclose(f);

    blake3_hasher h;
    if (strcmp(argv[1], "keyed") == 0) {
        FILE *kf = fopen(argv[2], "rb");
        uint8_t key[32];
        fread(key, 1, 32, kf);
        fclose(kf);
        blake3_hasher_init_keyed(&h, key);
    } else {
        blake3_hasher_init_derive_key(&h, argv[2]);
    }
    blake3_hasher_update(&h, buf, (size_t)sz);
    uint8_t out[32];
    blake3_hasher_finalize(&h, out, 32);
    print_hex(out, 32);

    free(buf);
    return 0;
}
