#!/bin/bash
# Differential test: compare reference vs our executable on many probes
REF=/workspace/executable
SUT=./executable
PASS=0
FAIL=0
FAILS=""

run_diff() {
    local desc="$1"
    shift
    local ref_stdout ref_stderr ref_exit sut_stdout sut_stderr sut_exit
    if [ -n "$INPUT" ]; then
        ref_stdout=$($REF "$@" 2>/tmp/ref_err <<<"$INPUT"); ref_exit=$?
        sut_stdout=$($SUT "$@" 2>/tmp/sut_err <<<"$INPUT"); sut_exit=$?
    else
        ref_stdout=$($REF "$@" 2>/tmp/ref_err </dev/null); ref_exit=$?
        sut_stdout=$($SUT "$@" 2>/tmp/sut_err </dev/null); sut_exit=$?
    fi
    ref_stderr=$(cat /tmp/ref_err)
    sut_stderr=$(cat /tmp/sut_err)
    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_stderr" = "$sut_stderr" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILS="$FAILS\n=== $desc ($*) ==="
        if [ "$ref_stdout" != "$sut_stdout" ]; then FAILS="$FAILS\n  STDOUT diff: ref=$(echo "$ref_stdout" | head -c200)  sut=$(echo "$sut_stdout" | head -c200)"; fi
        if [ "$ref_stderr" != "$sut_stderr" ]; then FAILS="$FAILS\n  STDERR diff: ref=$(echo "$ref_stderr" | head -c200)  sut=$(echo "$sut_stderr" | head -c200)"; fi
        if [ "$ref_exit" != "$sut_exit" ]; then FAILS="$FAILS\n  EXIT diff: ref=$ref_exit sut=$sut_exit"; fi
    fi
}

# Hash tests
INPUT="abc" run_diff "abc stdin"
INPUT="" run_diff "empty stdin"
INPUT="abc" run_diff "abc with -" -
INPUT="" run_diff "empty with --" --

# Files
printf 'abc' > /tmp/abc.txt
printf 'hello' > /tmp/hello.txt
printf '' > /tmp/empty.txt

run_diff "single file" /tmp/abc.txt
run_diff "two files" /tmp/abc.txt /tmp/hello.txt
run_diff "empty file" /tmp/empty.txt
run_diff "missing file" /tmp/no_such_file_xyzqq
run_diff "mixed success/missing" /tmp/abc.txt /tmp/no_such /tmp/hello.txt

# Flags
run_diff "--no-names" --no-names /tmp/abc.txt
run_diff "--tag" --tag /tmp/abc.txt
run_diff "--tag --no-names" --tag --no-names /tmp/abc.txt
run_diff "--length 16" --length 16 /tmp/abc.txt
run_diff "--length 64" --length 64 /tmp/abc.txt
run_diff "--length 0" --length 0 /tmp/abc.txt
run_diff "--length 1" --length 1 /tmp/abc.txt
run_diff "--length 100" --length 100 /tmp/abc.txt
run_diff "--seek 5" --seek 5 /tmp/abc.txt
run_diff "--seek 64 --length 32" --seek 64 --length 32 /tmp/abc.txt
run_diff "--seek 999999 --length 100" --seek 999999 --length 100 /tmp/abc.txt
INPUT="abc" run_diff "--length=16 stdin" --length=16
INPUT="abc" run_diff "-l 16 stdin" -l 16
INPUT="abc" run_diff "-l16 stdin" -l16

# Errors
run_diff "unknown flag" --bogus
run_diff "unknown short" -X
run_diff "--length neg" --length -1
run_diff "--length=" --length=
run_diff "--length 1.5" --length 1.5
run_diff "--length missing" --length
run_diff "directory file" /tmp
run_diff "--quiet alone" --quiet

# Big sizes from goldens
for size in 0 1 64 1023 1024 2049 8192 16384 65536; do
    run_diff "size=$size" goldens/inputs/sz_$size.bin
done

# Echo summary
echo "PASS=$PASS  FAIL=$FAIL"
if [ $FAIL -gt 0 ]; then
    echo -e "FAILURES:$FAILS"
fi
