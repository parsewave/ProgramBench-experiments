#!/usr/bin/env python3
"""Statistical top-up: 10 fresh probes from a Markov usage chain.

Markov states represent the discovered modes of code-minimap:
- HELP: --help, -h
- VERSION: --version
- COMPLETION: completion <shell>
- HELP_SUBCMD: help [subcmd]
- RENDER_STDIN: read stdin with various flag combos
- RENDER_FILE: read a file with various flag combos
- ERROR: invalid args
"""
import random
import subprocess
import tempfile
import os

random.seed(99999)

REF = "/workspace/executable"
SUT = "/work/work/executable"

# States with transition probabilities
STATES = {
    "HELP": 0.05,
    "VERSION": 0.05,
    "COMPLETION": 0.10,
    "HELP_SUBCMD": 0.05,
    "RENDER_STDIN": 0.50,
    "RENDER_FILE": 0.15,
    "ERROR": 0.10,
}

SHELLS = ["bash", "zsh", "fish", "elvish", "powershell"]

def gen_input():
    """Generate random text input."""
    kinds = ["src_like", "ascii", "mix_ws", "utf8", "edge"]
    k = random.choice(kinds)
    if k == "src_like":
        n = random.randint(3, 30)
        return "\n".join(
            (" " * random.randint(0, 8)) + random.choice(["", "fn foo() {", "let x = 1;", "return;", "}", "// comment", "if x > 0 {", "for i in 0..n {"])
            for _ in range(n)
        )
    elif k == "ascii":
        return "\n".join("".join(random.choices("abc ", k=random.randint(0, 20))) for _ in range(random.randint(1, 15)))
    elif k == "mix_ws":
        return "\n".join("".join(random.choices(["a", " ", "\t", "b"], k=random.randint(0, 20))) for _ in range(random.randint(1, 10)))
    elif k == "utf8":
        chars = "abcäöü あい中"
        return "\n".join("".join(random.choices(chars, k=random.randint(0, 15))) for _ in range(random.randint(1, 10)))
    elif k == "edge":
        return random.choice(["", "\n", "\n\n\n", " ", "a", "x" * 100])

def gen_args(include_render=True):
    args = []
    if not include_render:
        return args
    if random.random() < 0.6:
        args.extend(["-H", str(random.choice([0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]))])
    if random.random() < 0.6:
        args.extend(["-V", str(random.choice([0.0, 0.1, 0.25, 0.5, 0.75, 1.0]))])
    if random.random() < 0.4:
        args.extend(["--padding", str(random.choice([0, 1, 5, 10, 30]))])
    if random.random() < 0.2:
        args.extend(["--encoding", random.choice(["utf8", "utf8-lossy"])])
    return args

def transition():
    r = random.random()
    cumsum = 0
    for s, p in STATES.items():
        cumsum += p
        if r <= cumsum:
            return s
    return "RENDER_STDIN"

def run_probe(state):
    args = []
    stdin_data = ""
    if state == "HELP":
        args = [random.choice(["--help", "-h"])]
    elif state == "VERSION":
        args = ["--version"]
    elif state == "COMPLETION":
        args = ["completion", random.choice(SHELLS)]
    elif state == "HELP_SUBCMD":
        args = ["help"] + (["completion"] if random.random() < 0.5 else [])
    elif state == "RENDER_STDIN":
        args = gen_args()
        stdin_data = gen_input()
    elif state == "RENDER_FILE":
        # Write to temp file
        text = gen_input()
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
            f.write(text)
            path = f.name
        args = gen_args() + [path]
    elif state == "ERROR":
        choices = [
            ["--foo"],
            ["foo"],
            ["--padding", "abc"],
            ["-H", "xyz"],
            ["completion", "sh"],
            ["completion"],
            ["/tmp/nonexistent_topup.xyz"],
        ]
        args = random.choice(choices)
    return args, stdin_data

# Run 10 probes
results = []
for i in range(10):
    state = transition()
    args, stdin_data = run_probe(state)
    try:
        ref = subprocess.run([REF] + args, input=stdin_data.encode(), capture_output=True, timeout=10)
        sut = subprocess.run([SUT] + args, input=stdin_data.encode(), capture_output=True, timeout=10)
    except subprocess.TimeoutExpired:
        results.append((i, state, args, "TIMEOUT", None, None))
        continue
    ok = ref.returncode == sut.returncode and ref.stdout == sut.stdout and ref.stderr == sut.stderr
    results.append((i, state, args, ok, ref, sut))

print(f"{'Probe':>6} {'State':<15} {'Args':<60} {'Result'}")
all_ok = True
for r in results:
    i, state, args, ok, ref, sut = r
    if ok == "TIMEOUT":
        print(f"{i:>6} {state:<15} {str(args):<60} TIMEOUT")
        all_ok = False
    elif ok:
        print(f"{i:>6} {state:<15} {str(args):<60} PASS")
    else:
        print(f"{i:>6} {state:<15} {str(args):<60} FAIL")
        print(f"  REF: exit={ref.returncode} stdout={ref.stdout[:80]!r} stderr={ref.stderr[:80]!r}")
        print(f"  SUT: exit={sut.returncode} stdout={sut.stdout[:80]!r} stderr={sut.stderr[:80]!r}")
        all_ok = False

print()
print("CERTIFIED" if all_ok else "FAILED")
