#!/usr/bin/env python3
"""Fuzz-style differential test for code-minimap."""
import random
import subprocess
import sys

REF = "/workspace/executable"
SUT = "/work/work/executable"

random.seed(42)

def run(binary, args, stdin):
    p = subprocess.run([binary] + args, input=stdin, capture_output=True, timeout=10)
    return p.returncode, p.stdout, p.stderr

def compare(args, stdin):
    rc_r, so_r, se_r = run(REF, args, stdin)
    rc_s, so_s, se_s = run(SUT, args, stdin)
    if rc_r != rc_s or so_r != so_s or se_r != se_s:
        return False, (rc_r, so_r, se_r), (rc_s, so_s, se_s)
    return True, None, None

def gen_random_text(seed=None):
    if seed is not None:
        random.seed(seed)
    kind = random.choice(["ascii", "spaces", "mixed", "utf8", "long", "lines", "binary"])
    if kind == "ascii":
        return "".join(random.choices("abcdefgh ", k=random.randint(0, 50))).encode()
    elif kind == "spaces":
        n = random.randint(1, 20)
        lines = [" " * random.randint(0, 10) + random.choice(["", "a", "ab", "abc"]) + " " * random.randint(0, 5) for _ in range(n)]
        return "\n".join(lines).encode()
    elif kind == "mixed":
        n = random.randint(1, 10)
        return "\n".join("".join(random.choices("abc \t", k=random.randint(0, 20))) for _ in range(n)).encode()
    elif kind == "utf8":
        chars = "abcäöüß あいう 中文 €£ ñçá"
        return "".join(random.choices(chars, k=random.randint(0, 30))).encode()
    elif kind == "long":
        return ("a" * random.randint(50, 500)).encode()
    elif kind == "lines":
        n = random.randint(1, 50)
        return "\n".join("".join(random.choices("ab.", k=random.randint(0, 10))) for _ in range(n)).encode()
    elif kind == "binary":
        return bytes(random.randint(0, 255) for _ in range(random.randint(0, 30)))

def gen_random_args():
    args = []
    if random.random() < 0.5:
        args.extend(["-H", str(random.choice([0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 10.0]))])
    if random.random() < 0.5:
        args.extend(["-V", str(random.choice([0.0, 0.1, 0.25, 0.5, 0.75, 1.0]))])
    if random.random() < 0.4:
        args.extend(["--padding", str(random.choice([0, 1, 5, 10, 50]))])
    if random.random() < 0.2:
        args.extend(["--encoding", random.choice(["utf8", "utf8-lossy"])])
    return args

n_fail = 0
n_pass = 0
for i in range(500):
    text = gen_random_text()
    args = gen_random_args()
    ok, ref, sut = compare(args, text)
    if ok:
        n_pass += 1
    else:
        n_fail += 1
        if n_fail <= 5:
            print(f"FAIL #{i}: args={args}")
            print(f"  Input ({len(text)} bytes): {text[:80]!r}")
            print(f"  REF: exit={ref[0]} stdout={ref[1][:80]!r} stderr={ref[2][:80]!r}")
            print(f"  SUT: exit={sut[0]} stdout={sut[1][:80]!r} stderr={sut[2][:80]!r}")
            # Find minimal divergence
            r_brl = ref[1]
            s_brl = sut[1]
            if r_brl != s_brl:
                for k in range(min(len(r_brl), len(s_brl))):
                    if r_brl[k] != s_brl[k]:
                        print(f"  First diff at byte {k}: REF={r_brl[k]:02x} SUT={s_brl[k]:02x}")
                        break
                if len(r_brl) != len(s_brl):
                    print(f"  Length differs: REF={len(r_brl)} SUT={len(s_brl)}")

print(f"\nPassed: {n_pass}, Failed: {n_fail}")
