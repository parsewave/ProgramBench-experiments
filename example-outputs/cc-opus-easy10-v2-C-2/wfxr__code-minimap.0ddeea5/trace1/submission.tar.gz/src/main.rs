use clap::{CommandFactory, Parser, Subcommand, ValueEnum, ValueHint};
use clap_complete::{generate, Shell};
use std::fs::File;
use std::io::{self, Read, Write};
use std::process::ExitCode;

#[derive(Parser)]
#[command(
    name = "code-minimap",
    version,
    about = "A high performance code minimap generator",
    long_about = None,
    arg_required_else_help = false,
    next_line_help = true,
    disable_version_flag = true,
)]
struct Cli {
    /// Specify horizontal scale factor
    #[arg(short = 'H', long = "horizontal-scale", value_name = "HSCALE", default_value = "1.0")]
    hscale: f64,

    /// Specify vertical scale factor
    #[arg(short = 'V', long = "vertical-scale", value_name = "VSCALE", default_value = "1.0")]
    vscale: f64,

    /// Specify padding width
    #[arg(long = "padding", value_name = "PADDING")]
    padding: Option<usize>,

    /// Specify input encoding
    #[arg(long = "encoding", value_name = "ENCODING", default_value = "utf8-lossy", value_enum)]
    encoding: Encoding,

    /// Print version
    #[arg(long = "version", action = clap::ArgAction::Version)]
    version: Option<bool>,

    /// File to read
    #[arg(value_hint = ValueHint::FilePath, value_parser = clap::builder::NonEmptyStringValueParser::new())]
    file: Option<String>,

    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Subcommand)]
enum Commands {
    /// Generate shell completion file
    Completion {
        /// Target shell name
        shell: Shell,
    },
}

#[derive(Clone, Copy, ValueEnum, PartialEq)]
enum Encoding {
    #[value(name = "utf8-lossy")]
    Utf8Lossy,
    #[value(name = "utf8")]
    Utf8,
}

fn main() -> ExitCode {
    let cli = Cli::parse();

    if let Some(Commands::Completion { shell }) = cli.command {
        let mut cmd = Cli::command();
        generate(shell, &mut cmd, "code-minimap", &mut io::stdout());
        return ExitCode::SUCCESS;
    }

    // Read input
    let raw: Vec<u8> = if let Some(path) = &cli.file {
        match File::open(path) {
            Ok(mut f) => {
                let mut v = Vec::new();
                if let Err(e) = f.read_to_end(&mut v) {
                    eprintln!("code-minimap: {}", e);
                    return ExitCode::from(1);
                }
                v
            }
            Err(e) => {
                eprintln!("code-minimap: {}", e);
                return ExitCode::from(1);
            }
        }
    } else {
        let mut v = Vec::new();
        if let Err(e) = io::stdin().read_to_end(&mut v) {
            eprintln!("code-minimap: {}", e);
            return ExitCode::from(1);
        }
        v
    };

    let text: String = match cli.encoding {
        Encoding::Utf8 => match std::str::from_utf8(&raw) {
            Ok(s) => s.to_owned(),
            Err(_) => {
                eprintln!("code-minimap: stream did not contain valid UTF-8");
                return ExitCode::from(1);
            }
        },
        Encoding::Utf8Lossy => String::from_utf8_lossy(&raw).into_owned(),
    };

    render(&text, cli.hscale, cli.vscale, cli.padding);
    ExitCode::SUCCESS
}

fn render(text: &str, hscale: f64, vscale: f64, padding: Option<usize>) {
    let lines: Vec<&str> = text.lines().collect();
    if lines.is_empty() {
        return;
    }

    let vscale = vscale.min(1.0);

    let n_lines = lines.len();

    // Compute per-line width and leading whitespace position
    let mut line_widths: Vec<usize> = Vec::with_capacity(n_lines);
    let mut line_leadings: Vec<usize> = Vec::with_capacity(n_lines);

    for line in &lines {
        let trimmed = line.trim_end();
        let width = trimmed
            .char_indices()
            .last()
            .map(|(i, _)| i + 1)
            .unwrap_or(0);
        let leading = trimmed
            .char_indices()
            .find(|(_, c)| !c.is_whitespace())
            .map(|(i, _)| i)
            .unwrap_or(width);
        line_widths.push(width);
        line_leadings.push(leading);
    }

    // Forward V mapping: line idx -> dot row
    let line_dot_rows: Vec<usize> = (0..n_lines)
        .map(|i| ((i as f64) * vscale).floor() as usize)
        .collect();

    let dot_height = line_dot_rows.iter().max().copied().unwrap_or(0) + 1;

    // Per dot row: aggregate max width and min leading across contributing (non-empty) lines
    let mut dot_row_max_width: Vec<usize> = vec![0; dot_height];
    let mut dot_row_min_leading: Vec<usize> = vec![usize::MAX; dot_height];
    for (i, &dr) in line_dot_rows.iter().enumerate() {
        if line_widths[i] > 0 {
            if line_widths[i] > dot_row_max_width[dr] {
                dot_row_max_width[dr] = line_widths[i];
            }
            if line_leadings[i] < dot_row_min_leading[dr] {
                dot_row_min_leading[dr] = line_leadings[i];
            }
        }
    }
    // For dot rows with no content, normalize
    for dr in 0..dot_height {
        if dot_row_min_leading[dr] == usize::MAX {
            dot_row_min_leading[dr] = 0;
        }
    }

    // Precompute per-dot-row dot_mask (bool vec indexed by dot col)
    // Each mask has length = floor(max_width * hscale)
    let mut dot_row_masks: Vec<Vec<bool>> = Vec::with_capacity(dot_height);
    let mut dot_row_dot_widths: Vec<usize> = Vec::with_capacity(dot_height);
    for dr in 0..dot_height {
        let dr_max = dot_row_max_width[dr];
        let dr_lead = dot_row_min_leading[dr];
        let dr_dot_width = ((dr_max as f64) * hscale).floor() as usize;
        let mut mask = vec![false; dr_dot_width];
        if dr_max > 0 {
            for i in dr_lead..dr_max {
                let ds = ((i as f64) * hscale).floor() as usize;
                let de = (((i + 1) as f64) * hscale).floor() as usize;
                for d in ds..de.min(dr_dot_width) {
                    mask[d] = true;
                }
            }
        }
        dot_row_masks.push(mask);
        dot_row_dot_widths.push(dr_dot_width);
    }

    let braille_rows = (dot_height + 3) / 4;

    let stdout = io::stdout();
    let mut out = stdout.lock();

    let mut buf = Vec::with_capacity(8192);

    for brow in 0..braille_rows {
        let dot_row_start = brow * 4;
        let dot_row_end = ((brow + 1) * 4).min(dot_height);

        // Max width across dot rows in this braille row
        let mut row_max_w: usize = 0;
        for dr in dot_row_start..dot_row_end {
            if dot_row_max_width[dr] > row_max_w {
                row_max_w = dot_row_max_width[dr];
            }
        }

        // dot_width for braille row
        let row_dot_width: usize = if row_max_w == 0 {
            // No content in this braille row, but rows exist
            (hscale).floor() as usize
        } else {
            ((row_max_w as f64) * hscale).floor() as usize
        };

        let braille_cols = (row_dot_width + 1) / 2;

        buf.clear();

        for bcol in 0..braille_cols {
            let mut bits: u8 = 0;
            for dy in 0..4 {
                let dot_row = brow * 4 + dy;
                if dot_row >= dot_height {
                    continue;
                }
                let mask = &dot_row_masks[dot_row];
                for dx in 0..2 {
                    let dot_col = bcol * 2 + dx;
                    if dot_col >= row_dot_width {
                        continue;
                    }
                    let on = dot_col < mask.len() && mask[dot_col];
                    if on {
                        let bit = match (dx, dy) {
                            (0, 0) => 0,
                            (0, 1) => 1,
                            (0, 2) => 2,
                            (1, 0) => 3,
                            (1, 1) => 4,
                            (1, 2) => 5,
                            (0, 3) => 6,
                            (1, 3) => 7,
                            _ => unreachable!(),
                        };
                        bits |= 1 << bit;
                    }
                }
            }
            let cp = 0x2800u32 + bits as u32;
            let ch = char::from_u32(cp).unwrap();
            let mut tmp = [0u8; 4];
            buf.extend_from_slice(ch.encode_utf8(&mut tmp).as_bytes());
        }
        if let Some(p) = padding {
            if p > braille_cols {
                for _ in 0..(p - braille_cols) {
                    buf.push(b' ');
                }
            }
        }
        buf.push(b'\n');
        out.write_all(&buf).unwrap();
    }
}
