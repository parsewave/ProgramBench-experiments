#!/bin/bash
set -e
cd "$(dirname "$0")"
export PATH=/usr/local/cargo/bin:$PATH
export CARGO_HOME=/usr/local/cargo
export CARGO_NET_OFFLINE=true
cargo build --release --offline
cp target/release/code-minimap ./executable
