#!/usr/bin/env python3
"""Big fuzz test."""
import random
import subprocess
import sys

REF = "/workspace/executable"
SUT = "/work/work/executable"

random.seed(12345)

def run(binary, args, stdin):
    p = subprocess.run([binary] + args, input=stdin, capture_output=True, timeout=30)
    return p.returncode, p.stdout, p.stderr

def compare(args, stdin):
    rc_r, so_r, se_r = run(REF, args, stdin)
    rc_s, so_s, se_s = run(SUT, args, stdin)
    return rc_r == rc_s and so_r == so_s and se_r == se_s, (rc_r, so_r, se_r), (rc_s, so_s, se_s)

def gen_random_text():
    kind = random.choice(["small", "spaces", "mixed", "utf8", "long", "lines", "binary", "unicode_ws", "pathological"])
    if kind == "small":
        return "".join(random.choices("abc \t", k=random.randint(0, 30))).encode()
    elif kind == "spaces":
        n = random.randint(1, 30)
        lines = []
        for _ in range(n):
            lead = " " * random.randint(0, 20)
            body = random.choice(["", "a", "ab", "abc", "abcd", "x"*random.randint(0,20)])
            tail = " " * random.randint(0, 20)
            lines.append(lead + body + tail)
        return "\n".join(lines).encode()
    elif kind == "mixed":
        return "\n".join("".join(random.choices("abc \t\r", k=random.randint(0, 30))) for _ in range(random.randint(1, 20))).encode()
    elif kind == "utf8":
        chars = "abcäöüß あいう 中文 €£ ñçá😀😊"
        return "\n".join("".join(random.choices(chars, k=random.randint(0, 20))) for _ in range(random.randint(1, 15))).encode()
    elif kind == "long":
        return ("a" * random.randint(100, 1000) + "\n" + "b" * random.randint(50, 500)).encode()
    elif kind == "lines":
        n = random.randint(1, 100)
        return "\n".join("".join(random.choices("ab.", k=random.randint(0, 15))) for _ in range(n)).encode()
    elif kind == "binary":
        return bytes(random.randint(0, 255) for _ in range(random.randint(0, 50)))
    elif kind == "unicode_ws":
        # Mix unicode whitespace
        ws = [' ', '\t', '\xa0', ' ', '　']
        chars = list("abc") + ws
        return "\n".join("".join(random.choices(chars, k=random.randint(0, 30))) for _ in range(random.randint(1, 10))).encode()
    elif kind == "pathological":
        # Edge cases
        choices = [
            b'',
            b'\n',
            b'\n\n\n',
            b'\r\n',
            b'\r',
            b' ',
            b'\t',
            b'\xef\xbb\xbf',  # BOM
            b'\xc2\xa0\xc2\xa0a\xc2\xa0',  # NBSPs
            b'a\xff',
            b'\xff' * 5,
        ]
        return random.choice(choices)

def gen_random_args():
    args = []
    if random.random() < 0.7:
        h = random.choice([0.0, 0.01, 0.1, 0.25, 0.333, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.5, 2.0, 3.0, 10.0])
        args.extend(["-H", str(h)])
    if random.random() < 0.7:
        v = random.choice([0.0, 0.01, 0.1, 0.25, 0.333, 0.5, 0.7, 0.9, 1.0])
        args.extend(["-V", str(v)])
    if random.random() < 0.4:
        args.extend(["--padding", str(random.choice([0, 1, 3, 5, 10, 50, 100]))])
    if random.random() < 0.15:
        args.extend(["--encoding", random.choice(["utf8", "utf8-lossy"])])
    return args

n_fail = 0
n_pass = 0
for i in range(2000):
    text = gen_random_text()
    args = gen_random_args()
    try:
        ok, ref, sut = compare(args, text)
    except subprocess.TimeoutExpired:
        print(f"TIMEOUT #{i}: args={args}")
        continue
    if ok:
        n_pass += 1
    else:
        n_fail += 1
        if n_fail <= 10:
            print(f"FAIL #{i}: args={args}")
            print(f"  Input ({len(text)} bytes): {text[:100]!r}")
            print(f"  REF: exit={ref[0]} stdout={ref[1][:100]!r} stderr={ref[2][:80]!r}")
            print(f"  SUT: exit={sut[0]} stdout={sut[1][:100]!r} stderr={sut[2][:80]!r}")

print(f"\nPassed: {n_pass}, Failed: {n_fail}")
