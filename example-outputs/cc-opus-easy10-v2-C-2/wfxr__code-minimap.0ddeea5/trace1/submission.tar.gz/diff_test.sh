#!/bin/bash
# Differential test runner: compare /workspace/executable vs ./executable
set -u

REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAILS=()

# Function: run both with stdin
test_stdin() {
    local desc=$1
    local input=$2
    shift 2
    local ref_out ref_err ref_exit sut_out sut_err sut_exit
    ref_out=$(printf '%s' "$input" | $REF "$@" 2>/tmp/ref_err); ref_exit=$?
    ref_err=$(cat /tmp/ref_err)
    sut_out=$(printf '%s' "$input" | $SUT "$@" 2>/tmp/sut_err); sut_exit=$?
    sut_err=$(cat /tmp/sut_err)

    if [ "$ref_out" = "$sut_out" ] && [ "$ref_err" = "$sut_err" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
        # echo "OK: $desc"
    else
        FAIL=$((FAIL+1))
        FAILS+=("$desc")
        echo "FAIL: $desc"
        if [ "$ref_out" != "$sut_out" ]; then
            echo "  Stdout differs:"
            echo "  REF: $(printf '%s' "$ref_out" | od -An -tx1 | head -3 | tr -d '\n')"
            echo "  SUT: $(printf '%s' "$sut_out" | od -An -tx1 | head -3 | tr -d '\n')"
        fi
        if [ "$ref_err" != "$sut_err" ]; then
            echo "  Stderr differs:"
            echo "  REF: $ref_err"
            echo "  SUT: $sut_err"
        fi
        if [ "$ref_exit" != "$sut_exit" ]; then
            echo "  Exit differs: REF=$ref_exit SUT=$sut_exit"
        fi
    fi
}

# Function: run both with args only
test_args() {
    local desc=$1
    shift
    local ref_out ref_err ref_exit sut_out sut_err sut_exit
    ref_out=$($REF "$@" 2>/tmp/ref_err); ref_exit=$?
    ref_err=$(cat /tmp/ref_err)
    sut_out=$($SUT "$@" 2>/tmp/sut_err); sut_exit=$?
    sut_err=$(cat /tmp/sut_err)

    if [ "$ref_out" = "$sut_out" ] && [ "$ref_err" = "$sut_err" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILS+=("$desc")
        echo "FAIL: $desc"
        if [ "$ref_out" != "$sut_out" ]; then
            echo "  Stdout: REF=$(printf '%s' "$ref_out" | head -c 200) | SUT=$(printf '%s' "$sut_out" | head -c 200)"
        fi
        if [ "$ref_err" != "$sut_err" ]; then
            echo "  Stderr: REF=$ref_err | SUT=$sut_err"
        fi
        if [ "$ref_exit" != "$sut_exit" ]; then
            echo "  Exit: REF=$ref_exit SUT=$sut_exit"
        fi
    fi
}

echo "=== Subcommands and help ==="
test_args "--help" --help
test_args "-h" -h
test_args "--version" --version
test_args "help" help
test_args "help completion" help completion
test_args "help help" help help
test_args "help foo" help foo
test_args "no args" -- ""
test_args "completion bash" completion bash
test_args "completion zsh" completion zsh
test_args "completion fish" completion fish
test_args "completion elvish" completion elvish
test_args "completion powershell" completion powershell
test_args "completion no-arg" completion

echo "=== Error cases ==="
test_args "bogus flag" --foo
test_args "unknown subcmd" foo
test_args "bad encoding" --encoding latin1 < /dev/null
test_args "missing FILE" /tmp/nonexistent.txt
test_args "directory FILE" /tmp/dir_arg
test_args "bad padding" --padding abc < /dev/null
test_args "bad H" -H xyz < /dev/null
test_args "bad shell" completion sh

echo "=== Basic stdin renders ==="
test_stdin "empty" ""
test_stdin "single nl" $'\n'
test_stdin "single space" " "
test_stdin "single a" "a"
test_stdin "abc" "abc"
test_stdin "no trailing nl" "abc"
test_stdin "trailing nl" $'abc\n'
test_stdin "two lines" $'abc\ndef\n'
test_stdin "Hello World" "Hello World"
test_stdin "long line" "$(python3 -c 'print("x"*100)')"
test_stdin "many lines" "$(python3 -c 'print("\n".join(["a"*5]*20))')"

echo "=== Whitespace variants ==="
test_stdin "leading ws" "   a"
test_stdin "trailing ws" "a   "
test_stdin "all spaces" "    "
test_stdin "internal ws" "a   b"
test_stdin "tab" $'a\tb'
test_stdin "newline mid" $'\nabc\n\n'
test_stdin "CRLF" $'abc\r\ndef\r\n'
test_stdin "CR only" $'abc\rdef'
test_stdin "tab leading" $'\tabc'
test_stdin "FF leading" $'\x0cabc'
test_stdin "VT internal" $'a\x0bb'

echo "=== UTF-8 ==="
test_stdin "ä" "ä"
test_stdin "aä" "aä"
test_stdin "äa" "äa"
test_stdin "ää" "ää"
test_stdin "Japanese" "あいう"
test_stdin "emoji" "😀"
test_stdin "Cyrillic" "Привет"
test_stdin "BOM" $'\xef\xbb\xbfabc'
test_stdin "NBSP lead" $'\xc2\xa0abc'
test_stdin "NBSP trail" $'abc\xc2\xa0'

echo "=== Encoding ==="
test_stdin "utf8 valid" "abc" --encoding utf8
test_stdin "utf8 invalid" $'\xff' --encoding utf8
test_stdin "lossy single FF" $'\xff' --encoding utf8-lossy
test_stdin "lossy mixed" $'a\xffb' --encoding utf8-lossy
test_stdin "default lossy mixed" $'a\xffb'

echo "=== Scales ==="
for h in 0.0 0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 10.0; do
    for v in 0.0 0.1 0.25 0.5 0.75 1.0; do
        test_stdin "H=$h V=$v simple" "abcdef" -H $h -V $v
        test_stdin "H=$h V=$v multi" $'abc\ndef\nghi\n' -H $h -V $v
    done
done

echo "=== Padding ==="
for p in 0 1 2 5 10 20 100 1000; do
    test_stdin "P=$p short" "ab" --padding $p
    test_stdin "P=$p long" "abcdefgh" --padding $p
    test_stdin "P=$p multi" $'abc\nde\n' --padding $p
done

echo "=== Edge cases ==="
test_stdin "single nl V=0" $'\n' -V 0
test_stdin "single nl H=0" $'\n' -H 0
test_stdin "5 nls H=1" $'\n\n\n\n\n'
test_stdin "abc 4 nls" $'abc\n\n\n\n'
test_stdin "abc 5 nls" $'abc\n\n\n\n\n'
test_stdin "abc 8 nls" $'abc\n\n\n\n\n\n\n\n'
test_stdin "per-row narrow then wide" $'a\n\n\n\nabcdef\n'
test_stdin "per-row wide then narrow" $'abcdef\n\n\n\n\nab\n'
test_stdin "padding+scale" "ab" --padding 5 -H 2

echo ""
echo "=========================================="
echo "PASSED: $PASS"
echo "FAILED: $FAIL"
if [ $FAIL -gt 0 ]; then
    echo "Failed tests:"
    printf '  - %s\n' "${FAILS[@]}"
fi
