module pingu

go 1.25
