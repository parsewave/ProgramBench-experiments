package main

import (
	"errors"
	"fmt"
	"math"
	"net"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const versionLine = "pingu: v-rev9c2e3df"

const helpText = "Usage:\n" +
	"  pingu [OPTIONS] HOST\n" +
	"\n" +
	"`ping` command but with pingu\n" +
	"\n" +
	"Application Options:\n" +
	"  -c, --count=     Stop after <count> replies (default: 20)\n" +
	"  -P, --privilege  Enable privileged mode\n" +
	"  -V, --version    Show version\n" +
	"\n" +
	"Help Options:\n" +
	"  -h, --help       Show this help message\n" +
	"\n"

var frames = [20]string{
	" ...        .     ...   ..    ..     .........            ",
	" ...     ....          ..  ..      ... .....  .. ..       ",
	" ...    .......      ...         ... . ..... #######      ",
	".....  ........ .###############.....  ... ##########.  . ",
	" .... ........#####################.  ... ###########     ",
	"      ....... ######################.... ############     ",
	".    .  .... ########################... ###########      ",
	"   ..   ....#########################.. .###########      ",
	"    .       #########################.   .##########      ",
	"   ....     .########################.      ########      ",
	"  .....      .  ####################.        #######.     ",
	"......     .. . ################## . .      .#######      ",
	"......       #####################  .      .#######       ",
	"......   .###########################  ..  #######        ",
	"...    . ########################################.        ",
	"       ####################################### .          ",
	"      ##################################    .             ",
	"     ###################################  ........        ",
	"  .#####################################    .........     ",
	" .#######################################       .... . .  ",
}

type pinguOpts struct {
	count     int64
	privilege bool
	version   bool
}

var colorOn bool

func main() {
	colorOn = colorEnabled()

	opts, positionals, parseErr, helpReq := parseFlags(os.Args[1:])
	if helpReq {
		os.Stdout.WriteString(helpText)
		return
	}
	if parseErr != nil {
		msg := parseErr.Error()
		fmt.Fprintln(os.Stderr, msg)
		fmt.Fprintln(os.Stderr, errPrefix()+" parse error: "+msg)
		os.Exit(1)
	}
	if opts.version {
		fmt.Println(versionLine)
		return
	}
	if len(positionals) == 0 {
		fmt.Fprintln(os.Stderr, errPrefix()+" must requires an argument")
		os.Exit(1)
	}
	if len(positionals) > 1 {
		fmt.Fprintln(os.Stderr, errPrefix()+" too many arguments")
		os.Exit(1)
	}
	host := positionals[0]

	ipaddr, err := resolveHost(host)
	if err != nil {
		fmt.Fprintf(os.Stderr, "%s an error occurred while initializing pinger: failed to init pinger %s\n", errPrefix(), err.Error())
		return
	}

	header := fmt.Sprintf("PING %s (%s) type `Ctrl-C` to abort\n", host, ipaddr.IP.String())
	os.Stdout.WriteString(paintLine(97, header))

	runErr := runPing(host, ipaddr, opts.count, opts.privilege)
	if runErr != nil {
		fmt.Fprintf(os.Stderr, "%s an error occurred when running ping: %s\n", errPrefix(), runErr.Error())
		os.Exit(2)
	}
}

func errPrefix() string {
	return "[ " + paintVal(31, "ERROR") + " ]"
}

func parseFlags(args []string) (opts pinguOpts, positionals []string, parseErr error, helpReq bool) {
	opts.count = 20
	i := 0
	for i < len(args) {
		a := args[i]
		if a == "--" {
			positionals = append(positionals, args[i+1:]...)
			return
		}
		if strings.HasPrefix(a, "--") {
			rest := a[2:]
			eqIdx := strings.Index(rest, "=")
			name := rest
			var val string
			hasVal := false
			if eqIdx >= 0 {
				name = rest[:eqIdx]
				val = rest[eqIdx+1:]
				hasVal = true
			}
			switch name {
			case "help":
				if hasVal {
					parseErr = errors.New("bool flag `-h, --help' cannot have an argument")
					return
				}
				helpReq = true
				return
			case "version":
				if hasVal {
					parseErr = errors.New("bool flag `-V, --version' cannot have an argument")
					return
				}
				opts.version = true
			case "privilege":
				if hasVal {
					parseErr = errors.New("bool flag `-P, --privilege' cannot have an argument")
					return
				}
				opts.privilege = true
			case "count":
				if !hasVal {
					if i+1 >= len(args) {
						parseErr = errors.New("expected argument for flag `-c, --count'")
						return
					}
					next := args[i+1]
					if argumentIsOption(next) {
						parseErr = fmt.Errorf("expected argument for flag `-c, --count', but got option `%s'", next)
						return
					}
					val = next
					i++
				}
				v, err := strconv.ParseInt(val, 0, 64)
				if err != nil {
					parseErr = fmt.Errorf("invalid argument for flag `-c, --count' (expected int): %s", err.Error())
					return
				}
				opts.count = v
			default:
				parseErr = fmt.Errorf("unknown flag `%s'", name)
				return
			}
			i++
			continue
		}
		if strings.HasPrefix(a, "-") && len(a) > 1 {
			j := 1
			for j < len(a) {
				ch := a[j]
				switch ch {
				case 'h':
					if j+1 < len(a) && a[j+1] == '=' {
						parseErr = errors.New("bool flag `-h, --help' cannot have an argument")
						return
					}
					helpReq = true
					return
				case 'V':
					if j+1 < len(a) && a[j+1] == '=' {
						parseErr = errors.New("bool flag `-V, --version' cannot have an argument")
						return
					}
					opts.version = true
					j++
				case 'P':
					if j+1 < len(a) && a[j+1] == '=' {
						parseErr = errors.New("bool flag `-P, --privilege' cannot have an argument")
						return
					}
					opts.privilege = true
					j++
				case 'c':
					var val string
					rest := a[j+1:]
					if strings.HasPrefix(rest, "=") {
						val = rest[1:]
					} else if rest != "" {
						val = rest
					} else {
						if i+1 >= len(args) {
							parseErr = errors.New("expected argument for flag `-c, --count'")
							return
						}
						next := args[i+1]
						if argumentIsOption(next) {
							parseErr = fmt.Errorf("expected argument for flag `-c, --count', but got option `%s'", next)
							return
						}
						val = next
						i++
					}
					v, err := strconv.ParseInt(val, 0, 64)
					if err != nil {
						parseErr = fmt.Errorf("invalid argument for flag `-c, --count' (expected int): %s", err.Error())
						return
					}
					opts.count = v
					j = len(a)
				default:
					parseErr = fmt.Errorf("unknown flag `%c'", ch)
					return
				}
			}
			i++
			continue
		}
		positionals = append(positionals, a)
		i++
	}
	return
}

func argumentIsOption(s string) bool {
	if len(s) < 2 || s[0] != '-' {
		return false
	}
	if s[1] == '-' {
		return true
	}
	if s[1] >= '0' && s[1] <= '9' {
		return false
	}
	return true
}

func resolveHost(host string) (*net.IPAddr, error) {
	if len(host) == 0 {
		return nil, errors.New("addr cannot be empty")
	}
	return net.ResolveIPAddr("ip", host)
}

func colorEnabled() bool {
	if os.Getenv("NO_COLOR") != "" {
		return false
	}
	if os.Getenv("TERM") == "dumb" {
		return false
	}
	return isatty(os.Stdout.Fd())
}

func isatty(fd uintptr) bool {
	var termios syscall.Termios
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, fd, syscall.TCGETS, uintptr(unsafe.Pointer(&termios)))
	return errno == 0
}

func paintVal(code int, s string) string {
	if !colorOn {
		return s
	}
	return fmt.Sprintf("\x1b[%d;1m%s\x1b[0;22m", code, s)
}

func paintLine(code int, s string) string {
	if !colorOn {
		return s
	}
	return fmt.Sprintf("\x1b[%d;1m%s\x1b[0m", code, s)
}

type pingConn interface {
	Send(target *net.IPAddr, seq uint16) (sendTime time.Time, err error)
	Recv(seq uint16, sendTime time.Time, deadline time.Time) (rtt time.Duration, ttl int, fromIP string, nbytes int, gotReply bool)
	Close() error
}

func openICMP(privileged, isV6 bool) (pingConn, error) {
	if privileged {
		return openRaw(isV6)
	}
	return openDgram(isV6)
}

type dgramConn struct {
	uc *net.UDPConn
	v6 bool
}

func openDgram(isV6 bool) (*dgramConn, error) {
	family := syscall.AF_INET
	proto := 1
	if isV6 {
		family = syscall.AF_INET6
		proto = 58
	}
	fd, err := syscall.Socket(family, syscall.SOCK_DGRAM, proto)
	if err != nil {
		return nil, os.NewSyscallError("socket", err)
	}
	if !isV6 {
		syscall.SetsockoptInt(fd, syscall.IPPROTO_IP, syscall.IP_RECVTTL, 1)
		_ = syscall.Bind(fd, &syscall.SockaddrInet4{})
	} else {
		syscall.SetsockoptInt(fd, syscall.IPPROTO_IPV6, 51 /*IPV6_RECVHOPLIMIT*/, 1)
		_ = syscall.Bind(fd, &syscall.SockaddrInet6{})
	}
	f := os.NewFile(uintptr(fd), "icmp")
	pc, err := net.FilePacketConn(f)
	f.Close()
	if err != nil {
		return nil, err
	}
	uc, ok := pc.(*net.UDPConn)
	if !ok {
		pc.Close()
		return nil, errors.New("unexpected packet conn type")
	}
	return &dgramConn{uc: uc, v6: isV6}, nil
}

func (c *dgramConn) Send(target *net.IPAddr, seq uint16) (time.Time, error) {
	msg := buildEcho(c.v6, seq)
	t := time.Now()
	_, _, err := c.uc.WriteMsgUDP(msg, nil, &net.UDPAddr{IP: target.IP})
	return t, err
}

func (c *dgramConn) Recv(seq uint16, sendTime time.Time, deadline time.Time) (time.Duration, int, string, int, bool) {
	expectedType := byte(0)
	if c.v6 {
		expectedType = 129
	}
	for {
		now := time.Now()
		if !now.Before(deadline) {
			return 0, 0, "", 0, false
		}
		c.uc.SetReadDeadline(deadline)
		buf := make([]byte, 1500)
		oob := make([]byte, 1024)
		n, oobn, _, src, err := c.uc.ReadMsgUDP(buf, oob)
		if err != nil {
			return 0, 0, "", 0, false
		}
		if n < 8 {
			continue
		}
		if buf[0] != expectedType {
			continue
		}
		rseq := uint16(buf[6])<<8 | uint16(buf[7])
		if rseq != seq {
			continue
		}
		ttl := 64
		cmsgs, _ := syscall.ParseSocketControlMessage(oob[:oobn])
		for _, cm := range cmsgs {
			if !c.v6 && cm.Header.Level == syscall.IPPROTO_IP && cm.Header.Type == syscall.IP_TTL {
				if len(cm.Data) > 0 {
					ttl = int(cm.Data[0])
				}
			} else if c.v6 && cm.Header.Level == syscall.IPPROTO_IPV6 {
				if len(cm.Data) > 0 {
					ttl = int(cm.Data[0])
				}
			}
		}
		rtt := time.Since(sendTime)
		return rtt, ttl, src.IP.String(), n, true
	}
}

func (c *dgramConn) Close() error { return c.uc.Close() }

type rawConn struct {
	pc net.PacketConn
	v6 bool
}

func openRaw(isV6 bool) (*rawConn, error) {
	network := "ip4:icmp"
	if isV6 {
		network = "ip6:ipv6-icmp"
	}
	pc, err := net.ListenPacket(network, "")
	if err != nil {
		return nil, err
	}
	return &rawConn{pc: pc, v6: isV6}, nil
}

func (c *rawConn) Send(target *net.IPAddr, seq uint16) (time.Time, error) {
	msg := buildEcho(c.v6, seq)
	t := time.Now()
	_, err := c.pc.WriteTo(msg, &net.IPAddr{IP: target.IP})
	return t, err
}

func (c *rawConn) Recv(seq uint16, sendTime time.Time, deadline time.Time) (time.Duration, int, string, int, bool) {
	expectedType := byte(0)
	if c.v6 {
		expectedType = 129
	}
	for {
		now := time.Now()
		if !now.Before(deadline) {
			return 0, 0, "", 0, false
		}
		c.pc.SetReadDeadline(deadline)
		buf := make([]byte, 1500)
		n, src, err := c.pc.ReadFrom(buf)
		if err != nil {
			return 0, 0, "", 0, false
		}
		var data []byte
		ttl := 64
		if c.v6 {
			data = buf[:n]
		} else {
			if n < 20 {
				continue
			}
			ihl := int(buf[0]&0x0f) * 4
			if n < ihl+8 {
				continue
			}
			ttl = int(buf[8])
			data = buf[ihl:n]
			n = n - ihl
		}
		if len(data) < 8 || data[0] != expectedType {
			continue
		}
		rseq := uint16(data[6])<<8 | uint16(data[7])
		if rseq != seq {
			continue
		}
		srcIP := ""
		if ia, ok := src.(*net.IPAddr); ok {
			srcIP = ia.IP.String()
		} else {
			srcIP = src.String()
		}
		rtt := time.Since(sendTime)
		return rtt, ttl, srcIP, n, true
	}
}

func (c *rawConn) Close() error { return c.pc.Close() }

func buildEcho(v6 bool, seq uint16) []byte {
	msg := make([]byte, 8+24)
	if v6 {
		msg[0] = 128
	} else {
		msg[0] = 8
	}
	msg[6] = byte(seq >> 8)
	msg[7] = byte(seq)
	if !v6 {
		var s uint32
		for i := 0; i+1 < len(msg); i += 2 {
			s += uint32(msg[i])<<8 | uint32(msg[i+1])
		}
		if len(msg)%2 == 1 {
			s += uint32(msg[len(msg)-1]) << 8
		}
		for s>>16 != 0 {
			s = (s & 0xffff) + (s >> 16)
		}
		cs := ^uint16(s)
		msg[2] = byte(cs >> 8)
		msg[3] = byte(cs)
	}
	return msg
}

func runPing(host string, ipaddr *net.IPAddr, count int64, privileged bool) error {
	isV6 := ipaddr.IP.To4() == nil
	conn, err := openICMP(privileged, isV6)
	if err != nil {
		return err
	}
	defer conn.Close()

	stopCh := make(chan struct{})
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT)
	defer signal.Stop(sigCh)
	go func() {
		<-sigCh
		close(stopCh)
	}()

	var rtts []time.Duration
	sent := 0
	recvd := 0
	var runErr error

	start := time.Now()
seqLoop:
	for seqI := int64(0); count <= 0 || seqI < count; seqI++ {
		if seqI > 0 {
			target := start.Add(time.Duration(seqI) * time.Second)
			d := time.Until(target)
			if d > 0 {
				t := time.NewTimer(d)
				select {
				case <-t.C:
				case <-stopCh:
					t.Stop()
					break seqLoop
				}
			}
		} else {
			select {
			case <-stopCh:
				break seqLoop
			default:
			}
		}
		seq16 := uint16(seqI)
		sendTime, err := conn.Send(ipaddr, seq16)
		if err != nil {
			runErr = err
			break
		}
		sent++
		deadline := time.Now().Add(time.Second)
		rtt, ttl, fromIP, nbytes, ok := conn.Recv(seq16, sendTime, deadline)
		if ok {
			recvd++
			rtts = append(rtts, rtt)
			printReply(int(seqI), nbytes, fromIP, ttl, rtt)
		}
	}

	printStats(host, sent, recvd, rtts)
	return runErr
}

func printReply(seq int, nbytes int, fromIP string, ttl int, rtt time.Duration) {
	frame := frames[seq%20]
	line := frame +
		"seq=" + paintVal(93, strconv.Itoa(seq)) + " " +
		paintVal(94, strconv.Itoa(nbytes)) + "bytes from " +
		paintVal(37, fromIP) + ": ttl=" +
		paintVal(96, strconv.Itoa(ttl)) + " time=" +
		paintVal(95, rtt.String()) + "\n"
	os.Stdout.WriteString(line)
}

func printStats(host string, sent, recvd int, rtts []time.Duration) {
	dash := strings.Repeat("─", 9)
	sep := dash + " " + host + " ping statistics " + dash
	sepBlock := "\n" + sep + "\n"
	os.Stdout.WriteString(paintLine(37, sepBlock))

	loss := float64(0)
	if sent > 0 {
		loss = float64(sent-recvd) / float64(sent) * 100
	}
	lossStr := fmt.Sprintf("%v%%", loss)
	pktLine := paintVal(97, "PACKET STATISTICS") + ": " +
		paintVal(94, strconv.Itoa(sent)) + " transmitted => " +
		paintVal(92, strconv.Itoa(recvd)) + " received (" +
		paintVal(91, lossStr) + " loss)\n"
	os.Stdout.WriteString(pktLine)

	var minD, maxD, avgD, stdD time.Duration
	if len(rtts) > 0 {
		minD = rtts[0]
		maxD = rtts[0]
		var total time.Duration
		for _, r := range rtts {
			if r < minD {
				minD = r
			}
			if r > maxD {
				maxD = r
			}
			total += r
		}
		avgD = total / time.Duration(len(rtts))
		var sumSq time.Duration
		for _, r := range rtts {
			d := r - avgD
			sumSq += d * d
		}
		stdD = time.Duration(math.Sqrt(float64(sumSq / time.Duration(len(rtts)))))
	}
	rtLine := paintVal(97, "ROUND TRIP") + ": min=" +
		paintVal(94, minD.String()) + " avg=" +
		paintVal(96, avgD.String()) + " max=" +
		paintVal(92, maxD.String()) + " stddev=" +
		paintVal(35, stdD.String()) + "\n"
	os.Stdout.WriteString(rtLine)
}
