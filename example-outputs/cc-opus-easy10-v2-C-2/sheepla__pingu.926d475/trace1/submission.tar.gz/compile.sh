#!/bin/sh
set -e
cd "$(dirname "$0")"
export PATH="/usr/local/go/bin:$PATH"
export GOPROXY=off
export GOFLAGS=-mod=mod
export CGO_ENABLED=0
go build -trimpath -o executable .
