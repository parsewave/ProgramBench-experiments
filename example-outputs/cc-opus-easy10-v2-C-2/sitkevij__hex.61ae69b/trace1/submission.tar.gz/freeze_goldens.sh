#!/bin/bash
# Capture golden triples (stdout, stderr, exit code) for many probes
set -u
REF=/workspace/executable
OUT=/work/work/goldens
IN=/work/work/goldens/inputs
rm -rf "$OUT"
mkdir -p "$OUT" "$IN"

probe() {
    local name="$1"
    local stdin_file="$2"
    shift 2
    if [ "$stdin_file" = "-" ]; then
        "$REF" "$@" > "$OUT/$name.out" 2> "$OUT/$name.err"
    else
        "$REF" "$@" < "$stdin_file" > "$OUT/$name.out" 2> "$OUT/$name.err"
    fi
    echo "$?" > "$OUT/$name.exit"
    {
        echo "STDIN: $stdin_file"
        printf 'ARGS:'
        for a in "$@"; do printf ' %q' "$a"; done
        printf '\n'
    } > "$OUT/$name.meta"
}

probe_with_in() {
    local name="$1"
    local input="$2"
    shift 2
    local f="$IN/$name.in"
    printf '%s' "$input" > "$f"
    probe "$name" "$f" "$@"
}

# Surface
probe help - --help
probe help_short - -h
probe version - --version
probe version_short - -V
probe no_args /dev/null
probe bogus_long - --bogus
probe bogus_short - -b
probe dash_only - -
probe doubledash_only - --
probe doubledash_file - -- /workspace/assets/tiny.bin
probe nonexistent_file - /nonexistent_path_zzz
probe directory - /etc
probe devnull - /dev/null
probe two_files - foo bar

# File arg
probe file_tiny - /workspace/assets/tiny.bin
probe file_passwd_with_len - -l 50 /etc/passwd

# Stdin variations
probe_with_in stdin_simple "abc"
probe_with_in stdin_empty ""
probe_with_in stdin_10 "0123456789"
probe_with_in stdin_11 "01234567890"
probe_with_in stdin_20 "01234567890123456789"
probe_with_in stdin_16bytes "0123456789abcdef"
probe_with_in stdin_newlines $'a\nb\nc\n'
printf '\x00\x01\x07\x09\x0a\x0d\x1f\x20\x7e\x7f\x80\xff' > "$IN/edge1.in"
probe edge_bytes "$IN/edge1.in"
printf '\xab\xcd\xef' > "$IN/high.in"
probe high_bytes "$IN/high.in"
printf 'A\tB' > "$IN/tab.in"
probe tab_input "$IN/tab.in"
printf 'H\xc3\xa9llo' > "$IN/utf8.in"
probe utf8_input "$IN/utf8.in"
printf '\xef\xbb\xbf' > "$IN/bom.in"
probe bom "$IN/bom.in"
printf '\r\n' > "$IN/crlf.in"
probe crlf "$IN/crlf.in"

# -c (cols)
probe_with_in cols_1 "abc" -c 1
probe_with_in cols_2_ab "ab" -c 2
probe_with_in cols_2_abc "abc" -c 2
probe_with_in cols_2_abcd "abcd" -c 2
probe_with_in cols_5 "abcdef" -c 5
probe_with_in cols_5_exact "abcde" -c 5
probe_with_in cols_16 "0123456789abcdef" -c 16
probe_with_in cols_3_empty "" -c 3
probe_with_in cols_99 "abc" -c 99
probe_with_in cols_0 "abc" -c 0
probe_with_in cols_0_empty "" -c 0
probe_with_in cols_4_10 "0123456789" -c 4

# -l (len)
probe_with_in len_5 "0123456789abc" -l 5
probe_with_in len_0 "0123456789abc" -l 0
probe_with_in len_overshoot "01234" -l 10
probe_with_in len_one "0" -l 100
probe len_bad - -l abc
probe len_too_big - -l 99999999999999999999999

# -f (format)
probe_with_in fmt_o "abc" -f o
probe_with_in fmt_x "abc" -f x
probe_with_in fmt_X "abc" -f X
probe_with_in fmt_b "abc" -f b
printf '\xab\xcd\xef' > "$IN/hi.in"
probe fmt_o_hi "$IN/hi.in" -f o
probe fmt_X_hi "$IN/hi.in" -f X
probe fmt_b_hi "$IN/hi.in" -f b
probe fmt_bad - -f q

# -r (prefix)
probe_with_in r0 "abc" -r 0
probe_with_in r0_X "abc" -r 0 -f X
probe_with_in r0_o "abc" -r 0 -f o
probe_with_in r0_b "abc" -r 0 -f b
probe_with_in r0_empty "" -r 0 -f b
probe_with_in r1 "abc" -r 1

# -t (color)
probe_with_in t1 "abc" -t 1
probe_with_in t0 "abc" -t 0
probe_with_in t1_X "abc" -t 1 -f X
probe_with_in t1_b "a" -t 1 -f b
probe_with_in t1_o "a" -t 1 -f o
probe_with_in t1_r0 "a" -t 1 -r 0
printf '\x00\x01' > "$IN/01.in"
probe t1_null "$IN/01.in" -t 1
probe t_bad - -t 2

# -a (array)
probe_with_in array_r "abc" -a r
probe_with_in array_c "abc" -a c
probe_with_in array_g "abc" -a g
probe_with_in array_p "abc" -a p
probe_with_in array_k "abc" -a k
probe_with_in array_j "abc" -a j
probe_with_in array_s "abc" -a s
probe_with_in array_f "abc" -a f
probe_with_in array_r_empty "" -a r
probe_with_in array_g_empty "" -a g
probe_with_in array_f_empty "" -a f
probe_with_in array_r_10 "0123456789" -a r
probe_with_in array_g_10 "0123456789" -a g
probe_with_in array_c_10 "0123456789" -a c
probe_with_in array_p_10 "0123456789" -a p
probe_with_in array_k_10 "0123456789" -a k
probe_with_in array_j_10 "0123456789" -a j
probe_with_in array_s_10 "0123456789" -a s
probe_with_in array_f_10 "0123456789" -a f
probe_with_in array_r_11 "0123456789a" -a r
probe_with_in array_g_11 "0123456789a" -a g
probe_with_in array_f_11 "0123456789a" -a f
probe_with_in array_r_21 "012345678901234567890" -a r
probe_with_in array_r_c1 "abc" -a r -c 1
probe_with_in array_c_c2 "abcde" -a c -c 2
probe_with_in array_r_l2 "abc" -a r -l 2
probe_with_in array_r_X "abc" -a r -f X
probe_with_in array_r_r0 "abc" -a r -r 0
probe_with_in array_r_t1 "abc" -a r -t 1
probe_with_in array_g_3 "abc" -a g
probe_with_in array_r_30 "012345678901234567890123456789" -a r
probe array_bad - -a z

# -u (wave)
probe wave_5 - -u 5
probe wave_0 - -u 0
probe wave_1 - -u 1
probe wave_2 - -u 2
probe wave_3 - -u 3
probe wave_10 - -u 10
probe wave_11 - -u 11
probe wave_20 - -u 20
probe wave_100 - -u 100
probe wave_5_p0 - -u 5 -p 0
probe wave_5_p1 - -u 5 -p 1
probe wave_5_p2 - -u 5 -p 2
probe wave_5_p6 - -u 5 -p 6
probe wave_5_p10 - -u 5 -p 10
probe wave_3_p9 - -u 3 -p 9
probe wave_4_p2 - -u 4 -p 2
probe wave_5_c3 - -u 5 -c 3
probe wave_5_with_a - -u 5 -a r
probe wave_5_with_t - -u 5 -t 1
probe wave_5_with_file - -u 5 /workspace/assets/tiny.bin
probe wave_u_bad - -u abc
probe wave_u_overflow - -u 18446744073709551616
probe wave_p_invalid - -u 5 -p abc
probe wave_p_overflow - -u 5 -p 18446744073709551616
probe wave_0_p5 - -u 0 -p 5

# Repeated flags
probe rep_c - -c 5 -c 3
probe rep_l - -l 1 -l 2
probe rep_f - -f x -f b
probe rep_a - -a r -a c

# Missing required values
probe miss_c - -c
probe miss_l - -l
probe miss_f - -f
probe miss_a - -a
probe miss_t - -t
probe miss_u - -u
probe miss_p - -p
probe miss_r - -r

# Combined options
probe_with_in combo_1 "Hello\nWorld" -c 8 -f X -r 1
probe_with_in combo_2 "Hello" -c 3 -t 0 -f o
probe_with_in combo_3 "12345" -c 4 -l 3 -f b -r 0

# long-form variants
probe_with_in long_cols "abc" --cols=4
probe_with_in long_cols_sp "abc" --cols 4
probe_with_in long_format "abc" --format=X

echo "Done"
ls "$OUT" | grep -v '/' | wc -l
