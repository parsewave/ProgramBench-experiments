#!/bin/bash
# More aggressive fuzz tests
set -u
REF=/workspace/executable
SUT=/work/work/executable
FAILS=0
TOTAL=0

cmp_run() {
    local name="$1"
    shift
    TOTAL=$((TOTAL + 1))
    "$REF" "$@" > /tmp/_r.out 2> /tmp/_r.err
    local re=$?
    "$SUT" "$@" > /tmp/_s.out 2> /tmp/_s.err
    local se=$?
    if [ "$re" != "$se" ]; then
        echo "FAIL [$name]: exit ref=$re sut=$se ARGS: $*"
        FAILS=$((FAILS + 1))
        return
    fi
    if ! cmp -s /tmp/_r.out /tmp/_s.out; then
        echo "FAIL [$name]: stdout differs ARGS: $*"
        diff /tmp/_r.out /tmp/_s.out | head -10
        FAILS=$((FAILS + 1))
        return
    fi
    if ! cmp -s /tmp/_r.err /tmp/_s.err; then
        echo "FAIL [$name]: stderr differs ARGS: $*"
        diff /tmp/_r.err /tmp/_s.err | head -10
        FAILS=$((FAILS + 1))
        return
    fi
}

cmp_run_stdin() {
    local name="$1"
    local input="$2"
    shift 2
    TOTAL=$((TOTAL + 1))
    printf '%s' "$input" > /tmp/_in
    "$REF" "$@" < /tmp/_in > /tmp/_r.out 2> /tmp/_r.err
    local re=$?
    "$SUT" "$@" < /tmp/_in > /tmp/_s.out 2> /tmp/_s.err
    local se=$?
    if [ "$re" != "$se" ]; then
        echo "FAIL [$name]: exit ref=$re sut=$se INPUT=${input:0:30} ARGS: $*"
        FAILS=$((FAILS + 1))
        return
    fi
    if ! cmp -s /tmp/_r.out /tmp/_s.out; then
        echo "FAIL [$name]: stdout differs INPUT=${input:0:30} ARGS: $*"
        diff /tmp/_r.out /tmp/_s.out | head -10
        FAILS=$((FAILS + 1))
        return
    fi
    if ! cmp -s /tmp/_r.err /tmp/_s.err; then
        echo "FAIL [$name]: stderr differs ARGS: $*"
        diff /tmp/_r.err /tmp/_s.err | head -10
        FAILS=$((FAILS + 1))
        return
    fi
}

# Test all formats with all prefix combos
for f in o x X b; do
    for r in 0 1; do
        cmp_run_stdin "fmt_${f}_r${r}" "abcde" -f $f -r $r
    done
done

# Test all array formats with various sizes
for a in r c g p k j s f; do
    for size in 0 1 2 9 10 11 19 20 21 30; do
        input=$(head -c $size /dev/urandom | base64 | head -c $size)
        if [ -z "$input" ] && [ "$size" != "0" ]; then continue; fi
        cmp_run_stdin "arr_${a}_n${size}" "$input" -a $a
    done
done

# Wave with various N and -p
for n in 0 1 2 5 9 10 11 15 20 25 50; do
    for p in 0 1 2 4 8; do
        cmp_run "wave_n${n}_p${p}" -u $n -p $p
    done
done

# -c values
for c in 1 2 3 5 7 8 10 16 32 100; do
    for size in 0 1 5 10 15 20 33 50; do
        input=$(printf 'X%.0s' $(seq 1 $size))
        cmp_run_stdin "cols_c${c}_n${size}" "$input" -c $c
    done
done

# -l values
for l in 0 1 5 10 100; do
    for size in 0 3 10 50; do
        input=$(printf 'X%.0s' $(seq 1 $size))
        cmp_run_stdin "len_l${l}_n${size}" "$input" -l $l
    done
done

# Color with various
for t in 0 1; do
    cmp_run_stdin "color_t${t}_n3" "abc" -t $t
    cmp_run_stdin "color_t${t}_n0" "" -t $t
done

# Special bytes - all 256 values
all_bytes=$(python3 -c 'import sys; sys.stdout.buffer.write(bytes(range(256)))')
cmp_run_stdin "all_bytes" "$all_bytes"
cmp_run_stdin "all_bytes_t1" "$all_bytes" -t 1
cmp_run_stdin "all_bytes_a_r" "$all_bytes" -a r
cmp_run_stdin "all_bytes_a_f" "$all_bytes" -a f
cmp_run_stdin "all_bytes_b" "$all_bytes" -f b
cmp_run_stdin "all_bytes_X" "$all_bytes" -f X

# Bad / edge args
cmp_run "bad_cols_neg" -c -1 || true
cmp_run "bad_cols_str" -c xyz
cmp_run "bad_len_neg" -l -1 || true
cmp_run "bad_format_q" -f q
cmp_run "bad_array_z" -a z
cmp_run "bad_color_2" -t 2
cmp_run "bad_prefix_2" -r 2
cmp_run "bogus_long" --bogus-flag
cmp_run "bogus_pos" foo bar

# Help and version
cmp_run "help_long" --help
cmp_run "help_short" -h
cmp_run "version_long" --version
cmp_run "version_short" -V

# Files
cmp_run "file_tiny" /workspace/assets/tiny.bin
cmp_run "file_dev_null" /dev/null
cmp_run "file_nonexist" /nonexistent_xyz
cmp_run "file_etc" /etc

echo "==="
echo "Total: $TOTAL | Failed: $FAILS"
