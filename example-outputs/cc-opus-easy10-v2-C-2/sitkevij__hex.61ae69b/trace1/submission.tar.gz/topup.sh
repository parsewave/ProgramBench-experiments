#!/bin/bash
# Phase 6: Statistical top-up. Generate 10 fresh random probes.
set -u
REF=/workspace/executable
SUT=/work/work/executable
PASS=0
FAIL=0

# Random integer
rint() {
    echo $((RANDOM % $1))
}

probe() {
    local desc="$1"
    shift
    local stdin_arg="$1"
    shift
    if [ "$stdin_arg" = "-" ]; then
        "$REF" "$@" > /tmp/_tr.out 2> /tmp/_tr.err
        local re=$?
        "$SUT" "$@" > /tmp/_ts.out 2> /tmp/_ts.err
        local se=$?
    else
        "$REF" "$@" < "$stdin_arg" > /tmp/_tr.out 2> /tmp/_tr.err
        local re=$?
        "$SUT" "$@" < "$stdin_arg" > /tmp/_ts.out 2> /tmp/_ts.err
        local se=$?
    fi
    local issues=""
    [ "$re" != "$se" ] && issues+="exit($re vs $se) "
    cmp -s /tmp/_tr.out /tmp/_ts.out || issues+="stdout "
    cmp -s /tmp/_tr.err /tmp/_ts.err || issues+="stderr "
    if [ -n "$issues" ]; then
        echo "FAIL [$desc] $issues" "$@" "(stdin=$stdin_arg)"
        FAIL=$((FAIL + 1))
        diff /tmp/_tr.out /tmp/_ts.out | head -5
        diff /tmp/_tr.err /tmp/_ts.err | head -5
    else
        echo "PASS [$desc] $@ (stdin=$stdin_arg)"
        PASS=$((PASS + 1))
    fi
}

# Markov chain modes:
# 1. Hex view (with various flags)
# 2. Array view (with various flags)
# 3. Wave (with -u)
# 4. Help/version
# 5. Error case

# Random input
head -c $((RANDOM % 500)) /dev/urandom > /tmp/probe_input.bin

# Probe 1: hex view with random col + format
c=$((RANDOM % 20 + 1))
fmts=(o x X b)
f=${fmts[$((RANDOM % 4))]}
probe "p1_hex" /tmp/probe_input.bin -c $c -f $f

# Probe 2: array view random
arrays=(r c g p k j s f)
a=${arrays[$((RANDOM % 8))]}
c=$((RANDOM % 12 + 1))
probe "p2_array" /tmp/probe_input.bin -a $a -c $c

# Probe 3: wave
n=$((RANDOM % 30))
p=$((RANDOM % 10))
probe "p3_wave" - -u $n -p $p

# Probe 4: error case
probe "p4_err" - -f q

# Probe 5: long input with -l limit
head -c 1000 /dev/urandom > /tmp/probe_big.bin
l=$((RANDOM % 100))
probe "p5_limit" /tmp/probe_big.bin -l $l

# Probe 6: random combo
c=$((RANDOM % 15 + 1))
r=$((RANDOM % 2))
t=$((RANDOM % 2))
probe "p6_combo" /tmp/probe_input.bin -c $c -r $r -t $t

# Probe 7: array with prefix override
a=${arrays[$((RANDOM % 8))]}
probe "p7_arr_r0" /tmp/probe_input.bin -a $a -r 0 -f X

# Probe 8: wave with high precision
n=$((RANDOM % 10 + 1))
p=$((RANDOM % 8 + 5))
probe "p8_wave_hp" - -u $n -p $p

# Probe 9: hex with -t 1 (color)
fmt=${fmts[$((RANDOM % 4))]}
probe "p9_color" /tmp/probe_input.bin -t 1 -f $fmt

# Probe 10: file not found
probe "p10_nofile" - /nonexistent/path/$RANDOM

echo "==="
echo "Statistical top-up: PASS=$PASS FAIL=$FAIL"
[ $FAIL -eq 0 ] && echo "Spec certified."
