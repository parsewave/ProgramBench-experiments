#!/bin/bash
# Compare every golden against the rebuilt SUT
set -u
SUT=/work/work/executable
OUT=/work/work/goldens
DIFF_DIR=/work/work/diffs
mkdir -p "$DIFF_DIR"
rm -f "$DIFF_DIR"/*.diff "$DIFF_DIR"/summary.txt

pass=0
fail=0
total=0
fails=()

for meta in "$OUT"/*.meta; do
    name=$(basename "$meta" .meta)
    total=$((total + 1))
    # Read args
    stdin_file=$(grep -oP '(?<=^STDIN: ).+' "$meta")
    # Read args; eval them so quoted args are correctly split
    args_line=$(grep -oP '(?<=^ARGS:).+' "$meta")

    # Build the command
    if [ "$stdin_file" = "-" ]; then
        eval "$SUT $args_line" > "$DIFF_DIR/$name.sut.out" 2> "$DIFF_DIR/$name.sut.err"
    else
        eval "$SUT $args_line" < "$stdin_file" > "$DIFF_DIR/$name.sut.out" 2> "$DIFF_DIR/$name.sut.err"
    fi
    sut_exit=$?

    # Compare
    diff_out=""
    if ! diff -q "$OUT/$name.out" "$DIFF_DIR/$name.sut.out" > /dev/null 2>&1; then
        diff_out+="STDOUT differs\n"
    fi
    if ! diff -q "$OUT/$name.err" "$DIFF_DIR/$name.sut.err" > /dev/null 2>&1; then
        diff_out+="STDERR differs\n"
    fi
    ref_exit=$(cat "$OUT/$name.exit")
    if [ "$ref_exit" != "$sut_exit" ]; then
        diff_out+="EXIT differs: ref=$ref_exit sut=$sut_exit\n"
    fi

    if [ -z "$diff_out" ]; then
        pass=$((pass + 1))
        # Clean up SUT files
        rm -f "$DIFF_DIR/$name.sut.out" "$DIFF_DIR/$name.sut.err"
    else
        fail=$((fail + 1))
        fails+=("$name")
        {
            echo "=== $name ==="
            cat "$meta"
            printf "$diff_out"
            echo "--- STDOUT DIFF ---"
            diff "$OUT/$name.out" "$DIFF_DIR/$name.sut.out" || true
            echo "--- STDERR DIFF ---"
            diff "$OUT/$name.err" "$DIFF_DIR/$name.sut.err" || true
        } > "$DIFF_DIR/$name.diff"
    fi
done

echo "Total: $total | Pass: $pass | Fail: $fail"
if [ "$fail" -gt 0 ]; then
    echo "Failures:"
    for f in "${fails[@]}"; do
        echo "  $f"
    done
fi
