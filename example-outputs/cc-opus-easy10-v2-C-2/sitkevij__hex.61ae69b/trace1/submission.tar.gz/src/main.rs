use clap::{Arg, ArgAction, Command};
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::process::ExitCode;

fn build_cli() -> Command {
    Command::new("hx")
        .bin_name("executable")
        .about("Futuristic take on hexdump, made in Rust.\n")
        .version("0.7.0")
        .disable_version_flag(true)
        .arg(
            Arg::new("cols")
                .short('c')
                .long("cols")
                .value_name("columns")
                .help("Set column length")
                .num_args(1),
        )
        .arg(
            Arg::new("len")
                .short('l')
                .long("len")
                .value_name("len")
                .help("Set <len> bytes to read")
                .num_args(1),
        )
        .arg(
            Arg::new("format")
                .short('f')
                .long("format")
                .value_name("format")
                .help("Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b)")
                .num_args(1)
                .value_parser(["o", "x", "X", "b"]),
        )
        .arg(
            Arg::new("color")
                .short('t')
                .long("color")
                .value_name("color")
                .help("Set color tint terminal output. 0 to disable, 1 to enable")
                .num_args(1)
                .value_parser(["0", "1"]),
        )
        .arg(
            Arg::new("array")
                .short('a')
                .long("array")
                .value_name("array_format")
                .help("Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f)")
                .num_args(1)
                .value_parser(["r", "c", "g", "p", "k", "j", "s", "f"]),
        )
        .arg(
            Arg::new("func")
                .short('u')
                .long("func")
                .value_name("func_length")
                .help("Set function wave length")
                .num_args(1),
        )
        .arg(
            Arg::new("places")
                .short('p')
                .long("places")
                .value_name("func_places")
                .help("Set function wave output decimal places")
                .num_args(1),
        )
        .arg(
            Arg::new("prefix")
                .short('r')
                .long("prefix")
                .value_name("prefix")
                .help("Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable")
                .num_args(1)
                .value_parser(["0", "1"]),
        )
        .disable_help_flag(true)
        .arg(
            Arg::new("help")
                .short('h')
                .long("help")
                .help("Print help")
                .action(ArgAction::Help),
        )
        .arg(
            Arg::new("version")
                .short('V')
                .long("version")
                .help("Print version")
                .action(ArgAction::Version),
        )
        .arg(
            Arg::new("INPUTFILE")
                .help("Pass file path as an argument, or input data may be passed via stdin")
                .index(1),
        )
}

/// Parse u64 with the custom error messages the reference uses.
fn parse_u64_arg(value: &str, short: char, long: &str) -> Result<u64, ()> {
    match value.parse::<u64>() {
        Ok(v) => Ok(v),
        Err(e) => {
            let kind = format!("{:?}", e.kind());
            // e.kind() in current Rust returns IntErrorKind variants. The
            // panic Debug-output uses `IntErrorKind::InvalidDigit` style
            // but older versions emit just `InvalidDigit`. The reference
            // emits `ParseIntError { kind: InvalidDigit }` which matches
            // older Rust Debug for ParseIntError. We need to emulate that.
            let kind_short = if kind.contains("InvalidDigit") {
                "InvalidDigit"
            } else if kind.contains("PosOverflow") {
                "PosOverflow"
            } else if kind.contains("NegOverflow") {
                "NegOverflow"
            } else if kind.contains("Empty") {
                "Empty"
            } else if kind.contains("Zero") {
                "Zero"
            } else {
                "InvalidDigit"
            };
            let msg = match kind_short {
                "InvalidDigit" => "invalid digit found in string",
                "PosOverflow" => "number too large to fit in target type",
                "NegOverflow" => "number too small to fit in target type",
                "Empty" => "cannot parse integer from empty string",
                "Zero" => "number would be zero for non-zero type",
                _ => "invalid digit found in string",
            };
            eprintln!(
                "-{}, --{} <integer> expected. ParseIntError {{ kind: {} }}",
                short, long, kind_short
            );
            eprintln!("error: {}", msg);
            let _ = (kind_short,);
            return Err(());
        }
    }
}

fn use_color(color_flag: Option<&str>) -> bool {
    match color_flag {
        Some("1") => true,
        Some("0") => false,
        _ => {
            if env::var_os("NO_COLOR").is_some() {
                return false;
            }
            // Check if stdout is a TTY
            is_stdout_tty()
        }
    }
}

#[cfg(unix)]
fn is_stdout_tty() -> bool {
    use std::os::unix::io::AsRawFd;
    let fd = io::stdout().as_raw_fd();
    unsafe { libc_isatty(fd) != 0 }
}

#[cfg(not(unix))]
fn is_stdout_tty() -> bool {
    false
}

extern "C" {
    fn isatty(fd: i32) -> i32;
}

#[cfg(unix)]
unsafe fn libc_isatty(fd: i32) -> i32 {
    isatty(fd)
}

/// Color number for a byte: byte value, except 0 → 22.
fn color_for_byte(b: u8) -> u8 {
    if b == 0 {
        22
    } else {
        b
    }
}

/// Format a single byte representation according to `format` and `prefix`.
fn format_byte(b: u8, format: &str, prefix: bool) -> String {
    match format {
        "o" => {
            if prefix {
                format!("0o{:04o}", b)
            } else {
                format!("{:04o}", b)
            }
        }
        "x" => {
            if prefix {
                format!("0x{:02x}", b)
            } else {
                format!("{:02x}", b)
            }
        }
        "X" => {
            if prefix {
                format!("0x{:02X}", b)
            } else {
                format!("{:02X}", b)
            }
        }
        "b" => {
            if prefix {
                format!("0b{:08b}", b)
            } else {
                format!("{:08b}", b)
            }
        }
        _ => unreachable!(),
    }
}

fn ascii_char(b: u8) -> char {
    if (0x20..=0x7e).contains(&b) {
        b as char
    } else {
        '.'
    }
}

fn print_hex_view<W: Write>(
    out: &mut W,
    data: &[u8],
    cols: u64,
    format: &str,
    prefix: bool,
    color: bool,
) -> io::Result<()> {
    let token_width = match format {
        "x" | "X" => if prefix { 4 } else { 2 },
        "o" => if prefix { 6 } else { 4 },
        "b" => if prefix { 10 } else { 8 },
        _ => unreachable!(),
    };

    // Special-case cols == 0: behaves like cols == 1 but with zero-width pad.
    let effective_cols = if cols == 0 { 1usize } else { cols as usize };
    let pad_per_slot = if cols == 0 { 0usize } else { 5usize };

    let mut offset: usize = 0;
    let total = data.len();

    if total == 0 {
        write_offset_header(out, offset)?;
        // Empty line with pad_per_slot * effective_cols spaces
        write_n_spaces(out, pad_per_slot * effective_cols)?;
        writeln!(out)?;
    } else {
        let mut i = 0;
        while i < total {
            let end = (i + effective_cols).min(total);
            let row = &data[i..end];
            write_offset_header(out, offset + i)?;
            // Present byte slots
            for &b in row.iter() {
                let token = format_byte(b, format, prefix);
                if color {
                    let c = color_for_byte(b);
                    write!(out, "\x1b[38;5;{}m{}\x1b[0m ", c, token)?;
                } else {
                    write!(out, "{} ", token)?;
                }
            }
            // Absent slots: 5 spaces each (or 0 if cols==0)
            let absent = effective_cols - row.len();
            // Each absent slot pads by 5 spaces (or 0 for cols==0)
            write_n_spaces(out, 5 * absent)?;
            // ASCII section
            for &b in row.iter() {
                let ch = ascii_char(b);
                if color {
                    let c = color_for_byte(b);
                    write!(out, "\x1b[38;5;{}m{}\x1b[0m", c, ch)?;
                } else {
                    write!(out, "{}", ch)?;
                }
            }
            writeln!(out)?;
            i = end;
        }
        // Trailing empty line if total % effective_cols == 0
        if total % effective_cols == 0 {
            write_offset_header(out, offset + total)?;
            write_n_spaces(out, pad_per_slot * effective_cols)?;
            writeln!(out)?;
        }
    }

    writeln!(out, "   bytes: {}", total)?;
    Ok(())
}

fn write_offset_header<W: Write>(out: &mut W, offset: usize) -> io::Result<()> {
    write!(out, "0x{:06x}: ", offset)
}

fn write_n_spaces<W: Write>(out: &mut W, n: usize) -> io::Result<()> {
    // Use Rust's format machinery so we panic identically to the reference
    // (`Formatting argument out of range`) when n > u16::MAX.
    if n == 0 {
        return Ok(());
    }
    write!(out, "{:>w$}", "", w = n)
}

struct ArrayTemplate {
    header: &'static str,
    footer: &'static str,
    separator: &'static str,
    /// If true, separator is also printed after the LAST byte (Go style).
    trail_after_last: bool,
    /// Token suffix appended to each byte (after the hex representation), e.g. "uy" for FSharp.
    token_suffix: &'static str,
}

fn array_template(a: &str, len: usize) -> (String, ArrayTemplate) {
    match a {
        "r" => (
            format!("let ARRAY: [u8; {}] = [\n", len),
            ArrayTemplate {
                header: "",
                footer: "\n];",
                separator: ", ",
                trail_after_last: false,
                token_suffix: "",
            },
        ),
        "c" => (
            format!("unsigned char ARRAY[{}] = {{\n", len),
            ArrayTemplate {
                header: "",
                footer: "\n};",
                separator: ", ",
                trail_after_last: false,
                token_suffix: "",
            },
        ),
        "g" => (
            format!("a := [{}]byte{{\n", len),
            ArrayTemplate {
                header: "",
                footer: "\n}",
                separator: ", ",
                trail_after_last: true,
                token_suffix: "",
            },
        ),
        "p" => (
            "a = [\n".to_string(),
            ArrayTemplate {
                header: "",
                footer: "\n]",
                separator: ", ",
                trail_after_last: false,
                token_suffix: "",
            },
        ),
        "k" => (
            "val a = byteArrayOf(\n".to_string(),
            ArrayTemplate {
                header: "",
                footer: "\n)",
                separator: ", ",
                trail_after_last: false,
                token_suffix: "",
            },
        ),
        "j" => (
            "byte[] a = new byte[]{\n".to_string(),
            ArrayTemplate {
                header: "",
                footer: "\n};",
                separator: ", ",
                trail_after_last: false,
                token_suffix: "",
            },
        ),
        "s" => (
            "let a: [UInt8] = [\n".to_string(),
            ArrayTemplate {
                header: "",
                footer: "\n]",
                separator: ", ",
                trail_after_last: false,
                token_suffix: "",
            },
        ),
        "f" => (
            "let a = [|\n".to_string(),
            ArrayTemplate {
                header: "",
                footer: "\n|]",
                separator: "; ",
                trail_after_last: false,
                token_suffix: "uy",
            },
        ),
        _ => unreachable!(),
    }
}

fn print_array_view<W: Write>(
    out: &mut W,
    data: &[u8],
    cols: u64,
    array: &str,
) -> io::Result<()> {
    let (intro, tpl) = array_template(array, data.len());
    write!(out, "{}", intro)?;
    // Special: cols == 0 behaves like cols == 1.
    let effective_cols = if cols == 0 { 1usize } else { cols as usize };
    let total = data.len();

    // Initial indent
    write!(out, "    ")?;
    for (i, &b) in data.iter().enumerate() {
        write!(out, "0x{:02x}{}", b, tpl.token_suffix)?;
        let is_last = i == total - 1;
        let end_of_row = i % effective_cols == effective_cols - 1;

        // Separator
        if !is_last || tpl.trail_after_last {
            write!(out, "{}", tpl.separator)?;
        }
        // End-of-row newline + indent (even for last byte if at end of row)
        if end_of_row {
            write!(out, "\n    ")?;
        }
    }
    // If the last byte was NOT at end of row, no indent was started; we need just \n.
    // If the last byte WAS at end of row OR data is empty: we already wrote indent "    " (initial),
    // need to terminate that with \n.
    if total == 0 {
        // initial indent already printed, terminate
        writeln!(out)?;
    } else {
        let last_at_end = (total - 1) % effective_cols == effective_cols - 1;
        if last_at_end {
            // We already wrote "\n    " after last byte → terminate that line
            writeln!(out)?;
        } else {
            // No indent to terminate, just \n
            writeln!(out)?;
        }
    }
    write!(out, "{}", &tpl.footer[1..])?; // skip leading \n already handled
    writeln!(out)?;
    Ok(())
}

fn print_wave<W: Write>(out: &mut W, n: u64, places: u64) -> io::Result<()> {
    if n == 0 {
        writeln!(out)?;
        return Ok(());
    }
    let pi = std::f64::consts::PI;
    for i in 0..n {
        let v = (pi * ((i as f64) / (2.0 * (n as f64)))).sin();
        write!(out, "{:.*},", places as usize, v)?;
        if (i + 1) % 10 == 0 {
            writeln!(out)?;
        }
    }
    // If the last value was NOT at end of row, we need a final newline
    let total = n;
    if total % 10 != 0 {
        writeln!(out)?;
    } else {
        // Add extra blank line
        writeln!(out)?;
    }
    Ok(())
}

fn read_input(file: Option<&str>, limit: u64) -> io::Result<Vec<u8>> {
    let mut buf = Vec::new();
    match file {
        Some(path) => {
            let f = fs::File::open(path)?;
            if limit == 0 {
                let mut r = f;
                r.read_to_end(&mut buf)?;
            } else {
                let mut r = f.take(limit);
                r.read_to_end(&mut buf)?;
            }
        }
        None => {
            let stdin = io::stdin();
            if limit == 0 {
                stdin.lock().read_to_end(&mut buf)?;
            } else {
                let mut r = stdin.lock().take(limit);
                r.read_to_end(&mut buf)?;
            }
        }
    }
    Ok(buf)
}

fn run() -> u8 {
    let cmd = build_cli();
    let matches = match cmd.try_get_matches() {
        Ok(m) => m,
        Err(e) => {
            // Print clap error and exit with the right code.
            e.print().ok();
            return if e.use_stderr() { 2 } else { 0 };
        }
    };

    // Parse u64 args via custom parser
    let cols = match matches.get_one::<String>("cols") {
        Some(v) => match parse_u64_arg(v, 'c', "cols") {
            Ok(n) => n,
            Err(_) => return 1,
        },
        None => 10,
    };
    let len = match matches.get_one::<String>("len") {
        Some(v) => match parse_u64_arg(v, 'l', "len") {
            Ok(n) => n,
            Err(_) => return 1,
        },
        None => 0,
    };
    let func = match matches.get_one::<String>("func") {
        Some(v) => match parse_u64_arg(v, 'u', "func") {
            Ok(n) => Some(n),
            Err(_) => return 1,
        },
        None => None,
    };

    let places = if func.is_some() {
        match matches.get_one::<String>("places") {
            Some(v) => match parse_u64_arg(v, 'p', "places") {
                Ok(n) => n,
                Err(_) => return 1,
            },
            None => 4,
        }
    } else {
        4
    };

    let format = matches
        .get_one::<String>("format")
        .map(|s| s.as_str())
        .unwrap_or("x");
    let array = matches.get_one::<String>("array").map(|s| s.as_str());
    let color_flag = matches.get_one::<String>("color").map(|s| s.as_str());
    let prefix_flag = matches.get_one::<String>("prefix").map(|s| s.as_str());
    let prefix = match prefix_flag {
        Some("0") => false,
        _ => true,
    };

    let stdout = io::stdout();
    let mut out = stdout.lock();

    // Wave mode (highest priority)
    if let Some(n) = func {
        if let Err(_) = print_wave(&mut out, n, places) {
            return 1;
        }
        return 0;
    }

    // Read input
    let file = matches
        .get_one::<String>("INPUTFILE")
        .map(|s| s.as_str());
    let data = match read_input(file, len) {
        Ok(d) => d,
        Err(e) => {
            eprintln!("error: {} (os error {})", os_error_label(&e), e.raw_os_error().unwrap_or(0));
            return 1;
        }
    };

    if let Some(a) = array {
        if let Err(_) = print_array_view(&mut out, &data, cols, a) {
            return 1;
        }
        return 0;
    }

    let color = use_color(color_flag);
    if let Err(_) = print_hex_view(&mut out, &data, cols, format, prefix, color) {
        return 1;
    }
    0
}

fn os_error_label(e: &io::Error) -> String {
    // The reference prints English strings exactly as the OS returns them.
    // e.to_string() includes the "(os error N)" suffix on some platforms;
    // we want just the message portion.
    let s = e.to_string();
    // Strip trailing " (os error N)" if present
    if let Some(idx) = s.rfind(" (os error ") {
        s[..idx].to_string()
    } else {
        s
    }
}

fn main() -> ExitCode {
    ExitCode::from(run())
}
