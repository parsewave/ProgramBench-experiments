#!/bin/bash
# Larger random fuzzing
set -u
REF=/workspace/executable
SUT=/work/work/executable
TOTAL=0
FAILS=0

cmp_call() {
    local desc="$1"
    shift
    local stdin_file="$1"
    shift
    TOTAL=$((TOTAL + 1))
    if [ "$stdin_file" = "-" ]; then
        "$REF" "$@" > /tmp/_r.out 2> /tmp/_r.err; local re=$?
        "$SUT" "$@" > /tmp/_s.out 2> /tmp/_s.err; local se=$?
    else
        "$REF" "$@" < "$stdin_file" > /tmp/_r.out 2> /tmp/_r.err; local re=$?
        "$SUT" "$@" < "$stdin_file" > /tmp/_s.out 2> /tmp/_s.err; local se=$?
    fi
    local issues=""
    [ "$re" != "$se" ] && issues+="exit($re/$se) "
    cmp -s /tmp/_r.out /tmp/_s.out || issues+="stdout "
    cmp -s /tmp/_r.err /tmp/_s.err || issues+="stderr "
    if [ -n "$issues" ]; then
        echo "FAIL [$desc] $issues" "$@" "(stdin=$stdin_file)"
        FAILS=$((FAILS + 1))
        if [ $FAILS -le 5 ]; then
            echo "--- ref stdout (first 200) ---"
            head -c 200 /tmp/_r.out
            echo "--- sut stdout (first 200) ---"
            head -c 200 /tmp/_s.out
            echo "--- ref stderr ---"
            head -5 /tmp/_r.err
            echo "--- sut stderr ---"
            head -5 /tmp/_s.err
            echo "---"
        fi
    fi
}

# Random binary inputs of various sizes
mkdir -p /tmp/big_fuzz
rm -f /tmp/big_fuzz/*
for i in {1..20}; do
    size=$((RANDOM % 2000))
    head -c $size /dev/urandom > /tmp/big_fuzz/in_$i.bin
done

formats=(o x X b)
arrays=(r c g p k j s f)

for inp in /tmp/big_fuzz/in_*.bin; do
    # Vary cols
    for c in $(seq 1 20); do
        cmp_call "c${c}_$(basename $inp .bin)" "$inp" -c $c
    done
    # Format combos
    for f in "${formats[@]}"; do
        for r in 0 1; do
            cmp_call "${f}_${r}_$(basename $inp .bin)" "$inp" -f $f -r $r
        done
    done
    # All arrays with -c 3 and -c 10
    for a in "${arrays[@]}"; do
        cmp_call "a${a}_c3_$(basename $inp .bin)" "$inp" -a $a -c 3
        cmp_call "a${a}_c10_$(basename $inp .bin)" "$inp" -a $a -c 10
    done
    # Color
    cmp_call "t1_$(basename $inp .bin)" "$inp" -t 1
    cmp_call "t0_$(basename $inp .bin)" "$inp" -t 0
    # -l
    cmp_call "l5_$(basename $inp .bin)" "$inp" -l 5
    cmp_call "l50_$(basename $inp .bin)" "$inp" -l 50
done

# Wave with various
for n in 0 1 3 5 7 10 11 13 17 19 23 29 31 50 79 100 127 200 300 500 1000; do
    for p in 0 1 2 4 7 9 15; do
        cmp_call "w${n}_p${p}" - -u $n -p $p
    done
done

echo "==="
echo "Total: $TOTAL | Failures: $FAILS"
