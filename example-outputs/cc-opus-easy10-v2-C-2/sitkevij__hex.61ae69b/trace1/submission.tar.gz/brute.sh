#!/bin/bash
# Brute force fuzz testing: random arg combos + random inputs
set -u
REF=/workspace/executable
SUT=/work/work/executable
FAILS=()

run_one() {
    local desc="$1"
    shift
    local stdin_file="$1"
    shift
    if [ "$stdin_file" = "-" ]; then
        "$REF" "$@" > /tmp/_r.out 2> /tmp/_r.err; local re=$?
        "$SUT" "$@" > /tmp/_s.out 2> /tmp/_s.err; local se=$?
    else
        "$REF" "$@" < "$stdin_file" > /tmp/_r.out 2> /tmp/_r.err; local re=$?
        "$SUT" "$@" < "$stdin_file" > /tmp/_s.out 2> /tmp/_s.err; local se=$?
    fi
    local issues=""
    [ "$re" != "$se" ] && issues+="exit($re vs $se) "
    cmp -s /tmp/_r.out /tmp/_s.out || issues+="stdout "
    cmp -s /tmp/_r.err /tmp/_s.err || issues+="stderr "
    if [ -n "$issues" ]; then
        echo "FAIL [$desc] $issues ARGS:" "$@" "(stdin=$stdin_file)"
        FAILS+=("$desc")
        # Save diff for inspection
        cp /tmp/_r.out /tmp/last_fail_ref.out
        cp /tmp/_s.out /tmp/last_fail_sut.out
        cp /tmp/_r.err /tmp/last_fail_ref.err
        cp /tmp/_s.err /tmp/last_fail_sut.err
    fi
}

# Generate random binary inputs
mkdir -p /tmp/fuzz_inputs
rm -f /tmp/fuzz_inputs/*
for i in 1 2 3 4 5; do
    size=$((RANDOM % 1000))
    head -c $size /dev/urandom > /tmp/fuzz_inputs/in_$i.bin
done
# All-bytes input
python3 -c 'import sys; sys.stdout.buffer.write(bytes(range(256)))' > /tmp/fuzz_inputs/all_bytes.bin
# Just nulls
python3 -c 'import sys; sys.stdout.buffer.write(b"\x00" * 30)' > /tmp/fuzz_inputs/nulls.bin
# Just printable
python3 -c 'import sys; sys.stdout.buffer.write(b"ABCDEFGHIJ" * 5)' > /tmp/fuzz_inputs/printable.bin

declare -a inputs=(
    /tmp/fuzz_inputs/in_1.bin
    /tmp/fuzz_inputs/in_2.bin
    /tmp/fuzz_inputs/in_3.bin
    /tmp/fuzz_inputs/in_4.bin
    /tmp/fuzz_inputs/in_5.bin
    /tmp/fuzz_inputs/all_bytes.bin
    /tmp/fuzz_inputs/nulls.bin
    /tmp/fuzz_inputs/printable.bin
)

formats=(o x X b)
arrays=(r c g p k j s f)

count=0
for inp in "${inputs[@]}"; do
    # Default mode
    run_one "default_$(basename $inp .bin)" "$inp"
    count=$((count + 1))
    # Various cols
    for c in 0 1 2 5 10 16 32; do
        run_one "cols_${c}_$(basename $inp .bin)" "$inp" -c $c
        count=$((count + 1))
    done
    # Various formats
    for f in "${formats[@]}"; do
        run_one "fmt_${f}_$(basename $inp .bin)" "$inp" -f $f
        count=$((count + 1))
        run_one "fmt_${f}_r0_$(basename $inp .bin)" "$inp" -f $f -r 0
        count=$((count + 1))
    done
    # Array
    for a in "${arrays[@]}"; do
        run_one "arr_${a}_$(basename $inp .bin)" "$inp" -a $a
        count=$((count + 1))
        run_one "arr_${a}_c3_$(basename $inp .bin)" "$inp" -a $a -c 3
        count=$((count + 1))
    done
    # Color
    run_one "color_$(basename $inp .bin)" "$inp" -t 1
    count=$((count + 1))
    # -l
    for l in 0 1 5 100; do
        run_one "len_${l}_$(basename $inp .bin)" "$inp" -l $l
        count=$((count + 1))
    done
done

# Wave (no input)
for n in 0 1 2 3 5 7 10 11 13 15 20 100; do
    for p in 0 1 2 4 6 10; do
        run_one "wave_${n}_${p}" - -u $n -p $p
        count=$((count + 1))
    done
done

# Help / version
run_one "help" - --help
run_one "version" - --version
run_one "h_short" - -h
run_one "V_short" - -V
count=$((count + 4))

# Edge: clap errors
for args in "-c" "-l" "-f" "-a" "-t" "-u" "-p" "-r"; do
    run_one "miss_$args" - $args
    count=$((count + 1))
done

# Edge: bad values
run_one "bad_cols" - -c xyz
run_one "bad_len" - -l xyz
run_one "bad_func" - -u xyz
run_one "bad_format" - -f q
run_one "bad_array" - -a z
run_one "bad_color" - -t 5
run_one "bad_prefix" - -r 5
count=$((count + 7))

# Overflow
run_one "ov_cols" - -c 99999999999999999999
run_one "ov_len" - -l 99999999999999999999
run_one "ov_func" - -u 99999999999999999999
count=$((count + 3))

# File handling
run_one "no_args" -
run_one "nonexistent" - /no/such/file
run_one "dir" - /tmp
run_one "devnull" - /dev/null
run_one "fifo_args" - -- foo bar
run_one "unknown_flag" - --xyz
count=$((count + 6))

echo "==="
echo "Total: $count | Failures: ${#FAILS[@]}"
[ ${#FAILS[@]} -gt 0 ] && printf '  %s\n' "${FAILS[@]}"
