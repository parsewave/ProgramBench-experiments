#!/bin/bash
# Build the hx reimplementation. The grader expects ./executable in this directory.
set -e
cd "$(dirname "$0")"

export PATH="/usr/local/cargo/bin:$PATH"
export CARGO_TARGET_DIR=target

# Build the binary
cargo build --release --offline --quiet

# Copy/move the binary to ./executable
cp -f target/release/executable ./executable
chmod +x ./executable
