# hx — behavior map

## Identity
- Name: `hx` ("Futuristic take on hexdump, made in Rust")
- Version: `hx 0.7.0`
- Binary name as invoked: `executable`

## CLI (clap-style)

| Short | Long | Type | Default | Notes |
|-------|------|------|---------|-------|
| -c | --cols <columns> | u64 | 10 | Bytes per row. 0 → one byte per row but empty slot width 0. |
| -l | --len <len> | u64 | 0 | Read up to N bytes from input. 0 means "all". |
| -f | --format <o\|x\|X\|b> | enum | x | Octet display. Octal "0o0NNN", LowerHex "0xnn", UpperHex "0xNN", Binary "0bNNNNNNNN". |
| -t | --color <0\|1> | enum | auto | 0=off, 1=on. Default depends on TTY + NO_COLOR. |
| -a | --array <r\|c\|g\|p\|k\|j\|s\|f> | enum | none | Emit source array literal instead of hex view. |
| -u | --func <func_length> | u64 | none | Output N samples of sin(πi/(2N)). Suppresses other modes. |
| -p | --places <func_places> | u64 | 4 | Decimal places used by -u. Only validated when -u is given. |
| -r | --prefix <0\|1> | enum | 1 | Include `0x`/`0o`/`0b` prefix in hex view. Does not affect -a/-u. |
| -h | --help | flag |  | Standard clap help. Exit 0. |
| -V | --version | flag |  | "hx 0.7.0". Exit 0. |

Argument: `[INPUTFILE]` (optional). If given, reads file; else reads stdin.

Custom integer parsers exist for -c, -l, -u, -p (when -u is set). Error format:
```
{flag}, {long} <integer> expected. ParseIntError { kind: InvalidDigit }
error: invalid digit found in string
```
or `PosOverflow` / `number too large to fit in target type`. Both lines on stderr. Exit 1.

Clap errors (unknown flag, invalid value, duplicate flag, missing value, extra positional) exit 2.

## Mode precedence
1. `-u` set: function-wave mode. Ignores stdin/file/-a/-t.
2. Else `-a` set: array mode. Ignores -t and -f.
3. Else: hex view.

## Color decision
1. `-t 1`: ON always.
2. `-t 0`: OFF always.
3. `NO_COLOR` env var present (any value, including empty): OFF.
4. stdout is a TTY: ON.
5. else: OFF.

## Color mapping
- Each colored byte and each colored ASCII char is wrapped in `\e[38;5;Nm` ... `\e[0m`.
- N = byte value (decimal), EXCEPT byte 0x00 → 22.
- Offset header, separator spaces, empty slots, ASCII spaces are NOT colored.
- Final empty trailing line (when bytes%cols==0) is NOT colored.
- "   bytes: N\n" line is NOT colored.
- Color is applied only in hex view, NOT array or wave.

## Hex view layout

For each row of up to `cols` bytes from data:
```
"0x" + {offset:06x} + ": " + per_byte_slots + ascii_chars + "\n"
```

- Offset is hex with min width 6, expanded as needed (e.g., `0x1000000:`).
- Each present byte slot: `{byte_repr} ` where slot width follows the format:
  - hex prefix on: 4-char repr + 1 space = 5 chars per slot
  - hex prefix off (-r 0): 2-char repr + 1 space = 3 chars per slot
  - octal prefix on: 6-char repr + 1 space = 7 chars per slot
  - octal prefix off: 4-char repr + 1 space = 5 chars per slot
  - binary prefix on: 10-char repr + 1 space = 11 chars per slot
  - binary prefix off: 8-char repr + 1 space = 9 chars per slot
- Each absent slot: 5 chars of spaces (regardless of format).
- ASCII chars: byte if 0x20 <= b <= 0x7e else `.`. For absent positions: nothing (line ends).
- When color is ON, the `{byte_repr}` substring is wrapped in ANSI escape; the trailing slot space is NOT colored. Same for ASCII chars: each printable char or `.` is individually wrapped.

After data rows: if `len % cols == 0` (including len=0), print a final empty offset line:
```
"0x" + {next_offset:06x} + ": " + (5*cols spaces) + "\n"
```
This empty line is NEVER colored.

Last line always:
```
"   bytes: " + {len} + "\n"
```

### Edge case: -c 0
- Acts like -c 1 (one byte per line)
- But the absent slot pad is 0 spaces (since 5*0 = 0)
- Trailing line is still printed (always `len % 1 == 0` ... well actually empty input → just one empty line + bytes count)
- Each line: `"0x{offset:06x}: " + {byte_repr} + " " + ascii_char + "\n"`
- Trailing line: `"0x{offset:06x}: \n"` (no spaces after colon!)

### Format examples

```
Hex+prefix:  0x61
Hex+!prefix: 61
UpperHex+prefix: 0xAB
Octal+prefix:    0o0141
Binary+prefix:   0b01100001
```

## Array mode (`-a`)

Templates (LEN is the byte count read):
- `r` (Rust):    header `let ARRAY: [u8; {LEN}] = [\n`, footer `\n];`
- `c` (C):       header `unsigned char ARRAY[{LEN}] = {\n`, footer `\n};`
- `g` (Go):      header `a := [{LEN}]byte{\n`, footer `\n}`
- `p` (Python):  header `a = [\n`, footer `\n]`
- `k` (Kotlin):  header `val a = byteArrayOf(\n`, footer `\n)`
- `j` (Java):    header `byte[] a = new byte[]{\n`, footer `\n};`
- `s` (Swift):   header `let a: [UInt8] = [\n`, footer `\n]`
- `f` (FSharp):  header `let a = [|\n`, footer `\n|]`

Body algorithm:
1. Print 4-space indent.
2. For each byte at index `i` (0-based) in data:
   a. Print byte token: `0x{b:02x}` (lowercase always); for FSharp also append `uy`.
   b. Determine separator: for FSharp `; `, others `, `.
   c. Print separator after byte if: NOT last byte OR Go (Go always prints).
   d. If `i % cols == cols - 1` and NOT last byte: print `\n` + 4-space indent (start next row).
   e. If `i % cols == cols - 1` and IS last byte: print `\n` + 4-space indent (start next row anyway — produces trailing empty row).
3. Always end body with `\n`.
4. Then print footer.

(In step 2.e the “empty row” path means an exact-multiple-of-cols length triggers a trailing `\n    \n`.)

Equivalent formulation: print indent + body where each row is `cols` bytes long, separator `, ` (or `; `), last byte in array has no trailing separator (Go does), each row ends with `\n` + indent; final indent line is followed by `\n`. The trailing indent before `\n` always appears (giving the "extra empty line" for length-multiple-of-cols and for empty arrays).

Array is never colorized.

`-f` does not change array output (always `0x{:02x}` lowercase).
`-r 0` does not change array output.
`-l N` limits data, `-c N` controls cols.
`-c 0` puts each byte on its own line and produces the trailing indent line.

## Wave mode (`-u`)

Output: for N from -u and P from -p (default 4):
- For i = 0 .. N-1: print `sin(π * i / (2 * N))` formatted with P decimal places, then `,`.
- Wrap at 10 numbers per line: after every group of 10 print `\n`.
- After the final number, print `\n`.
- If N % 10 == 0 AND N > 0: print an additional empty line `\n`.
- Special: N == 0 prints just `\n`.

Formula confirmed: `sin(π * i / (2 * N))` using f64.

Wave never colorized, ignores file/stdin, ignores -c/-a/-t/-f/-r/-l.

## Reading input

- If a positional file path is provided: open and read up to -l (or all if 0).
- Else: read from stdin up to -l (or all).
- File errors: `error: {OS error message} (os error {errno})` on stderr, exit 1.
  - `No such file or directory (os error 2)`
  - `Is a directory (os error 21)`

`-` is not special. `--` works as POSIX double-dash.

## Exit codes
- 0: success
- 1: file open error, custom integer parser error
- 2: clap CLI error (unknown flag, bad value, etc.)
- 101: Rust panic (cols too large for format width)

## ASCII printable predicate
- Print byte verbatim if `0x20 <= b <= 0x7e`.
- Else print `.`.

## Color number choice
- byte == 0 → 22
- else → byte value (1..=255)
