#!/bin/bash
# Build script - produces ./executable in /work/work/
set -e
cd "$(dirname "$0")"

# Locate rust toolchain
if command -v rustc >/dev/null 2>&1; then
    : # rustc in PATH
elif [ -x /usr/local/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/rustc ]; then
    export PATH=/usr/local/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin:$PATH
elif [ -d /usr/local/rustup/toolchains ]; then
    export PATH=$(find /usr/local/rustup/toolchains -maxdepth 2 -name bin -type d | head -1):$PATH
fi

# Build with rustc directly (single binary, no external deps)
RUSTC=${RUSTC:-rustc}

# Compile our single-file Rust program
$RUSTC -O -C opt-level=3 -C debuginfo=0 -o executable src/main.rs

chmod +x executable
