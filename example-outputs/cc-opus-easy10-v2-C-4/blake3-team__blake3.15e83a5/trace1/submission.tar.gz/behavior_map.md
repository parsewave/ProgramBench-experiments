# b3sum behavior map

## Version
- `--version` / `-V` → stdout `b3sum 1.8.4\n`, exit 0

## Help
- `--help` → stdout full help (62 lines), exit 0
- `-h` → stdout short help, exit 0

## Default behavior (no flags)
- No args, no stdin: hash empty input, output `<64hex>  -\n`
- No args, stdin: hash stdin, output `<64hex>  -\n`
- File arg: hash file, output `<64hex>  <FILE>\n`
- Multiple files: one line per file
- `-` as file: stdin (same as no arg)
- `--`: end of flags, following are positional

## Flags

### --keyed
- Reads 32 bytes from stdin as key
- < 32 bytes: `Error: expected 32 key bytes from stdin, found N` (Error: prefix, exit 1)
- > 32 bytes: `Error: read more than 32 key bytes from stdin` (exit 1)
- Requires file args (FILE...)
- Cannot use `-` as file: `b3sum: -: Cannot open `-` in keyed mode` (exit 1)
- Conflicts with: --derive-key

### --derive-key <CONTEXT>
- Reads key material from stdin (or file)
- Conflicts with: --keyed, --check
- Required argument value

### --length <LEN> (default 32)
- u64
- Empty / negative / non-digit → clap error exit 2
- 0 → empty hash field
- Up to large values supported (XOF stream)
- Conflicts with: --check
- Repeated → "cannot be used multiple times" exit 2

### --seek <SEEK> (default 0)
- u64
- Seek into XOF stream
- Compatible with --tag and --length
- Conflicts: --check forbidden? actually no conflict but check ignores it

### --num-threads <NUM>
- u64 (cannot be negative as -1)
- 0 = use default
- Invalid → clap error exit 2

### --no-mmap
- Just disables mmap, output same

### --no-names
- Omit filename from output
- Combined with --tag: tag is also omitted (just hash)
- Combined with --raw: still raw bytes
- Conflicts with: --check

### --raw
- Write raw output bytes (no hex, no newline)
- Only ONE input file allowed: `Error: Only one filename can be provided when using --raw` (exit 1)
- Multiple files including stdin: error
- Conflicts with: --check

### --tag
- BSD-style output: `BLAKE3 (FILE) = HASH\n`
- For stdin: `BLAKE3 (-) = HASH\n`
- --no-names overrides --tag (just hash)
- Conflicts with: --check

### --check / -c
- Read sum lines from files or stdin
- Standard format: `<64hex>  <FILE>` (exactly two spaces)
- Tag format: `BLAKE3 (FILE) = <64hex>` (greedy match for closing paren)
- Escaped filename: line starts with `\`, then `\\` decodes to `\`, `\n` decodes to newline
- For each line, compute hash of file and compare
- Output: `FILE: OK\n` or `FILE: FAILED\n` or `FILE: FAILED (error)\n`
- Errors per line: `b3sum: <MESSAGE>\n` to stderr (Empty line, Invalid check line format, Invalid hex, Invalid hash length, empty file path)
- After all: if any failed → `b3sum: WARNING: N computed checksum(s) did NOT match\n` to stderr, exit 1
- Singular "checksum" if N=1, plural "checksums" if N>1
- Conflicts: --raw, --no-names, --tag, --keyed, --derive-key, --length

### --quiet
- Used with --check, suppresses OK lines
- Without --check → required arg missing error exit 2

## Error message formats
- File errors: `b3sum: <PATH>: <REASON> (os error N)\n` to stderr, exit 1
- anyhow errors: `Error: <MSG>\n` to stderr, exit 1
- clap errors: `error: <MSG>\n\nFor more information, try '--help'.\n` to stderr, exit 2
- Clap conflicts: `error: the argument '--X' cannot be used with '--Y'\n\nUsage: ...\n\nFor more information, try '--help'.\n` exit 2

## Output formats
- Regular: `<HEX>  <FILE>\n` (2 spaces between)
- Tag: `BLAKE3 (<FILE>) = <HEX>\n`
- Filename with `\` or `\n`: line prefixed with `\`, characters escaped (`\` → `\\`, `\n` → `\n`)
- Stdin filename = `-`
- Raw: raw bytes (no newline, no filename)
- Hex is lowercase

## Behavior details
- Empty input hash: `af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262`
- Hash of "hello world" (no newline): `d74981efa70a0c880b8d8c1985d075dbcbf679b99a5f9914e5aaf96b831a9e24`
- Hash of "hello world\n": `dc5a4edb8240b018124052c330270696f96771a63b45250a5c17d3000e823355`

## Special paths
- Directory: `b3sum: <PATH>: Is a directory (os error 21)` exit 1
- Missing: `b3sum: <PATH>: No such file or directory (os error 2)` exit 1
- Permission: `b3sum: <PATH>: Permission denied (os error 13)` exit 1
- Symlink resolved
- Multiple files: continue after error, exit 1 if any fail
