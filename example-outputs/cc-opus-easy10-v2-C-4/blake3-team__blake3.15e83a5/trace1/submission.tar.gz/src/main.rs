// b3sum reimplementation - BLAKE3 algorithm and CLI

use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::process::ExitCode;

// ============ BLAKE3 algorithm ============

const IV: [u32; 8] = [
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
];

const MSG_PERMUTATION: [usize; 16] = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8];

const CHUNK_START: u32 = 1 << 0;
const CHUNK_END: u32 = 1 << 1;
const PARENT: u32 = 1 << 2;
const ROOT: u32 = 1 << 3;
const KEYED_HASH: u32 = 1 << 4;
const DERIVE_KEY_CONTEXT: u32 = 1 << 5;
const DERIVE_KEY_MATERIAL: u32 = 1 << 6;

const BLOCK_LEN: usize = 64;
const CHUNK_LEN: usize = 1024;

#[inline(always)]
fn g(state: &mut [u32; 16], a: usize, b: usize, c: usize, d: usize, mx: u32, my: u32) {
    state[a] = state[a].wrapping_add(state[b]).wrapping_add(mx);
    state[d] = (state[d] ^ state[a]).rotate_right(16);
    state[c] = state[c].wrapping_add(state[d]);
    state[b] = (state[b] ^ state[c]).rotate_right(12);
    state[a] = state[a].wrapping_add(state[b]).wrapping_add(my);
    state[d] = (state[d] ^ state[a]).rotate_right(8);
    state[c] = state[c].wrapping_add(state[d]);
    state[b] = (state[b] ^ state[c]).rotate_right(7);
}

#[inline]
fn round_fn(state: &mut [u32; 16], m: &[u32; 16]) {
    g(state, 0, 4, 8, 12, m[0], m[1]);
    g(state, 1, 5, 9, 13, m[2], m[3]);
    g(state, 2, 6, 10, 14, m[4], m[5]);
    g(state, 3, 7, 11, 15, m[6], m[7]);
    g(state, 0, 5, 10, 15, m[8], m[9]);
    g(state, 1, 6, 11, 12, m[10], m[11]);
    g(state, 2, 7, 8, 13, m[12], m[13]);
    g(state, 3, 4, 9, 14, m[14], m[15]);
}

#[inline]
fn permute(m: &mut [u32; 16]) {
    let mut perm = [0u32; 16];
    for i in 0..16 {
        perm[i] = m[MSG_PERMUTATION[i]];
    }
    *m = perm;
}

#[inline]
fn compress(cv: &[u32; 8], block: &[u32; 16], counter: u64, block_len: u32, flags: u32) -> [u32; 16] {
    let mut state: [u32; 16] = [
        cv[0], cv[1], cv[2], cv[3], cv[4], cv[5], cv[6], cv[7],
        IV[0], IV[1], IV[2], IV[3],
        counter as u32, (counter >> 32) as u32, block_len, flags,
    ];
    let mut block = *block;

    round_fn(&mut state, &block); permute(&mut block);
    round_fn(&mut state, &block); permute(&mut block);
    round_fn(&mut state, &block); permute(&mut block);
    round_fn(&mut state, &block); permute(&mut block);
    round_fn(&mut state, &block); permute(&mut block);
    round_fn(&mut state, &block); permute(&mut block);
    round_fn(&mut state, &block);

    for i in 0..8 {
        state[i] ^= state[i + 8];
        state[i + 8] ^= cv[i];
    }

    state
}

fn words_from_le_bytes(bytes: &[u8], out: &mut [u32]) {
    for (i, chunk) in bytes.chunks(4).enumerate() {
        if chunk.len() == 4 {
            out[i] = u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
        } else {
            let mut buf = [0u8; 4];
            buf[..chunk.len()].copy_from_slice(chunk);
            out[i] = u32::from_le_bytes(buf);
        }
    }
}

#[derive(Clone)]
struct Output {
    input_cv: [u32; 8],
    block: [u32; 16],
    block_len: u32,
    counter: u64,
    flags: u32,
}

impl Output {
    fn chaining_value(&self) -> [u32; 8] {
        let state = compress(&self.input_cv, &self.block, self.counter, self.block_len, self.flags);
        let mut out = [0u32; 8];
        out.copy_from_slice(&state[0..8]);
        out
    }

    fn xof_bytes(&self, seek: u64, out: &mut [u8]) {
        if out.is_empty() { return; }
        let mut byte_pos: u64 = seek;
        let mut out_pos: usize = 0;
        while out_pos < out.len() {
            let block_num = byte_pos / 64;
            let block_offset = (byte_pos % 64) as usize;
            let state = compress(&self.input_cv, &self.block, block_num, self.block_len, self.flags | ROOT);
            let mut block_bytes = [0u8; 64];
            for i in 0..16 {
                block_bytes[i * 4..i * 4 + 4].copy_from_slice(&state[i].to_le_bytes());
            }
            let to_write = (out.len() - out_pos).min(64 - block_offset);
            out[out_pos..out_pos + to_write].copy_from_slice(&block_bytes[block_offset..block_offset + to_write]);
            out_pos += to_write;
            byte_pos += to_write as u64;
        }
    }
}

struct ChunkState {
    cv: [u32; 8],
    counter: u64,
    block: [u8; 64],
    block_len: u8,
    blocks_compressed: u8,
    flags: u32,
}

impl ChunkState {
    fn new(key: [u32; 8], counter: u64, flags: u32) -> Self {
        Self {
            cv: key,
            counter,
            block: [0; 64],
            block_len: 0,
            blocks_compressed: 0,
            flags,
        }
    }

    fn len(&self) -> usize {
        BLOCK_LEN * self.blocks_compressed as usize + self.block_len as usize
    }

    fn start_flag(&self) -> u32 {
        if self.blocks_compressed == 0 { CHUNK_START } else { 0 }
    }

    fn update(&mut self, mut input: &[u8]) {
        while !input.is_empty() {
            if self.block_len == BLOCK_LEN as u8 {
                let mut block_words = [0u32; 16];
                words_from_le_bytes(&self.block, &mut block_words);
                let state = compress(&self.cv, &block_words, self.counter, BLOCK_LEN as u32, self.flags | self.start_flag());
                self.cv.copy_from_slice(&state[0..8]);
                self.blocks_compressed += 1;
                self.block = [0; 64];
                self.block_len = 0;
            }
            let want = BLOCK_LEN - self.block_len as usize;
            let take = want.min(input.len());
            self.block[self.block_len as usize..self.block_len as usize + take].copy_from_slice(&input[..take]);
            self.block_len += take as u8;
            input = &input[take..];
        }
    }

    fn output(&self) -> Output {
        let mut block_words = [0u32; 16];
        words_from_le_bytes(&self.block, &mut block_words);
        Output {
            input_cv: self.cv,
            block: block_words,
            block_len: self.block_len as u32,
            counter: self.counter,
            flags: self.flags | self.start_flag() | CHUNK_END,
        }
    }
}

fn parent_output(left_cv: [u32; 8], right_cv: [u32; 8], key: [u32; 8], flags: u32) -> Output {
    let mut block = [0u32; 16];
    block[..8].copy_from_slice(&left_cv);
    block[8..].copy_from_slice(&right_cv);
    Output {
        input_cv: key,
        block,
        block_len: BLOCK_LEN as u32,
        counter: 0,
        flags: flags | PARENT,
    }
}

fn parent_cv(left_cv: [u32; 8], right_cv: [u32; 8], key: [u32; 8], flags: u32) -> [u32; 8] {
    parent_output(left_cv, right_cv, key, flags).chaining_value()
}

pub struct Hasher {
    chunk_state: ChunkState,
    key: [u32; 8],
    cv_stack: Vec<[u32; 8]>,
    flags: u32,
}

impl Hasher {
    pub fn new() -> Self {
        Self::new_internal(IV, 0)
    }

    pub fn new_keyed(key: &[u8; 32]) -> Self {
        let mut key_words = [0u32; 8];
        words_from_le_bytes(key, &mut key_words);
        Self::new_internal(key_words, KEYED_HASH)
    }

    pub fn new_derive_key(context: &str) -> Self {
        let mut context_hasher = Self::new_internal(IV, DERIVE_KEY_CONTEXT);
        context_hasher.update(context.as_bytes());
        let mut context_key_bytes = [0u8; 32];
        context_hasher.finalize_xof(0, &mut context_key_bytes);
        let mut context_key_words = [0u32; 8];
        words_from_le_bytes(&context_key_bytes, &mut context_key_words);
        Self::new_internal(context_key_words, DERIVE_KEY_MATERIAL)
    }

    fn new_internal(key: [u32; 8], flags: u32) -> Self {
        Self {
            chunk_state: ChunkState::new(key, 0, flags),
            key,
            cv_stack: Vec::new(),
            flags,
        }
    }

    pub fn update(&mut self, mut input: &[u8]) {
        while !input.is_empty() {
            if self.chunk_state.len() == CHUNK_LEN {
                let chunk_cv = self.chunk_state.output().chaining_value();
                let total_chunks = self.chunk_state.counter + 1;
                self.add_chunk_chaining_value(chunk_cv, total_chunks);
                self.chunk_state = ChunkState::new(self.key, total_chunks, self.flags);
            }
            let want = CHUNK_LEN - self.chunk_state.len();
            let take = want.min(input.len());
            self.chunk_state.update(&input[..take]);
            input = &input[take..];
        }
    }

    fn add_chunk_chaining_value(&mut self, mut new_cv: [u32; 8], mut total_chunks: u64) {
        while total_chunks & 1 == 0 {
            new_cv = parent_cv(self.cv_stack.pop().unwrap(), new_cv, self.key, self.flags);
            total_chunks >>= 1;
        }
        self.cv_stack.push(new_cv);
    }

    pub fn finalize_xof(&self, seek: u64, out: &mut [u8]) {
        let mut output = self.chunk_state.output();
        let mut parent_nodes_remaining = self.cv_stack.len();
        while parent_nodes_remaining > 0 {
            parent_nodes_remaining -= 1;
            output = parent_output(
                self.cv_stack[parent_nodes_remaining],
                output.chaining_value(),
                self.key,
                self.flags,
            );
        }
        output.xof_bytes(seek, out);
    }

    pub fn finalize(&self) -> [u8; 32] {
        let mut out = [0u8; 32];
        self.finalize_xof(0, &mut out);
        out
    }
}

// ============ CLI ============

fn main() -> ExitCode {
    let args: Vec<String> = env::args().collect();
    let prog_name = std::path::Path::new(&args[0])
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| args[0].clone());

    match parse_args(&args[1..]) {
        Ok(cli) => run(cli, &prog_name),
        Err(e) => {
            eprint!("{}", e.format(&prog_name));
            ExitCode::from(2)
        }
    }
}

#[derive(Default, Clone, Debug)]
struct Cli {
    files: Vec<String>,
    keyed: bool,
    derive_key: Option<String>,
    length: Option<u64>,
    seek: Option<u64>,
    num_threads: Option<u64>,
    no_mmap: bool,
    no_names: bool,
    raw: bool,
    tag: bool,
    check: bool,
    quiet: bool,
    help: HelpKind,
    version: bool,
    // For error reporting
    file_seen: bool,
    args_in_order: Vec<Arg>,
}

#[derive(Default, Clone, Debug, PartialEq)]
enum HelpKind {
    #[default]
    None,
    Short,
    Long,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Arg {
    Keyed,
    DeriveKey,
    Length,
    Seek,
    NumThreads,
    NoMmap,
    NoNames,
    Raw,
    Tag,
    Check,
    Quiet,
    Help,
    Version,
}

impl Arg {
    fn usage_display(&self) -> &'static str {
        match self {
            Arg::Keyed => "--keyed",
            Arg::DeriveKey => "--derive-key <CONTEXT>",
            Arg::Length => "--length <LEN>",
            Arg::Seek => "--seek <SEEK>",
            Arg::NumThreads => "--num-threads <NUM>",
            Arg::NoMmap => "--no-mmap",
            Arg::NoNames => "--no-names",
            Arg::Raw => "--raw",
            Arg::Tag => "--tag",
            Arg::Check => "--check",
            Arg::Quiet => "--quiet",
            Arg::Help => "--help",
            Arg::Version => "--version",
        }
    }
}

#[derive(Clone, Debug)]
enum ParseError {
    UnexpectedArg(String),
    UnexpectedValue { arg: String, val: String, usage_args: Vec<String>, file_seen: bool, keyed_first: bool },
    InvalidValue { arg: String, val: String, reason: String },
    NoValue { arg: String },
    Conflict { first: String, second: String, usage_args: Vec<String>, file_seen: bool, keyed_first: bool },
    MultipleTimes { arg: String },
    Required { args: Vec<String>, usage_args: Vec<String>, file_required: bool, file_seen: bool },
    EmptyFileValue,
}

impl ParseError {
    fn format(&self, prog: &str) -> String {
        match self {
            ParseError::UnexpectedArg(a) => {
                let tip = if a.starts_with('-') {
                    format!("\n  tip: to pass '{}' as a value, use '-- {}'\n", a, a)
                } else {
                    String::new()
                };
                format!(
                    "error: unexpected argument '{}' found\n{}\nUsage: {} [OPTIONS] [FILE]...\n\nFor more information, try '--help'.\n",
                    a, tip, prog
                )
            }
            ParseError::InvalidValue { arg, val, reason } => {
                format!(
                    "error: invalid value '{}' for '{}': {}\n\nFor more information, try '--help'.\n",
                    val, arg, reason
                )
            }
            ParseError::NoValue { arg } => {
                format!(
                    "error: a value is required for '{}' but none was supplied\n\nFor more information, try '--help'.\n",
                    arg
                )
            }
            ParseError::Conflict { first, second, usage_args, file_seen, keyed_first } => {
                let file_token = if *file_seen || *keyed_first { "<FILE>..." } else { "[FILE]..." };
                let usage = usage_args.iter().map(|s| s.as_str()).collect::<Vec<_>>().join(" ");
                let usage_line = if usage.is_empty() {
                    format!("Usage: {} {}", prog, file_token)
                } else {
                    format!("Usage: {} {} {}", prog, usage, file_token)
                };
                format!(
                    "error: the argument '{}' cannot be used with '{}'\n\n{}\n\nFor more information, try '--help'.\n",
                    first, second, usage_line
                )
            }
            ParseError::MultipleTimes { arg } => {
                format!(
                    "error: the argument '{}' cannot be used multiple times\n\nUsage: {} [OPTIONS] [FILE]...\n\nFor more information, try '--help'.\n",
                    arg, prog
                )
            }
            ParseError::Required { args, usage_args, file_required, file_seen } => {
                let file_token = if *file_required {
                    "<FILE>..."
                } else if *file_seen {
                    "<FILE>..."
                } else {
                    "[FILE]..."
                };
                let args_listed = args.iter()
                    .map(|a| format!("  {}", a))
                    .collect::<Vec<_>>()
                    .join("\n");
                let usage = usage_args.iter().map(|s| s.as_str()).collect::<Vec<_>>().join(" ");
                let usage_line = if usage.is_empty() {
                    format!("Usage: {} {}", prog, file_token)
                } else {
                    format!("Usage: {} {} {}", prog, usage, file_token)
                };
                format!(
                    "error: the following required arguments were not provided:\n{}\n\n{}\n\nFor more information, try '--help'.\n",
                    args_listed, usage_line
                )
            }
            ParseError::EmptyFileValue => {
                format!(
                    "error: a value is required for '[FILE]...' but none was supplied\n\nFor more information, try '--help'.\n"
                )
            }
            ParseError::UnexpectedValue { arg, val, usage_args, file_seen, keyed_first } => {
                let file_token = if *file_seen || *keyed_first { "<FILE>..." } else { "[FILE]..." };
                let usage = usage_args.iter().map(|s| s.as_str()).collect::<Vec<_>>().join(" ");
                let usage_line = if usage.is_empty() {
                    format!("Usage: {} {}", prog, file_token)
                } else {
                    format!("Usage: {} {} {}", prog, usage, file_token)
                };
                format!(
                    "error: unexpected value '{}' for '{}' found; no more were expected\n\n{}\n\nFor more information, try '--help'.\n",
                    val, arg, usage_line
                )
            }
        }
    }
}

fn known_short(c: char) -> Option<Arg> {
    match c {
        'h' => Some(Arg::Help),
        'V' => Some(Arg::Version),
        'l' => Some(Arg::Length),
        'c' => Some(Arg::Check),
        _ => None,
    }
}

fn known_long(name: &str) -> Option<Arg> {
    match name {
        "--keyed" => Some(Arg::Keyed),
        "--derive-key" => Some(Arg::DeriveKey),
        "--length" => Some(Arg::Length),
        "--seek" => Some(Arg::Seek),
        "--num-threads" => Some(Arg::NumThreads),
        "--no-mmap" => Some(Arg::NoMmap),
        "--no-names" => Some(Arg::NoNames),
        "--raw" => Some(Arg::Raw),
        "--tag" => Some(Arg::Tag),
        "--check" => Some(Arg::Check),
        "--quiet" => Some(Arg::Quiet),
        "--help" => Some(Arg::Help),
        "--version" => Some(Arg::Version),
        _ => None,
    }
}

fn arg_takes_value(arg: Arg) -> bool {
    matches!(arg, Arg::DeriveKey | Arg::Length | Arg::Seek | Arg::NumThreads)
}

fn arg_only_once(arg: Arg) -> bool {
    // All flags error when specified twice (except Help/Version which short-circuit)
    !matches!(arg, Arg::Help | Arg::Version)
}

fn arg_conflicts(a: Arg, b: Arg) -> bool {
    let check_conflicts = &[Arg::Raw, Arg::NoNames, Arg::Tag, Arg::Keyed, Arg::DeriveKey, Arg::Length];
    let keyed_conflicts = &[Arg::DeriveKey];
    if a == Arg::Check && check_conflicts.contains(&b) { return true; }
    if b == Arg::Check && check_conflicts.contains(&a) { return true; }
    if a == Arg::Keyed && keyed_conflicts.contains(&b) { return true; }
    if b == Arg::Keyed && keyed_conflicts.contains(&a) { return true; }
    false
}

fn parse_args(args: &[String]) -> Result<Cli, ParseError> {
    let mut cli = Cli::default();
    let mut i = 0;
    let mut end_of_options = false;

    while i < args.len() {
        // Short-circuit: if help/version was set, stop parsing
        if cli.help != HelpKind::None || cli.version {
            return Ok(cli);
        }

        let a = &args[i];

        if end_of_options {
            if a.is_empty() {
                return Err(ParseError::EmptyFileValue);
            }
            cli.files.push(a.clone());
            cli.file_seen = true;
            i += 1;
            continue;
        }

        if a == "--" {
            end_of_options = true;
            i += 1;
            continue;
        }

        if a == "-" {
            cli.files.push("-".to_string());
            cli.file_seen = true;
            i += 1;
            continue;
        }

        // Treat empty string as empty positional - clap rejects
        if a.is_empty() {
            return Err(ParseError::EmptyFileValue);
        }

        // Try to parse as long option
        if a.starts_with("--") {
            let (name, val) = if let Some(eq) = a.find('=') {
                (a[..eq].to_string(), Some(a[eq+1..].to_string()))
            } else {
                (a.clone(), None)
            };

            // If the name itself is "--" (i.e. arg was "--=..."), treat as unexpected
            if name == "--" {
                return Err(ParseError::UnexpectedArg("--".to_string()));
            }

            let arg_kind = match known_long(&name) {
                Some(k) => k,
                None => return Err(ParseError::UnexpectedArg(a.clone())),
            };

            // Check that flags without values don't get values
            if !arg_takes_value(arg_kind) && val.is_some() {
                return Err(ParseError::UnexpectedValue {
                    arg: name.clone(),
                    val: val.unwrap(),
                    usage_args: vec![name.clone()],
                    file_seen: cli.file_seen,
                    keyed_first: false,
                });
            }

            let help_kind = HelpKind::Long;
            apply_arg(&mut cli, arg_kind, val, args, &mut i, help_kind)?;
            continue;
        }

        // Short option(s) - starts with - but not --
        if a.starts_with('-') && a.len() > 1 {
            let rest = &a[1..];
            let chars: Vec<char> = rest.chars().collect();
            let mut j = 0;
            let arg_done; // whether we should advance i to next arg
            loop {
                if j >= chars.len() { arg_done = true; break; }
                // Short-circuit on help/version
                if cli.help != HelpKind::None || cli.version {
                    arg_done = true;
                    break;
                }
                let c = chars[j];
                let arg_kind = match known_short(c) {
                    Some(k) => k,
                    None => {
                        let mut bad = String::new();
                        bad.push('-');
                        bad.push(c);
                        return Err(ParseError::UnexpectedArg(bad));
                    }
                };
                if arg_takes_value(arg_kind) {
                    let rest_after: String = chars[j+1..].iter().collect();
                    let (val, take_next) = if !rest_after.is_empty() {
                        let val_str = if rest_after.starts_with('=') {
                            rest_after[1..].to_string()
                        } else {
                            rest_after.clone()
                        };
                        (Some(val_str), false)
                    } else {
                        (None, true)
                    };
                    if !take_next {
                        apply_arg_no_advance(&mut cli, arg_kind, val, args, &mut i, HelpKind::Long)?;
                        arg_done = true;
                        break;
                    } else {
                        apply_arg_consume_value(&mut cli, arg_kind, args, &mut i)?;
                        arg_done = false;
                        break;
                    }
                } else {
                    let hk = if arg_kind == Arg::Help && c == 'h' { HelpKind::Short } else { HelpKind::Long };
                    apply_arg_no_advance(&mut cli, arg_kind, None, args, &mut i, hk)?;
                    j += 1;
                }
            }
            if arg_done { i += 1; }
            continue;
        }

        // Positional
        cli.files.push(a.clone());
        cli.file_seen = true;
        i += 1;
    }

    // Validate
    // Check conflicts in order
    for x in 0..cli.args_in_order.len() {
        for y in x+1..cli.args_in_order.len() {
            let a = cli.args_in_order[x];
            let b = cli.args_in_order[y];
            if arg_conflicts(a, b) {
                let keyed_first = a == Arg::Keyed;
                return Err(ParseError::Conflict {
                    first: a.usage_display().to_string(),
                    second: b.usage_display().to_string(),
                    usage_args: vec![a.usage_display().to_string()],
                    file_seen: cli.file_seen,
                    keyed_first,
                });
            }
        }
    }

    // --quiet requires --check
    if cli.quiet && !cli.check {
        return Err(ParseError::Required {
            args: vec!["--check".to_string()],
            usage_args: vec!["--check".to_string(), "--quiet".to_string()],
            file_required: false,
            file_seen: cli.file_seen,
        });
    }
    // --keyed requires file
    if cli.keyed && cli.files.is_empty() {
        return Err(ParseError::Required {
            args: vec!["<FILE>...".to_string()],
            usage_args: vec!["--keyed".to_string()],
            file_required: true,
            file_seen: false,
        });
    }

    Ok(cli)
}

// For long options: takes inline val, advances i past current arg (and value-from-next if needed)
fn apply_arg(cli: &mut Cli, arg_kind: Arg, inline_val: Option<String>, args: &[String], i: &mut usize, help_kind: HelpKind) -> Result<(), ParseError> {
    if arg_only_once(arg_kind) && cli.args_in_order.contains(&arg_kind) {
        return Err(ParseError::MultipleTimes { arg: arg_kind.usage_display().to_string() });
    }

    let value: Option<String> = if arg_takes_value(arg_kind) {
        if let Some(v) = inline_val {
            Some(v)
        } else {
            if *i + 1 >= args.len() {
                return Err(ParseError::NoValue { arg: arg_kind.usage_display().to_string() });
            }
            let next = &args[*i + 1];
            if next.starts_with('-') && next.as_str() != "-" {
                let known = if next.starts_with("--") {
                    let name = if let Some(eq) = next.find('=') { &next[..eq] } else { next.as_str() };
                    known_long(name).is_some()
                } else {
                    let c = next.chars().nth(1);
                    if let Some(c) = c {
                        known_short(c).is_some()
                    } else {
                        false
                    }
                };
                if known {
                    return Err(ParseError::NoValue { arg: arg_kind.usage_display().to_string() });
                } else {
                    return Err(ParseError::UnexpectedArg(next.clone()));
                }
            }
            *i += 1;
            Some(args[*i].clone())
        }
    } else {
        None
    };

    set_arg(cli, arg_kind, value, help_kind)?;
    *i += 1;
    Ok(())
}

// For short flags clustered, when value is inline
fn apply_arg_no_advance(cli: &mut Cli, arg_kind: Arg, inline_val: Option<String>, _args: &[String], _i: &mut usize, help_kind: HelpKind) -> Result<(), ParseError> {
    if arg_only_once(arg_kind) && cli.args_in_order.contains(&arg_kind) {
        return Err(ParseError::MultipleTimes { arg: arg_kind.usage_display().to_string() });
    }
    set_arg(cli, arg_kind, inline_val, help_kind)?;
    Ok(())
}

// For short flag that needs to consume next arg as value: advances i past current + value
fn apply_arg_consume_value(cli: &mut Cli, arg_kind: Arg, args: &[String], i: &mut usize) -> Result<(), ParseError> {
    if arg_only_once(arg_kind) && cli.args_in_order.contains(&arg_kind) {
        return Err(ParseError::MultipleTimes { arg: arg_kind.usage_display().to_string() });
    }
    if *i + 1 >= args.len() {
        return Err(ParseError::NoValue { arg: arg_kind.usage_display().to_string() });
    }
    let next = &args[*i + 1];
    if next.starts_with('-') && next.as_str() != "-" {
        let known = if next.starts_with("--") {
            let name = if let Some(eq) = next.find('=') { &next[..eq] } else { next.as_str() };
            known_long(name).is_some()
        } else {
            let c = next.chars().nth(1);
            if let Some(c) = c { known_short(c).is_some() } else { false }
        };
        if known {
            return Err(ParseError::NoValue { arg: arg_kind.usage_display().to_string() });
        } else {
            return Err(ParseError::UnexpectedArg(next.clone()));
        }
    }
    *i += 1;
    let value = args[*i].clone();
    set_arg(cli, arg_kind, Some(value), HelpKind::Long)?;
    *i += 1;
    Ok(())
}

fn set_arg(cli: &mut Cli, arg_kind: Arg, value: Option<String>, help_kind: HelpKind) -> Result<(), ParseError> {
    cli.args_in_order.push(arg_kind);
    match arg_kind {
        Arg::Keyed => cli.keyed = true,
        Arg::DeriveKey => cli.derive_key = Some(value.unwrap()),
        Arg::Length => {
            let v = value.unwrap();
            let parsed: u64 = match v.parse::<u64>() {
                Ok(n) => n,
                Err(e) => return Err(ParseError::InvalidValue {
                    arg: arg_kind.usage_display().to_string(),
                    val: v,
                    reason: format!("{}", e),
                }),
            };
            cli.length = Some(parsed);
        }
        Arg::Seek => {
            let v = value.unwrap();
            let parsed: u64 = match v.parse::<u64>() {
                Ok(n) => n,
                Err(e) => return Err(ParseError::InvalidValue {
                    arg: arg_kind.usage_display().to_string(),
                    val: v,
                    reason: format!("{}", e),
                }),
            };
            cli.seek = Some(parsed);
        }
        Arg::NumThreads => {
            let v = value.unwrap();
            let parsed: u64 = match v.parse::<u64>() {
                Ok(n) => n,
                Err(e) => return Err(ParseError::InvalidValue {
                    arg: arg_kind.usage_display().to_string(),
                    val: v,
                    reason: format!("{}", e),
                }),
            };
            cli.num_threads = Some(parsed);
        }
        Arg::NoMmap => cli.no_mmap = true,
        Arg::NoNames => cli.no_names = true,
        Arg::Raw => cli.raw = true,
        Arg::Tag => cli.tag = true,
        Arg::Check => cli.check = true,
        Arg::Quiet => cli.quiet = true,
        Arg::Help => cli.help = help_kind,
        Arg::Version => cli.version = true,
    }
    Ok(())
}

// ============ Operation ============

fn run(cli: Cli, prog_name: &str) -> ExitCode {
    if cli.help == HelpKind::Short {
        print!("{}", help_short(prog_name));
        return ExitCode::from(0);
    }
    if cli.help == HelpKind::Long {
        print!("{}", help_long(prog_name));
        return ExitCode::from(0);
    }
    if cli.version {
        println!("b3sum 1.8.4");
        return ExitCode::from(0);
    }

    if cli.raw && cli.files.len() > 1 {
        eprintln!("Error: Only one filename can be provided when using --raw");
        return ExitCode::from(1);
    }

    let key_mode = if cli.keyed {
        let mut key = [0u8; 32];
        let stdin = io::stdin();
        let mut stdin = stdin.lock();
        let mut bytes_read = 0;
        while bytes_read < 32 {
            match stdin.read(&mut key[bytes_read..]) {
                Ok(0) => break,
                Ok(n) => bytes_read += n,
                Err(_) => break,
            }
        }
        if bytes_read < 32 {
            eprintln!("Error: expected 32 key bytes from stdin, found {}", bytes_read);
            return ExitCode::from(1);
        }
        let mut extra = [0u8; 1];
        let extra_n = stdin.read(&mut extra).unwrap_or(0);
        if extra_n > 0 {
            eprintln!("Error: read more than 32 key bytes from stdin");
            return ExitCode::from(1);
        }
        KeyMode::Keyed(key)
    } else if let Some(ctx) = cli.derive_key.clone() {
        KeyMode::DeriveKey(ctx)
    } else {
        KeyMode::None
    };

    if cli.check {
        check_mode(&cli)
    } else {
        hash_mode(&cli, &key_mode)
    }
}

enum KeyMode {
    None,
    Keyed([u8; 32]),
    DeriveKey(String),
}

fn make_hasher(mode: &KeyMode) -> Hasher {
    match mode {
        KeyMode::None => Hasher::new(),
        KeyMode::Keyed(key) => Hasher::new_keyed(key),
        KeyMode::DeriveKey(ctx) => Hasher::new_derive_key(ctx),
    }
}

fn hash_mode(cli: &Cli, key_mode: &KeyMode) -> ExitCode {
    let files: Vec<String> = if cli.files.is_empty() {
        vec!["-".to_string()]
    } else {
        cli.files.clone()
    };

    let length = cli.length.unwrap_or(32);
    let seek = cli.seek.unwrap_or(0);
    let mut exit_code = 0u8;

    let stdout = io::stdout();
    let mut stdout = stdout.lock();

    for file in &files {
        let mut hasher = make_hasher(key_mode);

        let res: io::Result<()> = if file == "-" {
            if cli.keyed {
                eprintln!("b3sum: -: Cannot open `-` in keyed mode");
                exit_code = 1;
                continue;
            }
            let stdin = io::stdin();
            let mut stdin = stdin.lock();
            hash_reader(&mut hasher, &mut stdin)
        } else {
            match File::open(file) {
                Ok(f) => {
                    let meta = f.metadata();
                    if let Ok(m) = &meta {
                        if m.is_dir() {
                            eprintln!("b3sum: {}: Is a directory (os error 21)", file);
                            exit_code = 1;
                            continue;
                        }
                    }
                    let mut reader = BufReader::new(f);
                    hash_reader(&mut hasher, &mut reader)
                }
                Err(e) => {
                    let raw = e.raw_os_error().unwrap_or(0);
                    let msg = os_error_message(raw);
                    eprintln!("b3sum: {}: {} (os error {})", file, msg, raw);
                    exit_code = 1;
                    continue;
                }
            }
        };

        if let Err(e) = res {
            let raw = e.raw_os_error().unwrap_or(0);
            let msg: String = if raw == 0 { e.to_string() } else { os_error_message(raw).to_string() };
            eprintln!("b3sum: {}: {} (os error {})", file, msg, raw);
            exit_code = 1;
            continue;
        }

        if cli.raw {
            let mut buf = vec![0u8; length as usize];
            hasher.finalize_xof(seek, &mut buf);
            if stdout.write_all(&buf).is_err() {
                return ExitCode::from(1);
            }
        } else {
            write_output_line(&mut stdout, &hasher, length, seek, file, cli.tag, cli.no_names);
        }
    }

    ExitCode::from(exit_code)
}

fn hash_reader<R: Read>(hasher: &mut Hasher, reader: &mut R) -> io::Result<()> {
    let mut buf = [0u8; 65536];
    loop {
        let n = reader.read(&mut buf)?;
        if n == 0 { break; }
        hasher.update(&buf[..n]);
    }
    Ok(())
}

fn write_output_line<W: Write>(w: &mut W, hasher: &Hasher, length: u64, seek: u64, file: &str, tag: bool, no_names: bool) {
    let len = length as usize;
    let needs_escape = file.contains('\\') || file.contains('\n');
    let display_name = if needs_escape {
        escape_filename(file)
    } else {
        file.to_string()
    };

    if no_names {
        write_hex_xof(w, hasher, seek, len);
        let _ = writeln!(w);
    } else if tag {
        if needs_escape {
            let _ = write!(w, "\\BLAKE3 ({}) = ", display_name);
        } else {
            let _ = write!(w, "BLAKE3 ({}) = ", display_name);
        }
        write_hex_xof(w, hasher, seek, len);
        let _ = writeln!(w);
    } else {
        if needs_escape {
            let _ = write!(w, "\\");
        }
        write_hex_xof(w, hasher, seek, len);
        let _ = writeln!(w, "  {}", display_name);
    }
}

fn write_hex_xof<W: Write>(w: &mut W, hasher: &Hasher, seek: u64, len: usize) {
    const CHUNK: usize = 4096;
    let mut buf = vec![0u8; CHUNK.min(len)];
    let mut remaining = len;
    let mut offset = seek;
    while remaining > 0 {
        let take = remaining.min(CHUNK);
        let slice = &mut buf[..take];
        hasher.finalize_xof(offset, slice);
        let mut hex = String::with_capacity(take * 2);
        for &b in slice.iter() {
            use std::fmt::Write as _;
            let _ = write!(hex, "{:02x}", b);
        }
        let _ = w.write_all(hex.as_bytes());
        remaining -= take;
        offset += take as u64;
    }
}

fn escape_filename(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            _ => out.push(c),
        }
    }
    out
}

fn unescape_filename(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\\' {
            match chars.next() {
                Some('\\') => out.push('\\'),
                Some('n') => out.push('\n'),
                Some(other) => { out.push('\\'); out.push(other); }
                None => out.push('\\'),
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn os_error_message(errno: i32) -> &'static str {
    match errno {
        1 => "Operation not permitted",
        2 => "No such file or directory",
        5 => "Input/output error",
        9 => "Bad file descriptor",
        13 => "Permission denied",
        20 => "Not a directory",
        21 => "Is a directory",
        _ => "Other error",
    }
}

// ============ Check mode ============

fn check_mode(cli: &Cli) -> ExitCode {
    let files: Vec<String> = if cli.files.is_empty() {
        vec!["-".to_string()]
    } else {
        cli.files.clone()
    };

    let mut total_failed: u64 = 0;
    let mut had_open_error = false;

    for file in &files {
        let reader: Box<dyn BufRead> = if file == "-" {
            Box::new(BufReader::new(io::stdin()))
        } else {
            match File::open(file) {
                Ok(f) => {
                    // Check if directory
                    if let Ok(meta) = f.metadata() {
                        if meta.is_dir() {
                            eprintln!("Error: Is a directory (os error 21)");
                            had_open_error = true;
                            continue;
                        }
                    }
                    Box::new(BufReader::new(f))
                }
                Err(e) => {
                    let raw = e.raw_os_error().unwrap_or(0);
                    let msg = os_error_message(raw);
                    eprintln!("Error: {} (os error {})", msg, raw);
                    had_open_error = true;
                    continue;
                }
            }
        };

        for line in reader.lines() {
            let line = match line {
                Ok(l) => l,
                Err(_) => continue,
            };
            match process_check_line(&line, cli.quiet, cli.seek.unwrap_or(0)) {
                CheckLineResult::Ok => {}
                CheckLineResult::Failed => total_failed += 1,
                CheckLineResult::Error => total_failed += 1,
            }
        }
    }

    if total_failed > 0 {
        let word = if total_failed == 1 { "checksum" } else { "checksums" };
        eprintln!("b3sum: WARNING: {} computed {} did NOT match", total_failed, word);
        ExitCode::from(1)
    } else if had_open_error {
        ExitCode::from(1)
    } else {
        ExitCode::from(0)
    }
}

enum CheckLineResult {
    Ok,
    Failed,
    Error,
}

fn process_check_line(line: &str, quiet: bool, seek: u64) -> CheckLineResult {
    let line = line.strip_suffix('\r').unwrap_or(line);

    if line.is_empty() {
        eprintln!("b3sum: Empty line");
        return CheckLineResult::Error;
    }

    // Detect escaped line (starts with backslash)
    let (escaped, content) = if line.starts_with('\\') {
        (true, &line[1..])
    } else {
        (false, line)
    };

    // Try to parse: regular format "HASH  FILE" or tag format "BLAKE3 (FILE) = HASH"
    let parse_result: Result<(String, String), String> = if content.starts_with("BLAKE3 (") {
        parse_tag_line(content)
    } else {
        parse_regular_line(content)
    };

    let (hash_hex, filename) = match parse_result {
        Ok(p) => p,
        Err(e) => {
            eprintln!("b3sum: {}", e);
            return CheckLineResult::Error;
        }
    };

    if hash_hex.len() != 64 {
        eprintln!("b3sum: Invalid hash length");
        return CheckLineResult::Error;
    }
    let expected = match hex_decode(&hash_hex) {
        Some(b) => b,
        None => {
            eprintln!("b3sum: Invalid hex");
            return CheckLineResult::Error;
        }
    };

    if filename.is_empty() {
        eprintln!("b3sum: empty file path");
        return CheckLineResult::Error;
    }

    let actual_filename = if escaped {
        unescape_filename(&filename)
    } else {
        filename.clone()
    };

    let display = if escaped {
        format!("\\{}", filename)
    } else {
        filename.clone()
    };

    let mut hasher = Hasher::new();
    let res = match File::open(&actual_filename) {
        Ok(f) => {
            if let Ok(meta) = f.metadata() {
                if meta.is_dir() {
                    println!("{}: FAILED (Is a directory (os error 21))", display);
                    return CheckLineResult::Failed;
                }
            }
            let mut reader = BufReader::new(f);
            hash_reader(&mut hasher, &mut reader)
        }
        Err(e) => {
            let raw = e.raw_os_error().unwrap_or(0);
            let msg = os_error_message(raw);
            println!("{}: FAILED ({} (os error {}))", display, msg, raw);
            return CheckLineResult::Failed;
        }
    };

    if let Err(e) = res {
        let raw = e.raw_os_error().unwrap_or(0);
        let msg = os_error_message(raw);
        println!("{}: FAILED ({} (os error {}))", display, msg, raw);
        return CheckLineResult::Failed;
    }

    let mut actual = [0u8; 32];
    hasher.finalize_xof(seek, &mut actual);

    if actual.as_slice() == expected.as_slice() {
        if !quiet {
            println!("{}: OK", display);
        }
        CheckLineResult::Ok
    } else {
        println!("{}: FAILED", display);
        CheckLineResult::Failed
    }
}

fn parse_regular_line(s: &str) -> Result<(String, String), String> {
    if let Some(pos) = s.find("  ") {
        let hash = &s[..pos];
        let file = &s[pos + 2..];
        Ok((hash.to_string(), file.to_string()))
    } else {
        Err("Invalid check line format".to_string())
    }
}

fn parse_tag_line(s: &str) -> Result<(String, String), String> {
    if !s.starts_with("BLAKE3 (") {
        return Err("Invalid check line format".to_string());
    }
    let after = &s["BLAKE3 (".len()..];
    if let Some(pos) = after.rfind(") = ") {
        let file = &after[..pos];
        let hash = &after[pos + 4..];
        Ok((hash.to_string(), file.to_string()))
    } else {
        Err("Invalid check line format".to_string())
    }
}

fn hex_decode(s: &str) -> Option<Vec<u8>> {
    if s.len() % 2 != 0 { return None; }
    let mut out = Vec::with_capacity(s.len() / 2);
    let bytes = s.as_bytes();
    for chunk in bytes.chunks(2) {
        let h = hex_val(chunk[0])?;
        let l = hex_val(chunk[1])?;
        out.push((h << 4) | l);
    }
    Some(out)
}

fn hex_val(c: u8) -> Option<u8> {
    match c {
        b'0'..=b'9' => Some(c - b'0'),
        b'a'..=b'f' => Some(c - b'a' + 10),
        _ => None,
    }
}

// ============ Help text ============

fn help_short(prog: &str) -> String {
    format!("Usage: {prog} [OPTIONS] [FILE]...

Arguments:
  [FILE]...  Files to hash, or checkfiles to check

Options:
      --keyed                 Use the keyed mode, reading the 32-byte key from stdin
      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string
  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]
      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]
      --num-threads <NUM>     The maximum number of threads to use
      --no-mmap               Disable memory mapping
      --no-names              Omit filenames in the output
      --raw                   Write raw output bytes to stdout, rather than hex
      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]
  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them
      --quiet                 Skip printing OK for each checked file
  -h, --help                  Print help (see more with '--help')
  -V, --version               Print version
", prog=prog)
}

fn help_long(prog: &str) -> String {
    // Blank lines INSIDE an option description need 10 leading spaces.
    // Blank lines BETWEEN options are empty.
    let sp = "          "; // 10 spaces
    format!("Usage: {prog} [OPTIONS] [FILE]...

Arguments:
  [FILE]...
          Files to hash, or checkfiles to check
{sp}
          When no file is given, or when - is given, read standard input.

Options:
      --keyed
          Use the keyed mode, reading the 32-byte key from stdin

      --derive-key <CONTEXT>
          Use the key derivation mode, with the given context string
{sp}
          Cannot be used with --keyed.

  -l, --length <LEN>
          The number of output bytes, before hex encoding
{sp}
          [default: 32]

      --seek <SEEK>
          The starting output byte offset, before hex encoding
{sp}
          [default: 0]

      --num-threads <NUM>
          The maximum number of threads to use
{sp}
          By default, this is the number of logical cores. If this flag is omitted, or if its value
          is 0, RAYON_NUM_THREADS is also respected.

      --no-mmap
          Disable memory mapping
{sp}
          Currently this also disables multithreading.

      --no-names
          Omit filenames in the output

      --raw
          Write raw output bytes to stdout, rather than hex
{sp}
          --no-names is implied. In this case, only a single input is allowed.

      --tag
          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]

  -c, --check
          Read BLAKE3 sums from the [FILE]s and check them

      --quiet
          Skip printing OK for each checked file
{sp}
          Must be used with --check.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
", prog=prog, sp=sp)
}
