#!/bin/bash
# Differential testing: run both binaries with various inputs and diff outputs.
set +e

REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAIL_DETAILS=""

run_test() {
    local name="$1"
    local stdin_arg="$2"  # path to stdin file or "" for /dev/null
    shift 2
    local ref_out ref_err ref_exit sut_out sut_err sut_exit

    if [ -z "$stdin_arg" ]; then
        ref_out=$("$REF" "$@" 2>/tmp/ref_err </dev/null)
        ref_exit=$?
        sut_out=$("$SUT" "$@" 2>/tmp/sut_err </dev/null)
        sut_exit=$?
    else
        ref_out=$("$REF" "$@" 2>/tmp/ref_err < "$stdin_arg")
        ref_exit=$?
        sut_out=$("$SUT" "$@" 2>/tmp/sut_err < "$stdin_arg")
        sut_exit=$?
    fi
    ref_err=$(cat /tmp/ref_err)
    sut_err=$(cat /tmp/sut_err)
    if [ "$ref_out" = "$sut_out" ] && [ "$ref_err" = "$sut_err" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        FAIL_DETAILS="$FAIL_DETAILS\n--- FAIL: $name (args: $*) ---"
        if [ "$ref_exit" != "$sut_exit" ]; then
            FAIL_DETAILS="$FAIL_DETAILS\nexit: ref=$ref_exit sut=$sut_exit"
        fi
        if [ "$ref_out" != "$sut_out" ]; then
            FAIL_DETAILS="$FAIL_DETAILS\nstdout differs:"
            FAIL_DETAILS="$FAIL_DETAILS\nref: $(echo "$ref_out" | head -3 | cat -A)"
            FAIL_DETAILS="$FAIL_DETAILS\nsut: $(echo "$sut_out" | head -3 | cat -A)"
        fi
        if [ "$ref_err" != "$sut_err" ]; then
            FAIL_DETAILS="$FAIL_DETAILS\nstderr differs:"
            FAIL_DETAILS="$FAIL_DETAILS\nref: $ref_err"
            FAIL_DETAILS="$FAIL_DETAILS\nsut: $sut_err"
        fi
    fi
}

# Test inputs
mkdir -p /tmp/test_inputs
echo -n "abc" > /tmp/test_inputs/3byte
echo -n "abcdefghij" > /tmp/test_inputs/10byte
echo -n "abcdefghijk" > /tmp/test_inputs/11byte
printf '' > /tmp/test_inputs/empty
printf '\x00\x01\x09\x1f\x20\x7e\x7f\xff' > /tmp/test_inputs/binary
printf '\x00\xff\xff\x00' > /tmp/test_inputs/zeros
echo -n "Hello, World!" > /tmp/test_inputs/hello

# Basic hex tests
run_test "hex_3byte" /tmp/test_inputs/3byte
run_test "hex_10byte" /tmp/test_inputs/10byte
run_test "hex_11byte" /tmp/test_inputs/11byte
run_test "hex_empty" /tmp/test_inputs/empty
run_test "hex_binary" /tmp/test_inputs/binary
run_test "hex_zeros" /tmp/test_inputs/zeros
run_test "hex_tiny_file" "" /workspace/assets/tiny.bin

# Cols
for c in 0 1 2 3 5 10 16 20 100; do
    run_test "hex_c$c" /tmp/test_inputs/hello -c "$c"
done

# Format
for f in o x X b; do
    run_test "hex_f$f" /tmp/test_inputs/hello -f "$f"
done

# Prefix
run_test "hex_r0" /tmp/test_inputs/hello -r 0
run_test "hex_r1" /tmp/test_inputs/hello -r 1
run_test "hex_r0_fX" /tmp/test_inputs/hello -r 0 -f X
run_test "hex_r0_fo" /tmp/test_inputs/hello -r 0 -f o
run_test "hex_r0_fb" /tmp/test_inputs/hello -r 0 -f b

# Length
for l in 0 1 5 100; do
    run_test "hex_l$l" /tmp/test_inputs/hello -l "$l"
done

# Color
run_test "hex_t1" /tmp/test_inputs/hello -t 1
run_test "hex_t1_binary" /tmp/test_inputs/binary -t 1
run_test "hex_t0" /tmp/test_inputs/hello -t 0

# Array formats with various lengths
for fmt in r c g p k j s f; do
    for in_file in empty 3byte 10byte 11byte; do
        run_test "array_${fmt}_$in_file" /tmp/test_inputs/$in_file -a $fmt
    done
done

# Array with -c
for fmt in r g; do
    for c in 0 1 3 5 10 100; do
        run_test "array_${fmt}_c${c}" /tmp/test_inputs/hello -a $fmt -c $c
    done
done

# Func wave
for u in 0 1 2 5 9 10 11 15 20 25 30; do
    run_test "wave_$u" "" -u $u
done

# Places
for p in 0 1 2 3 4 5 10; do
    run_test "wave_5_p$p" "" -u 5 -p $p
done

# Combined and edge cases
run_test "wave_with_input" /tmp/test_inputs/hello -u 5
run_test "wave_with_file" "" -u 5 /workspace/assets/tiny.bin
run_test "wave_with_array" /tmp/test_inputs/hello -u 5 -a r

# Help and version
run_test "help_long" /tmp/test_inputs/empty --help
run_test "help_short" /tmp/test_inputs/empty -h
run_test "version_long" /tmp/test_inputs/empty --version
run_test "version_short" /tmp/test_inputs/empty -V

# Errors
run_test "err_no_file" "" /nonexistent
run_test "err_unknown" "" --bogus
run_test "err_unknown_short" "" -z
run_test "err_c_invalid" /tmp/test_inputs/empty -c abc
run_test "err_c_empty" /tmp/test_inputs/empty --cols ""
run_test "err_l_invalid" /tmp/test_inputs/empty -l abc
run_test "err_u_invalid" "" -u abc
run_test "err_p_invalid" "" -u 5 -p abc
run_test "err_format_invalid" /tmp/test_inputs/empty -f q
run_test "err_array_invalid" /tmp/test_inputs/empty -a q
run_test "err_color_invalid" /tmp/test_inputs/empty -t 2
run_test "err_prefix_invalid" /tmp/test_inputs/empty -r 2
run_test "err_repeated" /tmp/test_inputs/empty -c 5 -c 3

# Total
echo "Pass: $PASS"
echo "Fail: $FAIL"
if [ "$FAIL" -gt 0 ]; then
    echo -e "$FAIL_DETAILS"
fi
