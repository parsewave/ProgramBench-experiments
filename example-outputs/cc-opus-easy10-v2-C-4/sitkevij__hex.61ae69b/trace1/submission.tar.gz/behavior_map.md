# hx behavior map (v0.7.0)

## Mode precedence
1. `-h/--help` → print help to stdout, exit 0
2. `-V/--version` → print "hx 0.7.0\n" to stdout, exit 0
3. `-u/--func N` → print wave values, exit 0 (no input processing)
4. `-a/--array X` → print array format, exit 0
5. default → hex display

## Args / clap

- argv[0] basename used as program name in help/error
- Errors:
  - Invalid integer: `{short}, {long} <integer> expected. ParseIntError { kind: {Empty|PosOverflow|InvalidDigit} }\nerror: {desc}\n` exit 1
    - Empty: "cannot parse integer from empty string"
    - PosOverflow: "number too large to fit in target type"
    - InvalidDigit: "invalid digit found in string"
  - Clap errors (unknown flag, invalid enum value, missing value, repeated): exit 2 with usual clap-format error + usage hint
  - File not found: `error: No such file or directory (os error 2)\n` exit 1

## Defaults
- cols=10, format=x (lowerhex), prefix=1, color=auto (off when not tty)
- places=4
- len=0 (read all)

## Hex output structure
- Row: `0x{offset:06x}: {byte_slots} {ascii}`
- Each byte slot when filled:
  - `-f x` (default): `0x{:02x}` (lowercase, 2 hex digits)
  - `-f X`: `0x{:02X}` (uppercase)
  - `-f o`: `0o{:04o}` (4 octal digits)
  - `-f b`: `0b{:08b}` (8 binary digits)
  - With `-r 0`: same digits without prefix (e.g., `61`, `0141`, `01100001`)
- Slot separator: space
- Missing byte slots: 5 spaces each (matches `0xXX ` width) regardless of format
- ASCII rendering: printable 0x20-0x7e shown as-is, others as `.`
- Trailing empty row when `byte_count % cols == 0`: `0x{next:06x}: ` + (5 * cols spaces) + `\n`
- Footer: `   bytes: {count}\n` (3 spaces, "bytes: ", count)

## Color (when -t 1, or default+tty)
- Each byte/ascii char wrapped: `\e[38;5;Nm{text}\e[0m`
- N = byte_value if byte != 0, else 22

## Array format
Structure: header + body + footer
- Body: bytes wrapped at `cols` per line, indented with 4 spaces
- Separator (between bytes): `, ` (or `; ` for fsharp)
- After last byte: typically no trailing separator; **exception**: golang ALWAYS has `, ` after every byte
- Trailing empty indent line (`    `) when `count % cols == 0`
- Per-byte: `0x{:02x}` for all formats EXCEPT fsharp which uses `0x{:02x}uy`
- Array body always lowerhex; ignores `-f` and `-r`

Format strings (header/footer):
- r (rust):    `let ARRAY: [u8; {N}] = [\n` ... `];\n`
- c (C):       `unsigned char ARRAY[{N}] = {{\n` ... `};\n`
- g (golang):  `a := [{N}]byte{{\n` ... `}\n`
- p (python):  `a = [\n` ... `]\n`
- k (kotlin):  `val a = byteArrayOf(\n` ... `)\n`
- j (java):    `byte[] a = new byte[]{{\n` ... `};\n`
- s (swift):   `let a: [UInt8] = [\n` ... `]\n`
- f (fsharp):  `let a = [|\n` ... `|]\n`

## Func/wave output
- `-u N`: print sin(i*π/(2N)) for i in [0, N), formatted with -p decimal places (default 4)
- Each value followed by `,` then comma (no space)
- 10 values per line (newline after every 10), regardless of -c
- Always print trailing newline after loop
- Effect: N=0 → `\n`; N=10 → `...,\n\n`; N=11 → `...,\n...,\n`
- Ignores `-t` (no colors)
- Ignores file/stdin (just outputs wave)
