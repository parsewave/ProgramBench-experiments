#!/usr/bin/env python3
"""Reimplementation of hx 0.7.0 - futuristic hexdump."""

import sys
import os
import math


PROG = os.path.basename(sys.argv[0])


HELP = (
    "Futuristic take on hexdump, made in Rust.\n"
    "\n"
    "\n"
    f"Usage: {PROG} [OPTIONS] [INPUTFILE]\n"
    "\n"
    "Arguments:\n"
    "  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin\n"
    "\n"
    "Options:\n"
    "  -c, --cols <columns>        Set column length\n"
    "  -l, --len <len>             Set <len> bytes to read\n"
    "  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]\n"
    "  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]\n"
    "  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]\n"
    "  -u, --func <func_length>    Set function wave length\n"
    "  -p, --places <func_places>  Set function wave output decimal places\n"
    "  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]\n"
    "  -h, --help                  Print help\n"
    "  -V, --version               Print version\n"
)


# Map short → (long, takes_value)
OPTIONS_SPEC = {
    '-c': ('--cols', True),
    '-l': ('--len', True),
    '-f': ('--format', True),
    '-t': ('--color', True),
    '-a': ('--array', True),
    '-u': ('--func', True),
    '-p': ('--places', True),
    '-r': ('--prefix', True),
    '-h': ('--help', False),
    '-V': ('--version', False),
}

LONG_TO_SHORT = {long: short for short, (long, _) in OPTIONS_SPEC.items()}

# For integer parsing errors: short, long, name
INT_FLAG_LABEL = {
    '--cols':   ('-c', '--cols'),
    '--len':    ('-l', '--len'),
    '--func':   ('-u', '--func'),
    '--places': ('-p', '--places'),
}

ENUM_OPTIONS = {
    '--format':  ['o', 'x', 'X', 'b'],
    '--color':   ['0', '1'],
    '--array':   ['r', 'c', 'g', 'p', 'k', 'j', 's', 'f'],
    '--prefix':  ['0', '1'],
}


def usage_footer():
    return (
        f"\nUsage: {PROG} [OPTIONS] [INPUTFILE]\n"
        f"\nFor more information, try '--help'.\n"
    )


def clap_error(msg, exit_code=2):
    sys.stderr.write(f"error: {msg}\n")
    sys.stderr.write(usage_footer())
    sys.exit(exit_code)


def clap_error_with_tip(msg, tip, exit_code=2):
    sys.stderr.write(f"error: {msg}\n")
    sys.stderr.write(f"\n  tip: {tip}\n")
    sys.stderr.write(usage_footer())
    sys.exit(exit_code)


def clap_error_enum(value, long_name, possible_values, exit_code=2, similar=None):
    sys.stderr.write(f"error: invalid value '{value}' for '{long_name} <{long_name.lstrip('-')}>'\n")
    short_label = {
        '--format': 'format',
        '--color': 'color',
        '--array': 'array_format',
        '--prefix': 'prefix',
    }[long_name]
    sys.stderr.seek(0)
    # rewrite with proper label
    sys.stderr.truncate(0)
    sys.stderr.write(f"error: invalid value '{value}' for '{long_name} <{short_label}>'\n")
    sys.stderr.write(f"  [possible values: {', '.join(possible_values)}]\n")
    if similar:
        sys.stderr.write(f"\n  tip: a similar value exists: '{similar}'\n")
    sys.stderr.write(f"\nFor more information, try '--help'.\n")
    sys.exit(exit_code)


def integer_parse_error(short, long_name, kind, exit_code=1):
    descs = {
        'Empty': 'cannot parse integer from empty string',
        'InvalidDigit': 'invalid digit found in string',
        'PosOverflow': 'number too large to fit in target type',
    }
    sys.stderr.write(f"{short}, {long_name} <integer> expected. ParseIntError {{ kind: {kind} }}\n")
    sys.stderr.write(f"error: {descs[kind]}\n")
    sys.exit(exit_code)


def parse_int_or_die(short, long_name, raw, target='usize'):
    if raw == "":
        integer_parse_error(short, long_name, 'Empty')
    # validate digits only
    s = raw
    if all(c.isdigit() for c in s):
        try:
            v = int(s)
        except ValueError:
            integer_parse_error(short, long_name, 'InvalidDigit')
        # usize max = 2^64-1
        if target == 'usize' and v > (1 << 64) - 1:
            integer_parse_error(short, long_name, 'PosOverflow')
        return v
    else:
        integer_parse_error(short, long_name, 'InvalidDigit')


def enum_validate(value, long_name, possible_values):
    if value not in possible_values:
        # Build error message similar to clap
        msg_lines = []
        # Try to find a similar value (case-insensitive, single char)
        similar = None
        if len(value) == 1:
            for pv in possible_values:
                if pv.lower() == value.lower():
                    similar = pv
                    break
        label_map = {
            '--format': 'format',
            '--color': 'color',
            '--array': 'array_format',
            '--prefix': 'prefix',
        }
        label = label_map.get(long_name, long_name.lstrip('-'))
        sys.stderr.write(f"error: invalid value '{value}' for '{long_name} <{label}>'\n")
        sys.stderr.write(f"  [possible values: {', '.join(possible_values)}]\n")
        if similar and similar != value:
            sys.stderr.write(f"\n  tip: a similar value exists: '{similar}'\n")
        sys.stderr.write(f"\nFor more information, try '--help'.\n")
        sys.exit(2)
    return value


def parse_args(argv):
    """Manually parse args clap-style."""
    result = {
        'cols': None,
        'len': None,
        'format': None,
        'color': None,
        'array': None,
        'func': None,
        'places': None,
        'prefix': None,
        'help': False,
        'version': False,
        'inputfile': None,
    }
    seen = set()
    positional_done = False
    i = 0
    args = argv[1:]
    while i < len(args):
        arg = args[i]
        if not positional_done and arg == '--':
            positional_done = True
            i += 1
            continue

        # Already past --, treat as positional
        if positional_done:
            if result['inputfile'] is not None:
                clap_error(f"unexpected argument '{arg}' found")
            result['inputfile'] = arg
            i += 1
            continue

        # Long with =value
        if arg.startswith('--') and '=' in arg:
            long_name, value = arg.split('=', 1)
            # Validate long name
            short_for_long = {long_: short for short, (long_, _) in OPTIONS_SPEC.items()}
            if long_name not in short_for_long:
                _unknown_arg(arg)
            takes_value = OPTIONS_SPEC[short_for_long[long_name]][1]
            if not takes_value:
                clap_error(f"unexpected value '{value}' for '{long_name}'")
            if long_name in seen:
                clap_error(f"the argument '{long_name} <{_value_label(long_name)}>' cannot be used multiple times")
            seen.add(long_name)
            _apply_option(result, long_name, value)
            i += 1
            continue

        # Short with =value
        if arg.startswith('-') and not arg.startswith('--') and '=' in arg:
            eq_idx = arg.index('=')
            short = arg[:eq_idx]
            value = arg[eq_idx+1:]
            if short not in OPTIONS_SPEC:
                _unknown_arg(arg)
            long_name = OPTIONS_SPEC[short][0]
            takes_value = OPTIONS_SPEC[short][1]
            if not takes_value:
                clap_error(f"unexpected value '{value}' for '{long_name}'")
            if long_name in seen:
                clap_error(f"the argument '{long_name} <{_value_label(long_name)}>' cannot be used multiple times")
            seen.add(long_name)
            _apply_option(result, long_name, value)
            i += 1
            continue

        # Long without =
        if arg.startswith('--'):
            long_name = arg
            short_for_long = {long_: short for short, (long_, _) in OPTIONS_SPEC.items()}
            if long_name not in short_for_long:
                _unknown_arg(arg)
            takes_value = OPTIONS_SPEC[short_for_long[long_name]][1]
            if long_name in seen:
                clap_error(f"the argument '{long_name} <{_value_label(long_name)}>' cannot be used multiple times")
            seen.add(long_name)
            if takes_value:
                if i + 1 >= len(args):
                    sys.stderr.write(f"error: a value is required for '{long_name} <{_value_label(long_name)}>' but none was supplied\n")
                    pvs = ENUM_OPTIONS.get(long_name)
                    if pvs:
                        sys.stderr.write(f"  [possible values: {', '.join(pvs)}]\n")
                    sys.stderr.write(usage_footer())
                    sys.exit(2)
                value = args[i+1]
                if value.startswith('-') and value != '-':
                    # clap rejects this as missing value (unless looks like a path)
                    sys.stderr.write(f"error: a value is required for '{long_name} <{_value_label(long_name)}>' but none was supplied\n")
                    pvs = ENUM_OPTIONS.get(long_name)
                    if pvs:
                        sys.stderr.write(f"  [possible values: {', '.join(pvs)}]\n")
                    sys.stderr.write(usage_footer())
                    sys.exit(2)
                _apply_option(result, long_name, value)
                i += 2
            else:
                _apply_flag(result, long_name)
                i += 1
            continue

        # Short option
        if arg.startswith('-') and arg != '-':
            short = arg[:2]
            rest = arg[2:]
            if short not in OPTIONS_SPEC:
                _unknown_arg(arg)
            long_name = OPTIONS_SPEC[short][0]
            takes_value = OPTIONS_SPEC[short][1]
            if takes_value:
                if long_name in seen:
                    clap_error(f"the argument '{long_name} <{_value_label(long_name)}>' cannot be used multiple times")
                seen.add(long_name)
                if rest:
                    value = rest
                else:
                    if i + 1 >= len(args):
                        sys.stderr.write(f"error: a value is required for '{long_name} <{_value_label(long_name)}>' but none was supplied\n")
                        pvs = ENUM_OPTIONS.get(long_name)
                        if pvs:
                            sys.stderr.write(f"  [possible values: {', '.join(pvs)}]\n")
                        sys.stderr.write(usage_footer())
                        sys.exit(2)
                    value = args[i+1]
                    if value.startswith('-') and value != '-':
                        sys.stderr.write(f"error: a value is required for '{long_name} <{_value_label(long_name)}>' but none was supplied\n")
                        pvs = ENUM_OPTIONS.get(long_name)
                        if pvs:
                            sys.stderr.write(f"  [possible values: {', '.join(pvs)}]\n")
                        sys.stderr.write(usage_footer())
                        sys.exit(2)
                    i += 1  # consume next
                _apply_option(result, long_name, value)
                i += 1
            else:
                # Flag short, possibly combined like -hV
                # First flag consumed, rest treated as combined
                if long_name in seen:
                    clap_error(f"the argument '--{long_name.lstrip('-')}' cannot be used multiple times")
                seen.add(long_name)
                _apply_flag(result, long_name)
                # Remaining chars in same arg get ignored if help/version exits early
                i += 1
            continue

        # Positional: input file
        if result['inputfile'] is not None:
            clap_error(f"unexpected argument '{arg}' found")
        result['inputfile'] = arg
        i += 1

    return result


def _value_label(long_name):
    return {
        '--cols': 'columns',
        '--len': 'len',
        '--format': 'format',
        '--color': 'color',
        '--array': 'array_format',
        '--func': 'func_length',
        '--places': 'func_places',
        '--prefix': 'prefix',
    }[long_name]


def _unknown_arg(arg):
    sys.stderr.write(f"error: unexpected argument '{arg}' found\n")
    sys.stderr.write(f"\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n")
    sys.stderr.write(usage_footer())
    sys.exit(2)


def _apply_option(result, long_name, value):
    key = long_name.lstrip('-')
    if key == 'cols':
        result['cols'] = parse_int_or_die('-c', '--cols', value)
    elif key == 'len':
        result['len'] = parse_int_or_die('-l', '--len', value)
    elif key == 'func':
        result['func'] = parse_int_or_die('-u', '--func', value)
    elif key == 'places':
        result['places'] = parse_int_or_die('-p', '--places', value)
    elif key in ('format', 'color', 'array', 'prefix'):
        enum_validate(value, '--' + key, ENUM_OPTIONS['--' + key])
        result[key] = value
    else:
        raise RuntimeError(f"unknown option {long_name}")


def _apply_flag(result, long_name):
    key = long_name.lstrip('-')
    if key in ('help', 'version'):
        result[key] = True


# ===== Output formatting =====

def colorize(text, byte_val, enable):
    if not enable:
        return text
    color = byte_val if byte_val != 0 else 22
    return f"\x1b[38;5;{color}m{text}\x1b[0m"


def format_byte(b, fmt, prefix):
    """Format a single byte per -f and -r flags."""
    if fmt == 'x':
        digits = f"{b:02x}"
        return ("0x" if prefix else "") + digits
    elif fmt == 'X':
        digits = f"{b:02X}"
        return ("0x" if prefix else "") + digits
    elif fmt == 'o':
        digits = f"{b:04o}"
        return ("0o" if prefix else "") + digits
    elif fmt == 'b':
        digits = f"{b:08b}"
        return ("0b" if prefix else "") + digits


def ascii_char(b):
    """ASCII repr: printable byte 0x20..0x7e -> char, else '.'"""
    if 0x20 <= b <= 0x7e:
        return chr(b)
    return '.'


def render_hex(data, cols, fmt, prefix, color):
    """Hex display."""
    out = sys.stdout.buffer
    # Slot width is always 5 (for "0xXX ") regardless of format, for missing slots
    PAD_WIDTH = 5
    chunks = []
    if cols == 0:
        # use 1 byte per row but padding count is 0
        effective_cols = 1
        pad_count = 0
    else:
        effective_cols = cols
        pad_count = cols

    n = len(data)
    offset = 0
    while offset < n:
        chunk = data[offset:offset+effective_cols]
        line = bytearray()
        line += f"0x{offset:06x}: ".encode()
        # Bytes
        for b in chunk:
            byte_s = format_byte(b, fmt, prefix)
            line += colorize(byte_s, b, color).encode()
            line += b' '
        # Padding for missing slots
        missing = effective_cols - len(chunk)
        line += b' ' * (missing * PAD_WIDTH)
        # ASCII
        for b in chunk:
            ch = ascii_char(b)
            line += colorize(ch, b, color).encode()
        line += b'\n'
        out.write(bytes(line))
        offset += effective_cols

    # Trailing empty row if count is exact multiple of effective_cols (incl 0 bytes)
    if n % effective_cols == 0:
        # Use pad_count for trailing width (so cols=0 gives 0 spaces of padding)
        line = bytearray()
        line += f"0x{n:06x}: ".encode()
        line += b' ' * (pad_count * PAD_WIDTH)
        line += b'\n'
        out.write(bytes(line))

    out.write(f"   bytes: {n}\n".encode())


ARRAY_FORMATS = {
    'r': {
        'header': lambda n: f"let ARRAY: [u8; {n}] = [\n",
        'footer': "];\n",
        'sep': ', ',
        'always_trail': False,
        'byte': lambda b: f"0x{b:02x}",
    },
    'c': {
        'header': lambda n: f"unsigned char ARRAY[{n}] = {{\n",
        'footer': "};\n",
        'sep': ', ',
        'always_trail': False,
        'byte': lambda b: f"0x{b:02x}",
    },
    'g': {
        'header': lambda n: f"a := [{n}]byte{{\n",
        'footer': "}\n",
        'sep': ', ',
        'always_trail': True,
        'byte': lambda b: f"0x{b:02x}",
    },
    'p': {
        'header': lambda n: "a = [\n",
        'footer': "]\n",
        'sep': ', ',
        'always_trail': False,
        'byte': lambda b: f"0x{b:02x}",
    },
    'k': {
        'header': lambda n: "val a = byteArrayOf(\n",
        'footer': ")\n",
        'sep': ', ',
        'always_trail': False,
        'byte': lambda b: f"0x{b:02x}",
    },
    'j': {
        'header': lambda n: "byte[] a = new byte[]{\n",
        'footer': "};\n",
        'sep': ', ',
        'always_trail': False,
        'byte': lambda b: f"0x{b:02x}",
    },
    's': {
        'header': lambda n: "let a: [UInt8] = [\n",
        'footer': "]\n",
        'sep': ', ',
        'always_trail': False,
        'byte': lambda b: f"0x{b:02x}",
    },
    'f': {
        'header': lambda n: "let a = [|\n",
        'footer': "|]\n",
        'sep': '; ',
        'always_trail': False,
        'byte': lambda b: f"0x{b:02x}uy",
    },
}


def render_array(data, fmt_code, cols):
    spec = ARRAY_FORMATS[fmt_code]
    out = sys.stdout.buffer
    out.write(spec['header'](len(data)).encode())
    sep = spec['sep']
    always_trail = spec['always_trail']
    byte_fn = spec['byte']

    if cols == 0:
        effective_cols = 1
    else:
        effective_cols = cols

    n = len(data)
    if n == 0:
        # Empty body: just "    \n"
        out.write(b"    \n")
    else:
        offset = 0
        while offset < n:
            chunk = data[offset:offset+effective_cols]
            line = "    "
            row_strs = []
            for j, b in enumerate(chunk):
                row_strs.append(byte_fn(b))
            is_last_row = (offset + len(chunk) >= n)
            if always_trail:
                # Every byte has trailing sep
                line += sep.join(row_strs) + sep
            else:
                if is_last_row:
                    # last row: no trailing sep on last byte
                    line += sep.join(row_strs)
                else:
                    # non-last row: trailing sep then space at end
                    line += sep.join(row_strs) + sep
            out.write((line + '\n').encode())
            offset += effective_cols

        # Trailing empty indent line when count is exact multiple of effective_cols
        if n % effective_cols == 0:
            out.write(b"    \n")

    out.write(spec['footer'].encode())


def render_wave(N, places):
    out = sys.stdout.buffer
    if N == 0:
        out.write(b"\n")
        return
    line_parts = []
    pieces = []
    for i in range(N):
        v = math.sin(i * math.pi / (2 * N))
        s = f"{v:.{places}f}"
        pieces.append(s + ",")
        if (i + 1) % 10 == 0:
            out.write(("".join(pieces)).encode())
            out.write(b"\n")
            pieces = []
    if pieces:
        out.write(("".join(pieces)).encode())
        out.write(b"\n")
    else:
        # Last value was at exact multiple of 10 - extra newline
        out.write(b"\n")


def detect_color_default():
    """When -t is not given, color enabled iff stdout is a tty AND NO_COLOR not set."""
    try:
        if not sys.stdout.isatty():
            return False
    except Exception:
        return False
    if os.environ.get('NO_COLOR') is not None and os.environ['NO_COLOR'] != '':
        return False
    return True


def main():
    args = parse_args(sys.argv)

    if args['help']:
        sys.stdout.write(HELP)
        sys.exit(0)
    if args['version']:
        sys.stdout.write("hx 0.7.0\n")
        sys.exit(0)

    # Defaults
    cols = args['cols'] if args['cols'] is not None else 10
    length = args['len']  # None means default 0 (all)
    fmt = args['format'] if args['format'] is not None else 'x'
    if args['color'] is not None:
        color = (args['color'] == '1')
    else:
        color = detect_color_default()
    prefix = (args['prefix'] != '0')  # default 1

    # Mode dispatch
    if args['func'] is not None:
        places = args['places'] if args['places'] is not None else 4
        render_wave(args['func'], places)
        return

    # Read data
    if args['inputfile'] is not None:
        path = args['inputfile']
        try:
            with open(path, 'rb') as f:
                if length is not None and length > 0:
                    data = f.read(length)
                else:
                    data = f.read()
        except FileNotFoundError:
            sys.stderr.write("error: No such file or directory (os error 2)\n")
            sys.exit(1)
        except PermissionError:
            sys.stderr.write("error: Permission denied (os error 13)\n")
            sys.exit(1)
        except IsADirectoryError:
            sys.stderr.write("error: Is a directory (os error 21)\n")
            sys.exit(1)
    else:
        if length is not None and length > 0:
            data = sys.stdin.buffer.read(length)
        else:
            data = sys.stdin.buffer.read()

    if args['array'] is not None:
        render_array(data, args['array'], cols)
        return

    render_hex(data, cols, fmt, prefix, color)


if __name__ == '__main__':
    main()
