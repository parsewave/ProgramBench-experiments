#!/bin/sh
# Build script: produce ./executable from Python source.
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Detect python3
PY=python3
if ! command -v $PY >/dev/null 2>&1; then
    PY=python
fi

# Make a self-contained executable.  Strip any leading shebang from hx.py and
# prepend our own pointing to the discovered interpreter.
{
    echo "#!/usr/bin/env $PY"
    # Drop the first line if it is a shebang.
    awk 'NR==1 && /^#!/ {next} {print}' hx.py
} > executable
chmod +x executable
