#!/bin/sh
set -e
cd "$(dirname "$0")"
gcc -O2 -Wall -o executable cmatrix.c -lncursesw -ltinfo
