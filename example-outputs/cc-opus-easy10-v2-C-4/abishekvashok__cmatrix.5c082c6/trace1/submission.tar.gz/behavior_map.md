# CMatrix behavior map

Reference: `/workspace/executable` (cmatrix 2.0)

## Identity

- C binary linked against libncursesw, libtinfo, libc.
- Embedded strings: version 2.0, compile timestamp via __TIME__ / __DATE__.
- Getopt optstring (from binary `strings`): `abBcfhlLnrosmxkVM:u:C:t:`
- All paths emit a leading single space at start of lines for usage/error text.

## Deterministic byte targets

### `-h` and `-?` — usage
- exit 0, stdout = exact bytes in `goldens/help.txt` (972 bytes), stderr empty.
- Triggered when getopt returns `h` OR `?` (the latter is the getopt "unknown option" case).
- So unknown options (`-z`, `--bogus`, `-u` w/o arg) also print help and exit 0.

### `-V` — version
- exit 0, stderr empty, stdout = ` CMatrix version 2.0 (compiled <TIME>, <DATE>)\nEmail: abishekvashok@gmail.com\nWeb: https://github.com/abishekvashok/cmatrix\n`
- TIME/DATE are baked at compile time. Tests likely match format, not exact timestamp.

### `-C <bad>` — invalid color
- exit 0 (!), stdout empty, stderr =
  ` Invalid color selection\n Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n`
- Detected before curses init. Valid color names: green, red, blue, white, yellow, cyan, magenta, black.

### `-t <bad>` — bad tty
- exit 1, stdout empty, stderr = `cmatrix: error: '<path>' couldn't be opened: <strerror>.\n`
- Where `<strerror>` is the C `strerror(errno)` text.

### Combined `-h` and `-V`
- First-encountered wins (getopt order in argv). `-hV` → help, `-Vh` → version.

### TERM unknown (without `-f`)
- exit 1, stderr = `Error opening terminal: <TERM>.\n` (from ncurses internally)
- TERM unset is treated as "unknown".

### `-l` (without setfont/consolechars)
- exit 0, stdout contains init+teardown ANSI sequences (96 bytes), stderr =
  ` Unable to use both "setfont" and "consolechars".\n`

### `-f` with bad TERM
- SIGSEGV (exit 139). Likely unreachable from a sane test harness; do not target.

## Streaming behavior (matrix mode)

Runs ncurses against the controlling terminal. With TERM=xterm and piped stdout we observe:

- Initial setup bytes (entering alt screen, hide cursor, set scrolling region, clear).
- Frame loop: green chars at `\033[32m`, "head" of each column at `\033[37m` (white).
- `napms()` delays between frames (5 levels of speed 0–10, default 4).
- Exits cleanly on `q` (normal mode) or any key (`-s` mode), restoring terminal state.
- In `-L` lock mode, `q` is ignored (probably needs SIGTERM/SIGINT).

### Color SGR codes observed
- default fg:bg `\033[39;49m`, default fg `\033[39m`
- regular color: `\033[3Nm` for N=1..7 (red..white), 32 default green
- head char: `\033[37m` (white)
- bold: `\033[0;1m`, reset `\033[0m`
- rainbow: colors 32, 33, 34, 35, 36 cycled

### -B / -b
- `-B` all bold: every char wrapped in bold via `\033[0;1m...`
- `-b` random bold: about half the chars wrapped in bold, toggled with `\033[0m`/`\033[0;1m`
- `-n` no bold (default)

### -M message
- Message is printed somewhere on screen (center). Text "hello" appears verbatim in output.

## Exit handling

Signals:
- SIGINT, SIGQUIT, SIGTERM: clean exit, restore screen state.
- SIGWINCH: resize screen (clear and redraw with new size).
- `-L` lock disables q-quit but still respects signals.

## Implementation notes

Use `newterm` (cmatrix does, per strings), not `initscr`, so curses inits properly with redirected output.
The error `Error opening terminal: <TERM>.` comes from ncurses `newterm` when it can't find the terminfo entry.
