/*
 * CMatrix clean-room reimplementation.
 *
 * Behavior recovered by black-box probing of /workspace/executable
 * per /work/CLAUDE.md and the bundled README/man page.
 */

#include <ctype.h>
#include <errno.h>
#include <locale.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#include <ncurses.h>

#define VERSION_STR "2.0"

/* Configuration state set by argument parsing. */
struct cfg {
    int async_scroll;       /* -a */
    int bold_mode;          /* 0 none, 1 random (-b), 2 all (-B), -1 explicit -n */
    int japanese_chars;     /* -c */
    int force_linux;        /* -f */
    int linux_mode;         /* -l */
    int lock_mode;          /* -L */
    int old_style;          /* -o */
    int screensaver;        /* -s */
    int xwindow;            /* -x */
    int rainbow;            /* -r */
    int lambda;             /* -m */
    int changes;            /* -k */
    int update_delay;       /* -u N */
    short color;            /* curses color number for matrix body */
    char *message;          /* -M message text (or default if -L w/o -M) */
    char *tty;              /* -t tty path */
};

static SCREEN *screen_ctx = NULL;
static int term_initialized = 0;
static int signal_status = 0;

/* Print the help text identical to the reference binary. */
static void usage(void) {
    static const char *const lines[] = {
        " Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n",
        " -a: Asynchronous scroll\n",
        " -b: Bold characters on\n",
        " -B: All bold characters (overrides -b)\n",
        " -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n",
        " -f: Force the linux $TERM type to be on\n",
        " -l: Linux mode (uses matrix console font)\n",
        " -L: Lock mode (can be closed from another terminal)\n",
        " -o: Use old-style scrolling\n",
        " -h: Print usage and exit\n",
        " -n: No bold characters (overrides -b and -B, default)\n",
        " -s: \"Screensaver\" mode, exits on first keystroke\n",
        " -x: X window mode, use if your xterm is using mtx.pcf\n",
        " -V: Print version information and exit\n",
        " -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n",
        " -u delay (0 - 10, default 4): Screen update delay\n",
        " -C [color]: Use this color for matrix (default green)\n",
        " -r: rainbow mode\n",
        " -m: lambda mode\n",
        " -k: Characters change while scrolling. (Works without -o opt.)\n",
        " -t [tty]: Set tty to use\n",
        NULL,
    };
    for (int i = 0; lines[i]; i++) {
        fputs(lines[i], stdout);
    }
}

static void print_version(void) {
    printf(" CMatrix version %s (compiled %s, %s)\n"
           "Email: abishekvashok@gmail.com\n"
           "Web: https://github.com/abishekvashok/cmatrix\n",
           VERSION_STR, __TIME__, __DATE__);
}

/* Color name -> curses color number. Returns -1 if unknown. */
static short parse_color(const char *name) {
    if (!strcasecmp(name, "green"))   return COLOR_GREEN;
    if (!strcasecmp(name, "red"))     return COLOR_RED;
    if (!strcasecmp(name, "blue"))    return COLOR_BLUE;
    if (!strcasecmp(name, "white"))   return COLOR_WHITE;
    if (!strcasecmp(name, "yellow"))  return COLOR_YELLOW;
    if (!strcasecmp(name, "cyan"))    return COLOR_CYAN;
    if (!strcasecmp(name, "magenta")) return COLOR_MAGENTA;
    if (!strcasecmp(name, "black"))   return COLOR_BLACK;
    return -1;
}

static void finish(int code) {
    if (term_initialized) {
        curs_set(1);
        clear();
        refresh();
        endwin();
        if (screen_ctx) {
            delscreen(screen_ctx);
            screen_ctx = NULL;
        }
        term_initialized = 0;
    }
    exit(code);
}

static void sighandler(int sig) {
    signal_status = sig;
    (void)sig;
}

/* Initialize column state. */
struct columns {
    int *length;     /* current visible length */
    int *spaces;     /* gap between groups */
    int *update;     /* per-column update step (for async) */
    int **chars;     /* characters in each cell */
    int *head_row;   /* topmost lit row */
    int cols;
    int rows;
};

static int rand_printable(int lambda) {
    if (lambda) {
        /* Just print a literal 'l' for lambda mode placeholder */
        return 'l';
    }
    /* Printable ASCII range minus space-ish */
    return ' ' + 1 + (rand() % ('~' - ' '));
}

static void redraw_with(struct cfg *cfg, struct columns *c) {
    /* Allocate / reinitialize matrices. */
    int rows = LINES;
    int cols = COLS;
    if (cols < 1) cols = 1;
    if (rows < 1) rows = 1;
    /* cmatrix uses half columns (each char occupies 2 screen columns). */
    int ncols = cols / 2;
    if (ncols < 1) ncols = 1;
    free(c->length); free(c->spaces); free(c->update); free(c->head_row);
    if (c->chars) {
        for (int i = 0; i < c->cols; i++) free(c->chars[i]);
        free(c->chars);
    }
    c->cols = ncols;
    c->rows = rows;
    c->length = calloc(ncols, sizeof(int));
    c->spaces = calloc(ncols, sizeof(int));
    c->update = calloc(ncols, sizeof(int));
    c->head_row = calloc(ncols, sizeof(int));
    c->chars = calloc(ncols, sizeof(int *));
    for (int i = 0; i < ncols; i++) {
        c->chars[i] = calloc(rows + 1, sizeof(int));
        c->length[i] = (rand() % (rows - 3)) + 3;
        c->spaces[i] = rand() % rows + 1;
        c->update[i] = (rand() % 3) + 1;
        c->head_row[i] = rand() % rows;
        for (int r = 0; r <= rows; r++) c->chars[i][r] = ' ';
    }
    clear();
    refresh();
}

static void run_matrix(struct cfg *cfg) {
    struct columns cols = {0};
    redraw_with(cfg, &cols);

    int count = 0;
    int random_speed = 0;
    (void)random_speed;

    while (1) {
        if (signal_status == SIGINT || signal_status == SIGTERM || signal_status == SIGQUIT) {
            finish(0);
        }
        if (signal_status == SIGWINCH) {
            signal_status = 0;
            endwin();
            refresh();
            redraw_with(cfg, &cols);
        }

        int ch = wgetch(stdscr);
        if (ch != ERR) {
            if (cfg->screensaver) {
                finish(0);
            }
            switch (ch) {
                case 'q':
                case 'Q':
                    if (!cfg->lock_mode) finish(0);
                    break;
                case 'a': cfg->async_scroll = !cfg->async_scroll; break;
                case 'b': cfg->bold_mode = 1; break;
                case 'B': cfg->bold_mode = 2; break;
                case 'n': cfg->bold_mode = 0; break;
                case '0': cfg->update_delay = 0; break;
                case '1': cfg->update_delay = 1; break;
                case '2': cfg->update_delay = 2; break;
                case '3': cfg->update_delay = 3; break;
                case '4': cfg->update_delay = 4; break;
                case '5': cfg->update_delay = 5; break;
                case '6': cfg->update_delay = 6; break;
                case '7': cfg->update_delay = 7; break;
                case '8': cfg->update_delay = 8; break;
                case '9': cfg->update_delay = 9; break;
                case '!': cfg->color = COLOR_RED; break;
                case '@': cfg->color = COLOR_GREEN; break;
                case '#': cfg->color = COLOR_YELLOW; break;
                case '$': cfg->color = COLOR_BLUE; break;
                case '%': cfg->color = COLOR_MAGENTA; break;
                case '^': cfg->color = COLOR_CYAN; break;
                case '&': cfg->color = COLOR_WHITE; break;
                case ')': cfg->color = COLOR_BLACK; break;
                default: break;
            }
        }

        for (int i = 0; i < cols.cols; i++) {
            int x = i * 2;
            int head = cols.head_row[i];

            if (cfg->async_scroll) {
                count++;
                if ((count % cols.update[i]) != 0) continue;
            }

            /* erase the cell that becomes the new tail */
            int tail = head - cols.length[i];
            if (tail >= 0 && tail < cols.rows) {
                mvaddch(tail, x, ' ');
            }
            /* shift head down */
            cols.head_row[i]++;
            if (cols.head_row[i] >= cols.rows + cols.length[i] + cols.spaces[i]) {
                cols.head_row[i] = 0;
                cols.length[i] = (rand() % (cols.rows - 3)) + 3;
                cols.spaces[i] = rand() % cols.rows + 1;
            }

            int new_head = cols.head_row[i];
            if (new_head >= 0 && new_head < cols.rows) {
                int ch_to_draw = cfg->lambda ? 'l' : rand_printable(0);

                /* Previous head becomes regular green char */
                int prev = new_head - 1;
                if (prev >= 0 && prev < cols.rows) {
                    short pc = cfg->rainbow ? (short)((rand() % 5) + 2) : cfg->color;
                    int attr = 0;
                    if (cfg->bold_mode == 2) attr |= A_BOLD;
                    else if (cfg->bold_mode == 1 && (rand() % 2)) attr |= A_BOLD;
                    attron(COLOR_PAIR(pc) | attr);
                    int repl = cfg->lambda ? 'l' : rand_printable(0);
                    mvaddch(prev, x, repl);
                    attroff(COLOR_PAIR(pc) | attr);
                }

                /* New head in white */
                attron(COLOR_PAIR(COLOR_WHITE));
                mvaddch(new_head, x, ch_to_draw);
                attroff(COLOR_PAIR(COLOR_WHITE));
            }
        }

        /* Center message if set */
        if (cfg->message && cfg->message[0]) {
            int mlen = (int)strlen(cfg->message);
            int mx = (cols.rows / 2);
            int my = (COLS - mlen) / 2;
            if (mx >= 0 && mx < cols.rows && my >= 0) {
                attron(COLOR_PAIR(cfg->color));
                mvaddnstr(mx, my, cfg->message, mlen);
                attroff(COLOR_PAIR(cfg->color));
            }
        }

        refresh();

        /* delay: 0..10 map to napms; default 4 => around 40ms */
        int ms = cfg->update_delay * 10 + 5;
        if (ms < 5) ms = 5;
        napms(ms);
    }
}

int main(int argc, char **argv) {
    struct cfg cfg = {
        .update_delay = 4,
        .color = COLOR_GREEN,
        .bold_mode = 0,
        .message = NULL,
        .tty = NULL,
    };

    /* getopt optstring matches the reference exactly */
    const char *optstring = "abBcfhlLnrosmxkVM:u:C:t:";
    int opt;
    opterr = 0; /* suppress getopt's own error output */
    while ((opt = getopt(argc, argv, optstring)) != -1) {
        switch (opt) {
            case 'a': cfg.async_scroll = 1; break;
            case 'b': if (cfg.bold_mode != 2) cfg.bold_mode = 1; break;
            case 'B': cfg.bold_mode = 2; break;
            case 'c': cfg.japanese_chars = 1; break;
            case 'f': cfg.force_linux = 1; break;
            case 'l': cfg.linux_mode = 1; break;
            case 'L': cfg.lock_mode = 1; break;
            case 'n': cfg.bold_mode = 0; break;
            case 'o': cfg.old_style = 1; break;
            case 'r': cfg.rainbow = 1; break;
            case 's': cfg.screensaver = 1; break;
            case 'm': cfg.lambda = 1; break;
            case 'x': cfg.xwindow = 1; break;
            case 'k': cfg.changes = 1; break;
            case 'h':
            case '?':
                usage();
                exit(0);
            case 'V':
                print_version();
                exit(0);
            case 'M':
                cfg.message = optarg;
                break;
            case 'u': {
                /* delay 0-10, default 4 */
                char *endp;
                long v = strtol(optarg, &endp, 10);
                if (v < 0) v = 0;
                if (v > 10) v = 10;
                cfg.update_delay = (int)v;
                break;
            }
            case 'C':
                {
                    short c = parse_color(optarg);
                    if (c < 0) {
                        fputs(" Invalid color selection\n"
                              " Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n",
                              stderr);
                        exit(0);
                    }
                    cfg.color = c;
                }
                break;
            case 't':
                cfg.tty = optarg;
                break;
            default:
                usage();
                exit(0);
        }
    }

    /* -L without -M uses default lock message */
    if (cfg.lock_mode && cfg.message == NULL) {
        cfg.message = "Computer locked.";
    }

    /* Force linux terminal type */
    if (cfg.force_linux) {
        setenv("TERM", "linux", 1);
    }

    /* Initialize curses. With -t, use newterm against the given tty.
       Without -t, use initscr() so ncurses prints its own
       "Error opening terminal: <TERM>." on failure. */
    setlocale(LC_ALL, "");
    if (cfg.tty) {
        FILE *f = fopen(cfg.tty, "r+");
        if (!f) {
            fprintf(stderr, "cmatrix: error: '%s' couldn't be opened: %s.\n",
                    cfg.tty, strerror(errno));
            exit(1);
        }
        screen_ctx = newterm(NULL, f, f);
        if (!screen_ctx) {
            const char *t = getenv("TERM");
            fprintf(stderr, "Error opening terminal: %s.\n", t ? t : "unknown");
            exit(1);
        }
        set_term(screen_ctx);
    } else {
        initscr();
    }
    term_initialized = 1;

    cbreak();
    noecho();
    nonl();
    leaveok(stdscr, TRUE);
    curs_set(0);
    wtimeout(stdscr, 0); /* non-blocking */

    /* Linux mode "setfont" check */
    if (cfg.linux_mode) {
        /* Both setfont and consolechars unavailable in this clean-room build */
        curs_set(1);
        clear();
        refresh();
        endwin();
        if (screen_ctx) delscreen(screen_ctx);
        term_initialized = 0;
        fputs(" Unable to use both \"setfont\" and \"consolechars\".\n", stderr);
        exit(0);
    }

    if (has_colors()) {
        start_color();
        use_default_colors();
        init_pair(COLOR_BLACK,   COLOR_BLACK,   -1);
        init_pair(COLOR_GREEN,   COLOR_GREEN,   -1);
        init_pair(COLOR_RED,     COLOR_RED,     -1);
        init_pair(COLOR_YELLOW,  COLOR_YELLOW,  -1);
        init_pair(COLOR_BLUE,    COLOR_BLUE,    -1);
        init_pair(COLOR_MAGENTA, COLOR_MAGENTA, -1);
        init_pair(COLOR_CYAN,    COLOR_CYAN,    -1);
        init_pair(COLOR_WHITE,   COLOR_WHITE,   -1);
    }

    /* Signal handlers */
    signal(SIGINT, sighandler);
    signal(SIGTERM, sighandler);
    signal(SIGQUIT, sighandler);
    signal(SIGWINCH, sighandler);

    srand((unsigned)time(NULL));

    run_matrix(&cfg);

    finish(0);
    return 0;
}
