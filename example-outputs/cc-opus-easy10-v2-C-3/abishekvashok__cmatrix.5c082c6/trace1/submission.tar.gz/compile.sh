#!/bin/bash
set -e
cd "$(dirname "$0")"
gcc -O2 -Wall -Wno-unused-result \
    -o executable cmatrix.c \
    -lncursesw \
    -ltinfo
