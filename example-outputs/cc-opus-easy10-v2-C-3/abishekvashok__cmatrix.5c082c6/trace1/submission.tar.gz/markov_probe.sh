#!/bin/bash
# Generate random invocations from realistic user patterns

# Modes discovered:
#   - help-seeker: -h, -?, --help
#   - version-checker: -V
#   - color-tweaker: -C <color>, sometimes invalid
#   - flag-stacker: random subset of bool flags
#   - tty-tester: -t <some path>
#   - msg-setter: -M <message>
#   - speed-tweaker: -u <num>

REF=/workspace/executable
MINE=/work/work/executable

VALID_COLORS=(green red blue white yellow cyan magenta black GREEN Red yelloW)
INVALID_COLORS=(foo purple "" rgb "")
BOOL_FLAGS=(-a -b -B -c -l -L -n -r -o -s -m -x -k)
TTY_PATHS=(/tmp/xxx_zzz /etc/hosts /var "" /dev/null)
MSGS=("hello" "" "Some message with spaces" "x" "ABC")
DELAYS=(0 1 4 5 10 11 99 -1 -5 abc)

# Modes (with weights)
MODES=(help version color flagstack tty msg speed mixed)

rand_pick() {
  local -n arr=$1
  echo "${arr[RANDOM % ${#arr[@]}]}"
}

PASS=0; FAIL=0; ERRS=()
for i in $(seq 1 10); do
  mode="${MODES[RANDOM % ${#MODES[@]}]}"
  case "$mode" in
    help)     args=(-h);;
    version)  args=(-V);;
    color)    if (( RANDOM % 2 )); then args=(-C "$(rand_pick VALID_COLORS)"); else args=(-C "$(rand_pick INVALID_COLORS)"); fi;;
    flagstack)
      n=$(( (RANDOM % 4) + 1 ))
      args=()
      for _ in $(seq 1 $n); do args+=("$(rand_pick BOOL_FLAGS)"); done;;
    tty)      args=(-t "$(rand_pick TTY_PATHS)");;
    msg)      args=(-M "$(rand_pick MSGS)");;
    speed)    args=(-u "$(rand_pick DELAYS)");;
    mixed)
      # Combine 2-3 random pieces
      args=("$(rand_pick BOOL_FLAGS)" -C "$(rand_pick VALID_COLORS)" -u "$(rand_pick DELAYS)")
      ;;
  esac
  
  # Random env: half the time unset TERM
  if (( RANDOM % 2 )); then env_pre="env -u TERM"; else env_pre="env"; fi
  
  r_out=$(mktemp); r_err=$(mktemp); m_out=$(mktemp); m_err=$(mktemp)
  $env_pre timeout 1 "$REF" "${args[@]}" 1>"$r_out" 2>"$r_err"; r_ec=$?
  $env_pre timeout 1 "$MINE" "${args[@]}" 1>"$m_out" 2>"$m_err"; m_ec=$?
  
  ok=1; reason=""
  if [ "$r_ec" != "$m_ec" ]; then ok=0; reason="ec ref=$r_ec mine=$m_ec"; fi
  if ! diff -q "$r_out" "$m_out" >/dev/null; then ok=0; reason="$reason stdout-diff"; fi
  if ! diff -q "$r_err" "$m_err" >/dev/null; then ok=0; reason="$reason stderr-diff"; fi
  
  if [ "$ok" = 1 ]; then
    PASS=$((PASS+1))
    echo "PASS[$i]: mode=$mode env_pre='$env_pre' args=(${args[@]})"
  else
    FAIL=$((FAIL+1))
    ERRS+=("[$i] mode=$mode env=$env_pre args=(${args[@]}): $reason")
  fi
  rm -f "$r_out" "$r_err" "$m_out" "$m_err"
done

echo "=== TOP-UP: $PASS/10 pass ==="
for e in "${ERRS[@]}"; do echo "FAIL: $e"; done
