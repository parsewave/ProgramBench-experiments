#!/bin/bash
# Usage: capture.sh <name> <unset_term:0|1> <env_setvars> -- <args...>
name="$1"; shift
unset_term="$1"; shift
envs=()
while [ "$1" != "--" ]; do envs+=("$1"); shift; done
shift
mkdir -p "$name"
if [ "$unset_term" = "1" ]; then
  env -u TERM "${envs[@]}" timeout 2 /workspace/executable "$@" 1>"$name/stdout" 2>"$name/stderr"
else
  env "${envs[@]}" timeout 2 /workspace/executable "$@" 1>"$name/stdout" 2>"$name/stderr"
fi
ec=$?
echo "$ec" > "$name/exitcode"
{
  echo "Env unset_term=$unset_term setvars=${envs[*]}"
  echo "Args: $*"
} > "$name/cmd"
echo "captured: $name -> exit=$ec stdout=$(wc -c <$name/stdout) stderr=$(wc -c <$name/stderr)"
