#!/bin/bash
PASS=0; FAIL=0; TOTAL=0; FAILS=()
diff_run() {
  local label="$1"; shift
  local unset_term="$1"; shift
  local extra_env=("$1"); shift
  local args=("$@")

  local r_out r_err m_out m_err
  r_out=$(mktemp); r_err=$(mktemp); m_out=$(mktemp); m_err=$(mktemp)

  if [ "$unset_term" = "1" ]; then
    env -u TERM ${extra_env[@]} timeout 2 /workspace/executable "${args[@]}" 1>"$r_out" 2>"$r_err"
    r_ec=$?
    env -u TERM ${extra_env[@]} timeout 2 /work/work/executable  "${args[@]}" 1>"$m_out" 2>"$m_err"
    m_ec=$?
  else
    env ${extra_env[@]} timeout 2 /workspace/executable "${args[@]}" 1>"$r_out" 2>"$r_err"
    r_ec=$?
    env ${extra_env[@]} timeout 2 /work/work/executable  "${args[@]}" 1>"$m_out" 2>"$m_err"
    m_ec=$?
  fi

  TOTAL=$((TOTAL+1))
  ok=1; reason=""
  if [ "$r_ec" != "$m_ec" ]; then ok=0; reason+=" exit:$r_ec!=$m_ec"; fi
  if ! diff -q "$r_out" "$m_out" >/dev/null; then ok=0; reason+=" stdout-diff"; fi
  if ! diff -q "$r_err" "$m_err" >/dev/null; then ok=0; reason+=" stderr-diff"; fi
  if [ "$ok" = 1 ]; then
    PASS=$((PASS+1))
  else
    FAIL=$((FAIL+1))
    FAILS+=("$label$reason")
  fi
  rm -f "$r_out" "$r_err" "$m_out" "$m_err"
}

# Help/version variants
diff_run "h"            0 "" -h
diff_run "?"            0 "" -?
diff_run "--help"       0 "" --help
diff_run "Z"            0 "" -Z
diff_run "-bogus"       0 "" -bogus
diff_run "--bogus"      0 "" --bogus
diff_run "V"            0 "" -V
diff_run "hV"           0 "" -h -V
diff_run "Vh"           0 "" -V -h
diff_run "hVcombined"   0 "" -hV
diff_run "Vhcombined"   0 "" -Vh
diff_run "Cfoo"         0 "" -C foo
diff_run "Cpurple"      0 "" -C purple
diff_run "Cempty"       0 "" -C ""
diff_run "CfooV"        0 "" -C foo -V
diff_run "VCfoo"        0 "" -V -C foo
diff_run "hCfoo"        0 "" -h -C foo
diff_run "Cfooh"        0 "" -C foo -h
diff_run "u_alone"      0 "" -u
diff_run "C_alone"      0 "" -C
diff_run "t_alone"      0 "" -t
diff_run "V_foo"        0 "" -V foo

# Terminal-init paths (TERM unset)
diff_run "no_args"      1 "" 
diff_run "ddash"        1 "" --
diff_run "dashonly"     1 "" -
diff_run "Cgreen"       1 "" -C green
diff_run "CGREEN"       1 "" -C GREEN
diff_run "CRed"         1 "" -C Red
diff_run "CyelloW"      1 "" -C yelloW
diff_run "u0"           1 "" -u 0
diff_run "uneg1"        1 "" -u -1
diff_run "ueleven"      1 "" -u 11
diff_run "uabc"         1 "" -u abc
diff_run "L"            1 "" -L
diff_run "Mhello"       1 "" -M hello
diff_run "a"            1 "" -a
diff_run "b"            1 "" -b
diff_run "foo_pos"      1 "" foo
diff_run "BnB"          1 "" -B -n -B
diff_run "rrr"          1 "" -r -r -r

# -t error paths
diff_run "t_nonex"      0 "" -t /tmp/cmatrix_nope_xxx
diff_run "t_etchosts"   0 "" -t /etc/hosts

# TERM-set early exit paths
diff_run "xterm_V"      0 "TERM=xterm" -V
diff_run "xterm_h"      0 "TERM=xterm" -h
diff_run "xterm_Cfoo"   0 "TERM=xterm" -C foo
diff_run "linux_V"      0 "TERM=linux" -V

echo "=== $PASS/$TOTAL pass, $FAIL fail ==="
for f in "${FAILS[@]}"; do echo "FAIL: $f"; done
