#!/bin/bash
# Comprehensive differential test
PASS=0; FAIL=0; ERRORS=()

run_diff() {
  local lbl="$1"; shift
  local r_out r_err m_out m_err
  r_out=$(mktemp); r_err=$(mktemp); m_out=$(mktemp); m_err=$(mktemp)
  "$@" 1>"$r_out" 2>"$r_err"; r_ec=$?
  ARGS=("${@/\/workspace\/executable/\/work\/work\/executable}")
  "${ARGS[@]}" 1>"$m_out" 2>"$m_err"; m_ec=$?
  if [ "$r_ec" = "$m_ec" ] && diff -q "$r_out" "$m_out" >/dev/null && diff -q "$r_err" "$m_err" >/dev/null; then
    PASS=$((PASS+1))
  else
    FAIL=$((FAIL+1))
    ERRORS+=("$lbl: ec ref=$r_ec mine=$m_ec out_diff=$(diff -q "$r_out" "$m_out") err_diff=$(diff -q "$r_err" "$m_err")")
  fi
  rm -f "$r_out" "$r_err" "$m_out" "$m_err"
}

# These all run the reference; the wrapper auto-rewrites the path to /work/work/executable for "mine"
REF=/workspace/executable

# Help / version variants
run_diff "h"          timeout 1 $REF -h
run_diff "?"          timeout 1 $REF -?
run_diff "--help"     timeout 1 $REF --help
run_diff "Z"          timeout 1 $REF -Z
run_diff "-Bogus"     timeout 1 $REF -Bogus
run_diff "--bogus"    timeout 1 $REF --bogus
run_diff "V"          timeout 1 $REF -V
run_diff "hV"         timeout 1 $REF -h -V
run_diff "Vh"         timeout 1 $REF -V -h
run_diff "hVcombo"    timeout 1 $REF -hV
run_diff "Vhcombo"    timeout 1 $REF -Vh
run_diff "Cfoo"       timeout 1 $REF -C foo
run_diff "Cpurple"    timeout 1 $REF -C purple
run_diff "Cempty"     timeout 1 $REF -C ""
run_diff "Cgreen_space" timeout 1 $REF -C " green"
run_diff "Cgreen_nospace" env -u TERM timeout 1 $REF -Cgreen
run_diff "u_no_arg"   timeout 1 $REF -u
run_diff "C_no_arg"   timeout 1 $REF -C
run_diff "t_no_arg"   timeout 1 $REF -t
run_diff "M_no_arg"   timeout 1 $REF -M
run_diff "tnonexist"  timeout 1 $REF -t /tmp/cmatrix_xxx_zz
run_diff "tperm_denied" timeout 1 $REF -t /etc/hosts
run_diff "tvar_dir"   timeout 1 $REF -t /var
run_diff "tempty"     timeout 1 $REF -t ""

# Combinations / argv order
run_diff "VCfoo"      timeout 1 $REF -V -C foo
run_diff "CfooV"      timeout 1 $REF -C foo -V
run_diff "hCfoo"      timeout 1 $REF -h -C foo
run_diff "Cfooh"      timeout 1 $REF -C foo -h
run_diff "Cred_Cfoo"  env -u TERM timeout 1 $REF -C red -C foo
run_diff "Vfoo_extra" timeout 1 $REF -V foo
run_diff "Vfoo_extra_multi" timeout 1 $REF -V foo bar baz
run_diff "h_foo_extra" timeout 1 $REF -h foo bar
run_diff "VV_VV"      timeout 1 $REF -V -V -V -V
run_diff "hh_hh"      timeout 1 $REF -h -h -h
run_diff "h_ddash_V"  timeout 1 $REF -h -- -V
run_diff "V_ddash_h"  timeout 1 $REF -V -- -h
run_diff "u4_V"       timeout 1 $REF -u 4 -V
run_diff "u_long_V"   timeout 1 $REF -u 12345 -V

# Cases that fall through to terminal init (TERM unset → "Error opening terminal")
run_diff "no_args"    env -u TERM timeout 1 $REF
run_diff "ddash"      env -u TERM timeout 1 $REF --
run_diff "dash"       env -u TERM timeout 1 $REF -
run_diff "ddash_h"    env -u TERM timeout 1 $REF -- -h
run_diff "ddash_V"    env -u TERM timeout 1 $REF -- -V
run_diff "Cgreen"     env -u TERM timeout 1 $REF -C green
run_diff "CGREEN"     env -u TERM timeout 1 $REF -C GREEN
run_diff "CRed"       env -u TERM timeout 1 $REF -C Red
run_diff "CyelloW"    env -u TERM timeout 1 $REF -C yelloW
run_diff "Cgreen_extra" env -u TERM timeout 1 $REF -C green foo
run_diff "u0"         env -u TERM timeout 1 $REF -u 0
run_diff "uneg1"      env -u TERM timeout 1 $REF -u -1
run_diff "u11"        env -u TERM timeout 1 $REF -u 11
run_diff "uabc"       env -u TERM timeout 1 $REF -u abc
run_diff "L"          env -u TERM timeout 1 $REF -L
run_diff "Mhello"     env -u TERM timeout 1 $REF -M hello
run_diff "a"          env -u TERM timeout 1 $REF -a
run_diff "b"          env -u TERM timeout 1 $REF -b
run_diff "B"          env -u TERM timeout 1 $REF -B
run_diff "n"          env -u TERM timeout 1 $REF -n
run_diff "r"          env -u TERM timeout 1 $REF -r
run_diff "o"          env -u TERM timeout 1 $REF -o
run_diff "s"          env -u TERM timeout 1 $REF -s
run_diff "m"          env -u TERM timeout 1 $REF -m
run_diff "x"          env -u TERM timeout 1 $REF -x
run_diff "k"          env -u TERM timeout 1 $REF -k
run_diff "c"          env -u TERM timeout 1 $REF -c
run_diff "foo_pos"    env -u TERM timeout 1 $REF foo
run_diff "rrr"        env -u TERM timeout 1 $REF -r -r -r

# With TERM=xterm  (early exit paths only)
run_diff "xterm_h"    env TERM=xterm timeout 1 $REF -h
run_diff "xterm_V"    env TERM=xterm timeout 1 $REF -V
run_diff "xterm_Cfoo" env TERM=xterm timeout 1 $REF -C foo
run_diff "xterm_tnonexist" env TERM=xterm timeout 1 $REF -t /tmp/xxx_zz

# With TERM=linux
run_diff "linux_h"    env TERM=linux timeout 1 $REF -h
run_diff "linux_V"    env TERM=linux timeout 1 $REF -V
run_diff "linux_Cfoo" env TERM=linux timeout 1 $REF -C foo

echo "=== $PASS/$((PASS+FAIL)) pass, $FAIL fail ==="
for e in "${ERRORS[@]}"; do echo "ERR: $e"; done
