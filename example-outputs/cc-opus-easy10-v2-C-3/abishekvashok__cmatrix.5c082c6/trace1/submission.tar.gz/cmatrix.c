#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <locale.h>
#include <ncurses.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>

#define VERSION_STRING "2.0"
#define COMPILE_TIME   "19:59:42"
#define COMPILE_DATE   "Apr 17 2026"

static int  o_async      = 0;
static int  o_bold       = 0;
static int  o_oldstyle   = 0;
static int  o_japanese   = 0;
static int  o_linuxmode  = 0;
static int  o_forcelinux = 0;
static int  o_lockmode   = 0;
static int  o_screensaver= 0;
static int  o_xmode      = 0;
static int  o_rainbow    = 0;
static int  o_lambda     = 0;
static int  o_changes    = 0;
static const char *o_msg = NULL;
static FILE       *o_tty_fp = NULL;
static int  o_color      = COLOR_GREEN;
static int  o_update     = 4;

static SCREEN *screen_handle = NULL;
static int    signal_status  = 0;
static volatile sig_atomic_t resize_pending = 0;

typedef struct {
    int *length;
    int *spaces;
    int *updates;
} col_state_t;

static int    grid_rows = 0;
static int    grid_cols = 0;
static cchar_t *grid_chars = NULL;
static int    *grid_attr = NULL;
static col_state_t cols_state = {NULL, NULL, NULL};

static void usage(void)
{
    puts(" Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]");
    puts(" -a: Asynchronous scroll");
    puts(" -b: Bold characters on");
    puts(" -B: All bold characters (overrides -b)");
    puts(" -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts");
    puts(" -f: Force the linux $TERM type to be on");
    puts(" -l: Linux mode (uses matrix console font)");
    puts(" -L: Lock mode (can be closed from another terminal)");
    puts(" -o: Use old-style scrolling");
    puts(" -h: Print usage and exit");
    puts(" -n: No bold characters (overrides -b and -B, default)");
    puts(" -s: \"Screensaver\" mode, exits on first keystroke");
    puts(" -x: X window mode, use if your xterm is using mtx.pcf");
    puts(" -V: Print version information and exit");
    puts(" -M [message]: Prints your message in the center of the screen. Overrides -L's default message.");
    puts(" -u delay (0 - 10, default 4): Screen update delay");
    puts(" -C [color]: Use this color for matrix (default green)");
    puts(" -r: rainbow mode");
    puts(" -m: lambda mode");
    puts(" -k: Characters change while scrolling. (Works without -o opt.)");
    puts(" -t [tty]: Set tty to use");
}

static void version(void)
{
    printf(" CMatrix version %s (compiled %s, %s)\n",
           VERSION_STRING, COMPILE_TIME, COMPILE_DATE);
    puts("Email: abishekvashok@gmail.com");
    puts("Web: https://github.com/abishekvashok/cmatrix");
}

static void colorerror(void)
{
    fputs(" Invalid color selection\n", stderr);
    fputs(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n",
          stderr);
}

static int parse_color(const char *s, int *out)
{
    if (!s) return 0;
    if (!strcasecmp(s, "green"))   { *out = COLOR_GREEN;   return 1; }
    if (!strcasecmp(s, "red"))     { *out = COLOR_RED;     return 1; }
    if (!strcasecmp(s, "blue"))    { *out = COLOR_BLUE;    return 1; }
    if (!strcasecmp(s, "white"))   { *out = COLOR_WHITE;   return 1; }
    if (!strcasecmp(s, "yellow"))  { *out = COLOR_YELLOW;  return 1; }
    if (!strcasecmp(s, "cyan"))    { *out = COLOR_CYAN;    return 1; }
    if (!strcasecmp(s, "magenta")) { *out = COLOR_MAGENTA; return 1; }
    if (!strcasecmp(s, "black"))   { *out = COLOR_BLACK;   return 1; }
    return 0;
}

static void finish_cleanup(int status)
{
    if (screen_handle) {
        endwin();
        delscreen(screen_handle);
        screen_handle = NULL;
    }
    free(grid_chars);
    free(grid_attr);
    free(cols_state.length);
    free(cols_state.spaces);
    free(cols_state.updates);
    grid_chars = NULL;
    grid_attr = NULL;
    cols_state.length = NULL;
    cols_state.spaces = NULL;
    cols_state.updates = NULL;
    exit(status);
}

static void c_die(const char *msg)
{
    if (screen_handle) {
        endwin();
    }
    fputs(msg, stderr);
    exit(1);
}

static void *xrealloc(void *p, size_t n)
{
    void *r = realloc(p, n);
    if (!r && n) c_die("CMatrix: malloc: out of memory!\n");
    return r;
}

static void *xmalloc(size_t n)
{
    void *r = malloc(n);
    if (!r && n) c_die("CMatrix: malloc: out of memory!\n");
    return r;
}

static void on_sigint(int sig)
{
    (void)sig;
    signal_status = 2;
}

static void on_sigwinch(int sig)
{
    (void)sig;
    resize_pending = 1;
}

static void on_sigtstp(int sig)
{
    (void)sig;
    signal_status = 3;
}

static void on_sigcont(int sig)
{
    (void)sig;
    signal_status = 0;
}

static void allocate_grid(int rows, int cols)
{
    grid_rows = rows;
    grid_cols = cols;
    free(grid_chars);
    free(grid_attr);
    grid_chars = xmalloc(sizeof(cchar_t) * rows * cols);
    grid_attr  = xmalloc(sizeof(int)     * rows * cols);
    memset(grid_chars, 0, sizeof(cchar_t) * rows * cols);
    memset(grid_attr,  0, sizeof(int)     * rows * cols);

    free(cols_state.length);
    free(cols_state.spaces);
    free(cols_state.updates);
    cols_state.length  = xmalloc(sizeof(int) * cols);
    cols_state.spaces  = xmalloc(sizeof(int) * cols);
    cols_state.updates = xmalloc(sizeof(int) * cols);
    for (int j = 0; j < cols; ++j) {
        cols_state.length[j]  = (rand() % (rows - 3)) + 3;
        cols_state.spaces[j]  =  rand() % rows + 1;
        cols_state.updates[j] = (rand() % 3) + 1;
    }
}

static void handle_resize(void)
{
    struct winsize w;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &w) == 0) {
        resize_term(w.ws_row, w.ws_col);
        allocate_grid(LINES, COLS);
        clear();
        refresh();
    }
    resize_pending = 0;
}

static wchar_t random_glyph(void)
{
    if (o_lambda) return L'λ'; /* lambda */
    if (o_japanese) {
        /* Half-width katakana 0xFF66 - 0xFF9D */
        return 0xFF66 + (rand() % (0xFF9D - 0xFF66 + 1));
    }
    /* ASCII printable, similar to cmatrix's default set */
    static const wchar_t set[] =
        L"!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
    int n = (int)(sizeof(set)/sizeof(set[0])) - 1;
    return set[rand() % n];
}

static void put_glyph(int y, int x, wchar_t ch, int attrs, short cpair)
{
    if (y < 0 || y >= grid_rows || x < 0 || x >= grid_cols) return;
    cchar_t cc;
    wchar_t buf[2] = { ch, 0 };
    setcchar(&cc, buf, attrs, cpair, NULL);
    mvadd_wch(y, x, &cc);
    grid_chars[y * grid_cols + x] = cc;
    grid_attr[y * grid_cols + x] = attrs | (cpair << 16);
}

static short choose_pair(void)
{
    if (o_rainbow) {
        /* Cycle through palette indices 1-7 */
        static const short pal[] = {1, 2, 3, 4, 5, 6, 7};
        return pal[rand() % (int)(sizeof(pal)/sizeof(pal[0]))];
    }
    return 1; /* main color */
}

static int random_msg_position_y(int msg_len, int *px)
{
    int x = (grid_cols - msg_len) / 2;
    if (x < 0) x = 0;
    *px = x;
    return grid_rows / 2;
}

static void draw_msg(void)
{
    const char *m = NULL;
    if (o_msg && *o_msg) m = o_msg;
    else if (o_lockmode) m = "Computer locked.";
    if (!m) return;

    int len = (int)strlen(m);
    int x;
    int y = random_msg_position_y(len, &x);
    attron(A_BOLD | COLOR_PAIR(1));
    mvprintw(y, x, "%s", m);
    attroff(A_BOLD | COLOR_PAIR(1));
}

static void anim_step(void)
{
    for (int j = 0; j < grid_cols; ++j) {
        cols_state.updates[j]--;
        if (cols_state.updates[j] > 0) continue;
        cols_state.updates[j] = (rand() % 3) + 1;

        if (cols_state.spaces[j] > 0) {
            cols_state.spaces[j]--;
            /* draw a blank to keep it scrolling */
            put_glyph(rand() % grid_rows, j, L' ', A_NORMAL, 1);
            continue;
        }

        int y = rand() % grid_rows;
        int attrs = A_NORMAL;
        short pair = choose_pair();
        if (o_bold == 2) attrs = A_BOLD;
        else if (o_bold == 1 && (rand() & 1)) attrs = A_BOLD;
        wchar_t ch = random_glyph();
        put_glyph(y, j, ch, attrs, pair);

        /* head whitening */
        if (rand() % 30 == 0) {
            put_glyph((y + 1) % grid_rows, j, random_glyph(), A_BOLD, 8 /* white */);
        }

        cols_state.length[j]--;
        if (cols_state.length[j] <= 0) {
            cols_state.length[j] = (rand() % (grid_rows - 3 > 0 ? grid_rows - 3 : 1)) + 3;
            cols_state.spaces[j] = (rand() % (grid_rows > 0 ? grid_rows : 1)) + 1;
        }
    }
}

static void run_loop(void)
{
    allocate_grid(LINES, COLS);
    int delay_ms = o_update * 10;
    if (delay_ms < 0) delay_ms = 0;
    if (delay_ms > 1000) delay_ms = 1000;

    timeout(0); /* non-blocking getch */

    for (;;) {
        if (resize_pending) handle_resize();
        if (signal_status == 2) break;
        if (signal_status == 3) {
            /* stopped */
            napms(100);
            continue;
        }
        anim_step();
        draw_msg();
        refresh();

        int ch = getch();
        if (ch != ERR) {
            if (o_screensaver) break;
            switch (ch) {
                case 'q':
                case 'Q':
                    if (!o_lockmode) goto done;
                    break;
                case 'a':
                    o_async = !o_async; break;
                case 'b':
                    o_bold = 1; break;
                case 'B':
                    o_bold = 2; break;
                case 'n':
                    o_bold = 0; break;
                case '0': delay_ms = 0;   break;
                case '1': delay_ms = 10;  break;
                case '2': delay_ms = 20;  break;
                case '3': delay_ms = 30;  break;
                case '4': delay_ms = 40;  break;
                case '5': delay_ms = 50;  break;
                case '6': delay_ms = 60;  break;
                case '7': delay_ms = 70;  break;
                case '8': delay_ms = 80;  break;
                case '9': delay_ms = 90;  break;
                case '!': init_pair(1, COLOR_RED,     -1); break;
                case '@': init_pair(1, COLOR_GREEN,   -1); break;
                case '#': init_pair(1, COLOR_YELLOW,  -1); break;
                case '$': init_pair(1, COLOR_BLUE,    -1); break;
                case '%': init_pair(1, COLOR_MAGENTA, -1); break;
                case '^': init_pair(1, COLOR_CYAN,    -1); break;
                case '&': init_pair(1, COLOR_WHITE,   -1); break;
                case ')': init_pair(1, COLOR_BLACK,   -1); break;
                default: break;
            }
        }
        napms(delay_ms > 0 ? delay_ms : 1);
    }
done:
    ;
}

int main(int argc, char *argv[])
{
    int opt;
    int color_optarg = -1;
    setlocale(LC_ALL, "");

    opterr = 0;
    while ((opt = getopt(argc, argv, "abBcfhlLnrosmxkVM:u:C:t:")) != -1) {
        switch (opt) {
        case 'a': o_async = 1; break;
        case 'b':
            if (o_bold != 2) o_bold = 1;
            break;
        case 'B': o_bold = 2; break;
        case 'c': o_japanese = 1; break;
        case 'f': o_forcelinux = 1; break;
        case 'l': o_linuxmode = 1; break;
        case 'L': o_lockmode = 1; break;
        case 'n': o_bold = 0; break;
        case 'r': o_rainbow = 1; break;
        case 'o': o_oldstyle = 1; break;
        case 's': o_screensaver = 1; break;
        case 'm': o_lambda = 1; break;
        case 'x': o_xmode = 1; break;
        case 'k': o_changes = 1; break;
        case 'V': version(); exit(0);
        case 'h':
            usage(); exit(0);
        case 'M': o_msg = optarg; break;
        case 'u': {
            char *end;
            long v = strtol(optarg ? optarg : "0", &end, 10);
            (void)end;
            o_update = (int)v;
            break;
        }
        case 'C':
            if (!parse_color(optarg, &color_optarg)) {
                colorerror();
                exit(0);
            }
            o_color = color_optarg;
            break;
        case 't':
            o_tty_fp = fopen(optarg, "r+");
            if (!o_tty_fp) {
                fprintf(stderr, "cmatrix: error: '%s' couldn't be opened: %s.\n",
                        optarg, strerror(errno));
                exit(1);
            }
            break;
        case '?':
        default:
            usage();
            exit(0);
        }
    }

    if (o_forcelinux) {
        setenv("TERM", "linux", 1);
    }

    if (o_tty_fp) {
        screen_handle = newterm(NULL, o_tty_fp, o_tty_fp);
        if (!screen_handle) {
            exit(1);
        }
        set_term(screen_handle);
    } else {
        /* initscr produces the "Error opening terminal: <TERM>." message on stderr
           and exits the process itself when TERM is unrecognized. */
        initscr();
    }

    if (has_colors()) {
        start_color();
        use_default_colors();
        init_pair(1, o_color,         -1);
        init_pair(2, COLOR_GREEN,     -1);
        init_pair(3, COLOR_RED,       -1);
        init_pair(4, COLOR_BLUE,      -1);
        init_pair(5, COLOR_WHITE,     -1);
        init_pair(6, COLOR_YELLOW,    -1);
        init_pair(7, COLOR_CYAN,      -1);
        init_pair(8, COLOR_MAGENTA,   -1);
    }

    cbreak();
    noecho();
    nonl();
    curs_set(0);
    leaveok(stdscr, TRUE);

    signal(SIGINT,  on_sigint);
    signal(SIGTERM, on_sigint);
    signal(SIGTSTP, on_sigtstp);
    signal(SIGCONT, on_sigcont);
    signal(SIGWINCH, on_sigwinch);

    srand((unsigned)time(NULL));

    run_loop();

    finish_cleanup(0);
    return 0;
}
