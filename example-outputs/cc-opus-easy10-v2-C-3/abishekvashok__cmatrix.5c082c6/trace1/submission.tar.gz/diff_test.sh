#!/bin/bash
# Run all goldens against our binary
PASS=0
FAIL=0
FAILS=()
cd /work/work/goldens
for d in */; do
  d="${d%/}"
  cmd_file="$d/cmd"
  [ -f "$cmd_file" ] || continue
  # Parse the cmd file to extract args
  env_line=$(head -1 "$cmd_file")
  args_line=$(tail -1 "$cmd_file")
  unset_term=$(echo "$env_line" | grep -oP 'unset_term=\K[01]')
  envs=$(echo "$env_line" | sed -E 's/^.*setvars=//')
  args=$(echo "$args_line" | sed -E 's/^Args: //')
  # Build env command
  if [ "$unset_term" = "1" ]; then
    env_pre="env -u TERM $envs"
  else
    env_pre="env $envs"
  fi
  out_actual=$(mktemp); err_actual=$(mktemp)
  # shellcheck disable=SC2086
  $env_pre timeout 2 /work/work/executable $args 1>"$out_actual" 2>"$err_actual"
  actual_exit=$?
  exp_out="$d/stdout"; exp_err="$d/stderr"; exp_exit=$(cat "$d/exitcode")
  ok=1
  if ! diff -q "$out_actual" "$exp_out" >/dev/null; then ok=0; fi
  if ! diff -q "$err_actual" "$exp_err" >/dev/null; then ok=0; fi
  if [ "$actual_exit" != "$exp_exit" ]; then ok=0; fi
  if [ "$ok" = "1" ]; then
    PASS=$((PASS+1))
  else
    FAIL=$((FAIL+1))
    FAILS+=("$d (exit exp=$exp_exit got=$actual_exit; out_diff=$([ -z "$(diff -q "$out_actual" "$exp_out")" ] && echo same || echo diff); err_diff=$([ -z "$(diff -q "$err_actual" "$exp_err")" ] && echo same || echo diff))")
  fi
  rm -f "$out_actual" "$err_actual"
done
echo "=== $PASS pass, $FAIL fail ==="
for f in "${FAILS[@]}"; do echo "FAIL: $f"; done
