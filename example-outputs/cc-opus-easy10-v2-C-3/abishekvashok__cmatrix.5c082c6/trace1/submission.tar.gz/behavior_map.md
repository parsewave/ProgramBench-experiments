# cmatrix behavior map

Reference: /workspace/executable (cmatrix v2.0).
Bundled docs: README.md, cmatrix.1.

## Getopt string
From `strings`: `abBcfhlLnrosmxkVM:u:C:t:`
- Bool flags: a b B c f h l L n r o s m x k V
- Required-arg: M u C t
- opterr appears to be 0 (no auto messages from getopt)

## Exit-path summary (priority-ordered, left-to-right in argv)

The implementation walks getopt left-to-right. Each "exit-on-encounter" branch
calls usage() / version() / colorerror() / fileerror() and exits before
further getopt processing.

| Trigger (first match wins)        | Action                                           | stdout | stderr | exit |
|-----------------------------------|--------------------------------------------------|--------|--------|------|
| `-h` / `-?` / unknown opt / `--bogus` / missing-required-arg | usage() | 972B   | 0      | 0    |
| `-V`                              | version()                                        | 131B   | 0      | 0    |
| `-C <invalid>` (incl. empty)      | colorerror()                                     | 0      | 101B   | 0    |
| `-t <path>` (fopen fails)         | fileerror()                                      | 0      | varies | 1    |
| Otherwise (-, --, valid flags…)   | proceeds to ncurses init                         | depends | depends | depends |

## Exact byte sequences

### usage() → stdout, 972 bytes, then exit(0)
```
 Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
```

### version() → stdout, 131 bytes, then exit(0)
Format string in binary: ` CMatrix version %s (compiled %s, %s)` where:
- arg1 = "2.0"
- arg2 = `__TIME__` = "19:59:42"
- arg3 = `__DATE__` = "Apr 17 2026"

Literal output:
```
 CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
```

### colorerror() → stderr, 101 bytes, then exit(0)
Triggered by -C with arg not in {green,red,blue,white,yellow,cyan,magenta,black} (case-insensitive).
```
 Invalid color selection
 Valid colors are green, red, blue, white, yellow, cyan, magenta and black.
```

### fileerror() → stderr, then exit(1)
Format: `cmatrix: error: '%s' couldn't be opened: %s.\n` where:
- %s1 = the path as given
- %s2 = strerror(errno) from fopen() failure

Examples:
- `-t /tmp/cmatrix_nope` → `cmatrix: error: '/tmp/cmatrix_nope' couldn't be opened: No such file or directory.\n`
- `-t /etc/hosts` → `cmatrix: error: '/etc/hosts' couldn't be opened: Permission denied.\n`

### ncurses-init failure path → stderr, exit(1)
When TERM is unset/invalid, ncurses' newterm() (or setupterm) prints to stderr:
```
Error opening terminal: unknown.
```
This is 33 bytes including trailing newline. ncurses itself emits it; cmatrix's `cmatrix.c` does `newterm(NULL, stdout, stdin)` and exits 1 on NULL return.

## Argparse precedence examples

| Argv             | Outcome                              |
|------------------|--------------------------------------|
| `-h -V`          | usage (h first)                      |
| `-V -h`          | version (V first)                    |
| `-hV`            | usage (h first in same word)         |
| `-Vh`            | version                              |
| `-C foo -V`      | invalid color (C foo first)          |
| `-V -C foo`      | version (V first)                    |
| `-C foo -h`      | invalid color (C foo first)          |
| `-h -C foo`      | usage (h first)                      |
| `-V foo`         | version (extra positional ignored)   |
| `foo` (positional only) | falls through to ncurses init |
| `-u`             | usage (missing arg → '?' handler)    |
| `-C`             | usage                                |
| `-t`             | usage                                |
| `-bogus`         | usage (each unknown char triggers '?')|
| `-`              | falls through                        |
| `--`             | falls through                        |

## -C color matching

Case-insensitive equality (strcasecmp) against:
- green, red, blue, white, yellow, cyan, magenta, black

Examples confirmed:
- `Green`, `GREEN`, `grEEn`, `RED`, `yelloW` → accepted (no color error)
- `gree`, `greenn`, `redx`, `blu`, `foo`, `purple`, "" → colorerror()

## Animation path (TTY mode)

When all early-exit branches are bypassed and ncurses init succeeds:
- Runs forever, drawing matrix-rain to the terminal.
- Reads keystrokes for interactive controls (q quits, etc.).
- Output bytes are randomized/animated; not byte-equal across runs.
- In `-s` (screensaver) mode, exits on first keystroke.
- In `-L` (lock) mode, ignores quit keys.

Reproduce structurally: ncurses-based main loop that runs until killed
(or until 'q' / first keystroke depending on mode). Match the bypass
conditions exactly, but byte-equality on the animation is not feasible.

## Stdout/stderr discipline

- usage() output goes to **stdout** (each line begins with a single space).
- version() output goes to **stdout** (first line has leading space).
- colorerror() output goes to **stderr** (each line begins with single space).
- fileerror() output goes to **stderr**.
- ncurses "Error opening terminal: unknown." goes to **stderr**.

## Compiled timestamp

Hardcode "19:59:42" and "Apr 17 2026" to match exactly (do not use __TIME__/__DATE__
in our build — we'd get a different timestamp).
