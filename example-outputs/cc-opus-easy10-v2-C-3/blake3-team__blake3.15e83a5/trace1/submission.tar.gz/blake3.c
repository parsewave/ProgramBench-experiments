#include "blake3.h"
#include <string.h>

#define CHUNK_START         (1u << 0)
#define CHUNK_END           (1u << 1)
#define PARENT              (1u << 2)
#define ROOT                (1u << 3)
#define KEYED_HASH          (1u << 4)
#define DERIVE_KEY_CONTEXT  (1u << 5)
#define DERIVE_KEY_MATERIAL (1u << 6)

static const uint32_t IV[8] = {
    0x6A09E667u, 0xBB67AE85u, 0x3C6EF372u, 0xA54FF53Au,
    0x510E527Fu, 0x9B05688Cu, 0x1F83D9ABu, 0x5BE0CD19u,
};

static const uint8_t MSG_PERMUTATION[16] = {
    2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8,
};

static inline uint32_t load32(const uint8_t *p) {
    return ((uint32_t)p[0])
         | ((uint32_t)p[1] << 8)
         | ((uint32_t)p[2] << 16)
         | ((uint32_t)p[3] << 24);
}

static inline void store32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

static inline uint32_t rotr32(uint32_t x, uint32_t n) {
    return (x >> n) | (x << ((32u - n) & 31));
}

static inline void g(uint32_t state[16], int a, int b, int c, int d, uint32_t mx, uint32_t my) {
    state[a] = state[a] + state[b] + mx;
    state[d] = rotr32(state[d] ^ state[a], 16);
    state[c] = state[c] + state[d];
    state[b] = rotr32(state[b] ^ state[c], 12);
    state[a] = state[a] + state[b] + my;
    state[d] = rotr32(state[d] ^ state[a], 8);
    state[c] = state[c] + state[d];
    state[b] = rotr32(state[b] ^ state[c], 7);
}

static inline void round_fn(uint32_t state[16], const uint32_t m[16]) {
    g(state, 0, 4, 8,  12, m[0],  m[1]);
    g(state, 1, 5, 9,  13, m[2],  m[3]);
    g(state, 2, 6, 10, 14, m[4],  m[5]);
    g(state, 3, 7, 11, 15, m[6],  m[7]);
    g(state, 0, 5, 10, 15, m[8],  m[9]);
    g(state, 1, 6, 11, 12, m[10], m[11]);
    g(state, 2, 7, 8,  13, m[12], m[13]);
    g(state, 3, 4, 9,  14, m[14], m[15]);
}

static inline void permute(uint32_t m[16]) {
    uint32_t tmp[16];
    for (int i = 0; i < 16; i++) tmp[i] = m[MSG_PERMUTATION[i]];
    memcpy(m, tmp, sizeof(tmp));
}

static void compress(
    uint32_t out_state[16],
    const uint32_t cv[8],
    const uint8_t block[BLAKE3_BLOCK_LEN],
    uint64_t counter,
    uint32_t block_len,
    uint32_t flags
) {
    uint32_t state[16];
    state[0] = cv[0];
    state[1] = cv[1];
    state[2] = cv[2];
    state[3] = cv[3];
    state[4] = cv[4];
    state[5] = cv[5];
    state[6] = cv[6];
    state[7] = cv[7];
    state[8]  = IV[0];
    state[9]  = IV[1];
    state[10] = IV[2];
    state[11] = IV[3];
    state[12] = (uint32_t)counter;
    state[13] = (uint32_t)(counter >> 32);
    state[14] = block_len;
    state[15] = flags;

    uint32_t m[16];
    for (int i = 0; i < 16; i++) m[i] = load32(block + 4 * i);

    round_fn(state, m); permute(m);
    round_fn(state, m); permute(m);
    round_fn(state, m); permute(m);
    round_fn(state, m); permute(m);
    round_fn(state, m); permute(m);
    round_fn(state, m); permute(m);
    round_fn(state, m);

    for (int i = 0; i < 8; i++) {
        state[i] ^= state[i + 8];
        state[i + 8] ^= cv[i];
    }
    memcpy(out_state, state, sizeof(state));
}

typedef struct {
    uint32_t input_chaining_value[8];
    uint8_t block[BLAKE3_BLOCK_LEN];
    uint32_t block_len;
    uint64_t counter;
    uint32_t flags;
} blake3_output;

static uint32_t chunk_state_start_flag(const blake3_chunk_state *cs) {
    return cs->blocks_compressed == 0 ? CHUNK_START : 0u;
}

static size_t chunk_state_len(const blake3_chunk_state *cs) {
    return (size_t)cs->blocks_compressed * BLAKE3_BLOCK_LEN + cs->block_len;
}

static void chunk_state_init(blake3_chunk_state *cs, const uint32_t key[8], uint64_t counter, uint32_t flags) {
    memcpy(cs->chaining_value, key, 32);
    cs->chunk_counter = counter;
    memset(cs->block, 0, BLAKE3_BLOCK_LEN);
    cs->block_len = 0;
    cs->blocks_compressed = 0;
    cs->flags = flags;
}

static void chunk_state_update(blake3_chunk_state *cs, const uint8_t *input, size_t len) {
    while (len > 0) {
        if (cs->block_len == BLAKE3_BLOCK_LEN) {
            uint32_t out[16];
            compress(out, cs->chaining_value, cs->block, cs->chunk_counter,
                     BLAKE3_BLOCK_LEN,
                     cs->flags | chunk_state_start_flag(cs));
            memcpy(cs->chaining_value, out, 32);
            cs->blocks_compressed++;
            memset(cs->block, 0, BLAKE3_BLOCK_LEN);
            cs->block_len = 0;
        }
        size_t want = BLAKE3_BLOCK_LEN - cs->block_len;
        if (want > len) want = len;
        memcpy(cs->block + cs->block_len, input, want);
        cs->block_len += (uint8_t)want;
        input += want;
        len -= want;
    }
}

static void chunk_state_output(const blake3_chunk_state *cs, blake3_output *out) {
    memcpy(out->input_chaining_value, cs->chaining_value, 32);
    memcpy(out->block, cs->block, BLAKE3_BLOCK_LEN);
    out->block_len = cs->block_len;
    out->counter = cs->chunk_counter;
    out->flags = cs->flags | chunk_state_start_flag(cs) | CHUNK_END;
}

static void parent_output(blake3_output *out,
                          const uint32_t left_cv[8],
                          const uint32_t right_cv[8],
                          const uint32_t key[8],
                          uint32_t flags) {
    memcpy(out->input_chaining_value, key, 32);
    for (int i = 0; i < 8; i++) store32(out->block + 4 * i, left_cv[i]);
    for (int i = 0; i < 8; i++) store32(out->block + 32 + 4 * i, right_cv[i]);
    out->block_len = BLAKE3_BLOCK_LEN;
    out->counter = 0;
    out->flags = flags | PARENT;
}

static void output_chaining_value(const blake3_output *o, uint32_t cv[8]) {
    uint32_t result[16];
    compress(result, o->input_chaining_value, o->block, o->counter, o->block_len, o->flags);
    for (int i = 0; i < 8; i++) cv[i] = result[i];
}

static void output_root_bytes(const blake3_output *o, uint64_t seek, uint8_t *out, size_t out_len) {
    uint64_t block_counter = seek / BLAKE3_BLOCK_LEN;
    size_t offset = (size_t)(seek % BLAKE3_BLOCK_LEN);
    while (out_len > 0) {
        uint32_t result[16];
        compress(result, o->input_chaining_value, o->block, block_counter, o->block_len, o->flags | ROOT);
        uint8_t bytes[BLAKE3_BLOCK_LEN];
        for (int i = 0; i < 16; i++) store32(bytes + 4 * i, result[i]);
        size_t available = BLAKE3_BLOCK_LEN - offset;
        size_t take = available < out_len ? available : out_len;
        memcpy(out, bytes + offset, take);
        out += take;
        out_len -= take;
        offset = 0;
        block_counter++;
    }
}

static void hasher_init_internal(blake3_hasher *h, const uint32_t key[8], uint32_t flags) {
    chunk_state_init(&h->chunk_state, key, 0, flags);
    memcpy(h->key, key, 32);
    h->cv_stack_len = 0;
    h->flags = flags;
}

void blake3_hasher_init(blake3_hasher *h) {
    hasher_init_internal(h, IV, 0u);
}

void blake3_hasher_init_keyed(blake3_hasher *h, const uint8_t key[BLAKE3_KEY_LEN]) {
    uint32_t key_words[8];
    for (int i = 0; i < 8; i++) key_words[i] = load32(key + 4 * i);
    hasher_init_internal(h, key_words, KEYED_HASH);
}

void blake3_hasher_init_derive_key_raw(blake3_hasher *h, const void *context, size_t context_len) {
    blake3_hasher ctx_hasher;
    hasher_init_internal(&ctx_hasher, IV, DERIVE_KEY_CONTEXT);
    blake3_hasher_update(&ctx_hasher, context, context_len);
    uint8_t context_key[BLAKE3_KEY_LEN];
    blake3_hasher_finalize(&ctx_hasher, context_key, BLAKE3_KEY_LEN);

    uint32_t key_words[8];
    for (int i = 0; i < 8; i++) key_words[i] = load32(context_key + 4 * i);
    hasher_init_internal(h, key_words, DERIVE_KEY_MATERIAL);
}

void blake3_hasher_init_derive_key(blake3_hasher *h, const char *context) {
    blake3_hasher_init_derive_key_raw(h, context, strlen(context));
}

static void push_chunk_cv(blake3_hasher *h, const uint32_t new_cv[8], uint64_t total_chunks_after) {
    uint32_t cv[8];
    memcpy(cv, new_cv, 32);
    uint64_t t = total_chunks_after;
    while ((t & 1u) == 0u) {
        uint32_t parent_cv[8];
        blake3_output po;
        parent_output(&po, &h->cv_stack[(h->cv_stack_len - 1) * 8], cv, h->key, h->flags);
        output_chaining_value(&po, parent_cv);
        memcpy(cv, parent_cv, 32);
        h->cv_stack_len--;
        t >>= 1;
    }
    memcpy(&h->cv_stack[h->cv_stack_len * 8], cv, 32);
    h->cv_stack_len++;
}

void blake3_hasher_update(blake3_hasher *h, const void *input_void, size_t len) {
    const uint8_t *input = (const uint8_t *)input_void;
    while (len > 0) {
        if (chunk_state_len(&h->chunk_state) == BLAKE3_CHUNK_LEN) {
            blake3_output o;
            chunk_state_output(&h->chunk_state, &o);
            uint32_t chunk_cv[8];
            output_chaining_value(&o, chunk_cv);
            uint64_t total = h->chunk_state.chunk_counter + 1;
            push_chunk_cv(h, chunk_cv, total);
            chunk_state_init(&h->chunk_state, h->key, total, h->flags);
        }
        size_t want = BLAKE3_CHUNK_LEN - chunk_state_len(&h->chunk_state);
        if (want > len) want = len;
        chunk_state_update(&h->chunk_state, input, want);
        input += want;
        len -= want;
    }
}

void blake3_hasher_finalize_seek(const blake3_hasher *h, uint64_t seek, uint8_t *out, size_t out_len) {
    if (out_len == 0) return;

    blake3_output o;
    chunk_state_output(&h->chunk_state, &o);

    if (h->cv_stack_len == 0) {
        output_root_bytes(&o, seek, out, out_len);
        return;
    }

    uint32_t current_cv[8];
    output_chaining_value(&o, current_cv);

    int idx = (int)h->cv_stack_len - 1;
    while (idx > 0) {
        blake3_output po;
        parent_output(&po, &h->cv_stack[idx * 8], current_cv, h->key, h->flags);
        output_chaining_value(&po, current_cv);
        idx--;
    }
    blake3_output root;
    parent_output(&root, &h->cv_stack[0], current_cv, h->key, h->flags);
    output_root_bytes(&root, seek, out, out_len);
}

void blake3_hasher_finalize(const blake3_hasher *h, uint8_t *out, size_t out_len) {
    blake3_hasher_finalize_seek(h, 0, out, out_len);
}
