#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <ctype.h>
#include "blake3.h"

#define READ_BUF 65536

typedef struct {
    bool keyed;
    bool derive_key;
    char *derive_key_value;
    bool length_set;
    uint64_t length;
    bool seek_set;
    uint64_t seek;
    bool num_threads_set;
    int64_t num_threads;
    bool no_mmap;
    bool no_names;
    bool raw;
    bool tag;
    bool check;
    bool quiet;
    char **files;
    int num_files;
} options_t;

static const char *USAGE_DEFAULT = "Usage: executable [OPTIONS] [FILE]...";

static const char *HELP_SHORT =
"Usage: executable [OPTIONS] [FILE]...\n"
"\n"
"Arguments:\n"
"  [FILE]...  Files to hash, or checkfiles to check\n"
"\n"
"Options:\n"
"      --keyed                 Use the keyed mode, reading the 32-byte key from stdin\n"
"      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string\n"
"  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]\n"
"      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]\n"
"      --num-threads <NUM>     The maximum number of threads to use\n"
"      --no-mmap               Disable memory mapping\n"
"      --no-names              Omit filenames in the output\n"
"      --raw                   Write raw output bytes to stdout, rather than hex\n"
"      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n"
"  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them\n"
"      --quiet                 Skip printing OK for each checked file\n"
"  -h, --help                  Print help (see more with '--help')\n"
"  -V, --version               Print version\n";

static const char *HELP_LONG =
"Usage: executable [OPTIONS] [FILE]...\n"
"\n"
"Arguments:\n"
"  [FILE]...\n"
"          Files to hash, or checkfiles to check\n"
"          \n"
"          When no file is given, or when - is given, read standard input.\n"
"\n"
"Options:\n"
"      --keyed\n"
"          Use the keyed mode, reading the 32-byte key from stdin\n"
"\n"
"      --derive-key <CONTEXT>\n"
"          Use the key derivation mode, with the given context string\n"
"          \n"
"          Cannot be used with --keyed.\n"
"\n"
"  -l, --length <LEN>\n"
"          The number of output bytes, before hex encoding\n"
"          \n"
"          [default: 32]\n"
"\n"
"      --seek <SEEK>\n"
"          The starting output byte offset, before hex encoding\n"
"          \n"
"          [default: 0]\n"
"\n"
"      --num-threads <NUM>\n"
"          The maximum number of threads to use\n"
"          \n"
"          By default, this is the number of logical cores. If this flag is omitted, or if its value\n"
"          is 0, RAYON_NUM_THREADS is also respected.\n"
"\n"
"      --no-mmap\n"
"          Disable memory mapping\n"
"          \n"
"          Currently this also disables multithreading.\n"
"\n"
"      --no-names\n"
"          Omit filenames in the output\n"
"\n"
"      --raw\n"
"          Write raw output bytes to stdout, rather than hex\n"
"          \n"
"          --no-names is implied. In this case, only a single input is allowed.\n"
"\n"
"      --tag\n"
"          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n"
"\n"
"  -c, --check\n"
"          Read BLAKE3 sums from the [FILE]s and check them\n"
"\n"
"      --quiet\n"
"          Skip printing OK for each checked file\n"
"          \n"
"          Must be used with --check.\n"
"\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n"
"\n"
"  -V, --version\n"
"          Print version\n";

static const char *VERSION_STR = "b3sum 1.8.4\n";

static void clap_print_for_more(FILE *f) {
    fputs("\nFor more information, try '--help'.\n", f);
}

static void clap_print_usage(FILE *f, const char *usage_body) {
    fputs("Usage: executable ", f);
    fputs(usage_body, f);
    fputc('\n', f);
}

static void error_unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n", arg);
    fprintf(stderr, "\n  tip: to pass '%s' as a value, use '-- %s'\n", arg, arg);
    fputc('\n', stderr);
    clap_print_usage(stderr, "[OPTIONS] [FILE]...");
    clap_print_for_more(stderr);
    exit(2);
}

static void error_invalid_value(const char *value, const char *flag_long, const char *reason) {
    fprintf(stderr, "error: invalid value '%s' for '%s': %s\n", value, flag_long, reason);
    clap_print_for_more(stderr);
    exit(2);
}

static void error_requires_value(const char *flag_long) {
    fprintf(stderr, "error: a value is required for '%s' but none was supplied\n", flag_long);
    clap_print_for_more(stderr);
    exit(2);
}

static void error_multiple(const char *flag_long) {
    fprintf(stderr, "error: the argument '%s' cannot be used multiple times\n", flag_long);
    fputc('\n', stderr);
    clap_print_usage(stderr, "[OPTIONS] [FILE]...");
    clap_print_for_more(stderr);
    exit(2);
}

static void error_conflict(const char *a, const char *b, const char *usage_body) {
    fprintf(stderr, "error: the argument '%s' cannot be used with '%s'\n", a, b);
    fputc('\n', stderr);
    clap_print_usage(stderr, usage_body);
    clap_print_for_more(stderr);
    exit(2);
}

static void error_required(const char *required_flag, const char *usage_body) {
    fprintf(stderr, "error: the following required arguments were not provided:\n");
    fprintf(stderr, "  %s\n", required_flag);
    fputc('\n', stderr);
    clap_print_usage(stderr, usage_body);
    clap_print_for_more(stderr);
    exit(2);
}

static bool parse_u64(const char *s, uint64_t *out, const char **err_reason) {
    if (!s || !*s) { *err_reason = "cannot parse integer from empty string"; return false; }
    const char *p = s;
    uint64_t v = 0;
    if (*p == '+') { *err_reason = "invalid digit found in string"; return false; }
    if (*p == '-') { *err_reason = "invalid digit found in string"; return false; }
    if (!isdigit((unsigned char)*p)) { *err_reason = "invalid digit found in string"; return false; }
    while (*p) {
        if (!isdigit((unsigned char)*p)) {
            *err_reason = "invalid digit found in string";
            return false;
        }
        uint64_t d = (uint64_t)(*p - '0');
        if (v > (UINT64_MAX - d) / 10) {
            *err_reason = "number too large to fit in target type";
            return false;
        }
        v = v * 10 + d;
        p++;
    }
    *out = v;
    return true;
}

static bool parse_i64(const char *s, int64_t *out, const char **err_reason) {
    if (!s || !*s) { *err_reason = "cannot parse integer from empty string"; return false; }
    bool neg = false;
    const char *p = s;
    if (*p == '+') p++;
    if (!isdigit((unsigned char)*p)) { *err_reason = "invalid digit found in string"; return false; }
    uint64_t v = 0;
    while (*p) {
        if (!isdigit((unsigned char)*p)) {
            *err_reason = "invalid digit found in string";
            return false;
        }
        uint64_t d = (uint64_t)(*p - '0');
        if (v > (UINT64_MAX - d) / 10) {
            *err_reason = "number too large to fit in target type";
            return false;
        }
        v = v * 10 + d;
        p++;
    }
    if (neg) {
        if (v > (uint64_t)INT64_MAX + 1) { *err_reason = "number too small to fit in target type"; return false; }
        *out = -(int64_t)v;
    } else {
        if (v > (uint64_t)INT64_MAX) { *err_reason = "number too large to fit in target type"; return false; }
        *out = (int64_t)v;
    }
    return true;
}

// Hash a file (with file_path used for error messages; if file_path is "-", read from stdin)
// hasher must be initialized
// On success returns 0
static int hash_file_to(blake3_hasher *h, const char *path, bool no_mmap, FILE **inout_stdin) {
    if (strcmp(path, "-") == 0) {
        FILE *in = inout_stdin ? *inout_stdin : stdin;
        uint8_t buf[READ_BUF];
        size_t n;
        while ((n = fread(buf, 1, sizeof(buf), in)) > 0) {
            blake3_hasher_update(h, buf, n);
        }
        if (ferror(in)) return -1;
        return 0;
    }

    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    struct stat st;
    if (fstat(fd, &st) < 0) { int e = errno; close(fd); errno = e; return -1; }
    if (S_ISDIR(st.st_mode)) { close(fd); errno = EISDIR; return -1; }

    // Try mmap if regular file
    if (!no_mmap && S_ISREG(st.st_mode) && st.st_size > 0) {
        void *addr = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
        if (addr != MAP_FAILED) {
            blake3_hasher_update(h, addr, (size_t)st.st_size);
            munmap(addr, (size_t)st.st_size);
            close(fd);
            return 0;
        }
    }

    uint8_t buf[READ_BUF];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        blake3_hasher_update(h, buf, (size_t)n);
    }
    if (n < 0) { int e = errno; close(fd); errno = e; return -1; }
    close(fd);
    return 0;
}

// Print hex
static void print_hex(FILE *f, const uint8_t *bytes, size_t len) {
    static const char hex[] = "0123456789abcdef";
    for (size_t i = 0; i < len; i++) {
        fputc(hex[bytes[i] >> 4], f);
        fputc(hex[bytes[i] & 0xF], f);
    }
}

// Detect if filename needs escaping (contains \ or \n)
static bool needs_escaping(const char *s) {
    for (; *s; s++) {
        if (*s == '\\' || *s == '\n') return true;
    }
    return false;
}

// Print escaped filename (\ -> \\, \n -> \n)
static void print_escaped(FILE *f, const char *s) {
    for (; *s; s++) {
        if (*s == '\\') { fputc('\\', f); fputc('\\', f); }
        else if (*s == '\n') { fputc('\\', f); fputc('n', f); }
        else fputc((unsigned char)*s, f);
    }
}

// Print one hash line, applying escape rules
static void print_hash_line(const uint8_t *hash, size_t hash_len, const char *path,
                            bool no_names, bool tag) {
    bool esc = !no_names && needs_escaping(path);
    if (esc) fputc('\\', stdout);
    if (tag) {
        if (no_names) {
            // unusual: --tag --no-names just emits hex hash
            print_hex(stdout, hash, hash_len);
        } else {
            fputs("BLAKE3 (", stdout);
            print_escaped(stdout, path);
            fputs(") = ", stdout);
            print_hex(stdout, hash, hash_len);
        }
    } else {
        print_hex(stdout, hash, hash_len);
        if (!no_names) {
            fputs("  ", stdout);
            print_escaped(stdout, path);
        }
    }
    fputc('\n', stdout);
}

// Read all stdin (up to max_len + 1 bytes to detect overflow)
static ssize_t read_all_stdin(uint8_t *buf, size_t max_len_plus_1) {
    size_t total = 0;
    while (total < max_len_plus_1) {
        ssize_t n = read(0, buf + total, max_len_plus_1 - total);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) break;
        total += (size_t)n;
    }
    return (ssize_t)total;
}

// Initialize a hasher based on options. Reads stdin for --keyed.
// Returns 0 on success, nonzero on failure (with error already printed).
static int init_hasher(blake3_hasher *h, const options_t *opts) {
    if (opts->keyed) {
        uint8_t key[33];
        ssize_t n = read_all_stdin(key, 33);
        if (n < 0) {
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
            return -1;
        }
        if (n < 32) {
            fprintf(stderr, "Error: expected 32 key bytes from stdin, found %zd\n", n);
            return -1;
        }
        if (n > 32) {
            fprintf(stderr, "Error: read more than 32 key bytes from stdin\n");
            return -1;
        }
        blake3_hasher_init_keyed(h, key);
    } else if (opts->derive_key) {
        blake3_hasher_init_derive_key(h, opts->derive_key_value);
    } else {
        blake3_hasher_init(h);
    }
    return 0;
}

// Compute hash of one input. Initializes a fresh hasher.
// Output goes to 'out' buffer (must be at least length bytes).
// Returns 0 on success, -1 on error (with errno set if file error).
static int compute_hash(const options_t *opts, const blake3_hasher *base_h,
                       const char *path, uint8_t *out, size_t len, bool no_mmap) {
    blake3_hasher h = *base_h;
    int rc = hash_file_to(&h, path, no_mmap, NULL);
    if (rc < 0) return rc;
    blake3_hasher_finalize_seek(&h, opts->seek, out, len);
    return 0;
}

// Output a single file's hash
// Returns 0 on success, 1 on error (file open, etc.)
static int output_one_hash(const options_t *opts, const blake3_hasher *base_h, const char *path) {
    if (opts->keyed && strcmp(path, "-") == 0) {
        fprintf(stderr, "b3sum: -: Cannot open `-` in keyed mode\n");
        return 1;
    }
    size_t len = opts->length_set ? (size_t)opts->length : 32;
    uint8_t *out = (uint8_t *)malloc(len > 0 ? len : 1);
    if (!out) {
        fprintf(stderr, "b3sum: allocation failed\n");
        return 1;
    }
    int rc = compute_hash(opts, base_h, path, out, len, opts->no_mmap);
    if (rc < 0) {
        fprintf(stderr, "b3sum: %s: %s (os error %d)\n", path, strerror(errno), errno);
        free(out);
        return 1;
    }
    if (opts->raw) {
        fwrite(out, 1, len, stdout);
    } else {
        print_hash_line(out, len, path, opts->no_names, opts->tag);
    }
    free(out);
    return 0;
}

// Strip trailing \r and \n. Returns new length (0-terminated).
static size_t strip_eol(char *s, size_t len) {
    while (len > 0 && (s[len - 1] == '\n' || s[len - 1] == '\r')) len--;
    s[len] = '\0';
    return len;
}

// Parse a hash line. *out_filename is filled (must be freed) if successful.
// Returns:
//  0 on success
//  1 on "Empty line"
//  2 on "Invalid check line format"
//  3 on "Invalid hash length"
//  4 on "Invalid hex"
//  5 on "Invalid backslash escape"
//  6 on "empty file path"
static int parse_check_line(const char *line, uint8_t *hash_out, char **out_filename) {
    if (*line == '\0') return 1;

    // Detect BSD-style "BLAKE3 (FILENAME) = HASH"
    const char *bsd_prefix = "BLAKE3 (";
    if (strncmp(line, bsd_prefix, strlen(bsd_prefix)) == 0) {
        const char *name_start = line + strlen(bsd_prefix);
        const char *sep = strstr(name_start, ") = ");
        if (!sep) return 2;
        // Check there's exactly ") = " then the hash
        // Filename is name_start..sep
        size_t name_len = (size_t)(sep - name_start);
        const char *hash_start = sep + 4;
        size_t hash_len = strlen(hash_start);
        if (hash_len != 64) return 3;
        for (size_t i = 0; i < 64; i++) {
            char c = hash_start[i];
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return 4;
        }
        if (name_len == 0) return 6;
        char *fn = (char *)malloc(name_len + 1);
        if (!fn) return -1;
        memcpy(fn, name_start, name_len);
        fn[name_len] = '\0';
        for (int i = 0; i < 32; i++) {
            uint32_t hi = (hash_start[2*i] <= '9') ? (hash_start[2*i] - '0') : (hash_start[2*i] - 'a' + 10);
            uint32_t lo = (hash_start[2*i+1] <= '9') ? (hash_start[2*i+1] - '0') : (hash_start[2*i+1] - 'a' + 10);
            hash_out[i] = (uint8_t)((hi << 4) | lo);
        }
        *out_filename = fn;
        return 0;
    }

    // Check for leading backslash (escape mode)
    bool escaped = false;
    if (*line == '\\') {
        escaped = true;
        line++;
        // After leading \, check if it's a BSD-style or sums-style
        if (strncmp(line, "BLAKE3 (", 8) == 0) {
            // Recurse-like: parse as BSD with unescape
            const char *name_start = line + 8;
            const char *sep = strstr(name_start, ") = ");
            if (!sep) return 2;
            size_t enc_name_len = (size_t)(sep - name_start);
            const char *hash_start = sep + 4;
            size_t hash_len = strlen(hash_start);
            if (hash_len != 64) return 3;
            for (size_t i = 0; i < 64; i++) {
                char c = hash_start[i];
                if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return 4;
            }
            // Unescape filename
            char *fn = (char *)malloc(enc_name_len + 1);
            if (!fn) return -1;
            size_t fi = 0;
            for (size_t i = 0; i < enc_name_len; i++) {
                if (name_start[i] == '\\') {
                    if (i + 1 >= enc_name_len) { free(fn); return 5; }
                    char next = name_start[i + 1];
                    if (next == '\\') { fn[fi++] = '\\'; i++; }
                    else if (next == 'n') { fn[fi++] = '\n'; i++; }
                    else { free(fn); return 5; }
                } else {
                    fn[fi++] = name_start[i];
                }
            }
            fn[fi] = '\0';
            if (fi == 0) return 6;
            for (int i = 0; i < 32; i++) {
                uint32_t hi = (hash_start[2*i] <= '9') ? (hash_start[2*i] - '0') : (hash_start[2*i] - 'a' + 10);
                uint32_t lo = (hash_start[2*i+1] <= '9') ? (hash_start[2*i+1] - '0') : (hash_start[2*i+1] - 'a' + 10);
                hash_out[i] = (uint8_t)((hi << 4) | lo);
            }
            *out_filename = fn;
            return 0;
        }
    }

    // Standard format: HASH<2-spaces>FILENAME
    const char *sep = strstr(line, "  ");
    if (!sep) return 2;
    size_t hash_len = (size_t)(sep - line);
    if (hash_len % 2 != 0 || hash_len != 64) return 3;
    for (size_t i = 0; i < hash_len; i++) {
        char c = line[i];
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return 4;
    }
    const char *fn_start = sep + 2;
    size_t fn_len = strlen(fn_start);

    if (escaped) {
        // Unescape: \\ -> \, \n -> \n
        char *fn = (char *)malloc(fn_len + 1);
        if (!fn) return -1;
        size_t fi = 0;
        for (size_t i = 0; i < fn_len; i++) {
            if (fn_start[i] == '\\') {
                if (i + 1 >= fn_len) { free(fn); return 5; }
                char next = fn_start[i + 1];
                if (next == '\\') { fn[fi++] = '\\'; i++; }
                else if (next == 'n') { fn[fi++] = '\n'; i++; }
                else { free(fn); return 5; }
            } else {
                fn[fi++] = fn_start[i];
            }
        }
        fn[fi] = '\0';
        if (fi == 0) return 6;
        for (int i = 0; i < 32; i++) {
            uint32_t hi = (line[2*i] <= '9') ? (line[2*i] - '0') : (line[2*i] - 'a' + 10);
            uint32_t lo = (line[2*i+1] <= '9') ? (line[2*i+1] - '0') : (line[2*i+1] - 'a' + 10);
            hash_out[i] = (uint8_t)((hi << 4) | lo);
        }
        *out_filename = fn;
        return 0;
    }

    char *fn = strdup(fn_start);
    if (!fn) return -1;
    if (fn_len == 0) return 6;
    for (int i = 0; i < 32; i++) {
        uint32_t hi = (line[2*i] <= '9') ? (line[2*i] - '0') : (line[2*i] - 'a' + 10);
        uint32_t lo = (line[2*i+1] <= '9') ? (line[2*i+1] - '0') : (line[2*i+1] - 'a' + 10);
        hash_out[i] = (uint8_t)((hi << 4) | lo);
    }
    *out_filename = fn;
    return 0;
}

// Print the filename for check output, preserving the escape syntax from the input.
// If the line had a leading '\', we keep the original escaped filename; otherwise plain.
static void print_check_filename_from_line(FILE *f, const char *line) {
    // Try to extract the filename token from the original (unmodified, EOL-stripped) line.
    // We're called only AFTER successful parse, so the formats are known.
    if (strncmp(line, "BLAKE3 (", 8) == 0) {
        const char *name_start = line + 8;
        const char *sep = strstr(name_start, ") = ");
        size_t name_len = (size_t)(sep - name_start);
        fwrite(name_start, 1, name_len, f);
        return;
    }
    if (line[0] == '\\') {
        // Print original \-prefixed line's filename (everything after hash+2sp)
        if (strncmp(line + 1, "BLAKE3 (", 8) == 0) {
            const char *name_start = line + 1 + 8;
            const char *sep = strstr(name_start, ") = ");
            size_t name_len = (size_t)(sep - name_start);
            // Output with leading \ to preserve escape format
            fputc('\\', f);
            fwrite(name_start, 1, name_len, f);
            return;
        }
        // Standard format with \ prefix
        const char *sep = strstr(line + 1, "  ");
        const char *fn = sep + 2;
        fputc('\\', f);
        fputs(fn, f);
        return;
    }
    // Standard format without \ prefix
    const char *sep = strstr(line, "  ");
    fputs(sep + 2, f);
}

typedef struct {
    int total_failed;
    int io_error;
} check_summary_t;

// Process a single checkfile (path or "-" for stdin). Returns count of failures.
static int process_checkfile(const options_t *opts, FILE *cf, check_summary_t *sum) {
    char *line = NULL;
    size_t line_cap = 0;
    ssize_t nread;
    while ((nread = getline(&line, &line_cap, cf)) != -1) {
        size_t len = (size_t)nread;
        len = strip_eol(line, len);
        // Save original line content before parsing
        char *orig_line = strdup(line);
        if (!orig_line) {
            fprintf(stderr, "b3sum: out of memory\n");
            sum->total_failed++;
            continue;
        }
        uint8_t expected[32];
        char *filename = NULL;
        int prc = parse_check_line(line, expected, &filename);
        if (prc != 0) {
            const char *msg = "Invalid check line format";
            switch (prc) {
                case 1: msg = "Empty line"; break;
                case 2: msg = "Invalid check line format"; break;
                case 3: msg = "Invalid hash length"; break;
                case 4: msg = "Invalid hex"; break;
                case 5: msg = "Invalid backslash escape"; break;
                case 6: msg = "empty file path"; break;
                default: msg = "Invalid check line format"; break;
            }
            fprintf(stderr, "b3sum: %s\n", msg);
            sum->total_failed++;
            free(orig_line);
            if (filename) free(filename);
            continue;
        }

        // Compute hash of filename (or stdin)
        blake3_hasher h;
        blake3_hasher_init(&h);
        int rc = hash_file_to(&h, filename, opts->no_mmap, NULL);
        if (rc < 0) {
            // FAILED with error reason
            int saved_errno = errno;
            print_check_filename_from_line(stdout, orig_line);
            fprintf(stdout, ": FAILED (%s (os error %d))\n", strerror(saved_errno), saved_errno);
            sum->total_failed++;
        } else {
            uint8_t actual[32];
            blake3_hasher_finalize(&h, actual, 32);
            if (memcmp(actual, expected, 32) == 0) {
                if (!opts->quiet) {
                    print_check_filename_from_line(stdout, orig_line);
                    fputs(": OK\n", stdout);
                }
            } else {
                print_check_filename_from_line(stdout, orig_line);
                fputs(": FAILED\n", stdout);
                sum->total_failed++;
            }
        }
        free(orig_line);
        free(filename);
    }
    free(line);
    return 0;
}

static int run_check(const options_t *opts) {
    check_summary_t sum = {0, 0};
    bool any_file = (opts->num_files > 0);
    if (!any_file) {
        process_checkfile(opts, stdin, &sum);
    } else {
        for (int i = 0; i < opts->num_files; i++) {
            const char *path = opts->files[i];
            FILE *cf;
            if (strcmp(path, "-") == 0) {
                cf = stdin;
            } else {
                cf = fopen(path, "rb");
                if (!cf) {
                    fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
                    return 1;
                }
            }
            process_checkfile(opts, cf, &sum);
            if (cf != stdin) fclose(cf);
        }
    }
    if (sum.total_failed > 0) {
        fprintf(stderr, "b3sum: WARNING: %d computed checksum%s did NOT match\n",
                sum.total_failed, sum.total_failed == 1 ? "" : "s");
        return 1;
    }
    return 0;
}

typedef enum {
    FLAG_KEYED = 0,
    FLAG_DERIVE,
    FLAG_LENGTH,
    FLAG_SEEK,
    FLAG_NUM_THREADS,
    FLAG_NO_MMAP,
    FLAG_NO_NAMES,
    FLAG_RAW,
    FLAG_TAG,
    FLAG_CHECK,
    FLAG_QUIET,
    FLAG_COUNT,
} flag_id_t;

static const char *FLAG_DISP[FLAG_COUNT] = {
    "--keyed",
    "--derive-key <CONTEXT>",
    "--length <LEN>",
    "--seek <SEEK>",
    "--num-threads <NUM>",
    "--no-mmap",
    "--no-names",
    "--raw",
    "--tag",
    "--check",
    "--quiet",
};

static bool flag_conflicts(flag_id_t a, flag_id_t b) {
    if (a == b) return false;
    // --keyed vs --derive-key
    if ((a == FLAG_KEYED && b == FLAG_DERIVE) || (a == FLAG_DERIVE && b == FLAG_KEYED)) return true;
    // --check conflicts with several
    flag_id_t check_conflicts[] = { FLAG_KEYED, FLAG_DERIVE, FLAG_LENGTH, FLAG_NO_NAMES, FLAG_RAW, FLAG_TAG };
    if (a == FLAG_CHECK) {
        for (int i = 0; i < 6; i++) if (b == check_conflicts[i]) return true;
    }
    if (b == FLAG_CHECK) {
        for (int i = 0; i < 6; i++) if (a == check_conflicts[i]) return true;
    }
    return false;
}

static void emit_conflict_error(flag_id_t A, const flag_id_t *Ys, int n_ys, const flag_id_t *Us, int n_us) {
    if (n_ys == 1) {
        fprintf(stderr, "error: the argument '%s' cannot be used with '%s'\n", FLAG_DISP[A], FLAG_DISP[Ys[0]]);
    } else {
        fprintf(stderr, "error: the argument '%s' cannot be used with:\n", FLAG_DISP[A]);
        for (int i = 0; i < n_ys; i++) {
            fprintf(stderr, "  %s\n", FLAG_DISP[Ys[i]]);
        }
    }
    fputc('\n', stderr);
    fputs("Usage: executable ", stderr);
    fputs(FLAG_DISP[A], stderr);
    for (int i = 0; i < n_us; i++) {
        fputc(' ', stderr);
        fputs(FLAG_DISP[Us[i]], stderr);
    }
    fputs(" <FILE>...\n", stderr);
    clap_print_for_more(stderr);
    exit(2);
}

int main(int argc, char **argv) {
    // Make stdout line-buffered so it interleaves predictably with stderr (matching Rust behavior)
    setvbuf(stdout, NULL, _IOLBF, 0);
    options_t opts = {0};

    char **files = (char **)malloc(sizeof(char *) * (size_t)(argc + 1));
    if (!files) return 1;
    opts.files = files;

    bool double_dash = false;

    // Track which flags were set, for conflict detection
    const char *first_flag_keyed = NULL;
    const char *first_flag_derive = NULL;
    const char *first_flag_length = NULL;
    const char *first_flag_seek = NULL;
    const char *first_flag_num_threads = NULL;
    const char *first_flag_no_mmap = NULL;
    const char *first_flag_no_names = NULL;
    const char *first_flag_raw = NULL;
    const char *first_flag_tag = NULL;
    const char *first_flag_check = NULL;
    const char *first_flag_quiet = NULL;

    flag_id_t flag_order[64];
    int n_flag_order = 0;
    bool flag_set[FLAG_COUNT] = {0};

    int i = 1;
    while (i < argc) {
        char *a = argv[i];
        if (double_dash) {
            opts.files[opts.num_files++] = a;
            i++;
            continue;
        }
        if (strcmp(a, "--") == 0) {
            double_dash = true;
            i++;
            continue;
        }
        if (a[0] != '-' || a[1] == '\0') {
            // positional (also "-" for stdin)
            opts.files[opts.num_files++] = a;
            i++;
            continue;
        }

        // It's a flag
        if (strcmp(a, "--help") == 0) {
            fputs(HELP_LONG, stdout);
            return 0;
        }
        if (strcmp(a, "--version") == 0) {
            fputs(VERSION_STR, stdout);
            return 0;
        }

        // Short flag combinations: -ABC... where each char is a short flag.
        // `l` takes a value (rest of arg, or next arg).
        // `h`, `V` exit immediately.
        // `c` is bool.
        if (a[0] == '-' && a[1] != '-' && a[1] != '\0') {
            int j = 1;
            bool consumed_arg = false;
            while (a[j] != '\0') {
                char c = a[j];
                if (c == 'h') {
                    fputs(HELP_SHORT, stdout);
                    return 0;
                }
                if (c == 'V') {
                    fputs(VERSION_STR, stdout);
                    return 0;
                }
                if (c == 'c') {
                    if (first_flag_check) error_multiple("--check");
                    first_flag_check = "--check";
                    opts.check = true;
                    if (!flag_set[FLAG_CHECK]) { flag_set[FLAG_CHECK] = true; flag_order[n_flag_order++] = FLAG_CHECK; }
                    j++;
                    continue;
                }
                if (c == 'l') {
                    if (first_flag_length) error_multiple("--length <LEN>");
                    const char *val;
                    if (a[j+1] == '\0') {
                        // Take next argv
                        if (i + 1 >= argc) error_requires_value("--length <LEN>");
                        val = argv[i + 1];
                        if (val[0] == '-' && val[1] != '\0') {
                            error_unexpected(val);
                        }
                        i++; // consume next arg
                        consumed_arg = true;
                    } else if (a[j+1] == '=') {
                        val = a + j + 2;
                    } else {
                        val = a + j + 1;
                    }
                    const char *err;
                    uint64_t v;
                    if (!parse_u64(val, &v, &err)) {
                        error_invalid_value(val, "--length <LEN>", err);
                    }
                    opts.length_set = true;
                    opts.length = v;
                    first_flag_length = "--length <LEN>";
                    if (!flag_set[FLAG_LENGTH]) { flag_set[FLAG_LENGTH] = true; flag_order[n_flag_order++] = FLAG_LENGTH; }
                    j = (int)strlen(a); // done with this arg
                    break;
                }
                // Unknown short flag - report as "-X"
                char err_arg[3] = {'-', c, '\0'};
                error_unexpected(err_arg);
            }
            (void)consumed_arg;
            i++;
            continue;
        }
        if (strcmp(a, "--keyed") == 0) {
            if (first_flag_keyed) error_multiple("--keyed");
            first_flag_keyed = "--keyed";
            opts.keyed = true;
            if (!flag_set[FLAG_KEYED]) { flag_set[FLAG_KEYED] = true; flag_order[n_flag_order++] = FLAG_KEYED; }
            i++;
            continue;
        }
        if (strcmp(a, "--derive-key") == 0 || strncmp(a, "--derive-key=", 13) == 0) {
            if (first_flag_derive) error_multiple("--derive-key <CONTEXT>");
            const char *val = NULL;
            bool eq_form = false;
            if (strncmp(a, "--derive-key=", 13) == 0) { val = a + 13; eq_form = true; }
            else {
                if (i + 1 >= argc) error_requires_value("--derive-key <CONTEXT>");
                val = argv[i + 1];
                if (val[0] == '-' && val[1] != '\0') {
                    error_unexpected(val);
                }
                i++;
            }
            (void)eq_form;
            first_flag_derive = "--derive-key <CONTEXT>";
            opts.derive_key = true;
            opts.derive_key_value = (char *)val;
            if (!flag_set[FLAG_DERIVE]) { flag_set[FLAG_DERIVE] = true; flag_order[n_flag_order++] = FLAG_DERIVE; }
            i++;
            continue;
        }
        if (strcmp(a, "--length") == 0 || strncmp(a, "--length=", 9) == 0 || strcmp(a, "-l") == 0 || strncmp(a, "-l=", 3) == 0) {
            if (first_flag_length) error_multiple("--length <LEN>");
            const char *val = NULL;
            if (strncmp(a, "--length=", 9) == 0) val = a + 9;
            else if (strncmp(a, "-l=", 3) == 0) val = a + 3;
            else {
                if (i + 1 >= argc) error_requires_value("--length <LEN>");
                val = argv[i + 1];
                if (val[0] == '-' && val[1] != '\0') {
                    error_unexpected(val);
                }
                i++;
            }
            const char *err;
            uint64_t v;
            if (!parse_u64(val, &v, &err)) {
                error_invalid_value(val, "--length <LEN>", err);
            }
            opts.length_set = true;
            opts.length = v;
            first_flag_length = "--length <LEN>";
            if (!flag_set[FLAG_LENGTH]) { flag_set[FLAG_LENGTH] = true; flag_order[n_flag_order++] = FLAG_LENGTH; }
            i++;
            continue;
        }
        if (strcmp(a, "--seek") == 0 || strncmp(a, "--seek=", 7) == 0) {
            if (first_flag_seek) error_multiple("--seek <SEEK>");
            const char *val = NULL;
            if (strncmp(a, "--seek=", 7) == 0) val = a + 7;
            else {
                if (i + 1 >= argc) error_requires_value("--seek <SEEK>");
                val = argv[i + 1];
                if (val[0] == '-' && val[1] != '\0') {
                    error_unexpected(val);
                }
                i++;
            }
            const char *err;
            uint64_t v;
            if (!parse_u64(val, &v, &err)) {
                error_invalid_value(val, "--seek <SEEK>", err);
            }
            opts.seek_set = true;
            opts.seek = v;
            first_flag_seek = "--seek <SEEK>";
            if (!flag_set[FLAG_SEEK]) { flag_set[FLAG_SEEK] = true; flag_order[n_flag_order++] = FLAG_SEEK; }
            i++;
            continue;
        }
        if (strcmp(a, "--num-threads") == 0 || strncmp(a, "--num-threads=", 14) == 0) {
            if (first_flag_num_threads) error_multiple("--num-threads <NUM>");
            const char *val = NULL;
            if (strncmp(a, "--num-threads=", 14) == 0) val = a + 14;
            else {
                if (i + 1 >= argc) error_requires_value("--num-threads <NUM>");
                val = argv[i + 1];
                if (val[0] == '-' && val[1] != '\0') {
                    error_unexpected(val);
                }
                i++;
            }
            const char *err;
            int64_t v;
            if (!parse_i64(val, &v, &err)) {
                error_invalid_value(val, "--num-threads <NUM>", err);
            }
            opts.num_threads_set = true;
            opts.num_threads = v;
            first_flag_num_threads = "--num-threads <NUM>";
            if (!flag_set[FLAG_NUM_THREADS]) { flag_set[FLAG_NUM_THREADS] = true; flag_order[n_flag_order++] = FLAG_NUM_THREADS; }
            i++;
            continue;
        }
        if (strcmp(a, "--no-mmap") == 0) {
            if (first_flag_no_mmap) error_multiple("--no-mmap");
            first_flag_no_mmap = "--no-mmap";
            opts.no_mmap = true;
            if (!flag_set[FLAG_NO_MMAP]) { flag_set[FLAG_NO_MMAP] = true; flag_order[n_flag_order++] = FLAG_NO_MMAP; }
            i++;
            continue;
        }
        if (strcmp(a, "--no-names") == 0) {
            if (first_flag_no_names) error_multiple("--no-names");
            first_flag_no_names = "--no-names";
            opts.no_names = true;
            if (!flag_set[FLAG_NO_NAMES]) { flag_set[FLAG_NO_NAMES] = true; flag_order[n_flag_order++] = FLAG_NO_NAMES; }
            i++;
            continue;
        }
        if (strcmp(a, "--raw") == 0) {
            if (first_flag_raw) error_multiple("--raw");
            first_flag_raw = "--raw";
            opts.raw = true;
            if (!flag_set[FLAG_RAW]) { flag_set[FLAG_RAW] = true; flag_order[n_flag_order++] = FLAG_RAW; }
            i++;
            continue;
        }
        if (strcmp(a, "--tag") == 0) {
            if (first_flag_tag) error_multiple("--tag");
            first_flag_tag = "--tag";
            opts.tag = true;
            if (!flag_set[FLAG_TAG]) { flag_set[FLAG_TAG] = true; flag_order[n_flag_order++] = FLAG_TAG; }
            i++;
            continue;
        }
        if (strcmp(a, "--check") == 0 || strcmp(a, "-c") == 0) {
            if (first_flag_check) error_multiple("--check");
            first_flag_check = "--check";
            opts.check = true;
            if (!flag_set[FLAG_CHECK]) { flag_set[FLAG_CHECK] = true; flag_order[n_flag_order++] = FLAG_CHECK; }
            i++;
            continue;
        }
        if (strcmp(a, "--quiet") == 0) {
            if (first_flag_quiet) error_multiple("--quiet");
            first_flag_quiet = "--quiet";
            opts.quiet = true;
            if (!flag_set[FLAG_QUIET]) { flag_set[FLAG_QUIET] = true; flag_order[n_flag_order++] = FLAG_QUIET; }
            i++;
            continue;
        }

        // Unknown
        error_unexpected(a);
    }

    // Conflict detection: walk flag_order in argv order; find first flag with any later conflicting flag.
    for (int x = 0; x < n_flag_order; x++) {
        flag_id_t A = flag_order[x];
        // Collect Y_list (flags after x that conflict with A)
        flag_id_t Ys[FLAG_COUNT];
        int n_ys = 0;
        for (int y = x + 1; y < n_flag_order; y++) {
            if (flag_conflicts(A, flag_order[y])) {
                Ys[n_ys++] = flag_order[y];
            }
        }
        if (n_ys > 0) {
            // Collect Us = intermediates between A and first Y that don't conflict with A
            flag_id_t first_Y = Ys[0];
            int first_Y_pos = -1;
            for (int y = x + 1; y < n_flag_order; y++) {
                if (flag_order[y] == first_Y) { first_Y_pos = y; break; }
            }
            flag_id_t Us[FLAG_COUNT];
            int n_us = 0;
            for (int u = x + 1; u < first_Y_pos; u++) {
                if (!flag_conflicts(A, flag_order[u])) {
                    Us[n_us++] = flag_order[u];
                }
            }
            emit_conflict_error(A, Ys, n_ys, Us, n_us);
        }
    }

    // Check required: --quiet requires --check
    if (opts.quiet && !opts.check) {
        error_required("--check", "--check --quiet <FILE>...");
    }

    // --keyed requires positional FILE arg(s)
    if (opts.keyed && opts.num_files == 0) {
        error_required("<FILE>...", "--keyed <FILE>...");
    }

    // Run
    if (opts.check) {
        return run_check(&opts);
    }

    // Initialize hasher (might read stdin for --keyed)
    blake3_hasher base_h;
    if (init_hasher(&base_h, &opts) < 0) return 1;

    // --raw: only one input allowed
    if (opts.raw) {
        opts.no_names = true; // implied
        int n_inputs = opts.num_files;
        if (n_inputs == 0) n_inputs = 1; // stdin
        if (n_inputs > 1) {
            fprintf(stderr, "Error: Only one filename can be provided when using --raw\n");
            return 1;
        }
    }

    int ret = 0;
    if (opts.num_files == 0) {
        if (output_one_hash(&opts, &base_h, "-") != 0) ret = 1;
    } else {
        for (int j = 0; j < opts.num_files; j++) {
            if (output_one_hash(&opts, &base_h, opts.files[j]) != 0) ret = 1;
        }
    }
    return ret;
}
