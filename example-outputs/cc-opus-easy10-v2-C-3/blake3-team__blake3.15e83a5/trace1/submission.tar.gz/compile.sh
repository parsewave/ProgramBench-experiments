#!/bin/sh
set -e
cd "$(dirname "$0")"
gcc -O2 -std=gnu11 -Wno-unused-result -o executable main.c blake3.c
