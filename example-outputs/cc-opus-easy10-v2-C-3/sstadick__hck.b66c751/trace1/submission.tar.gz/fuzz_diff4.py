#!/usr/bin/env python3
"""Aggressive fuzzing — multiple inputs, weird args, edge cases."""
import subprocess
import re
import random
import os
import tempfile

REF = "/workspace/executable"
SUT = "/work/work/executable"
TS_RE = re.compile(rb"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")
random.seed(789)

def norm(b):
    return TS_RE.sub(b"[TIMESTAMP ", b)

def run(bin_path, args, stdin):
    try:
        p = subprocess.run([bin_path] + args, input=stdin, capture_output=True, timeout=5)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"

def random_input():
    n_rows = random.randint(1, 8)
    n_cols = random.randint(1, 10)
    rows = []
    for _ in range(n_rows):
        cols = [random.choice(["a", "b", "c", "foo", "", "123", "xyz", "0"]) for _ in range(n_cols)]
        rows.append(' '.join(cols))
    return ('\n'.join(rows) + '\n').encode()

def gen_field_part(max_idx=10):
    choice = random.choice(['single', 'range', 'open_hi', 'open_lo'])
    if choice == 'single':
        return str(random.randint(1, max_idx))
    if choice == 'range':
        a = random.randint(1, max_idx)
        b = random.randint(a, max_idx+2)
        return f"{a}-{b}"
    if choice == 'open_hi':
        return f"{random.randint(1, max_idx)}-"
    return f"-{random.randint(1, max_idx)}"

def gen_fields_str():
    n = random.randint(1, 5)
    return ','.join(gen_field_part() for _ in range(n))

def random_args():
    args = []
    if random.random() < 0.6:
        args += ["-f", gen_fields_str()]
    if random.random() < 0.4:
        args += ["-e", gen_fields_str()]
    if random.random() < 0.3:
        args += ["-d", random.choice([" ", ",", ":", "|", r"\s+", r"\S+", r"\d+", r"\w+"])]
        if random.random() < 0.5:
            args += ["-L"]
    if random.random() < 0.3:
        args += ["-D", random.choice([",", "|", "::", "\\t", "  "])]
    if random.random() < 0.2:
        args += ["--crlf"]
    if random.random() < 0.1:
        args += ["--no-mmap"]
    return args

fails = 0
total = 0
mismatches = []
for i in range(2000):
    args = random_args()
    stdin = random_input()
    if "--crlf" in args:
        stdin = stdin.replace(b"\n", b"\r\n")
    total += 1
    rc1, o1, e1 = run(REF, args, stdin)
    rc2, o2, e2 = run(SUT, args, stdin)
    if rc1 != rc2 or o1 != o2 or norm(e1) != norm(e2):
        fails += 1
        if len(mismatches) < 10:
            mismatches.append((args, stdin, (rc1, o1, e1), (rc2, o2, e2)))

for (args, stdin, ref, sut) in mismatches:
    print(f"FAIL args={args}")
    print(f"  stdin={stdin[:150]!r}")
    print(f"  REF rc={ref[0]} out={ref[1][:150]!r} err={norm(ref[2])[:120]!r}")
    print(f"  SUT rc={sut[0]} out={sut[1][:150]!r} err={norm(sut[2])[:120]!r}")
print(f"\n{total - fails}/{total} passed")
