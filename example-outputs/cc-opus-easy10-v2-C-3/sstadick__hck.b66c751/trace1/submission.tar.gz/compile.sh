#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PATH="/usr/local/cargo/bin:$PATH"
export CARGO_HOME=/usr/local/cargo
export CARGO_NET_OFFLINE=true
cargo build --release --offline --target-dir target
cp target/release/executable ./executable
