#!/usr/bin/env python3
"""Statistical top-up: sample fresh probes from a usage Markov chain."""
import subprocess
import re
import random
import os
import gzip
import bz2
import lzma

REF = "/workspace/executable"
SUT = "/work/work/executable"
TS_RE = re.compile(rb"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")
random.seed(31415)

def norm(b):
    return TS_RE.sub(b"[TIMESTAMP ", b)

def run(bin_path, args, stdin):
    try:
        if stdin is None:
            p = subprocess.run([bin_path] + args, capture_output=True, timeout=5, stdin=subprocess.DEVNULL)
        else:
            p = subprocess.run([bin_path] + args, input=stdin, capture_output=True, timeout=5)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"

# Setup compressed files
os.makedirs("/tmp/topup", exist_ok=True)
plain = b"name age city\nalice 30 NYC\nbob 25 LA\ncarol 28 SF\n"
with open("/tmp/topup/h.txt", "wb") as f:
    f.write(plain)
with open("/tmp/topup/h.txt.gz", "wb") as f:
    f.write(gzip.compress(plain))
with open("/tmp/topup/h.txt.bz2", "wb") as f:
    f.write(bz2.compress(plain))
with open("/tmp/topup/h.txt.xz", "wb") as f:
    f.write(lzma.compress(plain))

# Discovered usage modes from probing:
# - basic field selection
# - regex delimiter
# - literal delimiter
# - header selection (literal and regex)
# - exclude (by field index)
# - exclude-header
# - decompression
# - CRLF
# - output delimiter
# - multiple files / stdin

probes = [
    # mode: basic field selection
    (["-f", "1,2", "/tmp/topup/h.txt"], None),
    (["-f", "-2"], plain),
    (["-f", "2-"], plain),
    # mode: regex
    (["-d", ",", "-f", "1,3"], b"a,b,c\n1,2,3\n"),
    (["-d", r"\d+", "-f", "1,2"], b"abc123def\nxyz9pqr\n"),
    # mode: literal
    (["-Ld", "::", "-f", "1,3"], b"foo::bar::baz\n"),
    # mode: header
    (["-F", "age", "/tmp/topup/h.txt"], None),
    (["-r", "-F", "^.ame$", "/tmp/topup/h.txt"], None),
    # mode: exclude
    (["-e", "2", "/tmp/topup/h.txt"], None),
    (["-E", "age", "/tmp/topup/h.txt"], None),
    # mode: decompress
    (["-z", "-f", "2", "/tmp/topup/h.txt.gz"], None),
    (["-z", "-f", "2", "/tmp/topup/h.txt.bz2"], None),
    (["-z", "-f", "2", "/tmp/topup/h.txt.xz"], None),
    # mode: crlf
    (["--crlf", "-f", "1,3"], b"a b c\r\nd e f\r\n"),
    # mode: output delimiter
    (["-f", "1,2", "-D", "|"], plain),
    # mode: multi-file
    (["-f", "1", "/tmp/topup/h.txt", "/tmp/topup/h.txt"], None),
    # mode: complex F+f
    (["-F", "city", "-f", "1", "/tmp/topup/h.txt"], None),
    # mode: escaping
    (["-f", "1,2", "-D", "\\t"], plain),
    # mode: stdin via dash
    (["-f", "2", "-", "/tmp/topup/h.txt"], b"stdin\n"),
    # mode: empty input
    (["-f", "1"], b""),
]

fails = 0
for (args, stdin) in probes:
    rc1, o1, e1 = run(REF, args, stdin)
    rc2, o2, e2 = run(SUT, args, stdin)
    if rc1 != rc2 or o1 != o2 or norm(e1) != norm(e2):
        fails += 1
        print(f"FAIL args={args}")
        print(f"  REF rc={rc1} out={o1!r} err={norm(e1)!r}")
        print(f"  SUT rc={rc2} out={o2!r} err={norm(e2)!r}")
print(f"\n{len(probes) - fails}/{len(probes)} passed")
