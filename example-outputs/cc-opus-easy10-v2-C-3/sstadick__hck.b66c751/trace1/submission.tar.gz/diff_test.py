#!/usr/bin/env python3
"""Differential test driver: run a list of probes against REF and SUT, report mismatches.

Every subprocess call MUST pass timeout=5 and stdin=subprocess.DEVNULL (or input=).
"""
import subprocess
import sys
import re
import os
import tempfile

REF = "/workspace/executable"
SUT = "/work/work/executable"

# Strip env_logger timestamps for comparison.
TS_RE = re.compile(rb"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")

def normalize(b: bytes) -> bytes:
    return TS_RE.sub(b"[TIMESTAMP ", b)

def run(bin_path, args, stdin_data=None, timeout=5):
    kwargs = dict(timeout=timeout, capture_output=True)
    if stdin_data is None:
        kwargs["stdin"] = subprocess.DEVNULL
    else:
        kwargs["input"] = stdin_data
    try:
        p = subprocess.run([bin_path] + args, **kwargs)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"

PROBES = []

def probe(label, args, stdin=None):
    PROBES.append((label, args, stdin))

# Basic
basic_input = b"a b c d e\n1 2 3 4 5\nfoo bar baz qux quux\n"
csv_input = b"a,b,c,d,e\n1,2,3,4,5\n"
colon_input = b"A:B::C\n1:2::3\n"
hdr_input = b"name age city\nalice 30 NYC\nbob 25 LA\n"

probe("default", [], basic_input)
probe("--help", ["--help"])
probe("-h", ["-h"])
probe("--version", ["--version"])
probe("-V", ["-V"])
probe("bogus", ["--bogus"])
probe("empty stdin", [], b"")

# Field selection
probe("-f1", ["-f", "1"], basic_input)
probe("-f1,3", ["-f", "1,3"], basic_input)
probe("-f2-4", ["-f", "2-4"], basic_input)
probe("-f-3", ["-f", "-3"], basic_input)
probe("-f3-", ["-f", "3-"], basic_input)
probe("-f5,7,1", ["-f", "5,7,1"], basic_input)
probe("-f1-3,1-2", ["-f", "1-3,1-2"], basic_input)
probe("-f1-3,2-3", ["-f", "1-3,2-3"], basic_input)
probe("-f1-3,2-4", ["-f", "1-3,2-4"], basic_input)
probe("-f2-4,1-3", ["-f", "2-4,1-3"], basic_input)
probe("-f4-5,5-8", ["-f", "4-5,5-8"], basic_input)
probe("-f1-3,3-4", ["-f", "1-3,3-4"], basic_input)
probe("-f1-3,2,1", ["-f", "1-3,2,1"], basic_input)
probe("-f1-3,1,2", ["-f", "1-3,1,2"], basic_input)
probe("-f1,2,3,1-2", ["-f", "1,2,3,1-2"], basic_input)
probe("-f1-2,1,2,3", ["-f", "1-2,1,2,3"], basic_input)
probe("-f0", ["-f", "0"], basic_input)
probe("-f1-0", ["-f", "1-0"], basic_input)
probe("-f3-1", ["-f", "3-1"], basic_input)
probe("-f letter", ["-f", "a"], basic_input)
probe("-f1-X", ["-f", "1-X"], basic_input)
probe("-f10", ["-f", "10"], basic_input)
probe("-f100-200", ["-f", "100-200"], basic_input)
probe("-f spaces", ["-f", "1, 2"], basic_input)
probe("-f trailing comma", ["-f", "1,"], basic_input)
probe("-f leading comma", ["-f", ",1"], basic_input)
probe("-f just dash", ["-f", "-"], basic_input)
probe("-f empty arg", ["-f", ""], basic_input)
probe("-f4-,1,5-8", ["-f", "4-,1,5-8"], basic_input)

# Delimiter
probe("-d,", ["-d", ",", "-f2,4"], csv_input)
probe("-Ld,", ["-L", "-d", ",", "-f2,4"], csv_input)
probe("-d:+", ["-d", ":+", "-f1,2,3"], colon_input)
probe("-Ld: regex", ["-d", ":", "-f1,2,3,4"], colon_input)
probe("-Ld:", ["-L", "-d", ":", "-f1,2,3,4"], colon_input)
probe("-d :", ["-d", ":+", "-f1,2,3"], colon_input)

# Output delim
probe("-D|", ["-d", ":", "-D", "|", "-f1,2"], colon_input)
probe("-D ->", ["-d", ":", "-D", " -> ", "-f1,2,3"], colon_input)
probe("-D empty", ["--output-delimiter=", "-d", ":", "-f1,2,3"], colon_input)

# Headers
probe("-F age", ["-F", "age"], hdr_input)
probe("-F age -F name", ["-F", "age", "-F", "name"], hdr_input)
probe("-F city -e3", ["-F", "city", "-e", "3"], hdr_input)
probe("-F city -E age", ["-F", "city", "-E", "age"], hdr_input)
probe("no match -F", ["-F", "nope"], hdr_input)
probe("-r -F regex", ["-r", "-F", "name$"], hdr_input)

# Multiple files
probe("multi-file", ["-f", "1", "/tmp/x.txt", "/tmp/y.txt"])
probe("dash stdin", ["-f", "1", "-"], b"stdin-line\n")
probe("file + stdin", ["-f", "1", "/tmp/x.txt", "-"], b"stdin-line\n")

# Edge cases
probe("no trailing newline", ["-f1"], b"a b c")
probe("blank lines", ["-f1"], b"\n\na b\n\n")
probe("leading ws", ["-f1,2,3,4"], b"   a b c\n")
probe("trailing ws", ["-f1,2,3,4"], b"a  b c   \n")

# CRLF
crlf_input = b"a b\r\nc d\r\n"
probe("crlf no flag", ["-f", "1"], crlf_input)
probe("crlf flag", ["--crlf", "-f", "1"], crlf_input)
probe("crlf 2 fields", ["--crlf", "-f", "1,2"], crlf_input)

# CSV via stdin
probe("csv stdin", ["-d", ",", "-f", "2,4"], csv_input)

# Combined F+f
probe("-f3 -F a", ["-f", "3", "-F", "a"], b"a b c d e\n1 2 3 4 5\n")
probe("-F a -f3", ["-F", "a", "-f", "3"], b"a b c d e\n1 2 3 4 5\n")
probe("-f4,1 -F c", ["-f", "4,1", "-F", "c"], b"a b c d e\n1 2 3 4 5\n")
probe("multi F", ["-F", "b", "-F", "d"], b"a b c d e\n1 2 3 4 5\n")
probe("multi F reversed", ["-F", "d", "-F", "b"], b"a b c d e\n1 2 3 4 5\n")

# Dup headers
probe("dup F", ["-F", "foo"], b"foo bar foo baz qux\n1 2 3 4 5\n")
probe("dup F+F", ["-F", "foo", "-F", "bar"], b"foo bar foo baz qux\n1 2 3 4 5\n")
probe("bar -F foo", ["-F", "bar", "-F", "foo"], b"foo bar foo baz qux\n1 2 3 4 5\n")

# Exclude
probe("-e2", ["-e", "2"], basic_input)
probe("-e2,4", ["-e", "2,4"], basic_input)
probe("-e-2", ["-e", "-2"], basic_input)
probe("-e3-", ["-e", "3-"], basic_input)
probe("-f1-3 -e2", ["-f", "1-3", "-e", "2"], basic_input)

# -I
probe("-I", ["-L", "-d", " ", "-I", "-f1,2,3"], b"a b c\n")

# Empty input
probe("empty -f1", ["-f", "1"], b"")

# Multiple -f (error)
probe("multi -f error", ["-f", "1", "-f", "3"], basic_input)


def main():
    # Setup files needed
    with open("/tmp/x.txt", "wb") as f:
        f.write(b"a b c d e\n1 2 3 4 5\n")
    with open("/tmp/y.txt", "wb") as f:
        f.write(b"AAA BBB CCC\nXXX YYY ZZZ\n")

    fails = 0
    total = 0
    for (label, args, stdin) in PROBES:
        total += 1
        ref_rc, ref_out, ref_err = run(REF, args, stdin)
        sut_rc, sut_out, sut_err = run(SUT, args, stdin)
        ref_err_n = normalize(ref_err)
        sut_err_n = normalize(sut_err)
        ok = (ref_rc == sut_rc) and (ref_out == sut_out) and (ref_err_n == sut_err_n)
        if not ok:
            fails += 1
            print(f"FAIL: {label}")
            print(f"  args={args} stdin={stdin!r}")
            print(f"  REF rc={ref_rc} stdout={ref_out!r} stderr={ref_err_n!r}")
            print(f"  SUT rc={sut_rc} stdout={sut_out!r} stderr={sut_err_n!r}")
    print(f"\n{total - fails}/{total} passed")
    return 0 if fails == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
