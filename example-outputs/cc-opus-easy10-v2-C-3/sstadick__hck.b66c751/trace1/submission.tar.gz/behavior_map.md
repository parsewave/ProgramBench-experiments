# hck behavioral map

## Identity / surface

- `executable --version` → `hck git:23bebe8-modified\n`, exit 0
- `executable --help` / `-h` produce clap-style help (full vs short)
- `executable --bogus` → clap unknown-argument error → exit 2
- `executable` with no input on stdin → exit 0, no output

## Input model

- Multiple positional FILE args read in sequence; `-` means stdin.
- Without positional args, reads stdin.
- File not found → `[<ts>Z ERROR hck] No such file or directory (os error 2)`, exit 1.
- Lines split by `\n` (LF). Trailing `\n` always emitted on output (even if input lacked it).
- Blank lines pass through (one empty field by `\s+`).
- `--crlf` mode: trailing `\r` is stripped before splitting; output uses `\r\n`.

## Delimiter

- Default `-d \s+` (regex).
- `-L` flag: treat `-d` as a literal substring. Multiple delimiters in a row produce empty fields.
- Regex uses Rust `regex` crate (RE2-like, no lookaround/backrefs).
- Invalid regex → `Error: regex parse error: ...`, exit 1.
- Empty regex `''` matches everywhere, producing empty fields between each char.

## Output delimiter

- `-D` default `\t`.
- May be multi-char or empty.

## `-I` / `--use-input-delim`

- Only effective when `-L` is in effect AND no explicit `-D`.
- Sets the output delimiter to the input delimiter literally.

## Field selection (`-f`, `-e`)

Parse: comma list of items where each item is:
- N (singleton)
- N-M (closed range, N≤M required; 5-1 → "High end of range less than low end of range" error)
- -M (open-start range, equivalent to 1-M)
- N- (open-end range, to last field of line)
- Whitespace inside or empty arg → "Failed to parse field" error
- Non-numeric → "Failed to parse field"
- 0 → "Fields and positions are numbered from 1: 0"
- `-f` may appear AT MOST ONCE (clap multi-use error if repeated). Same for `-e`.

### Field-spec dedup rule

Two specs S_i, S_j (i<j with overlap) interact:

- If S_j ⊆ S_i (S_j.start ≥ S_i.start AND S_j.end ≤ S_i.end) AND S_j.start ≠ S_i.start: **SUBSUME** → S_j claims nothing.
- Otherwise **SUBTRACT** → for each overlap position p:
  - If p = S_i.end AND p = S_j.start (single-position boundary at i-end/j-start): S_i KEEPS p, S_j loses p.
  - Else: S_j KEEPS p, S_i loses p.

Singletons are spec (x,x). Open ranges (5-) have end = ∞.

### Examples (verified)

- `1-3,1-2` → [3, 1, 2]
- `1-3,2-3` → [1, 2, 3]  (subsume)
- `4-5,5-8` → [4, 5]   (boundary keep)
- `4-5,3-4` → [5, 3, 4]   (later wins overlap, no boundary)
- `1-3,2,1` → [2, 3, 1] (singleton 2 in interior, subsumed; singleton 1 at start, wins via subtract)
- `1-2,1,2,3` → [2, 1, 3] (singleton 1 wins start; singleton 2 in interior, subsumed; 3 normal)

### Emission

- For each line, walk specs in order. For each spec, walk positions in its (clamped) range. Skip positions that aren't owned by this spec. Emit field at owned position with output delimiter between.
- OOB positions are silently skipped (no delimiter for them).
- If no positions emit on a line, still emit just `\n`.

### `-e` (exclude)

- Same parse as `-f`. After computing the field list from `-f`/`-F` selection, exclude any field index in `-e`.

## Header selection (`-F`, `-E`, `-r`)

- Treat first line of FIRST file as header (don't emit it; emit the matching headers re-ordered).
- `-F` value: literal substring match by default. Multiple `-F` allowed. With `-r`, value is a regex matching against each header field.
- `-E` excludes headers by literal or regex (same rules).
- If `-F` specified but no header matches: `[<ts>Z ERROR hck] No headers matched`, exit 1.
- If `-F` regex invalid (with `-r`): clap-style error before run, exit 2.
- Otherwise invalid regex (in -d) → runtime "Error: regex parse error: ..."

### Header selection order

1. For each `-F` (in cmdline order), find ALL columns whose header matches (substring or regex).
2. Combine all `-F`'s matched cols into ONE set, sort ascending. Rotate the sorted list so it starts at the FIRST `-F`'s FIRST matching column.
3. `-E` excludes header cols.

### Combining `-F` and `-f`

- Compute F-list (sorted-rotated as above) and f-list (`-f` parsed in order).
- Interleave: emit F[0], f[0], F[1], f[1], ... (skip any out-of-range index).
- Dedup with the field-spec rule applied to the resulting combined list of singletons (= the rule's behavior on singleton-only is "first wins").

## `-o` / output file

- Writes output to file. If unset, writes to stdout.

## `-z` / decompression

- For each FILE input (NOT stdin), if `-z` is set AND the filename extension is one of {.gz, .bz2, .xz, ...}, decompress before parsing.
- Unknown extension → treat as plain text.
- Missing file → `[<ts>Z ERROR hck] No such file or directory (os error 2)`, exit 1.

## `-Z` / compression

- Output is gzip-compressed using BGZF (multi-block) format with FEXTRA "BC" extra field.
- `-t` threads (default 4, 0 = single-threaded).
- `-l` compression level (default 6).

## `--no-mmap`, `--crlf`

- `--no-mmap` purely internal; no behavioral change observable in tests.
- `--crlf` toggles CRLF handling as above.

## Logging

- Errors emitted to stderr formatted as `[<RFC3339-Z timestamp> ERROR hck] <msg>` (env_logger default).
- clap parse errors use clap's default format.
- Exit codes: 0 success, 1 runtime errors, 2 clap parse errors.
