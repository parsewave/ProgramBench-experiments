use std::fs::File;
use std::io::{self, BufRead, BufReader, BufWriter, Read, Write};
use std::path::Path;
use std::process::{Command, Stdio};

use clap::{ArgAction, Parser};
use log::error;
use regex::bytes::Regex;

const HELP_BEFORE: &str = "* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`";

const HELP_LONG: &str = "* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

## Selection by headers

Instead of specifying fields to output by index ranges (i.e `1-2,4-`), you can specify a regex or string literal to select a headered column to output with the `-F` option. By default `-F` options are treated as string literals. To treat them as regexs add the `-r` flag.

## Ordering of outputs

*Values are written only once*. So for a `fields` value of `4-,1,5-8`, which translates to \"print columns 4 through the end and then the last column and then columns 5 through 8\", columns 5-8 won't be printed again because they were already consumed by the `4-` range.

If `field-headers` is used as a regex then the headers will be be grouped together in groups that all matched the same regex, and in the order of the regex as specified on the CLI.";

#[derive(Parser, Debug)]
#[command(
    name = "executable",
    bin_name = "executable",
    about = HELP_BEFORE,
    long_about = HELP_LONG,
    help_template = "{about-with-newline}\nUsage: {usage}\n\n{all-args}{after-help}",
    disable_help_flag = true,
    disable_version_flag = true,
    arg_required_else_help = false,
)]
struct Cli {
    /// Input files to parse, defaults to stdin.
    ///
    /// If a file has a recognizable file extension indicating that it is compressed, and a local binary to perform decompression is found, decompression will occur automagically. This requires with `-z`.
    #[arg(value_name = "INPUT")]
    inputs: Vec<String>,

    /// Output file to write to, defaults to stdout
    #[arg(short = 'o', long = "output", value_name = "OUTPUT")]
    output: Option<String>,

    /// Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag
    #[arg(short = 'd', long = "delimiter", default_value = r"\s+", value_name = "DELIMITER")]
    delimiter: String,

    /// Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
    #[arg(short = 'L', long = "delim-is-literal")]
    delim_literal: bool,

    /// Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
    #[arg(short = 'I', long = "use-input-delim")]
    use_input_delim: bool,

    /// Delimiter string to use on outputs
    #[arg(short = 'D', long = "output-delimiter", default_value = "\t", value_name = "OUTPUT_DELIMITER")]
    output_delimiter: String,

    /// Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
    #[arg(short = 'f', long = "fields", value_name = "FIELDS", allow_hyphen_values = true)]
    fields: Option<String>,

    /// Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`
    #[arg(short = 'e', long = "exclude", value_name = "EXCLUDE", allow_hyphen_values = true)]
    exclude: Option<String>,

    /// Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex
    #[arg(short = 'E', long = "exclude-header", value_name = "EXCLUDE_HEADER", action = ArgAction::Append)]
    exclude_header: Vec<String>,

    /// A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex
    #[arg(short = 'F', long = "header-field", value_name = "HEADER_FIELD", action = ArgAction::Append, value_parser = parse_header_field)]
    header_field: Vec<String>,

    /// Treat the header_fields as regexs instead of string literals
    #[arg(short = 'r', long = "header-is-regex")]
    header_is_regex: bool,

    /// Try to find the correct decompression method based on the file extensions
    #[arg(short = 'z', long = "try-decompress")]
    try_decompress: bool,

    /// Try to gzip compress the output
    #[arg(short = 'Z', long = "try-compress")]
    try_compress: bool,

    /// Threads to use for compression, 0 will result in `hck` staying single threaded
    #[arg(short = 't', long = "compression-threads", default_value = "4", value_name = "COMPRESSION_THREADS")]
    compression_threads: usize,

    /// Compression level
    #[arg(short = 'l', long = "compression-level", default_value = "6", value_name = "COMPRESSION_LEVEL")]
    compression_level: u32,

    /// Disallow the possibility of using mmap
    #[arg(long = "no-mmap")]
    no_mmap: bool,

    /// Support CRLF newlines
    #[arg(long = "crlf")]
    crlf: bool,

    /// Print help (see more with '--help')
    #[arg(short = 'h', long = "help", action = ArgAction::Help, help = "Print help (see more with '--help')", long_help = "Print help (see a summary with '-h')")]
    help: Option<bool>,

    /// Print version
    #[arg(short = 'V', long = "version", action = ArgAction::SetTrue)]
    version: bool,
}

/// Used only when -r is set — but clap doesn't know that, so we accept everything; we'll re-validate later.
fn parse_header_field(s: &str) -> Result<String, String> {
    // We don't validate regex here because we don't know if -r was passed yet.
    Ok(s.to_string())
}

/// A field selector: a single integer, an open-end range (start-), an open-start range (-end), or a closed range start-end.
#[derive(Debug, Clone)]
struct FieldSpec {
    start: usize,       // 1-based, inclusive
    end: usize,         // 1-based, inclusive; usize::MAX for open
    is_open_end: bool,  // syntactically open (like "5-")
}

fn parse_fields_str(s: &str) -> Result<Vec<FieldSpec>, String> {
    if s.is_empty() {
        return Err(String::new());
    }
    let mut out = Vec::new();
    for piece in s.split(',') {
        // "-" alone treated as empty
        if piece == "-" {
            return Err(String::new());
        }
        if let Some(dash_idx) = piece.find('-') {
            let lo_str = &piece[..dash_idx];
            let hi_str = &piece[dash_idx + 1..];
            if lo_str.is_empty() && hi_str.is_empty() {
                return Err(String::new());
            }
            let lo: usize = if lo_str.is_empty() {
                1
            } else {
                lo_str.parse().map_err(|_| piece.to_string())?
            };
            let hi: Option<usize> = if hi_str.is_empty() {
                None
            } else {
                Some(hi_str.parse().map_err(|_| piece.to_string())?)
            };
            match hi {
                Some(h) => {
                    // Check high < low FIRST (matches reference behavior)
                    if h < lo {
                        return Err(format!("__HIGH_LT_LOW__:{}", piece));
                    }
                    if lo == 0 {
                        return Err(format!("__ZERO__:0"));
                    }
                    if h == 0 {
                        return Err(format!("__ZERO__:0"));
                    }
                    out.push(FieldSpec { start: lo, end: h, is_open_end: false });
                }
                None => {
                    if lo == 0 {
                        return Err(format!("__ZERO__:0"));
                    }
                    out.push(FieldSpec { start: lo, end: usize::MAX, is_open_end: true });
                }
            }
        } else {
            if piece.is_empty() {
                return Err(piece.to_string());
            }
            let v: usize = piece.parse().map_err(|_| piece.to_string())?;
            if v == 0 {
                return Err(format!("__ZERO__:0"));
            }
            out.push(FieldSpec { start: v, end: v, is_open_end: false });
        }
    }
    if out.is_empty() {
        return Err(String::new());
    }
    Ok(out)
}

fn fail_field_parse(err: String) -> ! {
    if let Some(rest) = err.strip_prefix("__ZERO__:") {
        error!("Fields and positions are numbered from 1: {}", rest);
    } else if let Some(rest) = err.strip_prefix("__HIGH_LT_LOW__:") {
        error!("High end of range less than low end of range: {}", rest);
    } else {
        error!("Failed to parse field: {}", err);
    }
    std::process::exit(1);
}

/// Apply field-spec dedup. Returns a list of "ownership lists": one per spec, of positions
/// it can claim. For an open-ended spec, we return positions 1..=max_field and a flag indicating
/// open extension.
///
/// Algorithm (verified vs reference):
///   For pair (S_i, S_j) i<j with overlap:
///     - If S_j ⊆ S_i AND S_j.start != S_i.start: SUBSUME → S_j claim = empty
///     - Else: SUBTRACT
///         - For each overlap position p:
///           - If p == S_i.end AND p == S_j.start: S_i keeps p, S_j loses p
///           - Else: S_j wins p, S_i loses p
fn compute_ownership(specs: &[FieldSpec], num_fields: usize) -> Vec<Vec<usize>> {
    let n = specs.len();
    let mut owns: Vec<Vec<bool>> = Vec::with_capacity(n);
    // Initialize: each spec's owned positions are all positions in its range (clamped to num_fields).
    for s in specs {
        let mut v = vec![false; num_fields + 1];
        let end = if s.end == usize::MAX { num_fields } else { s.end };
        if end < num_fields + 1 {
            for p in s.start..=end.min(num_fields) {
                if p >= 1 {
                    v[p] = true;
                }
            }
        } else {
            for p in s.start..=num_fields {
                if p >= 1 {
                    v[p] = true;
                }
            }
        }
        owns.push(v);
    }

    // Apply pairwise rules.
    let mut subsumed = vec![false; n];
    for j in 0..n {
        for i in 0..j {
            if subsumed[i] || subsumed[j] {
                continue;
            }
            let si = &specs[i];
            let sj = &specs[j];
            // syntactic containments
            let j_in_i = sj.start >= si.start && sj.end <= si.end; // R_j ⊆ R_i
            let i_in_j = si.start >= sj.start && si.end <= sj.end; // R_j ⊇ R_i

            if j_in_i && sj.start != si.start {
                // SUBSUME: R_j is strictly inside R_i with different start
                subsumed[j] = true;
                for p in 0..=num_fields {
                    owns[j][p] = false;
                }
                continue;
            }

            if i_in_j && sj.start != si.start && !j_in_i {
                // R_i ⊆ R_j with different start: SUBSUME R_i
                subsumed[i] = true;
                for p in 0..=num_fields {
                    owns[i][p] = false;
                }
                continue;
            }

            // Rule: R_j is syntactically OPEN, R_i is CLOSED. R_j loses positions in R_i's range.
            if sj.end == usize::MAX && si.end != usize::MAX {
                let lo = si.start.max(1);
                let hi = si.end.min(num_fields);
                for p in lo..=hi {
                    owns[j][p] = false;
                }
                continue;
            }

            if i_in_j && sj.start == si.start && !j_in_i {
                // R_j ⊇ R_i strict, same start: R_j keeps only R_j.range - R_i.range
                let lo = si.start.max(1);
                let hi = if si.end == usize::MAX { num_fields } else { si.end.min(num_fields) };
                for p in lo..=hi {
                    if p <= num_fields {
                        owns[j][p] = false;
                    }
                }
                continue;
            }

            // SUBTRACT: overlap
            let lo = si.start.max(sj.start);
            let hi_i_eff = if si.end == usize::MAX { num_fields } else { si.end.min(num_fields) };
            let hi_j_eff = if sj.end == usize::MAX { num_fields } else { sj.end.min(num_fields) };
            let hi = hi_i_eff.min(hi_j_eff);
            if lo > hi {
                continue;
            }

            for p in lo..=hi {
                if p > num_fields {
                    break;
                }
                if !owns[j][p] {
                    // R_j has already lost this position (e.g. via NEW rule earlier). Don't take from R_i.
                    continue;
                }
                let is_boundary = p == si.end && p == sj.start;
                if is_boundary {
                    owns[j][p] = false;
                } else {
                    owns[i][p] = false;
                }
            }
        }
    }

    // Build ownership lists.
    let mut result = Vec::with_capacity(n);
    for v in owns {
        let mut list = Vec::new();
        for (p, b) in v.iter().enumerate().skip(1) {
            if *b {
                list.push(p);
            }
        }
        result.push(list);
    }
    result
}

/// Split header by the input mode (regex or literal).
fn split_line_regex<'a>(line: &'a [u8], re: &Regex) -> Vec<&'a [u8]> {
    re.split(line).collect()
}

fn split_line_literal<'a>(line: &'a [u8], delim: &[u8]) -> Vec<&'a [u8]> {
    if delim.is_empty() {
        // Empty literal acts as if no delimiter (matches between every char)
        let mut v: Vec<&[u8]> = Vec::new();
        v.push(&line[..0]);
        for i in 0..line.len() {
            v.push(&line[i..i + 1]);
        }
        v.push(&line[line.len()..]);
        return v;
    }
    let mut result = Vec::new();
    let mut start = 0;
    let mut i = 0;
    while i + delim.len() <= line.len() {
        if &line[i..i + delim.len()] == delim {
            result.push(&line[start..i]);
            i += delim.len();
            start = i;
        } else {
            i += 1;
        }
    }
    result.push(&line[start..]);
    result
}

enum DelimMode {
    Regex(Regex),
    Literal(Vec<u8>),
}

impl DelimMode {
    fn split<'a>(&self, line: &'a [u8]) -> Vec<&'a [u8]> {
        match self {
            DelimMode::Regex(r) => split_line_regex(line, r),
            DelimMode::Literal(s) => split_line_literal(line, s),
        }
    }
}

/// Open a path for reading, optionally decompressing based on extension.
fn open_input(path: &str, try_decompress: bool) -> io::Result<Box<dyn Read>> {
    if path == "-" {
        return Ok(Box::new(io::stdin().lock()));
    }
    let p = Path::new(path);
    if try_decompress {
        let ext = p.extension().and_then(|e| e.to_str()).unwrap_or("");
        let prog: Option<&str> = match ext {
            "gz" => Some("gzip"),
            "bz2" => Some("bzip2"),
            "xz" => Some("xz"),
            _ => None,
        };
        if let Some(prog) = prog {
            // Ensure file exists (so error message matches reference for missing file)
            let _ = File::open(p)?;
            let child = Command::new(prog)
                .arg("-dc")
                .arg(path)
                .stdout(Stdio::piped())
                .spawn()?;
            return Ok(Box::new(child.stdout.unwrap()));
        }
    }
    let f = File::open(p)?;
    Ok(Box::new(f))
}

/// Open the output sink, optionally compressing.
struct CmdWriter {
    child: std::process::Child,
}

impl Write for CmdWriter {
    fn write(&mut self, data: &[u8]) -> io::Result<usize> {
        self.child.stdin.as_mut().unwrap().write(data)
    }
    fn flush(&mut self) -> io::Result<()> {
        self.child.stdin.as_mut().unwrap().flush()
    }
}

impl Drop for CmdWriter {
    fn drop(&mut self) {
        // Close stdin to allow child to finish.
        self.child.stdin.take();
        let _ = self.child.wait();
    }
}

fn open_output(path: Option<&str>, try_compress: bool, level: u32) -> io::Result<Box<dyn Write>> {
    if try_compress {
        let lvl = level.clamp(1, 9);
        let stdout_target: Stdio = match path {
            Some(p) => Stdio::from(File::create(p)?),
            None => Stdio::inherit(),
        };
        let child = Command::new("gzip")
            .arg(format!("-{}", lvl))
            .arg("-c")
            .stdin(Stdio::piped())
            .stdout(stdout_target)
            .spawn()?;
        return Ok(Box::new(CmdWriter { child }));
    }
    let writer: Box<dyn Write> = match path {
        Some(p) => Box::new(BufWriter::new(File::create(p)?)),
        None => Box::new(BufWriter::new(io::stdout().lock())),
    };
    Ok(writer)
}

fn main() {
    // Init env_logger with default format that includes timestamp like reference.
    // Default RUST_LOG level: error and above visible.
    // Override module path to "hck" so error messages show [TS ERROR hck] not [TS ERROR executable].
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("error"))
        .format(|buf, record| {
            use std::io::Write as _;
            let ts = buf.timestamp();
            writeln!(buf, "[{} {} hck] {}", ts, record.level(), record.args())
        })
        .init();

    let cli = Cli::parse();
    if cli.version {
        println!("hck git:23bebe8-modified");
        std::process::exit(0);
    }
    run(cli).unwrap_or_else(|e| {
        error!("{}", e);
        std::process::exit(1);
    });
}

/// Determine if the selection (after applying excludes as range subtractions on each F spec)
/// produces an empty list of remaining sub-ranges across ALL F specs.
/// Returns true if SOME remaining range exists (=> emit at least \n per row), false if all empty.
fn selection_would_emit(
    field_specs: Option<&[FieldSpec]>,
    exclude_specs: Option<&[FieldSpec]>,
) -> bool {
    let default_specs = vec![FieldSpec { start: 1, end: usize::MAX, is_open_end: true }];
    let f: &[FieldSpec] = match field_specs {
        Some(v) => v,
        None => &default_specs,
    };
    let e: &[FieldSpec] = exclude_specs.unwrap_or(&[]);

    if e.is_empty() {
        return true;
    }

    // For each F spec, compute remaining sub-ranges after subtracting all E specs as ranges.
    for fs in f {
        // Each fs is [a, b] (b may be MAX).
        let mut remaining: Vec<(usize, usize)> = vec![(fs.start, fs.end)];
        for es in e {
            let mut new_remaining: Vec<(usize, usize)> = Vec::new();
            for (a, b) in remaining.into_iter() {
                let c = es.start;
                let d = es.end;
                // [a, b] minus [c, d]
                if d < a || c > b {
                    new_remaining.push((a, b));
                    continue;
                }
                // overlap exists
                if c > a {
                    new_remaining.push((a, c - 1));
                }
                if d != usize::MAX && d < b {
                    new_remaining.push((d + 1, b));
                }
                // if d == MAX or d >= b, the right part is empty
            }
            remaining = new_remaining;
            if remaining.is_empty() {
                break;
            }
        }
        if !remaining.is_empty() {
            return true;
        }
    }
    false
}

fn run(cli: Cli) -> Result<(), String> {
    // Parse fields and exclude specs (early to surface errors).
    let field_specs: Option<Vec<FieldSpec>> = if let Some(s) = &cli.fields {
        match parse_fields_str(s) {
            Ok(v) => Some(v),
            Err(e) => fail_field_parse(e),
        }
    } else {
        None
    };

    let exclude_specs: Option<Vec<FieldSpec>> = if let Some(s) = &cli.exclude {
        match parse_fields_str(s) {
            Ok(v) => Some(v),
            Err(e) => fail_field_parse(e),
        }
    } else {
        None
    };

    // Build delimiter.
    let delim_bytes: Vec<u8> = process_escapes(&cli.delimiter);
    let delim_mode = if cli.delim_literal {
        DelimMode::Literal(delim_bytes.clone())
    } else {
        let re = Regex::new(&cli.delimiter).map_err(|e| format!("{}", e))?;
        DelimMode::Regex(re)
    };

    // Output delimiter — process escapes.
    let out_delim: Vec<u8> = if cli.use_input_delim && cli.delim_literal && cli.output_delimiter == "\t" {
        delim_bytes.clone()
    } else {
        process_escapes(&cli.output_delimiter)
    };

    // Open input files (in order).
    let inputs: Vec<String> = if cli.inputs.is_empty() {
        vec!["-".to_string()]
    } else {
        cli.inputs.clone()
    };

    let mut output = open_output(cli.output.as_deref(), cli.try_compress, cli.compression_level)
        .map_err(|e| format!("{}", e))?;

    // Determine if we have header selectors.
    let want_headers = !cli.header_field.is_empty() || !cli.exclude_header.is_empty();

    // Early exit: if -e/-f combination makes selection empty (and we don't have header processing).
    if !want_headers && !selection_would_emit(field_specs.as_deref(), exclude_specs.as_deref()) {
        // Consume input but emit nothing.
        // For correctness with potential side effects (no observable in our case), just exit.
        return Ok(());
    }

    // Validate header regex early when -r is set.
    if cli.header_is_regex {
        for hf in &cli.header_field {
            regex::Regex::new(hf).map_err(|e| format!("regex parse error: {}", e))?;
        }
        for he in &cli.exclude_header {
            regex::Regex::new(he).map_err(|e| format!("regex parse error: {}", e))?;
        }
    }

    // We'll process all input files as a single stream of lines.
    // Read header from first file's first line if needed.
    let mut header_fields_for_emit: Option<Vec<usize>> = None;
    let mut input_iter = inputs.into_iter();
    let mut current_reader: Option<Box<dyn BufRead>> = None;

    // Establish first reader.
    let first_path = match input_iter.next() {
        Some(p) => p,
        None => {
            return Ok(());
        }
    };
    let first_reader: Box<dyn BufRead> = Box::new(BufReader::new(
        open_input(&first_path, cli.try_decompress).map_err(|e| format!("{}", e))?,
    ));
    current_reader = Some(first_reader);

    // Get all lines as a flat stream by chaining reader switches.
    // Read line-by-line. Detect CRLF for output.
    let mut header_emitted_already = false;

    'outer: loop {
        // Read one line from the current reader.
        let mut buf = Vec::new();
        let reader = current_reader.as_mut().unwrap();
        let n = reader.read_until(b'\n', &mut buf).map_err(|e| format!("{}", e))?;
        if n == 0 {
            // Switch to next file or end.
            match input_iter.next() {
                Some(p) => {
                    let r: Box<dyn BufRead> = Box::new(BufReader::new(
                        open_input(&p, cli.try_decompress).map_err(|e| format!("{}", e))?,
                    ));
                    current_reader = Some(r);
                    continue;
                }
                None => break 'outer,
            }
        }

        // Determine line content (without \n) and line ending.
        let had_lf = buf.last() == Some(&b'\n');
        let mut content_len = buf.len();
        if had_lf {
            content_len -= 1;
        }
        let mut had_cr = false;
        if cli.crlf && content_len > 0 && buf[content_len - 1] == b'\r' {
            had_cr = true;
            content_len -= 1;
        }
        let line = &buf[..content_len];

        // Determine output line terminator: \r\n if --crlf detected, else \n (if had_lf, else \n still — output always adds \n at end).
        let line_terminator: &[u8] = if cli.crlf && had_cr {
            b"\r\n"
        } else if cli.crlf {
            // --crlf set but this line didn't have CR: still emit \r\n? Probably \r\n always when --crlf is set.
            b"\r\n"
        } else {
            b"\n"
        };

        // Split line into fields.
        let fields_b: Vec<&[u8]> = delim_mode.split(line);
        let n_fields = fields_b.len();

        // First line of first file with header selectors: emit header (filtered).
        if want_headers && !header_emitted_already {
            // Validate -F: check each -F for at least one match.
            // Behavior:
            //   - If ALL -F have no match: error "No headers matched".
            //   - Else if some -F has 0 matches: error "Header not found: <that name>" (FIRST failing one).
            if !cli.header_field.is_empty() {
                let mut per_f_matches: Vec<Vec<usize>> = Vec::with_capacity(cli.header_field.len());
                for hf in &cli.header_field {
                    let m = find_header_matches(&fields_b, hf, cli.header_is_regex);
                    per_f_matches.push(m);
                }
                let any_match = per_f_matches.iter().any(|m| !m.is_empty());
                if !any_match {
                    return Err("No headers matched".to_string());
                }
                for (i, m) in per_f_matches.iter().enumerate() {
                    if m.is_empty() {
                        return Err(format!("Header not found: {}", cli.header_field[i]));
                    }
                }
            }
            let selected = if cli.header_field.is_empty() {
                // No -F: use default [1, num_fields] minus -E exclusions.
                let n_fields = fields_b.len();
                let mut all_indices: Vec<usize> = (1..=n_fields).collect();
                // Apply -E exclusions.
                let mut exclude_set: std::collections::HashSet<usize> = std::collections::HashSet::new();
                for he in &cli.exclude_header {
                    for (i, h) in fields_b.iter().enumerate() {
                        if header_matches(h, he, cli.header_is_regex) {
                            exclude_set.insert(i + 1);
                        }
                    }
                }
                // Apply -e
                if let Some(es) = exclude_specs.as_deref() {
                    let s = compute_exclude_set(es, n_fields);
                    for p in s { exclude_set.insert(p); }
                }
                all_indices.retain(|p| !exclude_set.contains(p));
                all_indices
            } else {
                compute_header_selection(
                    &fields_b,
                    &cli.header_field,
                    &cli.exclude_header,
                    cli.header_is_regex,
                    field_specs.as_deref(),
                    exclude_specs.as_deref(),
                )?
            };
            header_fields_for_emit = Some(selected.clone());
            header_emitted_already = true;
            // If nothing remains after exclusion, the reference produces no output at all (not even \n per row).
            if selected.is_empty() {
                break 'outer;
            }
            // Emit selected header columns.
            emit_indices(&fields_b, &selected, &out_delim, &mut output, line_terminator)
                .map_err(|e| format!("{}", e))?;
            continue;
        }

        // Regular emission.
        if let Some(indices) = header_fields_for_emit.as_ref() {
            // Use precomputed header-based selection.
            emit_indices(&fields_b, indices, &out_delim, &mut output, line_terminator)
                .map_err(|e| format!("{}", e))?;
            continue;
        }

        // No header selection — use -f / -e directly.
        let indices = compute_field_indices(&field_specs, &exclude_specs, n_fields);
        emit_indices(&fields_b, &indices, &out_delim, &mut output, line_terminator)
            .map_err(|e| format!("{}", e))?;
    }

    output.flush().map_err(|e| format!("{}", e))?;
    Ok(())
}

fn emit_indices<W: Write + ?Sized>(
    fields: &[&[u8]],
    indices: &[usize],
    out_delim: &[u8],
    output: &mut W,
    terminator: &[u8],
) -> io::Result<()> {
    let mut first = true;
    for &p in indices {
        if p < 1 || p > fields.len() {
            continue;
        }
        if !first {
            output.write_all(out_delim)?;
        }
        first = false;
        output.write_all(fields[p - 1])?;
    }
    output.write_all(terminator)?;
    Ok(())
}

fn compute_field_indices(
    field_specs: &Option<Vec<FieldSpec>>,
    exclude_specs: &Option<Vec<FieldSpec>>,
    n_fields: usize,
) -> Vec<usize> {
    let specs: Vec<FieldSpec> = match field_specs {
        Some(v) => v.clone(),
        None => vec![FieldSpec { start: 1, end: usize::MAX, is_open_end: true }],
    };
    let owns = compute_ownership(&specs, n_fields);

    // Build the emission order: walk through each spec in order, list the positions it owns
    // within its range in ASCENDING order, then concatenate.
    let mut result: Vec<usize> = Vec::new();
    for v in owns {
        for p in v {
            result.push(p);
        }
    }

    // Apply exclude
    if let Some(excl) = exclude_specs {
        let excl_set = compute_exclude_set(excl, n_fields);
        result.retain(|p| !excl_set.contains(p));
    }

    result
}

fn compute_exclude_set(specs: &[FieldSpec], n_fields: usize) -> std::collections::HashSet<usize> {
    let mut set = std::collections::HashSet::new();
    for s in specs {
        let end = if s.end == usize::MAX { n_fields } else { s.end.min(n_fields) };
        for p in s.start..=end {
            set.insert(p);
        }
    }
    set
}

fn header_matches(h: &[u8], pattern: &str, is_regex: bool) -> bool {
    let h_str = std::str::from_utf8(h).unwrap_or("");
    if is_regex {
        match regex::Regex::new(pattern) {
            Ok(re) => re.is_match(h_str),
            Err(_) => false,
        }
    } else {
        // Literal: EXACT match (== not substring).
        h_str == pattern
    }
}

fn find_header_matches(headers: &[&[u8]], pattern: &str, is_regex: bool) -> Vec<usize> {
    let mut out = Vec::new();
    for (i, h) in headers.iter().enumerate() {
        if header_matches(h, pattern, is_regex) {
            out.push(i + 1);
        }
    }
    out
}

fn compute_header_selection(
    headers: &[&[u8]],
    header_fields: &[String],
    exclude_headers: &[String],
    is_regex: bool,
    field_specs: Option<&[FieldSpec]>,
    exclude_specs: Option<&[FieldSpec]>,
) -> Result<Vec<usize>, String> {
    // Step 1: For each -F, find all matching column indices (1-based).
    let mut f_lists: Vec<Vec<usize>> = Vec::new();
    let mut first_match_first_f: Option<usize> = None;
    for hf in header_fields {
        let matches: Vec<usize> = find_header_matches(headers, hf, is_regex);
        if first_match_first_f.is_none() {
            first_match_first_f = matches.first().copied();
        }
        f_lists.push(matches);
    }

    // Build F-list: union of all matches sorted ascending, rotated to start at first_match_first_f.
    let mut union_set: std::collections::BTreeSet<usize> = std::collections::BTreeSet::new();
    for v in &f_lists {
        for p in v {
            union_set.insert(*p);
        }
    }
    let union_sorted: Vec<usize> = union_set.into_iter().collect();
    let f_list: Vec<usize> = if let Some(start_at) = first_match_first_f {
        if let Some(pos) = union_sorted.iter().position(|&x| x == start_at) {
            let mut rotated = union_sorted[pos..].to_vec();
            rotated.extend_from_slice(&union_sorted[..pos]);
            rotated
        } else {
            union_sorted
        }
    } else {
        union_sorted
    };

    // f_list (from -f)
    let inner_f_list: Vec<usize> = if let Some(fs) = field_specs {
        let owns = compute_ownership(fs, headers.len());
        let mut v = Vec::new();
        for o in owns {
            for p in o {
                v.push(p);
            }
        }
        v
    } else {
        Vec::new()
    };

    // Interleave F-list and inner_f_list.
    let mut combined: Vec<usize> = Vec::new();
    let mx = f_list.len().max(inner_f_list.len());
    for i in 0..mx {
        if let Some(&p) = f_list.get(i) {
            combined.push(p);
        }
        if let Some(&p) = inner_f_list.get(i) {
            combined.push(p);
        }
    }

    // Apply exclude (-E and -e)
    let mut exclude_indices: std::collections::HashSet<usize> = std::collections::HashSet::new();
    for he in exclude_headers {
        for (i, h) in headers.iter().enumerate() {
            if header_matches(h, he, is_regex) {
                exclude_indices.insert(i + 1);
            }
        }
    }
    if let Some(es) = exclude_specs {
        let s = compute_exclude_set(es, headers.len());
        for p in s {
            exclude_indices.insert(p);
        }
    }
    let mut seen: std::collections::HashSet<usize> = std::collections::HashSet::new();
    combined.retain(|p| {
        if exclude_indices.contains(p) {
            return false;
        }
        if seen.contains(p) {
            return false;
        }
        seen.insert(*p);
        true
    });

    Ok(combined)
}

/// Process escape sequences in user-provided strings: \t, \n, \r, \\, \xNN.
fn process_escapes(s: &str) -> Vec<u8> {
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b == b'\\' && i + 1 < bytes.len() {
            let next = bytes[i + 1];
            match next {
                b't' => { out.push(b'\t'); i += 2; }
                b'n' => { out.push(b'\n'); i += 2; }
                b'r' => { out.push(b'\r'); i += 2; }
                b'0' => { out.push(0); i += 2; }
                b'\\' => { out.push(b'\\'); i += 2; }
                b'\'' => { out.push(b'\''); i += 2; }
                b'"' => { out.push(b'"'); i += 2; }
                b'x' => {
                    if i + 3 < bytes.len() {
                        let hex_str = std::str::from_utf8(&bytes[i + 2..i + 4]).unwrap_or("");
                        if let Ok(v) = u8::from_str_radix(hex_str, 16) {
                            out.push(v);
                            i += 4;
                            continue;
                        }
                    }
                    out.push(b);
                    i += 1;
                }
                _ => {
                    out.push(b);
                    i += 1;
                }
            }
        } else {
            out.push(b);
            i += 1;
        }
    }
    out
}
