#!/usr/bin/env python3
"""Wider fuzzing with headers, multi-file, etc."""
import subprocess
import re
import random
import os

REF = "/workspace/executable"
SUT = "/work/work/executable"
TS_RE = re.compile(rb"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")
random.seed(123)

def norm(b):
    return TS_RE.sub(b"[TIMESTAMP ", b)

def run(bin_path, args, stdin):
    try:
        p = subprocess.run([bin_path] + args, input=stdin, capture_output=True, timeout=5)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"

def random_data(with_header=False, n_rows=None):
    n_rows = n_rows if n_rows is not None else random.randint(0, 5)
    n_cols = random.randint(2, 7)
    header_words = ['name', 'age', 'city', 'foo', 'bar', 'baz', 'is_x', 'is_y', 'col1', 'col2', 'data', 'val']
    rows = []
    if with_header:
        cols = random.sample(header_words, n_cols)
        rows.append(' '.join(cols))
    for _ in range(n_rows):
        cols = [random.choice(['1', '2', 'x', 'y', 'abc', '']) for _ in range(n_cols)]
        rows.append(' '.join(cols))
    return ('\n'.join(rows) + '\n').encode('utf-8') if rows else b''

def gen_fields_string(max_idx=8):
    n = random.randint(1, 3)
    parts = []
    for _ in range(n):
        choice = random.choice(['single', 'range', 'open_hi', 'open_lo'])
        if choice == 'single':
            parts.append(str(random.randint(1, max_idx)))
        elif choice == 'range':
            a = random.randint(1, max_idx-1)
            b = random.randint(a, max_idx)
            parts.append(f"{a}-{b}")
        elif choice == 'open_hi':
            parts.append(f"{random.randint(1, max_idx)}-")
        else:
            parts.append(f"-{random.randint(1, max_idx)}")
    return ','.join(parts)

def random_probe(case_id):
    args = []
    use_header = case_id % 3 == 0
    stdin = random_data(with_header=use_header)
    
    if random.random() < 0.4 and use_header:
        # Header selection
        words = ['name', 'age', 'city', 'foo', 'bar', 'col1', 'is_x']
        n = random.randint(1, 3)
        for _ in range(n):
            args.append("-F")
            args.append(random.choice(words))
        if random.random() < 0.4:
            args.append("-r")
        if random.random() < 0.3:
            args.append("-E")
            args.append(random.choice(words))
    else:
        if random.random() < 0.7:
            args += ["-f", gen_fields_string()]
        if random.random() < 0.4:
            args += ["-e", gen_fields_string()]
    
    if random.random() < 0.3:
        d = random.choice([" ", ",", ":", r"\s+", r"\d+"])
        args += ["-d", d]
        if random.random() < 0.5 and d != r"\s+" and d != r"\d+":
            args += ["-L"]
    if random.random() < 0.3:
        args += ["-D", random.choice([",", "|", " ", "::"])]
    if random.random() < 0.2:
        args += ["--crlf"]
        stdin = stdin.replace(b"\n", b"\r\n")
    return args, stdin

fails = 0
total = 0
mismatches = []
for i in range(500):
    args, stdin = random_probe(i)
    total += 1
    rc1, o1, e1 = run(REF, args, stdin)
    rc2, o2, e2 = run(SUT, args, stdin)
    if rc1 != rc2 or o1 != o2 or norm(e1) != norm(e2):
        fails += 1
        if len(mismatches) < 15:
            mismatches.append((args, stdin, (rc1, o1, e1), (rc2, o2, e2)))

for (args, stdin, ref, sut) in mismatches:
    print(f"FAIL args={args}")
    print(f"  stdin={stdin[:200]!r}{'...' if len(stdin)>200 else ''}")
    print(f"  REF rc={ref[0]} out={ref[1][:200]!r}{'...' if len(ref[1])>200 else ''} err={norm(ref[2])[:120]!r}")
    print(f"  SUT rc={sut[0]} out={sut[1][:200]!r}{'...' if len(sut[1])>200 else ''} err={norm(sut[2])[:120]!r}")

print(f"\n{total - fails}/{total} passed")
