#!/usr/bin/env python3
"""10 fresh probes from a usage Markov chain over discovered modes."""
import subprocess, re, random
REF = "/workspace/executable"
SUT = "/work/work/executable"
TS_RE = re.compile(rb"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")
random.seed(99999)

def norm(b):
    return TS_RE.sub(b"[TIMESTAMP ", b)

def run(b, args, stdin):
    try:
        if stdin is None:
            p = subprocess.run([b]+args, capture_output=True, timeout=5, stdin=subprocess.DEVNULL)
        else:
            p = subprocess.run([b]+args, input=stdin, capture_output=True, timeout=5)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"

# 10 fresh probes covering the discovered modes
probes = [
    # Mode: basic field selection
    (["-f", "1-3"], b"a b c d e\nf g h i j\n"),
    # Mode: regex delimiter
    (["-d", r"[,;]", "-f", "2"], b"a,b;c,d\n1,2;3,4\n"),
    # Mode: literal delim with multi-byte
    (["-Ld", "::", "-f", "1,3"], b"a::b::c::d\n1::2::3::4\n"),
    # Mode: open-end range
    (["-f", "3-"], b"a b c d e f\n1 2 3 4 5 6\n"),
    # Mode: open-start range  
    (["-f", "-2"], b"alpha beta gamma\n"),
    # Mode: exclude by index
    (["-f", "1-5", "-e", "2,4"], b"a b c d e\n1 2 3 4 5\n"),
    # Mode: output delim
    (["-d", ",", "-D", "|", "-f", "1,3"], b"a,b,c,d\nw,x,y,z\n"),
    # Mode: header literal
    (["-F", "name"], b"id name age\n1 alice 30\n2 bob 25\n"),
    # Mode: header regex
    (["-r", "-F", "^a.*"], b"alpha apple beta gamma\n1 2 3 4\n"),
    # Mode: CRLF
    (["--crlf", "-f", "2,4"], b"a b c d\r\ne f g h\r\n"),
]

passed = 0
for (args, stdin) in probes:
    rc1, o1, e1 = run(REF, args, stdin)
    rc2, o2, e2 = run(SUT, args, stdin)
    if rc1 == rc2 and o1 == o2 and norm(e1) == norm(e2):
        passed += 1
    else:
        print(f"FAIL args={args}")
        print(f"  REF: rc={rc1} out={o1!r} err={norm(e1)!r}")
        print(f"  SUT: rc={rc2} out={o2!r} err={norm(e2)!r}")

print(f"{passed}/{len(probes)} passed")
