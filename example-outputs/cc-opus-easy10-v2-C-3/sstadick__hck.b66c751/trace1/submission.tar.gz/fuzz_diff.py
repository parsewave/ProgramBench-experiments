#!/usr/bin/env python3
"""Generate random probes and run differentially."""
import subprocess
import sys
import random
import os
import re

REF = "/workspace/executable"
SUT = "/work/work/executable"
TS_RE = re.compile(rb"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")
random.seed(42)

def norm(b):
    return TS_RE.sub(b"[TIMESTAMP ", b)

def run(bin_path, args, stdin):
    try:
        p = subprocess.run([bin_path] + args, input=stdin, capture_output=True, timeout=5)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"

def random_data():
    n_rows = random.randint(0, 6)
    n_cols = random.randint(1, 8)
    rows = []
    for _ in range(n_rows):
        cols = []
        for _ in range(n_cols):
            cols.append(random.choice(['a', 'b', 'c', 'foo', 'bar', '123', 'X', '']))
        rows.append(' '.join(cols))
    return ('\n'.join(rows) + '\n').encode('utf-8') if rows else b''

def random_fields(max_idx=8):
    parts = []
    n = random.randint(1, 4)
    for _ in range(n):
        choice = random.choice(['single', 'range', 'open_lo', 'open_hi'])
        if choice == 'single':
            parts.append(str(random.randint(1, max_idx)))
        elif choice == 'range':
            a = random.randint(1, max_idx)
            b = random.randint(a, max_idx+2)
            parts.append(f"{a}-{b}")
        elif choice == 'open_lo':
            parts.append(f"-{random.randint(1, max_idx)}")
        else:
            parts.append(f"{random.randint(1, max_idx)}-")
    return ','.join(parts)

def random_probe():
    args = []
    stdin = random_data()
    use_f = random.random() < 0.7
    if use_f:
        args += ["-f", random_fields()]
    if random.random() < 0.4:
        args += ["-e", random_fields()]
    if random.random() < 0.3:
        args += ["-d", random.choice([" ", ",", ":", "\\s+"])]
        if random.random() < 0.5:
            args += ["-L"]
    if random.random() < 0.3:
        args += ["-D", random.choice([",", "|", " ", "::"])]
    if random.random() < 0.3:
        args += ["--crlf"]
        stdin = stdin.replace(b"\n", b"\r\n")
    return args, stdin

fails = 0
total = 0
mismatches = []
for i in range(200):
    args, stdin = random_probe()
    total += 1
    rc1, o1, e1 = run(REF, args, stdin)
    rc2, o2, e2 = run(SUT, args, stdin)
    if rc1 != rc2 or o1 != o2 or norm(e1) != norm(e2):
        fails += 1
        if len(mismatches) < 10:
            mismatches.append((args, stdin, (rc1, o1, e1), (rc2, o2, e2)))

for (args, stdin, ref, sut) in mismatches:
    print(f"FAIL args={args} stdin={stdin!r}")
    print(f"  REF rc={ref[0]} out={ref[1]!r} err={norm(ref[2])!r}")
    print(f"  SUT rc={sut[0]} out={sut[1]!r} err={norm(sut[2])!r}")

print(f"\n{total - fails}/{total} passed")
