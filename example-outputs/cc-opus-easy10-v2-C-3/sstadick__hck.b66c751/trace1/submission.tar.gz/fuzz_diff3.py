#!/usr/bin/env python3
"""More extreme cases including compression, complex headers."""
import subprocess
import re
import random
import os
import gzip
import bz2
import lzma

REF = "/workspace/executable"
SUT = "/work/work/executable"
TS_RE = re.compile(rb"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")
random.seed(456)

def norm(b):
    return TS_RE.sub(b"[TIMESTAMP ", b)

def run(bin_path, args, stdin):
    try:
        p = subprocess.run([bin_path] + args, input=stdin, capture_output=True, timeout=5)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"

# Test decompression
os.makedirs("/tmp/cz", exist_ok=True)
plain = b"a b c\n1 2 3\n"
for ext, comp in [("gz", gzip.compress), ("bz2", bz2.compress), ("xz", lzma.compress)]:
    with open(f"/tmp/cz/test.{ext}", "wb") as f:
        f.write(comp(plain))

fails = 0
total = 0

cases = [
    (["-z", "-f1", "/tmp/cz/test.gz"], b""),
    (["-z", "-f1", "/tmp/cz/test.bz2"], b""),
    (["-z", "-f1", "/tmp/cz/test.xz"], b""),
    (["-f", "1-3", "-D", "<>"], b"a b c d\n1 2 3 4\n"),
    (["-f", "1,3,2"], b"x y z\n"),
    (["-Ld", " "], b"a b c\n"),
    # Special regex
    (["-d", r"\d+"], b"foo123bar456baz\n"),
    (["-d", r"\d+", "-f2"], b"foo123bar456baz\n"),
    (["-d", r"[abc]+"], b"xaaybbzcc\n"),
    (["-d", "."], b"abcde\n"),
    # CRLF + other modes
    (["--crlf", "-f1,2", "-d", " "], b"a b c\r\n1 2 3\r\n"),
    (["--crlf", "-Ld", " "], b"a b c\r\n"),
    # Multiple files
    (["-f1"], b""),
    # Many empty lines
    (["-f1"], b"\n\n\n"),
    # Just \r
    (["-f1"], b"\r"),
    (["-f1"], b"\r\n"),
    # NUL byte
    (["-f1,2"], b"a\x00b c\n"),
    # Long line
    (["-f1"], b"a " * 200 + b"\n"),
    # -F empty header values
    (["-F", "", "name age city\nalice 30 NYC\n"], b""),
]

for args, stdin in cases:
    total += 1
    rc1, o1, e1 = run(REF, args, stdin)
    rc2, o2, e2 = run(SUT, args, stdin)
    if rc1 != rc2 or o1 != o2 or norm(e1) != norm(e2):
        fails += 1
        print(f"FAIL: args={args}")
        print(f"  stdin={stdin[:80]!r}")
        print(f"  REF rc={rc1} out={o1[:80]!r} err={norm(e1)[:80]!r}")
        print(f"  SUT rc={rc2} out={o2[:80]!r} err={norm(e2)[:80]!r}")
print(f"\n{total - fails}/{total} passed")
