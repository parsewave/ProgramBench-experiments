package main

import (
	"encoding/binary"
	"errors"
	"net"
	"os"
	"syscall"
	"time"
)

// pingResult holds one ping outcome.
type pingResult struct {
	seq  int
	ttl  int
	rtt  time.Duration
	from net.IP
}

// icmpConn wraps a packet connection plus IP family info.
type icmpConn struct {
	conn       net.PacketConn
	isIPv6     bool
	privileged bool
}

// openICMP opens the appropriate ICMP socket.
// For privileged mode, this uses net.ListenPacket("ip4:icmp", "") which
// requires CAP_NET_RAW; in unprivileged sandboxes this returns the same
// "listen ip4:icmp : socket: ..." error as the reference.
// For unprivileged mode, we use syscall.Socket(AF_INET, SOCK_DGRAM, IPPROTO_ICMP)
// wrapped via os.NewFile + net.FilePacketConn so that error formatting goes
// through Go's net package (yielding "write udp src->dst: sendmsg: ...").
func openICMP(isIPv6, privileged bool) (*icmpConn, error) {
	if privileged {
		network := "ip4:icmp"
		if isIPv6 {
			network = "ip6:ipv6-icmp"
		}
		c, err := net.ListenPacket(network, "")
		if err != nil {
			return nil, err
		}
		return &icmpConn{conn: c, isIPv6: isIPv6, privileged: true}, nil
	}

	// Unprivileged: DGRAM ICMP socket
	var (
		family = syscall.AF_INET
		proto  = syscall.IPPROTO_ICMP
	)
	if isIPv6 {
		family = syscall.AF_INET6
		proto = syscall.IPPROTO_ICMPV6
	}
	s, err := syscall.Socket(family, syscall.SOCK_DGRAM, proto)
	if err != nil {
		// Wrap in a *net.OpError so the message format matches
		// "listen <network> : socket: <err>" produced by net.ListenPacket.
		network := "udp4"
		if isIPv6 {
			network = "udp6"
		}
		return nil, &net.OpError{
			Op:  "listen",
			Net: network,
			Err: &os.SyscallError{Syscall: "socket", Err: err},
		}
	}

	// Bind to a random port so the source port shows up in errors.
	if isIPv6 {
		_ = syscall.Bind(s, &syscall.SockaddrInet6{})
	} else {
		_ = syscall.Bind(s, &syscall.SockaddrInet4{})
	}

	// Request that recvmsg returns TTL/HopLimit via control messages.
	if isIPv6 {
		// IPV6_RECVHOPLIMIT  = 51, IPV6_HOPLIMIT = 52
		_ = syscall.SetsockoptInt(s, syscall.IPPROTO_IPV6, 51, 1)
	} else {
		// IP_RECVTTL = 12
		_ = syscall.SetsockoptInt(s, syscall.IPPROTO_IP, 12, 1)
	}

	f := os.NewFile(uintptr(s), "datagram-oriented icmp")
	c, err := net.FilePacketConn(f)
	_ = f.Close() // FilePacketConn dups the fd, this releases the os.File wrapper
	if err != nil {
		syscall.Close(s)
		return nil, err
	}
	return &icmpConn{conn: c, isIPv6: isIPv6, privileged: false}, nil
}

func (c *icmpConn) Close() error { return c.conn.Close() }

// setBroadcast enables SO_BROADCAST on the underlying socket.
func setBroadcast(c *icmpConn) {
	var sc syscallConner
	if uc, ok := c.conn.(*net.UDPConn); ok {
		sc = uc
	} else if ic, ok := c.conn.(*net.IPConn); ok {
		sc = ic
	}
	if sc == nil {
		return
	}
	raw, err := sc.SyscallConn()
	if err != nil {
		return
	}
	_ = raw.Control(func(fd uintptr) {
		_ = syscall.SetsockoptInt(int(fd), syscall.SOL_SOCKET, syscall.SO_BROADCAST, 1)
	})
}

type syscallConner interface {
	SyscallConn() (syscall.RawConn, error)
}

// echoType returns the ICMP echo request type for the address family.
func (c *icmpConn) echoType() byte {
	if c.isIPv6 {
		return 128 // ICMPv6 Echo Request
	}
	return 8
}

func (c *icmpConn) replyType() byte {
	if c.isIPv6 {
		return 129
	}
	return 0
}

// sendEcho sends an ICMP echo request to dst with sequence n.
// payloadSize is the total ICMP packet size (header + data).
func (c *icmpConn) sendEcho(dst net.IP, id, seq uint16, total int) error {
	pkt := buildEchoPacket(c.echoType(), id, seq, total, c.isIPv6)
	switch conn := c.conn.(type) {
	case *net.UDPConn:
		ua := &net.UDPAddr{IP: dst, Port: 0}
		_, _, err := conn.WriteMsgUDP(pkt, nil, ua)
		return err
	case *net.IPConn:
		ia := &net.IPAddr{IP: dst}
		_, _, err := conn.WriteMsgIP(pkt, nil, ia)
		return err
	default:
		_, err := c.conn.WriteTo(pkt, &net.IPAddr{IP: dst})
		return err
	}
}

// readReply blocks for one ICMP echo reply matching seq.
// Returns the source IP, TTL, and any read error.
func (c *icmpConn) readReply(deadline time.Time, seq uint16) (net.IP, int, error) {
	for {
		_ = c.conn.SetReadDeadline(deadline)
		buf := make([]byte, 1500)
		oob := make([]byte, 128)
		var (
			n, oobn int
			err     error
			src     net.Addr
		)
		switch conn := c.conn.(type) {
		case *net.UDPConn:
			n, oobn, _, src, err = conn.ReadMsgUDP(buf, oob)
		case *net.IPConn:
			n, oobn, _, src, err = conn.ReadMsgIP(buf, oob)
		default:
			n, src, err = c.conn.ReadFrom(buf)
		}
		if err != nil {
			return nil, 0, err
		}
		// For unprivileged DGRAM the payload starts at ICMP header.
		// For privileged raw IPv4 the payload starts at IP header (we must skip it);
		// privileged raw IPv6 starts at ICMP.
		body := buf[:n]
		if c.privileged && !c.isIPv6 {
			if len(body) < 20 {
				continue
			}
			ihl := int(body[0]&0x0f) * 4
			if ihl < 20 || len(body) < ihl {
				continue
			}
			body = body[ihl:]
		}
		if len(body) < 8 {
			continue
		}
		if body[0] != c.replyType() {
			continue
		}
		gotSeq := binary.BigEndian.Uint16(body[6:8])
		if gotSeq != seq {
			continue
		}
		ttl := extractTTL(oob[:oobn], c.isIPv6)
		ip := addrIP(src)
		return ip, ttl, nil
	}
}

func addrIP(a net.Addr) net.IP {
	switch v := a.(type) {
	case *net.UDPAddr:
		return v.IP
	case *net.IPAddr:
		return v.IP
	}
	return nil
}

// extractTTL reads the TTL/HopLimit from control message data.
func extractTTL(oob []byte, isIPv6 bool) int {
	cmsgs, err := syscall.ParseSocketControlMessage(oob)
	if err != nil {
		return 0
	}
	for _, cm := range cmsgs {
		if isIPv6 {
			// IPPROTO_IPV6 = 41, IPV6_HOPLIMIT = 52
			if cm.Header.Level == syscall.IPPROTO_IPV6 && cm.Header.Type == 52 {
				if len(cm.Data) >= 4 {
					return int(binary.LittleEndian.Uint32(cm.Data[:4]))
				}
			}
		} else {
			// IPPROTO_IP = 0, IP_TTL = 2
			if cm.Header.Level == syscall.IPPROTO_IP && cm.Header.Type == 2 {
				if len(cm.Data) >= 4 {
					return int(binary.LittleEndian.Uint32(cm.Data[:4]))
				} else if len(cm.Data) >= 1 {
					return int(cm.Data[0])
				}
			}
		}
	}
	return 0
}

// buildEchoPacket constructs an ICMP echo request of the given total size.
// For IPv6, the kernel computes the checksum.
func buildEchoPacket(typ byte, id, seq uint16, total int, isIPv6 bool) []byte {
	if total < 8 {
		total = 8
	}
	pkt := make([]byte, total)
	pkt[0] = typ
	pkt[1] = 0
	binary.BigEndian.PutUint16(pkt[4:6], id)
	binary.BigEndian.PutUint16(pkt[6:8], seq)
	// Fill payload with a fixed pattern; pro-bing uses time/UUID but
	// since we only need the seq to match, byte index is fine.
	for i := 8; i < total; i++ {
		pkt[i] = byte(i - 8)
	}
	if !isIPv6 {
		cs := icmpChecksum(pkt)
		binary.BigEndian.PutUint16(pkt[2:4], cs)
	}
	return pkt
}

func icmpChecksum(b []byte) uint16 {
	var s uint32
	for i := 0; i+1 < len(b); i += 2 {
		s += uint32(b[i])<<8 | uint32(b[i+1])
	}
	if len(b)%2 == 1 {
		s += uint32(b[len(b)-1]) << 8
	}
	for s>>16 != 0 {
		s = (s & 0xffff) + (s >> 16)
	}
	return ^uint16(s)
}

var errReadTimeout = errors.New("read timeout")
