#!/bin/sh
set -e
cd "$(dirname "$0")"
export PATH=/usr/local/go/bin:$PATH
go build -o executable .
