# pingu behavior map

## CLI

```
Usage:
  pingu [OPTIONS] HOST

`ping` command but with pingu

Application Options:
  -c, --count=     Stop after <count> replies (default: 20)
  -P, --privilege  Enable privileged mode
  -V, --version    Show version

Help Options:
  -h, --help       Show this help message
```

Help text is 275 bytes, ends with `\n\n` (trailing blank line).
Help/version go to STDOUT.
All errors go to STDERR.

## Flag parsing (go-flags-compatible)

- `-c N`, `-cN`, `-c=N`, `--count N`, `--count=N` — all accepted
- Repeated flag → last wins
- `--help` / `-h` → print help (exit 0), stops further parsing
- `--version` / `-V` → print version (exit 0), but continues parsing
- `--help --version` → help wins; `--version --help` → help wins
- `--help <after parse error>` → parse error wins (e.g. `-c abc --help` → error)
- `--bogus --help` → parse error wins (parsing stops at `--bogus`)
- Bool flag with arg (`--privilege=true`) → `bool flag '-P, --privilege' cannot have an argument`
- Unknown flag → `unknown flag 'name'`
- Bad int → `invalid argument for flag '-c, --count' (expected int): strconv.ParseInt: parsing "X": <reason>`
  - `<reason>` ∈ {`invalid syntax`, `value out of range`}

Parse errors print TWICE to stderr (raw + `[ ERROR ] parse error: ` prefix), exit 1.

## Application logic

- 0 positional args: `[ ERROR ] must requires an argument\n` (typo intentional), exit 1
- 2+ positional args: `[ ERROR ] too many arguments\n`, exit 1
- Empty addr: `[ ERROR ] an error occurred while initializing pinger: failed to init pinger addr cannot be empty\n`, exit 0
- DNS NXDOMAIN: `... lookup <name>: no such host\n`, exit 0
- DNS network error: `... lookup <name> on <server>:<port>: <details>\n`, exit 0

When DNS resolves:
1. Print `PING <host> (<ip>) type \`Ctrl-C\` to abort\n` (host = original input string)
2. Open ICMP socket — if fails:
   - Privileged mode: `[ ERROR ] an error occurred when running ping: listen ip4:icmp : socket: <details>\n` (note space before `:`)
   - For ip6: `listen ip6:ipv6-icmp :`
   - exit 2, NO stats printed
3. Run ping loop (first immediately, then 1s intervals)
4. After loop, print stats:
   ```
   
   ───────── <host> ping statistics ─────────
   PACKET STATISTICS: <tx> transmitted => <rx> received (<loss>% loss)
   ROUND TRIP: min=<min> avg=<avg> max=<max> stddev=<stddev>
   ```
   (9 box-drawing chars on each side, U+2500)
5. exit 0 on success, exit 2 on any per-packet send error

Stats are printed even with 0 packets transmitted (showing `0s` for all RTT stats).

## Per-ping line format

`<58-char-frame> seq=<n> 32bytes from <ip>: ttl=<ttl> time=<duration>\n`

Frame width: 57 characters (one space after).

20 frames cycle modulo 20 (frame[seq%20]):

```
 0: ' ...        .     ...   ..    ..     .........           '
 1: ' ...     ....          ..  ..      ... .....  .. ..      '
 2: ' ...    .......      ...         ... . ..... #######     '
 3: '.....  ........ .###############.....  ... ##########.  .'
 4: ' .... ........#####################.  ... ###########    '
 5: '      ....... ######################.... ############    '
 6: '.    .  .... ########################... ###########     '
 7: '   ..   ....#########################.. .###########     '
 8: '    .       #########################.   .##########     '
 9: '   ....     .########################.      ########     '
10: '  .....      .  ####################.        #######.    '
11: '......     .. . ################## . .      .#######     '
12: '......       #####################  .      .#######      '
13: '......   .###########################  ..  #######       '
14: '...    . ########################################.       '
15: '       ####################################### .         '
16: '      ##################################    .            '
17: '     ###################################  ........       '
18: '  .#####################################    .........    '
19: ' .#######################################       .... . . '
```

## Timing

- count <= 0 → infinite ping (run until SIGINT)
- count > 0 → exact count then exit
- First ping at t=0, subsequent at t=1s, 2s, ...
- 1 second interval between sends
- SIGINT triggers clean shutdown with stats

## Duration format

Go's `time.Duration.String()`:
- 0 → "0s"
- µs (`\xc2\xb5s`), ms, s, m, h units
- Trailing zeros trimmed

## Statistics computation

- min, avg, max, stddev computed over received RTTs
- loss% = integer percent
- 32bytes = ICMP header (8) + payload (24) = 32 bytes

## Version

`pingu: v-rev9c2e3df\n`
