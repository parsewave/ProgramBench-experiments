module pingu

go 1.21
