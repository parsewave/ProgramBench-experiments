package main

import (
	"errors"
	"fmt"
	"log"
	"math"
	"net"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"
)

func main() {
	rc := run()
	os.Exit(rc)
}

func run() int {
	flags, err := parseArgs(os.Args[1:])

	if flags.help {
		os.Stdout.WriteString(helpText)
		return 0
	}
	if err != nil {
		var pe *flagParseError
		if errors.As(err, &pe) {
			fmt.Fprintln(os.Stderr, pe.msg)
			fmt.Fprintf(os.Stderr, "[ ERROR ] parse error: %s\n", pe.msg)
			return 1
		}
		fmt.Fprintf(os.Stderr, "[ ERROR ] %s\n", err)
		return 1
	}
	if flags.version {
		os.Stdout.WriteString(versionText)
		return 0
	}
	if !flags.hostSet {
		fmt.Fprintln(os.Stderr, "[ ERROR ] must requires an argument")
		return 1
	}
	if flags.extras > 0 {
		fmt.Fprintln(os.Stderr, "[ ERROR ] too many arguments")
		return 1
	}

	return doPing(flags)
}

// doPing runs the ping loop. Mirrors pingu's two-phase flow: init pinger,
// then run. Init errors exit 0 with "while initializing"; run errors exit 2
// with "when running ping". The PING header is printed only if init succeeds.
func doPing(flags parsedFlags) int {
	host := flags.host

	// Resolve the host first (init pinger phase). pro-bing checks empty before
	// calling resolver, so we match that template.
	ip, initErr := resolveHost(host)
	if initErr != nil {
		fmt.Fprintf(os.Stderr, "[ ERROR ] an error occurred while initializing pinger: failed to init pinger %s\n", initErr.Error())
		return 0
	}

	isIPv6 := ip.To4() == nil

	// Print PING header before opening sockets so behaviour matches reference
	// where the header appears regardless of subsequent socket failures.
	fmt.Printf("PING %s (%s) type `Ctrl-C` to abort\n", host, ip.String())

	conn, err := openICMP(isIPv6, flags.privilege)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[ ERROR ] an error occurred when running ping: %s\n", err.Error())
		return 2
	}
	defer conn.Close()

	// Broadcast warning (pro-bing logs INFO for broadcast addresses) and
	// enables SO_BROADCAST on the socket so kernel doesn't reject the send.
	if isBroadcast(ip) {
		log.Printf("INFO: Pinging a broadcast address")
		setBroadcast(conn)
	}

	// Run the ping loop.
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	defer signal.Stop(sigCh)

	var (
		results     []pingResult
		transmitted int
		runErr      error
		id          = uint16(os.Getpid() & 0xffff)
	)

	maxCount := flags.count
	interval := time.Second
	timeout := time.Second // per-ping receive timeout

	stop := false
	for seq := 0; !stop && (maxCount <= 0 || seq < maxCount); seq++ {
		if seq > 0 {
			select {
			case <-sigCh:
				stop = true
				break
			case <-time.After(interval):
			}
			if stop {
				break
			}
		}

		sendTime := time.Now()
		if err := conn.sendEcho(ip, id, uint16(seq), 32); err != nil {
			runErr = err
			break
		}
		transmitted++

		// Wait for matching reply or timeout
		deadline := sendTime.Add(timeout)
		from, ttl, err := conn.readReply(deadline, uint16(seq))
		if err != nil {
			// Treat timeouts as lost packets; other errors halt the loop.
			if ne, ok := err.(net.Error); ok && ne.Timeout() {
				continue
			}
			runErr = err
			break
		}
		rtt := time.Since(sendTime)

		if from == nil {
			from = ip
		}

		res := pingResult{
			seq:  seq,
			ttl:  ttl,
			rtt:  rtt,
			from: from,
		}
		results = append(results, res)
		fmt.Printf("%s seq=%d 32bytes from %s: ttl=%d time=%s\n",
			frames[seq%20], seq, from.String(), ttl, rtt.String())
	}

	printStats(host, transmitted, results)

	if runErr != nil {
		fmt.Fprintf(os.Stderr, "[ ERROR ] an error occurred when running ping: %s\n", runErr.Error())
		return 2
	}
	return 0
}

// resolveHost replicates pro-bing's NewPinger().Resolve flow: empty input
// triggers a special error; otherwise net.LookupIP is used and the first
// suitable address is returned. The error messages here are returned verbatim
// to the caller for templating.
func resolveHost(host string) (net.IP, error) {
	if host == "" {
		return nil, errors.New("addr cannot be empty")
	}
	// If it parses as a literal IP, use it directly.
	if ip := net.ParseIP(host); ip != nil {
		return ip, nil
	}
	ips, err := net.LookupIP(host)
	if err != nil {
		// Format as "lookup <name>...: <details>", matching Go's net.DNSError
		// String() which already produces this template.
		return nil, err
	}
	// Prefer IPv4 if available, matching pro-bing's resolve behavior.
	var v4, v6 net.IP
	for _, ip := range ips {
		if v4 == nil && ip.To4() != nil {
			v4 = ip
		} else if v6 == nil && ip.To4() == nil {
			v6 = ip
		}
	}
	if v4 != nil {
		return v4, nil
	}
	if v6 != nil {
		return v6, nil
	}
	return nil, errors.New("no suitable address")
}

func isBroadcast(ip net.IP) bool {
	if v4 := ip.To4(); v4 != nil {
		return v4[0] == 255 && v4[1] == 255 && v4[2] == 255 && v4[3] == 255
	}
	return false
}

// printStats writes the trailing summary block.
// Layout (UTF-8 horizontal box-drawing char U+2500, 9 per side):
//
//	\n
//	───────── <host> ping statistics ─────────
//	PACKET STATISTICS: <tx> transmitted => <rx> received (<loss>% loss)
//	ROUND TRIP: min=<min> avg=<avg> max=<max> stddev=<stddev>
func printStats(host string, transmitted int, results []pingResult) {
	const bar = "─────────"
	fmt.Printf("\n%s %s ping statistics %s\n", bar, host, bar)

	received := len(results)
	loss := 0
	if transmitted > 0 {
		loss = (transmitted - received) * 100 / transmitted
	}
	fmt.Printf("PACKET STATISTICS: %d transmitted => %d received (%d%% loss)\n", transmitted, received, loss)

	var minRTT, maxRTT, sum time.Duration
	for i, r := range results {
		if i == 0 || r.rtt < minRTT {
			minRTT = r.rtt
		}
		if r.rtt > maxRTT {
			maxRTT = r.rtt
		}
		sum += r.rtt
	}
	var avg time.Duration
	var stddev time.Duration
	if received > 0 {
		avg = sum / time.Duration(received)
		var sumSq float64
		for _, r := range results {
			d := float64(r.rtt - avg)
			sumSq += d * d
		}
		stddev = time.Duration(math.Sqrt(sumSq / float64(received)))
	}
	fmt.Printf("ROUND TRIP: min=%s avg=%s max=%s stddev=%s\n",
		minRTT.String(), avg.String(), maxRTT.String(), stddev.String())
}

// stub to keep imports tidy if some are unused on particular builds.
var _ = strings.Join
