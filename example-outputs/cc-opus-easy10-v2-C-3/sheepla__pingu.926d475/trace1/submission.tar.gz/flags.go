package main

import (
	"fmt"
	"strconv"
	"strings"
)

// parsedFlags holds the result of parsing CLI arguments.
type parsedFlags struct {
	count     int
	privilege bool
	help      bool
	version   bool
	host      string
	hostSet   bool
	extras    int
}

// flagParseError is returned when the user supplies invalid flags.
type flagParseError struct {
	msg string
}

func (e *flagParseError) Error() string { return e.msg }

// parseArgs parses CLI args in the go-flags style used by pingu.
// Returns parsed flags and an error on bad flags. If --help is seen mid-stream,
// parsing stops immediately so subsequent invalid flags don't trigger errors.
func parseArgs(args []string) (parsedFlags, error) {
	p := parsedFlags{count: 20}

	i := 0
	for i < len(args) {
		a := args[i]
		switch {
		case a == "--":
			i++
			for i < len(args) {
				p.addPositional(args[i])
				i++
			}
			return p, nil
		case strings.HasPrefix(a, "--"):
			advance, err := p.parseLong(a[2:], args, i)
			if err != nil {
				return p, err
			}
			if p.help {
				return p, nil
			}
			i = advance
		case len(a) >= 2 && a[0] == '-' && a != "-":
			advance, err := p.parseShortGroup(a, args, i)
			if err != nil {
				return p, err
			}
			if p.help {
				return p, nil
			}
			i = advance
		default:
			p.addPositional(a)
			i++
		}
	}
	return p, nil
}

func (p *parsedFlags) addPositional(s string) {
	if !p.hostSet {
		p.host = s
		p.hostSet = true
	} else {
		p.extras++
	}
}

// parseLong handles a "--name" or "--name=val" argument. Returns the
// next index to process.
func (p *parsedFlags) parseLong(raw string, args []string, i int) (int, error) {
	name, val, hasEq := strings.Cut(raw, "=")
	switch name {
	case "help":
		if hasEq {
			return i, &flagParseError{msg: "bool flag `-h, --help' cannot have an argument"}
		}
		p.help = true
		return i + 1, nil
	case "version":
		if hasEq {
			return i, &flagParseError{msg: "bool flag `-V, --version' cannot have an argument"}
		}
		p.version = true
		return i + 1, nil
	case "privilege":
		if hasEq {
			return i, &flagParseError{msg: "bool flag `-P, --privilege' cannot have an argument"}
		}
		p.privilege = true
		return i + 1, nil
	case "count":
		var s string
		next := i + 1
		if hasEq {
			s = val
		} else {
			if i+1 >= len(args) {
				return i, &flagParseError{msg: "expected argument for flag `-c, --count'"}
			}
			s = args[i+1]
			next = i + 2
		}
		n, err := strconv.ParseInt(s, 10, 64)
		if err != nil {
			return i, &flagParseError{msg: formatIntParseError(s, err)}
		}
		p.count = int(n)
		return next, nil
	default:
		return i, &flagParseError{msg: fmt.Sprintf("unknown flag `%s'", name)}
	}
}

// parseShortGroup handles an argument like "-c", "-cN", "-c=N", or
// combined short flags like "-Pc 5".
func (p *parsedFlags) parseShortGroup(a string, args []string, i int) (int, error) {
	for j := 1; j < len(a); j++ {
		c := a[j]
		switch c {
		case 'h':
			p.help = true
			return i + 1, nil
		case 'V':
			p.version = true
		case 'P':
			p.privilege = true
		case 'c':
			var s string
			rest := a[j+1:]
			if len(rest) > 0 {
				if rest[0] == '=' {
					s = rest[1:]
				} else {
					s = rest
				}
				n, err := strconv.ParseInt(s, 10, 64)
				if err != nil {
					return i, &flagParseError{msg: formatIntParseError(s, err)}
				}
				p.count = int(n)
				return i + 1, nil
			}
			if i+1 >= len(args) {
				return i, &flagParseError{msg: "expected argument for flag `-c, --count'"}
			}
			s = args[i+1]
			n, err := strconv.ParseInt(s, 10, 64)
			if err != nil {
				return i, &flagParseError{msg: formatIntParseError(s, err)}
			}
			p.count = int(n)
			return i + 2, nil
		default:
			return i, &flagParseError{msg: fmt.Sprintf("unknown flag `%c'", c)}
		}
	}
	return i + 1, nil
}

// formatIntParseError mirrors go-flags wrapping of strconv errors:
//
//	invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing "X": <reason>
func formatIntParseError(input string, err error) string {
	reason := "invalid syntax"
	if ne, ok := err.(*strconv.NumError); ok {
		switch ne.Err {
		case strconv.ErrSyntax:
			reason = "invalid syntax"
		case strconv.ErrRange:
			reason = "value out of range"
		default:
			reason = ne.Err.Error()
		}
	}
	return fmt.Sprintf("invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing %q: %s", input, reason)
}
