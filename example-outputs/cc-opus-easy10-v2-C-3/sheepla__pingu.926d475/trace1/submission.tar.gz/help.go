package main

const helpText = `Usage:
  pingu [OPTIONS] HOST

` + "`" + `ping` + "`" + ` command but with pingu

Application Options:
  -c, --count=     Stop after <count> replies (default: 20)
  -P, --privilege  Enable privileged mode
  -V, --version    Show version

Help Options:
  -h, --help       Show this help message

`

const versionText = "pingu: v-rev9c2e3df\n"
