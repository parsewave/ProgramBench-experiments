#!/usr/bin/env python3
"""Statistical top-up: generate random probes from a usage Markov chain and verify.

Following the procedure: sample fresh probes, compare reference vs reimplementation.
If all 10 match, the spec is certified.
"""
import os
import random
import subprocess
import sys
import tempfile
from pathlib import Path

B = "/work/work/target/release/executable"
R = "/workspace/executable"

random.seed(int(os.environ.get("SEED", "42")))


def run(binary, args, stdin_data=b""):
    """Run binary with args and stdin_data; return (returncode, stdout, stderr)."""
    result = subprocess.run(
        [binary] + args,
        input=stdin_data,
        capture_output=True,
        timeout=15,
    )
    return result.returncode, result.stdout, result.stderr


def random_data(size):
    return bytes(random.randint(0, 255) for _ in range(size))


def make_fixture_file(content):
    f = tempfile.NamedTemporaryFile(delete=False, dir="/tmp", prefix="tu_", suffix=".dat")
    f.write(content)
    f.close()
    return f.name


# Probe modes from Markov chain
MODES = [
    "hash_one_file",      # b3sum F
    "hash_multi_file",    # b3sum F F F
    "hash_stdin",         # echo X | b3sum
    "hash_with_flags",    # b3sum --tag --length N --seek S F
    "keyed_mode",         # echo KEY | b3sum --keyed F
    "derive_key_mode",    # echo MAT | b3sum --derive-key CTX F
    "raw_mode",           # b3sum --raw F
    "check_mode",         # b3sum -c CHECKFILE
    "check_with_quiet",   # b3sum -c --quiet CHECKFILE
    "error_case",         # various errors
]


def gen_probe():
    mode = random.choice(MODES)
    size = random.choice([0, 1, 7, 63, 64, 65, 100, 500, 1023, 1024, 1025, 2048, 4097, 10000, 100000])
    if mode == "hash_one_file":
        data = random_data(size)
        f = make_fixture_file(data)
        return [], [f], b"", "hash_one"
    if mode == "hash_multi_file":
        n = random.randint(1, 4)
        files = [make_fixture_file(random_data(size)) for _ in range(n)]
        return [], files, b"", "hash_multi"
    if mode == "hash_stdin":
        data = random_data(size)
        return [], [], data, "hash_stdin"
    if mode == "hash_with_flags":
        flags = []
        if random.random() < 0.5:
            flags += ["--tag"]
        if random.random() < 0.4:
            flags += ["--no-names"]
        if random.random() < 0.3:
            length = random.choice([0, 1, 16, 32, 64, 100, 1000])
            flags += ["-l", str(length)]
        if random.random() < 0.3:
            seek = random.choice([0, 1, 16, 32, 64, 100, 1000])
            flags += ["--seek", str(seek)]
        f = make_fixture_file(random_data(size))
        return flags, [f], b"", "hash_flags"
    if mode == "keyed_mode":
        key = random_data(32)
        f = make_fixture_file(random_data(size))
        return ["--keyed"], [f], key, "keyed"
    if mode == "derive_key_mode":
        ctx = random.choice(["", "a", "ctx", "my-app 2024-01-01", "BLAKE3 example 2020 email key"])
        f = make_fixture_file(random_data(size))
        return ["--derive-key", ctx], [f], b"", "derive"
    if mode == "raw_mode":
        f = make_fixture_file(random_data(size))
        flags = ["--raw"]
        if random.random() < 0.3:
            flags += ["-l", str(random.choice([0, 1, 16, 100]))]
        if random.random() < 0.3:
            flags += ["--seek", str(random.choice([0, 1, 32, 100]))]
        return flags, [f], b"", "raw"
    if mode == "check_mode" or mode == "check_with_quiet":
        # Make a few files, hash them, build a checkfile
        n = random.randint(1, 4)
        files = [make_fixture_file(random_data(random.choice([0, 1, 100, 1024, 5000]))) for _ in range(n)]
        # Hash them using reference
        lines = []
        for f in files:
            r = subprocess.run([R, f], capture_output=True)
            line = r.stdout.decode().strip()
            # Maybe corrupt some
            if random.random() < 0.2:
                # Replace some chars
                line = "0" * 64 + line[64:]
            lines.append(line)
        # Maybe add some bad lines
        if random.random() < 0.3:
            lines.insert(random.randint(0, len(lines)), "garbage line")
        if random.random() < 0.3:
            lines.append("")
        checkfile = make_fixture_file(("\n".join(lines) + "\n").encode())
        flags = ["-c"]
        if mode == "check_with_quiet":
            flags = ["-c", "--quiet"]
        return flags, [checkfile], b"", "check"
    if mode == "error_case":
        cases = [
            (["--bogus"], [], b""),
            (["-l", "abc"], ["fixtures/f1.txt"], b""),
            (["--keyed", "--derive-key", "x", "fixtures/f1.txt"], [], b""),
            (["--check", "--tag", "fixtures/f1.txt"], [], b""),
            (["--raw", "fixtures/f1.txt", "fixtures/f2.txt"], [], b""),
            (["--quiet", "fixtures/f1.txt"], [], b""),
            (["fixtures/f1.txt", "--bogus"], [], b""),
            (["--seek", "-1", "fixtures/f1.txt"], [], b""),
            (["--keyed", "fixtures/f1.txt"], [], b"short"),
        ]
        flags, files, stdin = random.choice(cases)
        return flags, files, stdin, "error"
    raise RuntimeError(f"unknown mode {mode}")


def compare(args, stdin_data, label):
    rc_r, out_r, err_r = run(R, args, stdin_data)
    rc_b, out_b, err_b = run(B, args, stdin_data)
    if rc_r == rc_b and out_r == out_b and err_r == err_b:
        return True, ""
    msg = [f"DIVERGE [{label}] args={args!r} stdin_len={len(stdin_data)}"]
    if rc_r != rc_b:
        msg.append(f"  rc: R={rc_r} B={rc_b}")
    if out_r != out_b:
        msg.append(f"  stdout diff:")
        msg.append(f"    R: {out_r[:200]!r}")
        msg.append(f"    B: {out_b[:200]!r}")
    if err_r != err_b:
        msg.append(f"  stderr diff:")
        msg.append(f"    R: {err_r[:200]!r}")
        msg.append(f"    B: {err_b[:200]!r}")
    return False, "\n".join(msg)


def main():
    n = int(os.environ.get("N", "10"))
    fails = 0
    for i in range(n):
        flags, files, stdin, label = gen_probe()
        args = flags + files
        ok, msg = compare(args, stdin, label)
        if ok:
            print(f"[{i+1}/{n}] PASS [{label}] {args!r}")
        else:
            print(f"[{i+1}/{n}] FAIL")
            print(msg)
            fails += 1
    print(f"\n{n - fails}/{n} PASS, {fails} FAIL")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
