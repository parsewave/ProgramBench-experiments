# b3sum behavior map (reverse-engineered)

## Identity
- Name shown in `--version`: `b3sum 1.8.4`
- Help/Usage line uses argv[0] basename (e.g., `executable`, `b3sum`)
- Per-file errors prefixed with literal `b3sum:` (not argv[0])

## Exit Codes
- `0`: success
- `1`: per-file IO error / check mismatch / `Error:` hard error
- `2`: argument parsing error (clap)

## CLI options (long form)
- `--keyed` — read 32-byte key from stdin, hash files with keyed mode
- `--derive-key <CONTEXT>` — derive key with context string
- `-l, --length <LEN>` — output length bytes (u64), default 32
- `--seek <SEEK>` — output offset (u64), default 0
- `--num-threads <NUM>` — number of threads (likely usize)
- `--no-mmap` — disable mmap (we treat as no-op effect-wise)
- `--no-names` — omit filenames
- `--raw` — write raw bytes; only one file allowed
- `--tag` — BSD-style `BLAKE3 (FILE) = HASH`
- `-c, --check` — check sums from input files
- `--quiet` — only used with --check
- `-h, --help` / `-V, --version`

## Conflict matrix (clap errors, exit 2)
- `--keyed` + `--derive-key` => "cannot be used with"
- `--check` + `--tag` => "cannot be used with"
- `--check` + `--raw` => "cannot be used with"
- `--check` + `--no-names` => "cannot be used with"
- `--check` + `--length` => "cannot be used with"
- `--check` + `--keyed` => "cannot be used with"
- `--check` + `--derive-key` => "cannot be used with"
- `--quiet` without `--check` => "required arguments were not provided: --check"
- `--keyed` without files => "required arguments were not provided: <FILE>..."
- Repeating any non-multi flag (--tag/--no-names/-l/--keyed/--no-mmap/etc) => "cannot be used multiple times"

## Output format (per file)
- Default: `HEX  PATH\n` (two spaces)
- `--tag`: `BLAKE3 (PATH) = HEX\n`
- `--no-names`: `HEX\n` (no path, no two-space gap)
- `--no-names` wins over `--tag`
- `--raw`: 32 (or -l) raw bytes, no newline
- If filename contains `\\` or `\n` or `\r`:
  - Line is prefixed with literal `\`
  - `\\` in filename → `\\\\`
  - `\n` in filename → `\\n`
  - `\r` in filename → `\\r`
  - Tab is NOT escaped (literal tab stays)
  - Applies to both default and `--tag` forms
- `--no-names`: no escape prefix (since no name)
- `--raw`: no name (one file only)

## Stdin handling
- If no positional file, read from stdin, print with name `-`
- `-` positional is stdin
- Multiple `-` allowed; second time reads remaining stdin (likely empty → empty hash)
- `--keyed` with `-` as positional: `b3sum: -: Cannot open ` + backtick + `-` + backtick + ` in keyed mode`

## Length / Seek
- `-l 0`: empty hash output → just "  PATH" line; raw outputs 0 bytes
- `-l N`: N bytes of hex output (2N hex chars)
- `--seek X`: skip X bytes of XOF output
- Both are u64; values > u64-max → clap "number too large to fit in target type"

## Error message families
- per-file (continue, exit 1 at end):
  - `b3sum: PATH: <OS_ERR_MSG> (os error <N>)`
    - e.g., `No such file or directory (os error 2)`
    - `Permission denied (os error 13)`
    - `Is a directory (os error 21)`
  - `b3sum: -: Cannot open ` + backtick + `-` + backtick + ` in keyed mode`
- hard `Error:` (exit 1):
  - `Error: No such file or directory (os error 2)` (e.g., for missing checkfile)
  - `Error: expected 32 key bytes from stdin, found N`
  - `Error: read more than 32 key bytes from stdin`
  - `Error: Only one filename can be provided when using --raw`

## --check mode
- One or more checkfiles (can be `-` for stdin)
- Each line parsed as either:
  - Default: `^(\\)?HEX  PATH$` where HEX is exactly 64 hex chars
  - Tag:    `^(\\)?BLAKE3 \(PATH\) = HEX$`
  - If line starts with `\`, then PATH is decoded: `\\\\` → `\`, `\\n` → newline, `\\r` → CR
- Per-line outcomes:
  - `b3sum: Empty line` — empty line in checkfile (counted as bad)
  - `b3sum: Invalid check line format` — unrecognized format
  - `b3sum: Invalid hash length` — hex not exactly 64 chars
  - `PATH: OK`
  - `PATH: FAILED` — hash mismatch
  - `PATH: FAILED (No such file or directory (os error 2))` — file missing
- PATH in output is the ORIGINAL escaped form (including leading `\` if present)
- After all lines: `b3sum: WARNING: N computed checksum(s) did NOT match`
  - Singular: "1 computed checksum did NOT match"
  - Plural: "N computed checksums did NOT match"
- Bad lines (Empty/Invalid format/Invalid hash length) all count toward N
- Exit code 1 if N > 0, else 0
- `--quiet`: suppress `PATH: OK` lines (still show FAILED + WARNING)
- Each checkfile processed in sequence. Missing checkfile aborts processing of that file with `Error: <msg>`.
- Empty checkfile: exit 0

## Hash determinism / test vectors
- Empty input: `af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262`
- `"abc"` (no newline): `6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85`
- BLAKE3 standard test vectors confirmed for `0..251` bytes cycled lengths
- Keyed/derive-key follow standard BLAKE3 spec
- Output is deterministic (no timestamps, RNG, etc.)

## Other details
- Repeated calls deterministic
- Trailing newline present in default/tag/no-names; absent in --raw
- Hex output is lowercase
- Stdin (when used as input file) shows path `-`
- File errors propagate per-file in multi-file mode (continue processing)
