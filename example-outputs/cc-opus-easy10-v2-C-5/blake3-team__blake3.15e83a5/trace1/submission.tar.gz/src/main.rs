mod blake3;

use clap::Parser;
use std::fs::File;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

const NAME_PREFIX: &str = "b3sum";

#[derive(Parser, Debug)]
#[command(
    version = "1.8.4",
    name = "b3sum",
    disable_help_subcommand = true,
    arg_required_else_help = false,
    next_line_help = false,
)]
struct Args {
    /// Files to hash, or checkfiles to check
    ///
    /// When no file is given, or when - is given, read standard input.
    #[arg(value_name = "FILE")]
    file: Vec<PathBuf>,

    /// Use the keyed mode, reading the 32-byte key from stdin
    #[arg(long, conflicts_with = "derive_key", conflicts_with = "check", requires = "file")]
    keyed: bool,

    /// Use the key derivation mode, with the given context string
    ///
    /// Cannot be used with --keyed.
    #[arg(long = "derive-key", value_name = "CONTEXT", conflicts_with = "check")]
    derive_key: Option<String>,

    /// The number of output bytes, before hex encoding
    #[arg(short, long, value_name = "LEN", default_value_t = 32, conflicts_with = "check")]
    length: u64,

    /// The starting output byte offset, before hex encoding
    #[arg(long, default_value_t = 0)]
    seek: u64,

    /// The maximum number of threads to use
    ///
    /// By default, this is the number of logical cores. If this flag is omitted, or if its value
    /// is 0, RAYON_NUM_THREADS is also respected.
    #[arg(long = "num-threads", value_name = "NUM")]
    num_threads: Option<usize>,

    /// Disable memory mapping
    ///
    /// Currently this also disables multithreading.
    #[arg(long = "no-mmap")]
    no_mmap: bool,

    /// Omit filenames in the output
    #[arg(long = "no-names", conflicts_with = "check")]
    no_names: bool,

    /// Write raw output bytes to stdout, rather than hex
    ///
    /// --no-names is implied. In this case, only a single input is allowed.
    #[arg(long, conflicts_with = "check")]
    raw: bool,

    /// Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]
    #[arg(long, conflicts_with = "check")]
    tag: bool,

    /// Read BLAKE3 sums from the [FILE]s and check them
    #[arg(short, long)]
    check: bool,

    /// Skip printing OK for each checked file
    ///
    /// Must be used with --check.
    #[arg(long, requires = "check")]
    quiet: bool,
}

fn read_key_from_stdin() -> anyhow::Result<[u8; 32]> {
    let mut buf = [0u8; 33];
    let mut read = 0;
    let mut stdin = io::stdin().lock();
    loop {
        let n = stdin.read(&mut buf[read..])?;
        if n == 0 {
            break;
        }
        read += n;
        if read >= 33 {
            break;
        }
    }
    if read > 32 {
        anyhow::bail!("read more than 32 key bytes from stdin");
    }
    if read < 32 {
        anyhow::bail!("expected 32 key bytes from stdin, found {}", read);
    }
    let mut key = [0u8; 32];
    key.copy_from_slice(&buf[..32]);
    Ok(key)
}

#[derive(Clone, Copy)]
enum HashMode {
    Regular,
    Keyed([u8; 32]),
    DeriveKey,
}

struct HasherFactory {
    mode: HashMode,
    derive_context: Option<String>,
}

impl HasherFactory {
    fn new_hasher(&self) -> blake3::Hasher {
        match &self.mode {
            HashMode::Regular => blake3::Hasher::new(),
            HashMode::Keyed(key) => blake3::Hasher::new_keyed(key),
            HashMode::DeriveKey => blake3::Hasher::new_derive_key(
                self.derive_context.as_deref().unwrap_or(""),
            ),
        }
    }
}

fn to_hex(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push_str(&format!("{:02x}", b));
    }
    s
}

fn hash_reader<R: Read>(reader: &mut R, factory: &HasherFactory) -> io::Result<blake3::Hasher> {
    let mut hasher = factory.new_hasher();
    let mut buf = vec![0u8; 65536];
    loop {
        let n = reader.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }
    Ok(hasher)
}

fn path_needs_escape(path: &Path) -> bool {
    use std::os::unix::ffi::OsStrExt;
    let bytes = path.as_os_str().as_bytes();
    bytes.iter().any(|&b| b == b'\\' || b == b'\n' || b == b'\r')
}

fn escape_path_bytes(path: &Path) -> Vec<u8> {
    use std::os::unix::ffi::OsStrExt;
    let bytes = path.as_os_str().as_bytes();
    let mut out = Vec::with_capacity(bytes.len() + 4);
    for &b in bytes {
        match b {
            b'\\' => out.extend_from_slice(b"\\\\"),
            b'\n' => out.extend_from_slice(b"\\n"),
            b'\r' => out.extend_from_slice(b"\\r"),
            _ => out.push(b),
        }
    }
    out
}

fn path_bytes(path: &Path) -> Vec<u8> {
    use std::os::unix::ffi::OsStrExt;
    path.as_os_str().as_bytes().to_vec()
}

fn write_output_line(stdout: &mut impl Write, args: &Args, path: Option<&Path>, hex: &str, raw_bytes: Option<&[u8]>) -> io::Result<()> {
    if args.raw {
        if let Some(b) = raw_bytes {
            stdout.write_all(b)?;
        }
        return Ok(());
    }
    if args.no_names {
        stdout.write_all(hex.as_bytes())?;
        stdout.write_all(b"\n")?;
        return Ok(());
    }
    let path = path.expect("path required");
    let needs_escape = path_needs_escape(path);
    if needs_escape {
        stdout.write_all(b"\\")?;
    }
    let path_out: Vec<u8> = if needs_escape {
        escape_path_bytes(path)
    } else {
        path_bytes(path)
    };
    if args.tag {
        stdout.write_all(b"BLAKE3 (")?;
        stdout.write_all(&path_out)?;
        stdout.write_all(b") = ")?;
        stdout.write_all(hex.as_bytes())?;
    } else {
        stdout.write_all(hex.as_bytes())?;
        stdout.write_all(b"  ")?;
        stdout.write_all(&path_out)?;
    }
    stdout.write_all(b"\n")?;
    Ok(())
}

fn hash_one_file(path: &Path, factory: &HasherFactory) -> io::Result<blake3::Hasher> {
    let mut file = File::open(path)?;
    hash_reader(&mut file, factory)
}

fn hash_stdin(factory: &HasherFactory) -> io::Result<blake3::Hasher> {
    let mut stdin = io::stdin().lock();
    hash_reader(&mut stdin, factory)
}

fn produce_hash_bytes(hasher: &blake3::Hasher, length: u64, seek: u64) -> Vec<u8> {
    let mut buf = vec![0u8; length as usize];
    hasher.finalize_seek(seek, &mut buf);
    buf
}

fn do_hashing(args: &Args, factory: &HasherFactory) -> i32 {
    let mut exit_code = 0;
    let stdout = io::stdout();
    let mut stdout = stdout.lock();
    let stderr = io::stderr();

    let files: Vec<PathBuf> = if args.file.is_empty() {
        vec![PathBuf::from("-")]
    } else {
        args.file.clone()
    };

    if args.raw && files.len() > 1 {
        eprintln!("Error: Only one filename can be provided when using --raw");
        return 1;
    }

    for file in &files {
        let path_str = file.to_string_lossy();
        let is_stdin = path_str == "-";

        if matches!(factory.mode, HashMode::Keyed(_)) && is_stdin {
            let mut stderr = stderr.lock();
            let _ = writeln!(stderr, "{}: -: Cannot open `-` in keyed mode", NAME_PREFIX);
            exit_code = 1;
            continue;
        }

        let result = if is_stdin {
            hash_stdin(factory)
        } else {
            hash_one_file(file, factory)
        };
        match result {
            Ok(hasher) => {
                let bytes = produce_hash_bytes(&hasher, args.length, args.seek);
                let hex = to_hex(&bytes);
                let _ = write_output_line(&mut stdout, args, Some(file), &hex, Some(&bytes));
            }
            Err(err) => {
                let mut stderr = stderr.lock();
                let _ = writeln!(stderr, "{}: {}: {}", NAME_PREFIX, path_str, err);
                exit_code = 1;
            }
        }
    }
    exit_code
}

// --- Check mode ---

enum ParsedLine<'a> {
    Empty,
    Invalid,
    InvalidHashLen,
    InvalidHex,
    EmptyPath,
    Ok {
        escaped: bool,
        hex: &'a str,
        path_field: &'a str, // the path as written in checkfile (escaped form, no prefix)
    },
}

fn parse_check_line(line: &str) -> ParsedLine<'_> {
    // Strip trailing \n / \r\n
    let line = line.trim_end_matches('\n').trim_end_matches('\r');
    if line.is_empty() {
        return ParsedLine::Empty;
    }
    // Detect escape prefix `\` at start
    let (escaped, body) = if let Some(rest) = line.strip_prefix('\\') {
        (true, rest)
    } else {
        (false, line)
    };
    // Default form has priority: HEX + "  " + PATH (two spaces)
    if let Some(idx) = body.find("  ") {
        let hex = &body[..idx];
        let path_field = &body[idx + 2..];
        if hex.len() != 64 {
            return ParsedLine::InvalidHashLen;
        }
        if !is_lowercase_hex(hex) {
            return ParsedLine::InvalidHex;
        }
        if path_field.is_empty() {
            return ParsedLine::EmptyPath;
        }
        return ParsedLine::Ok { escaped, hex, path_field };
    }
    // Fallback to tag form: "BLAKE3 (PATH) = HEX"
    if let Some(after_blake3) = body.strip_prefix("BLAKE3 (") {
        if let Some(close_idx) = after_blake3.rfind(") = ") {
            let path_field = &after_blake3[..close_idx];
            let hex = &after_blake3[close_idx + 4..];
            if hex.len() != 64 {
                return ParsedLine::InvalidHashLen;
            }
            if !is_lowercase_hex(hex) {
                return ParsedLine::InvalidHex;
            }
            if path_field.is_empty() {
                return ParsedLine::EmptyPath;
            }
            return ParsedLine::Ok { escaped, hex, path_field };
        }
        return ParsedLine::Invalid;
    }
    ParsedLine::Invalid
}

fn is_lowercase_hex(s: &str) -> bool {
    !s.is_empty() && s.bytes().all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f'))
}

fn unescape_path(escaped: &str) -> Option<Vec<u8>> {
    let bytes = escaped.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b == b'\\' {
            if i + 1 >= bytes.len() {
                return None;
            }
            match bytes[i + 1] {
                b'\\' => out.push(b'\\'),
                b'n' => out.push(b'\n'),
                b'r' => out.push(b'\r'),
                _ => return None,
            }
            i += 2;
        } else {
            out.push(b);
            i += 1;
        }
    }
    Some(out)
}

fn do_check(args: &Args, factory: &HasherFactory) -> anyhow::Result<i32> {
    let files: Vec<PathBuf> = if args.file.is_empty() {
        vec![PathBuf::from("-")]
    } else {
        args.file.clone()
    };

    let stdout = io::stdout();
    let mut stdout = stdout.lock();
    let stderr = io::stderr();

    let mut mismatch_count: u64 = 0;

    for checkfile in &files {
        let path_str = checkfile.to_string_lossy();
        let content = if path_str == "-" {
            let mut s = String::new();
            io::stdin().lock().read_to_string(&mut s)?;
            s
        } else {
            std::fs::read_to_string(checkfile)?
        };

        let mut parts: Vec<&str> = content.split('\n').collect();
        if let Some(last) = parts.last() {
            if last.is_empty() && (content.ends_with('\n') || content.is_empty()) {
                parts.pop();
            }
        }
        for line in &parts {
            let parsed = parse_check_line(line);
            match parsed {
                ParsedLine::Empty => {
                    let mut stderr = stderr.lock();
                    let _ = writeln!(stderr, "{}: Empty line", NAME_PREFIX);
                    mismatch_count += 1;
                }
                ParsedLine::Invalid => {
                    let mut stderr = stderr.lock();
                    let _ = writeln!(stderr, "{}: Invalid check line format", NAME_PREFIX);
                    mismatch_count += 1;
                }
                ParsedLine::InvalidHashLen => {
                    let mut stderr = stderr.lock();
                    let _ = writeln!(stderr, "{}: Invalid hash length", NAME_PREFIX);
                    mismatch_count += 1;
                }
                ParsedLine::InvalidHex => {
                    let mut stderr = stderr.lock();
                    let _ = writeln!(stderr, "{}: Invalid hex", NAME_PREFIX);
                    mismatch_count += 1;
                }
                ParsedLine::EmptyPath => {
                    let mut stderr = stderr.lock();
                    let _ = writeln!(stderr, "{}: empty file path", NAME_PREFIX);
                    mismatch_count += 1;
                }
                ParsedLine::Ok { escaped, hex, path_field } => {
                    // Decode path
                    let path_bytes = if escaped {
                        match unescape_path(path_field) {
                            Some(b) => b,
                            None => {
                                let mut stderr = stderr.lock();
                                let _ = writeln!(stderr, "{}: Invalid backslash escape", NAME_PREFIX);
                                mismatch_count += 1;
                                continue;
                            }
                        }
                    } else {
                        path_field.as_bytes().to_vec()
                    };
                    use std::os::unix::ffi::OsStrExt;
                    let path = Path::new(std::ffi::OsStr::from_bytes(&path_bytes));

                    // The displayed file path keeps the original (prefix + escaped form)
                    let display_field: Vec<u8> = if escaped {
                        let mut v = vec![b'\\'];
                        v.extend_from_slice(path_field.as_bytes());
                        v
                    } else {
                        path_field.as_bytes().to_vec()
                    };

                    // Compute hash
                    let is_stdin = path_bytes == b"-";
                    let hash_result = if is_stdin {
                        hash_stdin(factory)
                    } else {
                        hash_one_file(path, factory)
                    };
                    match hash_result {
                        Ok(hasher) => {
                            let mut got = [0u8; 32];
                            hasher.finalize(&mut got);
                            let got_hex = to_hex(&got);
                            if got_hex.eq_ignore_ascii_case(hex) {
                                if !args.quiet {
                                    stdout.write_all(&display_field)?;
                                    stdout.write_all(b": OK\n")?;
                                }
                            } else {
                                stdout.write_all(&display_field)?;
                                stdout.write_all(b": FAILED\n")?;
                                mismatch_count += 1;
                            }
                        }
                        Err(err) => {
                            stdout.write_all(&display_field)?;
                            stdout.write_all(b": FAILED (")?;
                            stdout.write_all(err.to_string().as_bytes())?;
                            stdout.write_all(b")\n")?;
                            mismatch_count += 1;
                        }
                    }
                }
            }
        }
    }

    if mismatch_count > 0 {
        let stderr = io::stderr();
        let mut stderr = stderr.lock();
        if mismatch_count == 1 {
            let _ = writeln!(stderr, "{}: WARNING: 1 computed checksum did NOT match", NAME_PREFIX);
        } else {
            let _ = writeln!(stderr, "{}: WARNING: {} computed checksums did NOT match", NAME_PREFIX, mismatch_count);
        }
        return Ok(1);
    }
    Ok(0)
}

fn main() {
    let args = Args::parse();

    // Decide mode
    let factory = if args.keyed {
        match read_key_from_stdin() {
            Ok(key) => HasherFactory { mode: HashMode::Keyed(key), derive_context: None },
            Err(e) => {
                eprintln!("Error: {}", e);
                std::process::exit(1);
            }
        }
    } else if let Some(ctx) = &args.derive_key {
        HasherFactory { mode: HashMode::DeriveKey, derive_context: Some(ctx.clone()) }
    } else {
        HasherFactory { mode: HashMode::Regular, derive_context: None }
    };

    let exit_code = if args.check {
        match do_check(&args, &factory) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("Error: {}", e);
                1
            }
        }
    } else {
        do_hashing(&args, &factory)
    };
    std::process::exit(exit_code);
}
