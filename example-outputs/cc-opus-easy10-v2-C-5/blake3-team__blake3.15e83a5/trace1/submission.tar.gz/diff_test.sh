#!/usr/bin/env bash
# Differential test framework: compare our binary against the reference
B="${B:-/work/work/target/release/executable}"
R="${R:-/workspace/executable}"
FIX_DIR="${FIX_DIR:-/work/work/fixtures}"
PASS=0
FAIL=0
FAILED_NAMES=()

run_probe() {
    local name="$1"
    local stdin_path="${2:-/dev/null}"
    shift 2
    local b_out b_err b_code r_out r_err r_code
    b_out=$(mktemp); b_err=$(mktemp)
    r_out=$(mktemp); r_err=$(mktemp)
    "$B" "$@" <"$stdin_path" >"$b_out" 2>"$b_err"
    b_code=$?
    "$R" "$@" <"$stdin_path" >"$r_out" 2>"$r_err"
    r_code=$?
    local ok=1
    if ! cmp -s "$b_out" "$r_out"; then ok=0; fi
    if ! cmp -s "$b_err" "$r_err"; then ok=0; fi
    if [ "$b_code" != "$r_code" ]; then ok=0; fi
    if [ "$ok" = "1" ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILED_NAMES+=("$name")
        if [ "${VERBOSE:-0}" = "1" ]; then
            echo "FAIL: $name (codes B=$b_code R=$r_code)"
            echo "--- stdout diff ---"
            diff "$b_out" "$r_out" | head -30
            echo "--- stderr diff ---"
            diff "$b_err" "$r_err" | head -30
        fi
    fi
    rm -f "$b_out" "$b_err" "$r_out" "$r_err"
}

# Basic
run_probe version /dev/null --version
run_probe help_long /dev/null --help
run_probe help_short /dev/null -h
run_probe no_args /dev/null
run_probe stdin_abc $FIX_DIR/f1.txt
# File
run_probe file_f1 /dev/null $FIX_DIR/f1.txt
run_probe file_multi /dev/null $FIX_DIR/f1.txt $FIX_DIR/f2.txt
run_probe file_empty /dev/null $FIX_DIR/empty.txt
run_probe file_missing /dev/null /tmp/nonexistent_xyz_123
run_probe file_dash $FIX_DIR/f1.txt -
run_probe file_mixed /dev/null $FIX_DIR/f1.txt /tmp/nonexistent_xyz_123 $FIX_DIR/f2.txt
# Length
run_probe length_0 /dev/null -l 0 $FIX_DIR/f1.txt
run_probe length_1 /dev/null -l 1 $FIX_DIR/f1.txt
run_probe length_64 /dev/null -l 64 $FIX_DIR/f1.txt
run_probe length_negative /dev/null -l -1 $FIX_DIR/f1.txt
run_probe length_abc /dev/null -l abc $FIX_DIR/f1.txt
run_probe length_huge /dev/null -l 99999999999999999999999 $FIX_DIR/f1.txt
# Seek
run_probe seek_0 /dev/null --seek 0 $FIX_DIR/f1.txt
run_probe seek_1 /dev/null --seek 1 $FIX_DIR/f1.txt
run_probe seek_32 /dev/null --seek 32 $FIX_DIR/f1.txt
run_probe seek_16_len_16 /dev/null --seek 16 -l 16 $FIX_DIR/f1.txt
# Tag/no-names
run_probe tag /dev/null --tag $FIX_DIR/f1.txt
run_probe tag_multi /dev/null --tag $FIX_DIR/f1.txt $FIX_DIR/f2.txt
run_probe tag_stdin $FIX_DIR/f1.txt --tag
run_probe noname /dev/null --no-names $FIX_DIR/f1.txt
run_probe noname_multi /dev/null --no-names $FIX_DIR/f1.txt $FIX_DIR/f2.txt
run_probe noname_tag /dev/null --no-names --tag $FIX_DIR/f1.txt
run_probe tag_noname /dev/null --tag --no-names $FIX_DIR/f1.txt
# Raw
run_probe raw /dev/null --raw $FIX_DIR/f1.txt
run_probe raw_multi /dev/null --raw $FIX_DIR/f1.txt $FIX_DIR/f2.txt
run_probe raw_len5 /dev/null --raw -l 5 $FIX_DIR/f1.txt
# Special filenames
run_probe esc_backslash /dev/null "$FIX_DIR/has\\backslash"
run_probe esc_backslash_tag /dev/null --tag "$FIX_DIR/has\\backslash"
# Errors
run_probe bogus /dev/null --bogus
run_probe keyed_no_file /dev/null --keyed
run_probe keyed_no_file_stdin $FIX_DIR/f1.txt --keyed
run_probe derive_no_file /dev/null --derive-key ctx
run_probe derive_keyed /dev/null --keyed --derive-key ctx $FIX_DIR/f1.txt
run_probe quiet_no_check /dev/null --quiet $FIX_DIR/f1.txt
run_probe check_no_tag /dev/null --check --tag $FIX_DIR/f1.txt
run_probe repeat_tag /dev/null --tag --tag $FIX_DIR/f1.txt
# Keyed
KEY32=$(mktemp)
head -c 32 /dev/zero > "$KEY32"
run_probe keyed_zeros "$KEY32" --keyed $FIX_DIR/f1.txt
# Derive
DK=$(mktemp)
echo "key material" > "$DK"
run_probe derive_ctx "$DK" --derive-key "ctx" $FIX_DIR/f1.txt
run_probe derive_multi "$DK" --derive-key "ctx" $FIX_DIR/f1.txt $FIX_DIR/f2.txt
run_probe derive_empty "$DK" --derive-key "" $FIX_DIR/f1.txt
# Hash test vectors via stdin
TV0=$(mktemp); :> "$TV0"
TV3=$(mktemp); printf "abc" > "$TV3"
TV1024=$(mktemp); python3 -c "import sys; sys.stdout.buffer.write(bytes([i % 251 for i in range(1024)]))" > "$TV1024"
TV1025=$(mktemp); python3 -c "import sys; sys.stdout.buffer.write(bytes([i % 251 for i in range(1025)]))" > "$TV1025"
TV2048=$(mktemp); python3 -c "import sys; sys.stdout.buffer.write(bytes([i % 251 for i in range(2048)]))" > "$TV2048"
TV4096=$(mktemp); python3 -c "import sys; sys.stdout.buffer.write(bytes([i % 251 for i in range(4096)]))" > "$TV4096"
TV100K=$(mktemp); python3 -c "import sys; sys.stdout.buffer.write(bytes([i % 251 for i in range(102400)]))" > "$TV100K"
run_probe hash_empty "$TV0"
run_probe hash_abc "$TV3"
run_probe hash_1024 "$TV1024"
run_probe hash_1025 "$TV1025"
run_probe hash_2048 "$TV2048"
run_probe hash_4096 "$TV4096"
run_probe hash_100k "$TV100K"
# Check mode
C_OK=$(mktemp)
echo "aa95faeede7041e63c6056bdcf10e6fbf709a355e539259da51a067e5dd27802  $FIX_DIR/f1.txt" > "$C_OK"
run_probe check_ok /dev/null -c "$C_OK"
run_probe check_ok_quiet /dev/null -c --quiet "$C_OK"
C_BAD=$(mktemp)
echo "0000000000000000000000000000000000000000000000000000000000000000  $FIX_DIR/f1.txt" > "$C_BAD"
run_probe check_bad /dev/null -c "$C_BAD"
C_TAG=$(mktemp)
$R --tag $FIX_DIR/f1.txt $FIX_DIR/f2.txt > "$C_TAG"
run_probe check_tag /dev/null -c "$C_TAG"
C_EMPTY=$(mktemp); :> "$C_EMPTY"
run_probe check_empty /dev/null -c "$C_EMPTY"
run_probe check_missing /dev/null -c /tmp/nonexistent_check_xyz
C_MIXED=$(mktemp)
cat > "$C_MIXED" <<MIXED
aa95faeede7041e63c6056bdcf10e6fbf709a355e539259da51a067e5dd27802  $FIX_DIR/f1.txt
0000000000000000000000000000000000000000000000000000000000000000  $FIX_DIR/f2.txt
not a real line

aa95faeede7041e63c6056bdcf10e6fbf709a355e539259da51a067e5dd27802  /tmp/nonexistent_xyz_123
MIXED
run_probe check_mixed /dev/null -c "$C_MIXED"
run_probe check_mixed_quiet /dev/null -c --quiet "$C_MIXED"

# Misc
run_probe num_threads /dev/null --num-threads 1 $FIX_DIR/f1.txt
run_probe num_threads_0 /dev/null --num-threads 0 $FIX_DIR/f1.txt
run_probe no_mmap /dev/null --no-mmap $FIX_DIR/f1.txt
run_probe no_mmap_repeat /dev/null --no-mmap --no-mmap $FIX_DIR/f1.txt
run_probe dash_dash /dev/null -- $FIX_DIR/f1.txt
run_probe dash_dash_stdin $FIX_DIR/f1.txt --

echo ""
echo "PASS: $PASS"
echo "FAIL: $FAIL"
if [ "$FAIL" -gt 0 ]; then
    echo "FAILED tests:"
    for n in "${FAILED_NAMES[@]}"; do echo "  - $n"; done
fi
