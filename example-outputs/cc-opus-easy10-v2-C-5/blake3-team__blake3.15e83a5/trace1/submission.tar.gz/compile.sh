#!/usr/bin/env bash
# Build the b3sum reimplementation. Produces ./executable in /work/work/.
set -e
cd "$(dirname "$0")"
export PATH="/usr/local/cargo/bin:$PATH"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"

cargo build --offline --release --quiet
cp -f target/release/executable ./executable
chmod +x ./executable
