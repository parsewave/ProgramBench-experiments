#define _XOPEN_SOURCE_EXTENDED
#define _DEFAULT_SOURCE
#include <ctype.h>
#include <errno.h>
#include <locale.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <ncurses.h>

static volatile sig_atomic_t signal_flag = 0;

static void usage(void) {
    printf(" Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n");
    printf(" -a: Asynchronous scroll\n");
    printf(" -b: Bold characters on\n");
    printf(" -B: All bold characters (overrides -b)\n");
    printf(" -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n");
    printf(" -f: Force the linux $TERM type to be on\n");
    printf(" -l: Linux mode (uses matrix console font)\n");
    printf(" -L: Lock mode (can be closed from another terminal)\n");
    printf(" -o: Use old-style scrolling\n");
    printf(" -h: Print usage and exit\n");
    printf(" -n: No bold characters (overrides -b and -B, default)\n");
    printf(" -s: \"Screensaver\" mode, exits on first keystroke\n");
    printf(" -x: X window mode, use if your xterm is using mtx.pcf\n");
    printf(" -V: Print version information and exit\n");
    printf(" -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n");
    printf(" -u delay (0 - 10, default 4): Screen update delay\n");
    printf(" -C [color]: Use this color for matrix (default green)\n");
    printf(" -r: rainbow mode\n");
    printf(" -m: lambda mode\n");
    printf(" -k: Characters change while scrolling. (Works without -o opt.)\n");
    printf(" -t [tty]: Set tty to use\n");
}

static void version(void) {
    printf(" CMatrix version 2.0 (compiled %s, %s)\n", __TIME__, __DATE__);
    printf("Email: abishekvashok@gmail.com\n");
    printf("Web: https://github.com/abishekvashok/cmatrix\n");
}

static int parse_color(const char *s) {
    if (!strcasecmp(s, "green"))   return COLOR_GREEN;
    if (!strcasecmp(s, "red"))     return COLOR_RED;
    if (!strcasecmp(s, "blue"))    return COLOR_BLUE;
    if (!strcasecmp(s, "white"))   return COLOR_WHITE;
    if (!strcasecmp(s, "yellow"))  return COLOR_YELLOW;
    if (!strcasecmp(s, "cyan"))    return COLOR_CYAN;
    if (!strcasecmp(s, "magenta")) return COLOR_MAGENTA;
    if (!strcasecmp(s, "black"))   return COLOR_BLACK;
    return -1;
}

static void on_signal(int sig) {
    (void)sig;
    signal_flag = 1;
}

static void finalize(void) {
    curs_set(1);
    clear();
    refresh();
    resetty();
    endwin();
}

static int rand_char(int use_lambda, int use_japanese) {
    if (use_lambda)
        return (int)'\xce' << 8 | 0xbb;
    if (use_japanese) {
        return ' ' + (rand() % 94);
    }
    int r = rand() % 94;
    return ' ' + 1 + r;
}

int main(int argc, char **argv) {
    int async = 0, bold = 0, force_term = 0, linux_mode = 0;
    int old_style = 0, japanese = 0, lock_mode = 0;
    int no_bold = 0, screensaver = 0, xwindow = 0;
    int rainbow = 0, lambda = 0, changes = 0;
    int update = 4;
    int color = COLOR_GREEN;
    char *message = NULL;
    char *tty_path = NULL;
    FILE *tty_file = NULL;

    setlocale(LC_ALL, "");

    opterr = 0;
    int opt;
    while ((opt = getopt(argc, argv, "abBcfhlLnrosmxkVM:u:C:t:?")) != -1) {
        switch (opt) {
        case 'a': async = 1; break;
        case 'b': bold = 1; break;
        case 'B': bold = 2; break;
        case 'c': japanese = 1; break;
        case 'f': force_term = 1; break;
        case 'l': linux_mode = 1; break;
        case 'L': lock_mode = 1; break;
        case 'n': no_bold = 1; bold = 0; break;
        case 'o': old_style = 1; break;
        case 'r': rainbow = 1; break;
        case 's': screensaver = 1; break;
        case 'm': lambda = 1; break;
        case 'x': xwindow = 1; break;
        case 'k': changes = 1; break;
        case 'h':
        case '?':
            usage();
            exit(0);
        case 'V':
            version();
            exit(0);
        case 'u':
            update = atoi(optarg);
            break;
        case 'C': {
            int c = parse_color(optarg);
            if (c < 0) {
                fprintf(stderr, " Invalid color selection\n");
                fprintf(stderr, " Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n");
                exit(0);
            }
            color = c;
            break;
        }
        case 'M':
            message = optarg;
            break;
        case 't':
            tty_path = optarg;
            break;
        }
    }

    (void)async; (void)bold; (void)force_term; (void)linux_mode;
    (void)old_style; (void)japanese; (void)lock_mode; (void)no_bold;
    (void)screensaver; (void)xwindow; (void)rainbow; (void)lambda;
    (void)changes; (void)update; (void)color; (void)message;

    if (tty_path) {
        tty_file = fopen(tty_path, "r+");
        if (!tty_file) {
            fprintf(stderr, "cmatrix: error: '%s' couldn't be opened: %s.\n",
                    tty_path, strerror(errno));
            exit(1);
        }
        SCREEN *term = newterm(NULL, tty_file, stdin);
        if (!term) {
            exit(1);
        }
        set_term(term);
    } else {
        initscr();
    }

    signal(SIGINT, on_signal);
    signal(SIGQUIT, on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGWINCH, on_signal);

    noecho();
    cbreak();
    keypad(stdscr, TRUE);
    curs_set(0);
    nodelay(stdscr, TRUE);
    if (has_colors()) {
        start_color();
        init_pair(1, color, COLOR_BLACK);
        init_pair(2, COLOR_WHITE, COLOR_BLACK);
        init_pair(3, COLOR_RED, COLOR_BLACK);
        init_pair(4, COLOR_GREEN, COLOR_BLACK);
        init_pair(5, COLOR_YELLOW, COLOR_BLACK);
        init_pair(6, COLOR_BLUE, COLOR_BLACK);
        init_pair(7, COLOR_MAGENTA, COLOR_BLACK);
        init_pair(8, COLOR_CYAN, COLOR_BLACK);
    }

    srand((unsigned int)time(NULL));

    int rows = LINES;
    int cols = COLS;
    if (rows < 3) rows = 3;
    if (cols < 3) cols = 3;

    int *head = calloc(cols, sizeof(int));
    int *speed = calloc(cols, sizeof(int));
    int *length = calloc(cols, sizeof(int));
    if (!head || !speed || !length) {
        finalize();
        exit(1);
    }
    for (int i = 0; i < cols; i++) {
        head[i] = -(rand() % rows);
        speed[i] = 1 + (rand() % 3);
        length[i] = 5 + (rand() % (rows > 10 ? rows - 5 : 5));
    }

    int delay_us = 10000 + update * 5000;
    if (delay_us < 10000) delay_us = 10000;

    int iter = 0;
    while (!signal_flag) {
        if (screensaver) {
            int ch = getch();
            if (ch != ERR) break;
        } else {
            int ch = getch();
            if (ch == 'q' && !lock_mode) break;
        }

        for (int c = 0; c < cols; c++) {
            int h = head[c];
            if (h >= 0 && h < rows) {
                attron(COLOR_PAIR(2) | A_BOLD);
                mvaddch(h, c, rand_char(lambda, japanese));
                attroff(COLOR_PAIR(2) | A_BOLD);
            }
            int tail = h - length[c];
            if (tail >= 0 && tail < rows) {
                mvaddch(tail, c, ' ');
            }
            for (int k = 1; k < length[c]; k++) {
                int y = h - k;
                if (y < 0 || y >= rows) continue;
                attron(COLOR_PAIR(1));
                if (bold == 2 || (bold == 1 && (rand() & 1))) {
                    attron(A_BOLD);
                }
                mvaddch(y, c, rand_char(lambda, japanese));
                attroff(A_BOLD);
                attroff(COLOR_PAIR(1));
            }
            head[c] += speed[c];
            if (head[c] - length[c] > rows + 2) {
                head[c] = -(rand() % 10);
                speed[c] = 1 + (rand() % 3);
                length[c] = 5 + (rand() % (rows > 10 ? rows - 5 : 5));
            }
        }

        if (message) {
            int mlen = (int)strlen(message);
            int mx = (cols - mlen) / 2;
            int my = rows / 2;
            if (mx >= 0 && my >= 0 && my < rows) {
                attron(COLOR_PAIR(2) | A_BOLD);
                mvaddnstr(my, mx, message, mlen);
                attroff(COLOR_PAIR(2) | A_BOLD);
            }
        }

        refresh();
        usleep(delay_us);
        iter++;
    }

    free(head); free(speed); free(length);
    finalize();
    if (tty_file) fclose(tty_file);
    return 0;
}
