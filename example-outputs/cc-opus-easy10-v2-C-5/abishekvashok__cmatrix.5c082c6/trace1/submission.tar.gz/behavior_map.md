# cmatrix behavior map

## Identification

- ELF x86_64 binary built from cmatrix source
- Uses ncurses for terminal rendering
- Self-describes as "CMatrix version 2.0"

## CLI surface

Argument parsing via `getopt(3)` with optstring approximately:
`abBcfhlLmnorsVxk?u:C:M:t:` (silenced via `opterr=0` or `:` prefix; missing args
and unknown opts both fall through to the usage path).

### Flags taking no argument

- `-a` async scroll
- `-b` bold
- `-B` all bold
- `-c` japanese chars
- `-f` force linux TERM
- `-l` linux mode
- `-L` lock mode
- `-m` lambda mode
- `-n` no bold
- `-o` old scroll
- `-r` rainbow
- `-s` screensaver (exits on keypress)
- `-x` xwindow mode
- `-k` characters change

### Flags exiting immediately

- `-h`, `-?`, `--help`, `--<anything>` (unknown long), `-<unknown short>` — print usage to STDOUT (972 bytes), exit 0
- `-V` — print version to STDOUT (131 bytes), exit 0
- `-C <invalid color>` — print invalid-color message to STDERR (101 bytes), exit 0
- `-t <missing or non-openable file>` — `cmatrix: error: '<path>' couldn't be opened: <strerror>.` to STDERR, exit 1

### Flags accepting an argument

- `-u <delay>` — any string accepted at parse time (validated nowhere; cast to int)
- `-C <color>` — case-insensitive match against {green, red, blue, white, yellow, cyan, magenta, black}
- `-M <message>` — accepted as-is
- `-t <tty>` — opened with `fopen(path, "w")` (Permission denied on /etc/passwd ⇒ "w" mode)

### Missing required arg

For `-u`, `-M`, `-C`, `-t` as the last arg with no value: prints usage, exit 0.
(Same path as unknown option.)

### Special argv tokens

- `--` alone or as a terminator: stops option processing, proceeds
- `-` alone: positional, ignored, proceeds
- positional args (e.g. `foo bar`): proceed (GNU getopt reorders)
- `foo -h`: reordered, `-h` takes effect

## Outputs (frozen as goldens in goldens/)

### help.stdout (972 bytes, exit 0, stderr empty)

```
 Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
```

Every line is prefixed by a single space (printed as ` Usage:`, ` -a:`, etc.).

### version.stdout (131 bytes, exit 0, stderr empty)

```
 CMatrix version 2.0 (compiled HH:MM:SS, Mon DD YYYY)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
```

The HH:MM:SS and Mon DD YYYY are __TIME__ and __DATE__ at build time
(reference shows `19:59:42, Apr 17 2026`). Leading space is only on the first
line. Total length 131 bytes assuming Apr 17 2026 — would still be 131 if
the date format width matches.

### invalid_color.stderr (101 bytes, stdout empty, exit 0)

```
 Invalid color selection
 Valid colors are green, red, blue, white, yellow, cyan, magenta and black.
```

### ncurses_fail.stderr (33 bytes, stdout empty, exit 1)

```
Error opening terminal: unknown.
```

This is ncurses' own `Error opening terminal: <TERM>.\n`. The trailing
period belongs to ncurses' message.

### tty open errors (variable bytes, stdout empty, exit 1)

```
cmatrix: error: '<path>' couldn't be opened: <strerror(errno)>.
```

Examples:
- `/tmp/missing` → `... couldn't be opened: No such file or directory.`
- `/etc/passwd` → `... couldn't be opened: Permission denied.` (writable mode `"w"`)

## Process model

- One-shot paths exit immediately (help, version, invalid color, tty error).
- Other paths call `initscr()`. Without a usable TERM, ncurses prints
  "Error opening terminal: <TERM>." and exits 1 itself.
- With a usable TERM, runs the matrix animation, streaming until killed.
- The first ~80 bytes of stream output are deterministic (ncurses init
  escape sequences: smcup, cursor positioning, attribute reset).

## Notes for reimplementation

- Argv parsing: use `getopt(3)` with the optstring above and `opterr=0`.
  Switch on returned char; for `?` (and missing-arg if applicable), call
  usage()-then-exit(0).
- Help: write ` Usage:...\n` plus 20 ` -X: desc\n` lines to stdout.
- Version: write ` CMatrix version 2.0 (compiled %s, %s)\nEmail:...\nWeb:...\n`
  using `__TIME__` and `__DATE__`.
- Invalid color: write to stderr with leading-space lines (2 lines).
- Tty error: `fprintf(stderr, "cmatrix: error: '%s' couldn't be opened: %s.\n", path, strerror(errno))`.
- Main animation: call `initscr()` (ncurses handles the unknown-TERM error
  for us), then loop drawing random characters until killed.
