#!/bin/sh
set -e
cd "$(dirname "$0")"
gcc -O2 -o executable main.c -lncurses
