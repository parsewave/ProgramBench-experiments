compile.sh
