# csview 1.3.4 behavior map

## Binary identity

- `csview 1.3.4`, Rust binary built with clap 4.5, csv 1.3, unicode-width 0.2.
- Help title: "A high performance csv viewer with cjk/emoji support."
- Usage: `Usage: executable [OPTIONS] [FILE]`

## CLI flags (in help order)

| Short | Long | Type | Default | Notes |
|---|---|---|---|---|
| `-H` | `--no-headers` | flag | off | first row is body, not header |
| `-n` | `--number` | flag | off | prepend `#` line-number column |
| `-t` | `--tsv` | flag | off | tab delimiter; conflicts with `-d` |
| `-d` | `--delimiter` | char | `,` | exactly 1 char |
| `-s` | `--style` | enum | `sharp` | `none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid` |
| `-p` | `--padding` | u32 | `1` | non-negative integer |
| `-i` | `--indent` | u32 | `0` | non-negative integer |
|  | `--sniff` | u32 | `1000` | width-sniff body row count limit, 0 = no limit |
|  | `--header-align` | enum | `center` | `left, center, right` |
|  | `--body-align` | enum | `left` | `left, center, right` |
| `-P` | `--disable-pager` | flag | off | inert when stdout is not a TTY |
| `-h` | `--help` | flag | | next-line help template |
| `-V` | `--version` | flag | | prints `csview 1.3.4` |

## Errors and exit codes

- clap parse: exit 2, clap-formatted stderr.
- file IO / dir / open: `csview: <err> (os error N)`, exit 1.
- CSV parse: `csview: CSV ...`, exit 1.

## CSV parsing

- csv crate, `flexible=false`, BOM auto-strip, blank lines skipped.
- Multi-line quoted fields preserved verbatim (embedded `\n` visually breaks rendering).

## Table model

Per column inner width = `max_display_width + 2 * padding`.

### Alignment
- left: pad_left=padding, fill_right
- right: pad_right=padding, fill_left
- center: split fill (left = floor((W-w)/2))

Default: header center, body left.

### Sniff
- Width determined from header + first `sniff` body rows (or all if `sniff=0`).
- Rows beyond sniff are truncated (`unicode-truncate`, no ellipsis).

### -n quirk
- The `#` column width's content max is `(buffered_body_count + 1).to_string().len()`,
  i.e., one digit wider than the highest index actually used.

## Styles

All styles share a `(top, mid, bot, vert)` glyph set. `grid` adds a mid
separator between every body-row pair; others only between header and body.

## Streaming
- Sniff buffers up to N body rows. Errors during buffering => stderr only,
  no stdout.
- Errors mid-stream => stdout up to that point + bottom border omitted.
- In `grid` style, the mid-sep is printed *before* attempting the next read,
  so a mid-stream error leaves a trailing separator above the error message.

## Empty input
- Zero columns, zero body, no `-H` => placeholder body row.
- `-H` + empty => no placeholder.
- `-n` always reserves a `#` column.
