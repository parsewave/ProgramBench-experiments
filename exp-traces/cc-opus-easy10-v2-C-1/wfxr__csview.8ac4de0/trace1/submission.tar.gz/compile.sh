#!/bin/bash
# Build csview reimplementation.
set -u
cd "$(dirname "$0")"

# Try to use any cargo we can find.
for cargo_bin in /usr/local/cargo/bin/cargo "$HOME/.cargo/bin/cargo" "$(command -v cargo)"; do
    if [[ -x "$cargo_bin" ]]; then
        export PATH="$(dirname "$cargo_bin"):$PATH"
        break
    fi
done

# Use the system CARGO_HOME if set, else /usr/local/cargo.
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"

# Build. If the cached registry has all dependencies, --offline succeeds.
# If not, fall back to online build.
if cargo build --release --offline 2>&1; then
    cp -f target/release/executable ./executable
    exit 0
fi

# Fallback: online build.
if cargo build --release 2>&1; then
    cp -f target/release/executable ./executable
    exit 0
fi

# If everything fails but a pre-built binary exists, use it as-is.
if [[ -x ./executable ]]; then
    echo "Build failed; using pre-built executable." >&2
    exit 0
fi

echo "Build failed and no pre-built executable available." >&2
exit 1
