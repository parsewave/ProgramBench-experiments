use std::fs::File;
use std::io::{self, Read, Write, BufWriter};
use std::process::ExitCode;

use clap::{Parser, ValueEnum};
use unicode_truncate::UnicodeTruncateStr;
use unicode_width::UnicodeWidthStr;

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
#[clap(rename_all = "lower")]
enum Style {
    None,
    Ascii,
    Ascii2,
    Sharp,
    Rounded,
    Reinforced,
    Markdown,
    Grid,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
#[clap(rename_all = "lower")]
enum Align {
    Left,
    Center,
    Right,
}

#[derive(Parser, Debug)]
#[command(
    name = "csview",
    version = "1.3.4",
    about = "A high performance csv viewer with cjk/emoji support.",
    next_line_help = true,
)]
struct Cli {
    /// Specify that the input has no header row
    #[arg(short = 'H', long)]
    no_headers: bool,

    /// Prepend a column of line numbers to the table
    #[arg(short = 'n', long)]
    number: bool,

    /// Use '\t' as delimiter for tsv
    #[arg(short = 't', long, conflicts_with = "delimiter")]
    tsv: bool,

    /// Specify the field delimiter
    #[arg(short = 'd', long, default_value = ",", conflicts_with = "tsv")]
    delimiter: char,

    /// Specify the border style
    #[arg(short = 's', long, default_value = "sharp", value_enum)]
    style: Style,

    /// Specify padding for table cell
    #[arg(short = 'p', long, default_value_t = 1)]
    padding: u32,

    /// Specify global indent for table
    #[arg(short = 'i', long, default_value_t = 0)]
    indent: u32,

    /// Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
    #[arg(long, default_value_t = 1000, value_name = "LIMIT")]
    sniff: u32,

    /// Specify the alignment of the table header
    #[arg(long, default_value = "center", value_enum)]
    header_align: Align,

    /// Specify the alignment of the table body
    #[arg(long, default_value = "left", value_enum)]
    body_align: Align,

    /// Disable pager
    #[arg(short = 'P', long)]
    disable_pager: bool,

    /// File to view
    file: Option<String>,
}

struct Glyphs {
    top: Option<(&'static str, &'static str, &'static str, &'static str)>,
    mid: Option<(&'static str, &'static str, &'static str, &'static str)>,
    bot: Option<(&'static str, &'static str, &'static str, &'static str)>,
    vert: (&'static str, &'static str, &'static str),
    grid: bool,
}

fn glyphs(style: Style) -> Glyphs {
    match style {
        Style::None => Glyphs {
            top: None, mid: None, bot: None,
            vert: ("", "", ""), grid: false,
        },
        Style::Ascii => Glyphs {
            top: Some(("+", "-", "+", "+")),
            mid: Some(("+", "-", "+", "+")),
            bot: Some(("+", "-", "+", "+")),
            vert: ("|", "|", "|"), grid: false,
        },
        Style::Ascii2 => Glyphs {
            top: None,
            mid: Some((" ", "-", "+", " ")),
            bot: None,
            vert: (" ", "|", " "), grid: false,
        },
        Style::Sharp => Glyphs {
            top: Some(("┌", "─", "┬", "┐")),
            mid: Some(("├", "─", "┼", "┤")),
            bot: Some(("└", "─", "┴", "┘")),
            vert: ("│", "│", "│"), grid: false,
        },
        Style::Rounded => Glyphs {
            top: Some(("╭", "─", "┬", "╮")),
            mid: Some(("├", "─", "┼", "┤")),
            bot: Some(("╰", "─", "┴", "╯")),
            vert: ("│", "│", "│"), grid: false,
        },
        Style::Reinforced => Glyphs {
            top: Some(("┏", "─", "┬", "┓")),
            mid: Some(("├", "─", "┼", "┤")),
            bot: Some(("┗", "─", "┴", "┛")),
            vert: ("│", "│", "│"), grid: false,
        },
        Style::Markdown => Glyphs {
            top: None,
            mid: Some(("|", "-", "|", "|")),
            bot: None,
            vert: ("|", "|", "|"), grid: false,
        },
        Style::Grid => Glyphs {
            top: Some(("┌", "─", "┬", "┐")),
            mid: Some(("├", "─", "┼", "┤")),
            bot: Some(("└", "─", "┴", "┘")),
            vert: ("│", "│", "│"), grid: true,
        },
    }
}

fn display_width(s: &str) -> usize {
    UnicodeWidthStr::width(s)
}

fn render_cell(content: &str, inner_width: usize, padding: usize, align: Align) -> String {
    let cw = display_width(content);
    let content_max = inner_width.saturating_sub(2 * padding);
    let (truncated, truncated_w) = if cw > content_max {
        let (t, w) = content.unicode_truncate(content_max);
        (t.to_string(), w)
    } else {
        (content.to_string(), cw)
    };

    let total_fill = inner_width.saturating_sub(truncated_w);
    match align {
        Align::Left => {
            let pad_left = padding.min(total_fill);
            let pad_right = total_fill - pad_left;
            format!("{}{}{}", " ".repeat(pad_left), truncated, " ".repeat(pad_right))
        }
        Align::Right => {
            let pad_right = padding.min(total_fill);
            let pad_left = total_fill - pad_right;
            format!("{}{}{}", " ".repeat(pad_left), truncated, " ".repeat(pad_right))
        }
        Align::Center => {
            let pad_left = total_fill / 2;
            let pad_right = total_fill - pad_left;
            format!("{}{}{}", " ".repeat(pad_left), truncated, " ".repeat(pad_right))
        }
    }
}

fn render_row<W: Write>(
    out: &mut W,
    cells: &[String],
    widths: &[usize],
    glyphs: &Glyphs,
    padding: usize,
    align: Align,
    indent: usize,
) -> io::Result<()> {
    write!(out, "{}", " ".repeat(indent))?;
    write!(out, "{}", glyphs.vert.0)?;
    for (i, (cell, &w)) in cells.iter().zip(widths.iter()).enumerate() {
        write!(out, "{}", render_cell(cell, w, padding, align))?;
        if i + 1 == cells.len() {
            write!(out, "{}", glyphs.vert.2)?;
        } else {
            write!(out, "{}", glyphs.vert.1)?;
        }
    }
    writeln!(out)?;
    Ok(())
}

fn render_border<W: Write>(
    out: &mut W,
    widths: &[usize],
    border: (&str, &str, &str, &str),
    indent: usize,
) -> io::Result<()> {
    write!(out, "{}", " ".repeat(indent))?;
    write!(out, "{}", border.0)?;
    for (i, &w) in widths.iter().enumerate() {
        for _ in 0..w {
            write!(out, "{}", border.1)?;
        }
        if i + 1 == widths.len() {
            write!(out, "{}", border.3)?;
        } else {
            write!(out, "{}", border.2)?;
        }
    }
    writeln!(out)?;
    Ok(())
}

fn run() -> i32 {
    let cli = Cli::parse();

    let delimiter: u8 = if cli.tsv {
        b'\t'
    } else {
        let mut buf = [0u8; 4];
        let s = cli.delimiter.encode_utf8(&mut buf);
        s.as_bytes()[0]
    };

    let input: Box<dyn Read> = if let Some(file) = &cli.file {
        match File::open(file) {
            Ok(f) => Box::new(f),
            Err(e) => {
                eprintln!("csview: {}", e);
                return 1;
            }
        }
    } else {
        Box::new(io::stdin())
    };

    let mut rdr = csv::ReaderBuilder::new()
        .delimiter(delimiter)
        .has_headers(false)
        .flexible(false)
        .from_reader(input);

    let mut record_iter = rdr.records().peekable();

    // Read header (1st record) if not -H.
    let mut headers: Vec<String> = Vec::new();
    if !cli.no_headers {
        if let Some(result) = record_iter.next() {
            match result {
                Ok(rec) => {
                    headers = rec.iter().map(|s| s.to_string()).collect();
                }
                Err(e) => {
                    eprintln!("csview: {}", e);
                    return 1;
                }
            }
        }
    }

    if cli.number {
        let mut new_h = vec!["#".to_string()];
        new_h.extend(headers.into_iter());
        headers = new_h;
    }

    let sniff_limit: Option<usize> = if cli.sniff == 0 {
        None
    } else {
        Some(cli.sniff as usize)
    };

    // Buffer body rows up to sniff_limit (or all if None).
    let mut buffered: Vec<Vec<String>> = Vec::new();
    let mut body_index: usize = 0;
    loop {
        if let Some(limit) = sniff_limit {
            if buffered.len() >= limit {
                break;
            }
        }
        match record_iter.next() {
            None => break,
            Some(Ok(rec)) => {
                let mut v: Vec<String> = rec.iter().map(|s| s.to_string()).collect();
                if cli.number {
                    body_index += 1;
                    let mut vv = vec![body_index.to_string()];
                    vv.extend(v.into_iter());
                    v = vv;
                }
                buffered.push(v);
            }
            Some(Err(e)) => {
                eprintln!("csview: {}", e);
                return 1;
            }
        }
    }

    // Determine number of columns from headers + buffered.
    let mut num_cols = headers.len();
    for row in &buffered {
        num_cols = num_cols.max(row.len());
    }

    // Compute widths.
    let mut col_widths: Vec<usize> = vec![0; num_cols];
    for (i, c) in headers.iter().enumerate() {
        if i < num_cols {
            col_widths[i] = col_widths[i].max(display_width(c));
        }
    }
    for row in &buffered {
        for (i, c) in row.iter().enumerate() {
            if i < num_cols {
                col_widths[i] = col_widths[i].max(display_width(c));
            }
        }
    }
    if cli.number && num_cols > 0 {
        let needed = (buffered.len() + 1).to_string().len();
        col_widths[0] = col_widths[0].max(needed);
    }

    let padding = cli.padding as usize;
    let indent = cli.indent as usize;
    let inner_widths: Vec<usize> = col_widths.iter().map(|w| w + 2 * padding).collect();
    let render_headers = !cli.no_headers;
    let g = glyphs(cli.style);

    // Check if any body exists (buffered or peek-ahead).
    let has_body = !buffered.is_empty() || record_iter.peek().is_some();

    let empty_table = num_cols == 0 && !has_body;

    let stdout = io::stdout();
    let lock = stdout.lock();
    let mut out = BufWriter::new(lock);

    if empty_table {
        if let Some(top) = g.top {
            write!(out, "{}", " ".repeat(indent)).ok();
            write!(out, "{}{}", top.0, top.3).ok();
            writeln!(out).ok();
        }
        if render_headers {
            write!(out, "{}", " ".repeat(indent)).ok();
            write!(out, "{}{}", g.vert.0, g.vert.2).ok();
            writeln!(out).ok();
        }
        if let Some(bot) = g.bot {
            write!(out, "{}", " ".repeat(indent)).ok();
            write!(out, "{}{}", bot.0, bot.3).ok();
            writeln!(out).ok();
        }
        out.flush().ok();
        return 0;
    }

    // Top border
    if let Some(top) = g.top {
        if render_border(&mut out, &inner_widths, top, indent).is_err() {
            return 1;
        }
    }

    // Header
    if render_headers {
        let mut padded_h = headers.clone();
        while padded_h.len() < num_cols { padded_h.push(String::new()); }
        if render_row(&mut out, &padded_h, &inner_widths, &g, padding, cli.header_align, indent).is_err() {
            return 1;
        }
        if has_body {
            if let Some(mid) = g.mid {
                if render_border(&mut out, &inner_widths, mid, indent).is_err() {
                    return 1;
                }
            }
        }
    }

    let mut any_body_rendered = false;

    // Render buffered body rows.
    for row in &buffered {
        if any_body_rendered && g.grid {
            if let Some(mid) = g.mid {
                if render_border(&mut out, &inner_widths, mid, indent).is_err() {
                    return 1;
                }
            }
        }
        let mut padded = row.clone();
        while padded.len() < num_cols { padded.push(String::new()); }
        if render_row(&mut out, &padded, &inner_widths, &g, padding, cli.body_align, indent).is_err() {
            return 1;
        }
        any_body_rendered = true;
    }

    // Stream remaining body rows (only if there was a sniff limit and possibly more to read).
    if sniff_limit.is_some() {
        while record_iter.peek().is_some() {
            if any_body_rendered && g.grid {
                if let Some(mid) = g.mid {
                    if render_border(&mut out, &inner_widths, mid, indent).is_err() {
                        return 1;
                    }
                }
            }
            match record_iter.next() {
                Some(Ok(rec)) => {
                    let mut v: Vec<String> = rec.iter().map(|s| s.to_string()).collect();
                    if cli.number {
                        body_index += 1;
                        let mut vv = vec![body_index.to_string()];
                        vv.extend(v.into_iter());
                        v = vv;
                    }
                    while v.len() < num_cols { v.push(String::new()); }
                    if render_row(&mut out, &v, &inner_widths, &g, padding, cli.body_align, indent).is_err() {
                        return 1;
                    }
                    any_body_rendered = true;
                }
                Some(Err(e)) => {
                    out.flush().ok();
                    drop(out);
                    eprintln!("csview: {}", e);
                    return 1;
                }
                None => break,
            }
        }
    }

    // Bottom border
    if let Some(bot) = g.bot {
        if render_border(&mut out, &inner_widths, bot, indent).is_err() {
            return 1;
        }
    }

    out.flush().ok();
    0
}

fn main() -> ExitCode {
    ExitCode::from(run() as u8)
}
