#!/usr/bin/env bash
# Build the htmlq reimplementation as ./executable.
# Simply emits a shell wrapper that invokes python3 on htmlq.py.
set -e
cd "$(dirname "$0")"

cat > executable <<'EOF'
#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$DIR/htmlq.py" "$@"
EOF

chmod +x executable
