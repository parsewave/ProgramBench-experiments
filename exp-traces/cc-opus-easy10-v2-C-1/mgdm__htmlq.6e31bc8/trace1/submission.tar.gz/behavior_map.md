# htmlq 0.4.0 behavioral spec (from probing /workspace/executable)

## Binary
- Rust binary, htmlq 0.4.0 by Michael Maclean
- Uses html5ever 0.25.2, kuchiki 0.8.1, selectors 0.22.0, cssparser 0.27.2, clap 2.34.0

## CLI

```
USAGE: executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
  -B, --detect-base        Detect base URL from <base> tag
  -h, --help               Help, exit 0
  -w, --ignore-whitespace  Skip whitespace-only text nodes when -t
  -p, --pretty             Pretty-print output
  -t, --text               Print text content only
  -V, --version            Print version, exit 0

OPTIONS:
  -a, --attribute <attr>      Output only this attribute value
  -b, --base <url>            Base URL for resolving relative links
  -f, --filename <FILE>       Input file (default stdin)
  -o, --output <FILE>         Output file (default stdout)
  -r, --remove-nodes <SEL>... Remove matching nodes before output (greedy: consumes multiple values)

ARGS:
  <selector>...  CSS selector(s); multiple are JOINED WITH SPACE; default "html"
```

### Argument parsing quirks
- `-r script html` consumes BOTH as -r values (greedy multi-value).
- Multiple positional selectors are joined with space (e.g., `div p` ≡ "div p" descendant).
- Use `--` to separate flags from positionals.
- Invalid flag → stderr "error: Found argument..." + exit 1
- Invalid CSS selector → panic, exit 101, stderr "Failed to parse CSS selector: ()"

## HTML parsing (html5ever)
- Implicit `<html><head></head><body>` wrapping for fragments.
- Tag names and attribute names lowercased.
- Attribute values case-preserved.
- Void elements (no closing tag): area, base, basefont, bgsound, br, col, embed, frame, hr, img, input, keygen, link, meta, param, source, track, wbr.
- Raw text elements (no entity decode): style, script, xmp, iframe, noembed, noframes, plaintext, noscript.
- Table tree: implicit tbody/tr insertion.
- p auto-close on new block.
- li auto-close on new li.
- BOM (0xEFBBBF) stripped.
- NUL bytes removed.
- Entities decoded during parsing.

## Selection
- Default selector "html" (the `<html>` element).
- Each matched element serialized + "\n".
- Multiple positional args joined with space.
- Document-order, no duplicates.

## Serialization (html5ever-style)
- Attribute order: SORTED alphabetically.
- All attributes quoted with double-quotes.
- Boolean attributes get `=""` (e.g., `<input disabled>` → `<input disabled="">`).
- Text escape: `&` → `&amp;`, `<` → `&lt;`, `>` → `&gt;`, U+00A0 → `&nbsp;`.
- Attribute value escape: `&` → `&amp;`, `"` → `&quot;`, U+00A0 → `&nbsp;`.
- NO escape for `<`, `>` in attribute values.
- Void elements: no closing tag, no self-closing slash.
- Raw text elements: contents NOT escaped (kept as text).
- Trailing `\n` after each match.

## -t (text mode)
- Concatenates ALL descendant text nodes of the selected element.
- Without -w: text nodes concatenated directly (no separator).
- With -w: each non-whitespace text node followed by `\n`; whitespace-only nodes SKIPPED.
- Match separator `\n` appended to each match.

## -a <attr> (attribute mode)
- Elements WITHOUT the attribute are SKIPPED (no output).
- Elements WITH attribute: output value + `\n`.
- Attribute value entities ARE decoded (printed as actual chars).
- Overrides -t and -p.

## -p (pretty print)
- Each match prefixed with `\n`.
- Block elements: newline + indent (4 spaces per level) before opening tag.
- Inline elements: kept on same line as parent.
- Inline elements: a, abbr, acronym, audio, b, bdi, bdo, big, br, button, canvas, cite, code, data, datalist, del, dfn, em, embed, i, iframe, img, input, ins, kbd, label, map, mark, math, meter, noscript, object, output, picture, progress, q, ruby, s, samp, script, select, slot, small, span, strong, sub, sup, svg, template, textarea, time, u, tt, var, video, wbr
- Text node inside block elements is printed inline (no newline) if it's the FIRST child.
- Subsequent text/element children get newline + indent.

## -b <url> (base URL)
- Resolves relative URLs in `href` and `src` attributes of selected elements.
- Invalid base URL: skip resolution (output as-is).
- Empty base "": skip resolution.

## -B (detect base)
- Looks for `<base href="...">` in document.
- If found, use as base. Otherwise fall back to `-b` value if supplied.

## -r <selector> (remove nodes)
- Variadic / greedy: consumes multiple values until next flag.
- Removes matching nodes from tree before serialization.
- KNOWN BUG: in 0.4.0, selecting an ANCESTOR of a removed node returns empty output. We implement CORRECTLY (just remove the nodes).

## -f / -o file I/O
- -f missing file: panic, exit 101
- -f directory: error message, exit 1
- -o bad path: panic, exit 101

## Exit codes
- 0: success
- 1: bad flag
- 101: panic (invalid selector, missing file)
