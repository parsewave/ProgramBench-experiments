#!/usr/bin/env python3
"""htmlq reimplementation in pure Python stdlib.

Approximates htmlq 0.4.0 (https://github.com/mgdm/htmlq) behavior:
HTML5 parsing, CSS selector matching, html5ever-style serialization.
"""
import sys
import os
import io
import re
import html
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

# ============================================================
# Element categorization (per HTML5 spec / kuchiki / htmlq)
# ============================================================

VOID_ELEMENTS = {
    "area", "base", "basefont", "bgsound", "br", "col", "embed", "frame",
    "hr", "img", "input", "keygen", "link", "meta", "param", "source",
    "track", "wbr",
}

RAW_TEXT_ELEMENTS = {
    "style", "script", "xmp", "iframe", "noembed", "noframes", "plaintext",
}

# Elements where pretty-printer keeps content inline.
# Derived empirically from probing /workspace/executable.
# Notably EXCLUDES: br, math, font (which htmlq treats as block-ish).
INLINE_ELEMENTS = {
    "a", "abbr", "acronym", "audio", "b", "bdi", "bdo", "big", "button",
    "canvas", "cite", "code", "data", "datalist", "del", "dfn", "em", "embed",
    "i", "iframe", "img", "input", "ins", "kbd", "label", "map", "mark",
    "meter", "noscript", "object", "output", "picture", "progress",
    "q", "ruby", "s", "samp", "script", "select", "slot", "small", "span",
    "strong", "sub", "sup", "svg", "template", "textarea", "time", "u", "tt",
    "var", "video", "wbr",
}

# Elements whose closure forces closure of in-scope <p>
P_CLOSING_ELEMENTS = {
    "address", "article", "aside", "blockquote", "center", "details",
    "dialog", "dir", "div", "dl", "fieldset", "figcaption", "figure",
    "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup",
    "hr", "main", "menu", "nav", "ol", "p", "pre", "section", "summary",
    "table", "ul", "li", "dd", "dt", "blockquote",
}

# ============================================================
# Tree node types
# ============================================================

class Node:
    __slots__ = ("kind", "tag", "attrs", "data", "children", "parent")

    def __init__(self, kind, tag=None, attrs=None, data=None):
        self.kind = kind          # 'document', 'element', 'text', 'comment', 'doctype'
        self.tag = tag            # for elements: tag name (lowercase)
        self.attrs = attrs or {}  # for elements: dict {name: value} (insertion order; we sort on serialize)
        self.data = data          # for text/comment/doctype: content
        self.children = []
        self.parent = None

    def append(self, child):
        # If appending text and last child is text, merge (per HTML5 tree builder behavior).
        if child.kind == "text" and self.children and self.children[-1].kind == "text":
            self.children[-1].data += child.data
            return
        child.parent = self
        self.children.append(child)

    def detach(self):
        if self.parent is not None:
            try:
                self.parent.children.remove(self)
            except ValueError:
                pass
            self.parent = None

    def iter_descendants(self):
        """Document-order iteration of all descendants (not including self)."""
        for ch in list(self.children):
            yield ch
            yield from ch.iter_descendants()

    def iter_self_and_descendants(self):
        yield self
        yield from self.iter_descendants()

    def text_content(self):
        """Concatenate all descendant text nodes."""
        out = []
        for n in self.iter_self_and_descendants():
            if n.kind == "text":
                out.append(n.data)
        return "".join(out)

    def descendant_text_nodes(self):
        for n in self.iter_self_and_descendants():
            if n.kind == "text":
                yield n


# ============================================================
# HTML5 parser (built on html.parser with HTML5 tree-building rules)
# ============================================================

class TreeBuilder(HTMLParser):
    """Build a kuchiki-like tree from HTML, with key HTML5 quirks."""

    def __init__(self):
        # convert_charrefs=False so we get explicit entity callbacks for raw text elements.
        # Actually, we want entities decoded for normal text and NOT for script/style.
        # html.parser's behavior with convert_charrefs=True is to decode entities in text.
        # We'll handle script/style ourselves via CDATA mode.
        super().__init__(convert_charrefs=True)
        self.document = Node("document")
        self.html = None    # <html> element
        self.head = None    # <head>
        self.body = None    # <body>
        self.open_stack = [self.document]   # currently open elements
        self.in_raw_text = None  # tag name if we're inside script/style/etc.

    def _ensure_html(self):
        if self.html is None:
            self.html = Node("element", tag="html")
            self.document.append(self.html)
            self.open_stack.append(self.html)

    def _ensure_head(self):
        self._ensure_html()
        if self.head is None:
            self.head = Node("element", tag="head")
            self.html.append(self.head)

    def _ensure_body(self):
        self._ensure_html()
        if self.head is None:
            self.head = Node("element", tag="head")
            self.html.append(self.head)
        # Pop head if currently open.
        while self.open_stack and self.open_stack[-1].kind == "element" and self.open_stack[-1].tag == "head":
            self.open_stack.pop()
        if self.body is None:
            self.body = Node("element", tag="body")
            self.html.append(self.body)
            self.open_stack.append(self.body)

    def current(self):
        return self.open_stack[-1] if self.open_stack else self.document

    def _has_in_scope(self, tag):
        """Crude in-scope check: is `tag` open above us?"""
        for n in reversed(self.open_stack):
            if n.kind == "element" and n.tag == tag:
                return True
        return False

    def _close_until(self, tag):
        """Close elements until we close `tag`."""
        while self.open_stack:
            top = self.open_stack[-1]
            self.open_stack.pop()
            if top.kind == "element" and top.tag == tag:
                return

    def _close_implicit_p(self):
        """If <p> is in scope when a P-closing element opens, close it."""
        if self._has_in_scope("p"):
            self._close_until("p")

    def _close_li(self):
        if self._has_in_scope("li"):
            self._close_until("li")

    def _close_dt_dd(self):
        for tag in ("dt", "dd"):
            if self._has_in_scope(tag):
                self._close_until(tag)
                break

    def _normalize_attrs(self, attrs):
        # html.parser gives list of (name, value); value can be None.
        out = {}
        for name, value in attrs:
            name = name.lower()
            if name in out:
                continue   # first occurrence wins (per HTML5 spec)
            out[name] = value if value is not None else ""
        return out

    def _insert_element(self, tag, attrs):
        # Phase: where to insert?
        # - Before <html>: tag goes into html (or starts html if 'html').
        # - In <head> phase: certain tags go into head, others trigger body.
        # - In body: normal insertion.

        # Handle <html> specifically.
        if tag == "html":
            if self.html is None:
                self.html = Node("element", tag="html", attrs=attrs)
                self.document.append(self.html)
                # Replace document with html on the stack base.
                self.open_stack = [self.document, self.html]
            else:
                # Merge attributes (existing values win)
                for k, v in attrs.items():
                    if k not in self.html.attrs:
                        self.html.attrs[k] = v
            return self.html

        if tag == "head":
            self._ensure_html()
            if self.head is None:
                self.head = Node("element", tag="head", attrs=attrs)
                self.html.append(self.head)
                self.open_stack.append(self.head)
            return self.head

        if tag == "body":
            self._ensure_html()
            if self.head is not None:
                # pop head if open
                while self.open_stack and self.open_stack[-1].kind == "element" and self.open_stack[-1].tag == "head":
                    self.open_stack.pop()
            if self.body is None:
                self.body = Node("element", tag="body", attrs=attrs)
                self.html.append(self.body)
                self.open_stack.append(self.body)
            else:
                for k, v in attrs.items():
                    if k not in self.body.attrs:
                        self.body.attrs[k] = v
            return self.body

        # Head-phase tags: stay in head if no body yet and we're not past head.
        HEAD_TAGS = {"title", "meta", "link", "style", "script", "base", "noscript", "template"}

        # If we haven't started body yet and tag is head-only, ensure head and insert.
        if self.body is None and tag in HEAD_TAGS and not self._has_in_scope("body"):
            self._ensure_head()
            # If head is not the current top, push it.
            if self.head not in self.open_stack:
                self.open_stack.append(self.head)
            parent = self.head
        else:
            # Past head — make sure body exists.
            if self.body is None and tag not in HEAD_TAGS:
                self._ensure_body()
            # Apply auto-close rules.
            if tag in P_CLOSING_ELEMENTS:
                self._close_implicit_p()
            if tag == "li":
                self._close_li()
            if tag in ("dt", "dd"):
                self._close_dt_dd()
            # <tbody>, <tr>, <td> handling: simplistic.
            if tag in ("thead", "tbody", "tfoot"):
                # Close current tbody/thead/tfoot if any.
                for t in ("thead", "tbody", "tfoot"):
                    if self._has_in_scope(t):
                        self._close_until(t)
                        break
                # Close any open <tr>.
                if self._has_in_scope("tr"):
                    self._close_until("tr")
            if tag == "tr":
                # If no tbody/thead/tfoot is open, insert tbody.
                has_section = any(n.kind == "element" and n.tag in ("thead", "tbody", "tfoot") for n in self.open_stack)
                if self._has_in_scope("table") and not has_section:
                    section = Node("element", tag="tbody")
                    self.current().append(section)
                    self.open_stack.append(section)
                if self._has_in_scope("tr"):
                    self._close_until("tr")
            # Auto-close <a> if a new <a> opens while one is in scope.
            if tag == "a" and self._has_in_scope("a"):
                self._close_until("a")
            # Auto-close current heading if new heading opens.
            if tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
                cur = self.current()
                if cur.kind == "element" and cur.tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
                    self._close_until(cur.tag)
            # Auto-close option if new option/optgroup opens.
            if tag == "option":
                cur = self.current()
                if cur.kind == "element" and cur.tag == "option":
                    self._close_until("option")
            if tag == "optgroup":
                cur = self.current()
                if cur.kind == "element" and cur.tag in ("option", "optgroup"):
                    self._close_until(cur.tag)
            # Ignore <form> if a form is already in scope (HTML5 spec).
            if tag == "form" and self._has_in_scope("form"):
                return self.current()
            if tag in ("td", "th"):
                # Ensure tr is in scope.
                if not self._has_in_scope("tr"):
                    # Need tbody and tr.
                    has_section = any(n.kind == "element" and n.tag in ("thead", "tbody", "tfoot") for n in self.open_stack)
                    if self._has_in_scope("table") and not has_section:
                        section = Node("element", tag="tbody")
                        self.current().append(section)
                        self.open_stack.append(section)
                    if self._has_in_scope("table"):
                        tr = Node("element", tag="tr")
                        self.current().append(tr)
                        self.open_stack.append(tr)
                # Close any open td/th.
                for t in ("td", "th"):
                    if self._has_in_scope(t):
                        self._close_until(t)
                        break
            parent = self.current()

        node = Node("element", tag=tag, attrs=attrs)
        parent.append(node)

        # Void elements: don't push to stack.
        if tag not in VOID_ELEMENTS:
            self.open_stack.append(node)
        return node

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        # HTML5: certain table-related tags outside a table are ignored.
        if tag in ("caption", "col", "colgroup", "tbody", "td", "tfoot", "th", "thead", "tr"):
            if not self._has_in_scope("table"):
                return
        attrs = self._normalize_attrs(attrs)
        node = self._insert_element(tag, attrs)
        if tag in RAW_TEXT_ELEMENTS:
            self.in_raw_text = tag

    def handle_startendtag(self, tag, attrs):
        # <br/>, <img/>, etc. Treat as void start tag.
        tag = tag.lower()
        attrs = self._normalize_attrs(attrs)
        # If foreign / unknown self-closing, still insert.
        node = self._insert_element(tag, attrs)
        # Pop if not void (i.e., self-closing non-void in HTML is treated as void in foreign content,
        # but in regular HTML, the self-closing slash is ignored and we'd expect a closing tag).
        # For simplicity, if the tag isn't void, leave it open.
        if tag in VOID_ELEMENTS:
            return
        # In HTML, <foo/> still expects </foo>; do nothing special.

    def handle_endtag(self, tag):
        tag = tag.lower()
        if self.in_raw_text == tag:
            self.in_raw_text = None
        # Void: no closing tag.
        if tag in VOID_ELEMENTS:
            return
        # Ignore close tags for table elements when not in table scope.
        if tag in ("caption", "col", "colgroup", "tbody", "tfoot", "thead") and not self._has_in_scope(tag):
            return
        # Find matching tag on stack.
        for i in range(len(self.open_stack) - 1, -1, -1):
            n = self.open_stack[i]
            if n.kind == "element" and n.tag == tag:
                # Pop all up to and including this.
                self.open_stack = self.open_stack[:i]
                return
        # Stray end tag.
        # HTML5 quirk: stray </p> with no <p> in scope but inside body creates an empty <p>.
        if tag == "p" and self.body is not None:
            p_node = Node("element", tag="p")
            self.current().append(p_node)

    def handle_data(self, data):
        if self.in_raw_text is not None:
            # In raw text: text without entity decoding (html.parser decodes already if convert_charrefs=True).
            # Need to handle this differently — see __init__ choice.
            pass
        if not data:
            return
        # Strip NUL bytes.
        data = data.replace("\x00", "")
        if not data:
            return
        # If inside raw text element, text goes directly.
        # If outside body & not whitespace-only, ensure body and insert.
        cur = self.current()
        if cur.kind == "document":
            # Text at top level (before <html>): skip whitespace, move non-ws to body.
            if not data.strip():
                return
            self._ensure_body()
            cur = self.current()
        elif cur.kind == "element" and cur.tag == "html":
            # Inside html but not in head or body.
            if self.body is not None:
                # After body opened: text goes into body (even if body was closed via </body>).
                cur = self.body
            elif not data.strip():
                # Before-head/after-head whitespace.
                if self.head is None:
                    return  # before-head: dropped
                # else: keep at html level (between head and body)
            else:
                self._ensure_body()
                cur = self.current()
        elif cur.kind == "element" and cur.tag == "head":
            if data.strip() and self.in_raw_text is None:
                # Non-whitespace inside head: move to body.
                self._ensure_body()
                cur = self.current()
        cur.append(Node("text", data=data))

    def handle_entityref(self, name):
        # Only reached when convert_charrefs=False. Not used.
        pass

    def handle_charref(self, name):
        pass

    def handle_comment(self, data):
        # html5: comment goes to current node. For document-level, it's a sibling of html.
        cur = self.current()
        if cur.kind == "document":
            cur.append(Node("comment", data=data))
        else:
            cur.append(Node("comment", data=data))

    def handle_decl(self, decl):
        # <!DOCTYPE ...>
        if decl.lower().startswith("doctype"):
            # parse: DOCTYPE NAME [...]
            parts = decl.split(None, 1)
            if len(parts) > 1:
                name = parts[1].split()[0].lower() if parts[1].split() else ""
            else:
                name = ""
            self.document.append(Node("doctype", data=name))

    def handle_pi(self, data):
        # Processing instruction — html5 treats as comment.
        cur = self.current()
        cur.append(Node("comment", data="?" + data))

    def unknown_decl(self, data):
        # CDATA in foreign content. In HTML, treated as bogus comment.
        cur = self.current()
        cur.append(Node("comment", data="[" + data + "]"))


def parse_html5(text):
    """Parse HTML, return Document Node."""
    # Strip BOM.
    if text.startswith("﻿"):
        text = text[1:]
    if text.startswith("\xef\xbb\xbf"):
        text = text[3:]
    tb = TreeBuilder()
    try:
        tb.feed(text)
    except Exception:
        pass
    try:
        tb.close()
    except Exception:
        pass
    # Ensure we have html/head/body if there's any content.
    if tb.html is None:
        # Create empty wrapping.
        tb._ensure_html()
    if tb.head is None:
        tb.head = Node("element", tag="head")
        tb.html.children.insert(0, tb.head)
        tb.head.parent = tb.html
    if tb.body is None:
        tb.body = Node("element", tag="body")
        tb.html.append(tb.body)
    return tb.document


# ============================================================
# CSS Selector parser & matcher
# ============================================================
# Subset: tag, *, #id, .class, [attr], [attr=v], [attr~=v], [attr|=v],
# [attr^=v], [attr$=v], [attr*=v]; combinators (space, >, +, ~); ,; pseudo classes.

CSS_TOKEN_RE = re.compile(
    r"""
    \s*(
        \*                                  # universal
      | [.#][\w\-]+                        # class / id
      | [a-zA-Z][\w\-]*                    # tag
      | \[[^\]]+\]                         # attribute
      | :(?:not|nth-child|nth-of-type|nth-last-child|nth-last-of-type|is|where|has|matches)\([^)]*\)
      | ::?[\w\-]+                         # other pseudo
      | [>+~,]                             # combinator
      | \s+                                # whitespace
      | --                                 # not a token but appears
    )
    """,
    re.VERBOSE
)

IDENT_RE = re.compile(r"[a-zA-Z_-][\w\-]*")


class Selector:
    """A single compound selector + its combinator with previous."""
    def __init__(self):
        self.simples = []      # list of SimpleSel
        self.combinator = " "  # combinator with PREVIOUS compound: ' ', '>', '+', '~'

    def __repr__(self):
        return f"Sel({self.combinator!r}{self.simples!r})"


class SimpleSel:
    def __init__(self, kind, value=None, arg=None):
        self.kind = kind     # 'tag', 'class', 'id', 'attr', 'pseudo', 'universal'
        self.value = value
        self.arg = arg


class CompoundSelector:
    """A complete chain of compound selectors connected by combinators."""
    def __init__(self):
        self.parts = []  # list of Selector


class SelectorList:
    """Comma-separated list of selectors (logical OR)."""
    def __init__(self):
        self.items = []  # list of CompoundSelector


def _tokenize_selector(s):
    """Tokenize a CSS selector string."""
    tokens = []
    i = 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            j = i
            while j < len(s) and s[j].isspace():
                j += 1
            tokens.append(("ws", s[i:j]))
            i = j
            continue
        if c in ">+~,":
            tokens.append((c, c))
            i += 1
            continue
        if c == "*":
            tokens.append(("universal", "*"))
            i += 1
            continue
        if c == ".":
            j = i + 1
            while j < len(s) and (s[j].isalnum() or s[j] in "_-"):
                j += 1
            tokens.append(("class", s[i+1:j]))
            i = j
            continue
        if c == "#":
            j = i + 1
            while j < len(s) and (s[j].isalnum() or s[j] in "_-"):
                j += 1
            tokens.append(("id", s[i+1:j]))
            i = j
            continue
        if c == "[":
            # Find matching ]
            j = s.find("]", i)
            if j < 0:
                raise ValueError(f"Unclosed attribute selector at {i}")
            tokens.append(("attr", s[i+1:j]))
            i = j + 1
            continue
        if c == ":":
            j = i + 1
            if j < len(s) and s[j] == ":":
                j += 1
            # Read pseudo name.
            k = j
            while k < len(s) and (s[k].isalnum() or s[k] in "-_"):
                k += 1
            name = s[j:k]
            arg = None
            if k < len(s) and s[k] == "(":
                # Find matching ).
                depth = 1
                m = k + 1
                while m < len(s) and depth > 0:
                    if s[m] == "(":
                        depth += 1
                    elif s[m] == ")":
                        depth -= 1
                    m += 1
                if depth != 0:
                    raise ValueError(f"Unclosed pseudo arg at {k}")
                arg = s[k+1:m-1]
                k = m
            tokens.append(("pseudo", (name, arg)))
            i = k
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] in "_-"):
                j += 1
            tokens.append(("tag", s[i:j].lower()))
            i = j
            continue
        raise ValueError(f"Unexpected character {c!r} at {i} in selector")
    return tokens


def parse_selector(s):
    """Parse a CSS selector string into a SelectorList."""
    s = s.strip()
    if not s:
        raise ValueError("Empty selector")
    try:
        tokens = _tokenize_selector(s)
    except ValueError:
        raise

    # Split on comma to get top-level selectors.
    selectors = []
    cur_tokens = []
    for t in tokens:
        if t[0] == ",":
            selectors.append(cur_tokens)
            cur_tokens = []
        else:
            cur_tokens.append(t)
    selectors.append(cur_tokens)

    out = SelectorList()
    for sel_tokens in selectors:
        comp = _parse_compound(sel_tokens)
        out.items.append(comp)
    return out


def _parse_compound(tokens):
    """Parse tokens into a CompoundSelector."""
    # Strip leading/trailing whitespace tokens.
    while tokens and tokens[0][0] == "ws":
        tokens.pop(0)
    while tokens and tokens[-1][0] == "ws":
        tokens.pop()
    if not tokens:
        raise ValueError("Empty compound selector")

    parts = []
    current = Selector()
    combinator_pending = None
    expect_compound = True   # next non-combinator token starts new compound

    i = 0
    while i < len(tokens):
        kind, val = tokens[i]
        if kind == "ws":
            # Whitespace combinator (descendant).
            if combinator_pending is None:
                combinator_pending = " "
        elif kind in (">", "+", "~"):
            combinator_pending = kind
        else:
            # Start of new compound?
            if combinator_pending is not None or not current.simples:
                if current.simples:
                    parts.append(current)
                    current = Selector()
                    current.combinator = combinator_pending if combinator_pending else " "
                    combinator_pending = None
                elif combinator_pending and current.combinator == " " and not current.simples:
                    current.combinator = combinator_pending
                    combinator_pending = None
                else:
                    combinator_pending = None
            if kind == "tag":
                current.simples.append(SimpleSel("tag", val))
            elif kind == "universal":
                current.simples.append(SimpleSel("universal"))
            elif kind == "class":
                current.simples.append(SimpleSel("class", val))
            elif kind == "id":
                current.simples.append(SimpleSel("id", val))
            elif kind == "attr":
                current.simples.append(_parse_attr(val))
            elif kind == "pseudo":
                name, arg = val
                current.simples.append(SimpleSel("pseudo", name, arg))
        i += 1

    if current.simples:
        parts.append(current)
    # First compound's combinator is meaningless (it's the start).
    if parts:
        parts[0].combinator = None

    comp = CompoundSelector()
    comp.parts = parts
    return comp


def _parse_attr(content):
    """Parse [attr], [attr=val], [attr~=val], etc."""
    s = content.strip()
    # Find operator
    ops = ["~=", "|=", "^=", "$=", "*=", "="]
    op = None
    op_pos = -1
    for o in ops:
        idx = s.find(o)
        if idx >= 0:
            if op_pos < 0 or idx < op_pos:
                op = o
                op_pos = idx
    if op is None:
        # [attr] (or [attr i])
        name = s.strip()
        # Strip "i" flag suffix
        m = re.match(r"^([\w\-]+)(\s+[iI])?$", name)
        if m:
            return SimpleSel("attr", m.group(1).lower(), {"op": None, "val": None, "i": bool(m.group(2))})
        return SimpleSel("attr", s.lower(), {"op": None, "val": None, "i": False})
    name = s[:op_pos].strip().lower()
    rest = s[op_pos + len(op):].strip()
    case_insensitive = False
    if rest.endswith(" i") or rest.endswith(" I"):
        case_insensitive = True
        rest = rest[:-2].strip()
    # Unquote
    if rest.startswith('"') and rest.endswith('"'):
        rest = rest[1:-1]
    elif rest.startswith("'") and rest.endswith("'"):
        rest = rest[1:-1]
    return SimpleSel("attr", name, {"op": op, "val": rest, "i": case_insensitive})


# ---------- Matching ----------

def match_simple(sel, node):
    """Does a SimpleSel match this element node?"""
    if node.kind != "element":
        return False
    if sel.kind == "tag":
        return node.tag == sel.value
    if sel.kind == "universal":
        return True
    if sel.kind == "id":
        return node.attrs.get("id") == sel.value
    if sel.kind == "class":
        cls = node.attrs.get("class", "")
        return sel.value in cls.split()
    if sel.kind == "attr":
        name = sel.value
        arg = sel.arg
        v = node.attrs.get(name)
        if arg["op"] is None:
            return v is not None
        if v is None:
            return False
        op = arg["op"]
        target = arg["val"]
        ci = arg["i"]
        if ci:
            v_cmp = v.lower()
            t_cmp = target.lower()
        else:
            v_cmp = v
            t_cmp = target
        if op == "=":
            return v_cmp == t_cmp
        if op == "~=":
            return t_cmp in v_cmp.split()
        if op == "|=":
            return v_cmp == t_cmp or v_cmp.startswith(t_cmp + "-")
        if op == "^=":
            return v_cmp.startswith(t_cmp) if target else False
        if op == "$=":
            return v_cmp.endswith(t_cmp) if target else False
        if op == "*=":
            return t_cmp in v_cmp if target else False
        return False
    if sel.kind == "pseudo":
        return match_pseudo(sel.value, sel.arg, node)
    return False


def match_pseudo(name, arg, node):
    parent = node.parent
    if name in ("first-child",):
        if parent is None:
            return False
        siblings = [c for c in parent.children if c.kind == "element"]
        return siblings and siblings[0] is node
    if name == "last-child":
        if parent is None:
            return False
        siblings = [c for c in parent.children if c.kind == "element"]
        return siblings and siblings[-1] is node
    if name == "only-child":
        if parent is None:
            return False
        siblings = [c for c in parent.children if c.kind == "element"]
        return len(siblings) == 1 and siblings[0] is node
    if name == "first-of-type":
        if parent is None:
            return False
        same = [c for c in parent.children if c.kind == "element" and c.tag == node.tag]
        return same and same[0] is node
    if name == "last-of-type":
        if parent is None:
            return False
        same = [c for c in parent.children if c.kind == "element" and c.tag == node.tag]
        return same and same[-1] is node
    if name == "only-of-type":
        if parent is None:
            return False
        same = [c for c in parent.children if c.kind == "element" and c.tag == node.tag]
        return len(same) == 1 and same[0] is node
    if name == "empty":
        return not node.children
    if name == "root":
        # html element is the "root" in HTML
        return node.tag == "html" and node.parent is not None and node.parent.kind == "document"
    if name == "scope":
        return False  # not supported
    if name == "any-link":
        return node.tag in ("a", "area", "link") and "href" in node.attrs
    if name == "link":
        return node.tag in ("a", "area", "link") and "href" in node.attrs
    if name in ("visited", "active", "focus", "hover"):
        return False
    if name == "checked":
        return node.tag in ("input", "option") and "checked" in node.attrs
    if name == "disabled":
        # htmlq/Servo's selectors crate doesn't match :disabled in our context.
        return False
    if name == "enabled":
        return False
    if name == "indeterminate":
        return False
    if name == "not":
        if arg is None:
            return False
        try:
            sl = parse_selector(arg)
        except Exception:
            return False
        return not any(match_compound(comp, node) for comp in sl.items)
    if name in ("is", "where", "matches"):
        if arg is None:
            return False
        try:
            sl = parse_selector(arg)
        except Exception:
            return False
        return any(match_compound(comp, node) for comp in sl.items)
    if name == "has":
        if arg is None:
            return False
        try:
            sl = parse_selector(arg)
        except Exception:
            return False
        for desc in node.iter_descendants():
            if desc.kind != "element":
                continue
            for comp in sl.items:
                if match_compound(comp, desc):
                    return True
        return False
    if name == "nth-child":
        return _nth_match(node, arg, of_type=False, from_end=False)
    if name == "nth-last-child":
        return _nth_match(node, arg, of_type=False, from_end=True)
    if name == "nth-of-type":
        return _nth_match(node, arg, of_type=True, from_end=False)
    if name == "nth-last-of-type":
        return _nth_match(node, arg, of_type=True, from_end=True)
    return False


def _parse_nth(arg):
    """Parse An+B; return (a, b)."""
    s = arg.strip().lower() if arg else ""
    if s == "odd":
        return (2, 1)
    if s == "even":
        return (2, 0)
    # Patterns: n, -n, 2n, -2n, 2n+1, 2n-1, +3, -3, 3, etc.
    m = re.match(r"^([+-]?\d*)n\s*([+-]\s*\d+)?$", s.replace(" ", ""))
    if m:
        a_s = m.group(1)
        if a_s in ("", "+"):
            a = 1
        elif a_s == "-":
            a = -1
        else:
            a = int(a_s)
        b_s = m.group(2)
        if b_s is None:
            b = 0
        else:
            b = int(b_s.replace(" ", ""))
        return (a, b)
    m = re.match(r"^([+-]?\d+)$", s)
    if m:
        return (0, int(m.group(1)))
    return (0, 0)


def _nth_match(node, arg, of_type, from_end):
    parent = node.parent
    if parent is None:
        return False
    if of_type:
        siblings = [c for c in parent.children if c.kind == "element" and c.tag == node.tag]
    else:
        siblings = [c for c in parent.children if c.kind == "element"]
    if from_end:
        siblings = list(reversed(siblings))
    try:
        idx = siblings.index(node) + 1  # 1-based
    except ValueError:
        return False
    a, b = _parse_nth(arg)
    if a == 0:
        return idx == b
    # idx = a*n + b for some n >= 0
    diff = idx - b
    if a > 0:
        return diff >= 0 and diff % a == 0
    else:
        return diff <= 0 and (-diff) % (-a) == 0


def match_compound_simples(sel, node):
    """Check all simple selectors in a compound match."""
    for s in sel.simples:
        if not match_simple(s, node):
            return False
    return True


def match_compound(comp, node):
    """Match a CompoundSelector (with combinators) against a candidate node.
    `node` is expected to be the LAST element in the chain.
    """
    if not comp.parts:
        return False
    if not match_compound_simples(comp.parts[-1], node):
        return False
    # Walk backwards through combinators.
    cur = node
    for i in range(len(comp.parts) - 1, 0, -1):
        prev = comp.parts[i]
        cand = comp.parts[i - 1]
        combo = prev.combinator
        if combo == " ":
            # Ancestor of cur must match.
            p = cur.parent
            while p is not None:
                if p.kind == "element" and match_compound_simples(cand, p):
                    cur = p
                    break
                p = p.parent
            else:
                return False
        elif combo == ">":
            p = cur.parent
            if p is None or p.kind != "element" or not match_compound_simples(cand, p):
                return False
            cur = p
        elif combo == "+":
            # Immediate preceding element sibling.
            p = cur.parent
            if p is None:
                return False
            siblings = [c for c in p.children if c.kind == "element"]
            try:
                idx = siblings.index(cur)
            except ValueError:
                return False
            if idx == 0:
                return False
            sib = siblings[idx - 1]
            if not match_compound_simples(cand, sib):
                return False
            cur = sib
        elif combo == "~":
            p = cur.parent
            if p is None:
                return False
            siblings = [c for c in p.children if c.kind == "element"]
            try:
                idx = siblings.index(cur)
            except ValueError:
                return False
            for sib in reversed(siblings[:idx]):
                if match_compound_simples(cand, sib):
                    cur = sib
                    break
            else:
                return False
    return True


def select(root, selector_str):
    """Yield all element nodes matching selector_str, in document order."""
    sl = parse_selector(selector_str)
    seen = set()
    for node in root.iter_self_and_descendants():
        if node.kind != "element":
            continue
        for comp in sl.items:
            if match_compound(comp, node):
                if id(node) not in seen:
                    seen.add(id(node))
                    yield node
                break


# ============================================================
# Serialization (html5ever-style)
# ============================================================

def escape_text(text):
    out = []
    for c in text:
        if c == "&":
            out.append("&amp;")
        elif c == " ":
            out.append("&nbsp;")
        elif c == "<":
            out.append("&lt;")
        elif c == ">":
            out.append("&gt;")
        else:
            out.append(c)
    return "".join(out)


def escape_attr(text):
    out = []
    for c in text:
        if c == "&":
            out.append("&amp;")
        elif c == " ":
            out.append("&nbsp;")
        elif c == '"':
            out.append("&quot;")
        else:
            out.append(c)
    return "".join(out)


def serialize_node(node, out, parent_tag=None):
    """Serialize a single node and its descendants (kuchiki / html5ever style)."""
    if node.kind == "element":
        tag = node.tag
        out.append("<")
        out.append(tag)
        # Sorted attributes.
        for name in sorted(node.attrs.keys()):
            value = node.attrs[name]
            out.append(" ")
            out.append(name)
            out.append('="')
            out.append(escape_attr(value))
            out.append('"')
        out.append(">")
        if tag in VOID_ELEMENTS:
            return
        # Children
        for child in node.children:
            serialize_node(child, out, parent_tag=tag)
        out.append("</")
        out.append(tag)
        out.append(">")
    elif node.kind == "text":
        if parent_tag in RAW_TEXT_ELEMENTS:
            out.append(node.data)
        else:
            out.append(escape_text(node.data))
    elif node.kind == "comment":
        out.append("<!--")
        out.append(node.data)
        out.append("-->")
    elif node.kind == "doctype":
        out.append("<!DOCTYPE ")
        out.append(node.data)
        out.append(">")
    elif node.kind == "document":
        for child in node.children:
            serialize_node(child, out)


def serialize(node):
    out = []
    serialize_node(node, out)
    return "".join(out)


# ============================================================
# Pretty-print serialization (htmlq's pretty_print)
# ============================================================

def is_inline_element(tag):
    return tag in INLINE_ELEMENTS


class _PrettyState:
    __slots__ = ("indent", "recent_block_close", "out")

    def __init__(self):
        self.indent = 0
        self.recent_block_close = False
        self.out = []

    def write(self, s):
        self.out.append(s)

    def indent_str(self, level=None):
        if level is None:
            level = self.indent
        return "  " * level


def pretty_serialize(node):
    """Pretty-print serialization (htmlq-style).
    For a block element: prefix with '\\n' and serialize as block.
    For an inline element: serialize inline (no leading '\\n').
    """
    state = _PrettyState()
    _pretty_walk(node, state)
    return "".join(state.out)


def _open_tag(node):
    out = ["<", node.tag]
    for name in sorted(node.attrs.keys()):
        v = node.attrs[name]
        out.append(' {0}="{1}"'.format(name, escape_attr(v)))
    out.append(">")
    return "".join(out)


def _pretty_walk(node, state):
    """Walk a node, emitting pretty-print events into state.out."""
    if node.kind == "text":
        text = node.data
        # Skip whitespace-only text nodes in pretty-print.
        if not text.strip():
            return
        if state.recent_block_close:
            state.write("\n")
            state.write(state.indent_str())
            state.recent_block_close = False
        state.write(escape_text(text))
        return

    if node.kind == "comment":
        if state.recent_block_close:
            state.write("\n")
            state.write(state.indent_str())
            state.recent_block_close = False
        state.write("<!--" + node.data + "-->")
        return

    if node.kind == "doctype":
        state.write("<!DOCTYPE " + node.data + ">")
        return

    if node.kind != "element":
        return

    tag = node.tag
    inline = is_inline_element(tag)

    # Opening:
    # - Block element: always write newline+indent before (unless we're at the very start).
    # - Inline element: write newline+indent only if recent_block_close.
    if not inline:
        state.write("\n")
        state.write(state.indent_str())
    elif state.recent_block_close:
        state.write("\n")
        state.write(state.indent_str())
    # Note: don't clear recent_block_close here.
    # It propagates into the element's contents (so first text child gets indented).

    state.write(_open_tag(node))

    if tag in VOID_ELEMENTS:
        if not inline:
            # Block void elements (br, hr): write a "closing" newline+indent slot.
            state.write("\n")
            state.write(state.indent_str())
            state.recent_block_close = True
        else:
            # Inline void element (img) consumed the block-close state.
            state.recent_block_close = False
        return

    # Increase indent for children.
    state.indent += 1

    # Raw text elements: serialize text content raw.
    is_raw = tag in RAW_TEXT_ELEMENTS

    for child in node.children:
        if is_raw and child.kind == "text":
            state.write(child.data)
        else:
            _pretty_walk(child, state)

    state.indent -= 1

    # Closing tag.
    if inline:
        # Inline: close inline (no newline before close).
        state.write("</")
        state.write(tag)
        state.write(">")
        # Closing an inline element clears recent_block_close
        # (it "encapsulates" any block close inside it).
        state.recent_block_close = False
    else:
        # Block: newline + indent + close tag.
        state.write("\n")
        state.write(state.indent_str())
        state.write("</")
        state.write(tag)
        state.write(">")
        state.recent_block_close = True


# ============================================================
# Base URL resolution
# ============================================================

LINK_ATTRS = {
    "a": ["href"],
    "area": ["href"],
    "link": ["href"],
}


def is_valid_url(s):
    if not s:
        return False
    try:
        p = urlparse(s)
        return bool(p.scheme) and bool(p.netloc)
    except Exception:
        return False


def apply_base_to_tree(root, base):
    """Resolve relative URLs in href to absolute against `base`."""
    if not base or not is_valid_url(base):
        return
    for node in root.iter_self_and_descendants():
        if node.kind != "element":
            continue
        attrs_to_fix = LINK_ATTRS.get(node.tag, [])
        for a in attrs_to_fix:
            if a in node.attrs:
                val = node.attrs[a]
                try:
                    node.attrs[a] = _resolve_url(base, val)
                except Exception:
                    pass


def _resolve_url(base, ref):
    """Resolve `ref` against `base` URL.
    Adds trailing slash for hostname-only URLs (like Rust's Url crate does).
    """
    result = urljoin(base, ref)
    # If protocol-relative ref like "//foo.com" resolves to "https://foo.com" (no path),
    # Rust's url crate normalizes to "https://foo.com/".
    try:
        p = urlparse(result)
        if p.scheme and p.netloc and not p.path and not p.params and not p.query and not p.fragment:
            result = result + "/"
    except Exception:
        pass
    return result


def find_base_href(document):
    """Search document tree for <base href="...">."""
    for n in document.iter_self_and_descendants():
        if n.kind == "element" and n.tag == "base":
            href = n.attrs.get("href")
            if href:
                return href
    return None


# ============================================================
# CLI argument parsing
# ============================================================

HELP_TEXT = """htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]
"""

VERSION_TEXT = "htmlq 0.4.0\n"

USAGE_BRIEF = """USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

For more information try --help
"""


def parse_args(argv):
    """Parse CLI args following htmlq's clap 2.x style.
    Returns: dict with keys: text, pretty, ignore_whitespace, detect_base,
             attribute, base, filename, output, remove_nodes, selectors,
             help, version.
    """
    args = {
        "text": False,
        "pretty": False,
        "ignore_whitespace": False,
        "detect_base": False,
        "attribute": None,
        "base": None,
        "filename": None,
        "output": None,
        "remove_nodes": [],
        "selectors": [],
        "help": False,
        "version": False,
        "_error": None,
        "_post_dd": False,
    }

    i = 0
    after_dd = False
    while i < len(argv):
        a = argv[i]
        if after_dd:
            args["selectors"].append(a)
            i += 1
            continue
        if a == "--":
            after_dd = True
            args["_post_dd"] = True
            i += 1
            continue
        if a in ("-h", "--help"):
            args["help"] = True
            i += 1
            continue
        if a in ("-V", "--version"):
            args["version"] = True
            i += 1
            continue
        if a in ("-t", "--text"):
            args["text"] = True
            i += 1
            continue
        if a in ("-p", "--pretty"):
            args["pretty"] = True
            i += 1
            continue
        if a in ("-w", "--ignore-whitespace"):
            args["ignore_whitespace"] = True
            i += 1
            continue
        if a in ("-B", "--detect-base"):
            args["detect_base"] = True
            i += 1
            continue
        # Combined short flags like -tp
        if a.startswith("-") and len(a) > 2 and not a.startswith("--") and not a[1].isdigit() and "=" not in a:
            # Could be a combined like -tp or -aFOO
            handled = False
            # Check for value-attached: -aVALUE
            shorts_with_value = {"a", "b", "f", "o", "r"}
            if a[1] in shorts_with_value:
                # -aVALUE or -a VALUE handled separately
                short = a[1]
                val = a[2:]
                if short == "a":
                    args["attribute"] = val
                elif short == "b":
                    args["base"] = val
                elif short == "f":
                    args["filename"] = val
                elif short == "o":
                    args["output"] = val
                elif short == "r":
                    args["remove_nodes"].append(val)
                    i += 1
                    continue
                i += 1
                continue
            # Combined boolean shorts.
            valid_shorts = {"t", "p", "w", "B", "h", "V"}
            if all(c in valid_shorts for c in a[1:]):
                for c in a[1:]:
                    if c == "t": args["text"] = True
                    elif c == "p": args["pretty"] = True
                    elif c == "w": args["ignore_whitespace"] = True
                    elif c == "B": args["detect_base"] = True
                    elif c == "h": args["help"] = True
                    elif c == "V": args["version"] = True
                i += 1
                continue
            args["_error"] = f"Found argument '{a}' which wasn't expected"
            return args
        # Long-option attached: --attr=value
        if a.startswith("--") and "=" in a:
            key, _, val = a[2:].partition("=")
            if key == "attribute":
                args["attribute"] = val
            elif key == "base":
                args["base"] = val
            elif key == "filename":
                args["filename"] = val
            elif key == "output":
                args["output"] = val
            elif key == "remove-nodes":
                args["remove_nodes"].append(val)
            else:
                args["_error"] = f"Found argument '{a}' which wasn't expected"
                return args
            i += 1
            continue
        # Short option with separate value, or long option.
        if a in ("-a", "--attribute"):
            if i + 1 >= len(argv):
                args["_error"] = f"option '{a}' requires a value"
                return args
            args["attribute"] = argv[i + 1]
            i += 2
            continue
        if a in ("-b", "--base"):
            if i + 1 >= len(argv):
                args["_error"] = f"option '{a}' requires a value"
                return args
            args["base"] = argv[i + 1]
            i += 2
            continue
        if a in ("-f", "--filename"):
            if i + 1 >= len(argv):
                args["_error"] = f"option '{a}' requires a value"
                return args
            args["filename"] = argv[i + 1]
            i += 2
            continue
        if a in ("-o", "--output"):
            if i + 1 >= len(argv):
                args["_error"] = f"option '{a}' requires a value"
                return args
            args["output"] = argv[i + 1]
            i += 2
            continue
        if a in ("-r", "--remove-nodes"):
            # Takes one value (NOT greedy in clap's default for multiple-occurrence).
            i += 1
            if i >= len(argv):
                args["_error"] = f"option '{a}' requires a value"
                return args
            args["remove_nodes"].append(argv[i])
            i += 1
            continue
        if a.startswith("-"):
            args["_error"] = f"Found argument '{a}' which wasn't expected"
            return args
        # Positional.
        args["selectors"].append(a)
        i += 1
    return args


# ============================================================
# Main
# ============================================================

def main(argv):
    args = parse_args(argv)

    if args["help"]:
        sys.stdout.write(HELP_TEXT)
        return 0
    if args["version"]:
        sys.stdout.write(VERSION_TEXT)
        return 0
    if args["_error"]:
        sys.stderr.write(f"error: {args['_error']}, or isn't valid in this context\n\n")
        # Usage block.
        if args["filename"] is not None:
            sys.stderr.write("USAGE:\n    executable --filename <FILE>\n\nFor more information try --help\n")
        else:
            sys.stderr.write(USAGE_BRIEF)
        return 1

    # Read input.
    if args["filename"]:
        try:
            with open(args["filename"], "rb") as f:
                raw = f.read()
        except IsADirectoryError:
            sys.stderr.write('Error: Os { code: 21, kind: IsADirectory, message: "Is a directory" }\n')
            return 1
        except FileNotFoundError as e:
            sys.stderr.write(f'thread \'main\' panicked at \'should have opened input file: Os {{ code: 2, kind: NotFound, message: "No such file or directory" }}\'\n')
            return 101
        except PermissionError:
            sys.stderr.write(f'thread \'main\' panicked at \'should have opened input file: Os {{ code: 13, kind: PermissionDenied, message: "Permission denied" }}\'\n')
            return 101
    else:
        raw = sys.stdin.buffer.read()

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("utf-8", errors="replace")

    document = parse_html5(text)

    # Determine base URL.
    base_url = None
    if args["detect_base"]:
        base_url = find_base_href(document)
        if base_url is None and args["base"]:
            base_url = args["base"]
    elif args["base"]:
        base_url = args["base"]

    if base_url:
        apply_base_to_tree(document, base_url)

    # Remove nodes. Track ancestors of removed nodes — htmlq 0.4.0 has a bug
    # where serializing an ancestor of a detached node returns empty.
    poisoned_ancestors = set()
    for rem_sel in args["remove_nodes"]:
        try:
            to_remove = list(select(document, rem_sel))
        except Exception:
            continue
        for n in to_remove:
            # Record ancestors before detach.
            p = n.parent
            while p is not None:
                poisoned_ancestors.add(id(p))
                p = p.parent
            n.detach()

    # Selector.
    sels = [s for s in args["selectors"] if s]
    if sels:
        selector_str = " ".join(sels)
    else:
        selector_str = "html"

    try:
        matches = list(select(document, selector_str))
    except Exception as e:
        sys.stderr.write(f"thread 'main' panicked at 'Failed to parse CSS selector: ()'\n")
        return 101

    # Reproduce htmlq 0.4.0's -r bug: skip the FIRST match in document order
    # that is an ancestor of a detached node.
    skip_idx = None
    if poisoned_ancestors:
        for i, m in enumerate(matches):
            if id(m) in poisoned_ancestors:
                skip_idx = i
                break

    # Open output stream.
    if args["output"]:
        try:
            out_f = open(args["output"], "wb")
        except FileNotFoundError:
            sys.stderr.write(f'thread \'main\' panicked at \'should have created output file\'\n')
            return 101
    else:
        out_f = sys.stdout.buffer

    try:
        for i, node in enumerate(matches):
            if i == skip_idx:
                continue
            if args["attribute"]:
                attr_val = node.attrs.get(args["attribute"])
                if attr_val is None:
                    continue
                out_f.write(attr_val.encode("utf-8", errors="replace"))
                out_f.write(b"\n")
            elif args["text"]:
                if args["ignore_whitespace"]:
                    # Each non-whitespace text node + \n
                    for tn in node.descendant_text_nodes():
                        if tn.data.strip():
                            out_f.write(tn.data.encode("utf-8", errors="replace"))
                            out_f.write(b"\n")
                else:
                    txt = node.text_content()
                    out_f.write(txt.encode("utf-8", errors="replace"))
                out_f.write(b"\n")
            elif args["pretty"]:
                out_f.write(pretty_serialize(node).encode("utf-8", errors="replace"))
                out_f.write(b"\n")
            else:
                out_f.write(serialize(node).encode("utf-8", errors="replace"))
                out_f.write(b"\n")
    finally:
        if args["output"]:
            out_f.close()

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
