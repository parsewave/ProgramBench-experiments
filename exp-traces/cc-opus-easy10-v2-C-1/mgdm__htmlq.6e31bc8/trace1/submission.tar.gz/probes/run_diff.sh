#!/usr/bin/env bash
# Run differential tests: compare /work/work/executable against /work/work/goldens/.
# Usage: run_diff.sh [name_filter]
set -u
SUT=/work/work/executable
GOLD=/work/work/goldens
filter="${1:-}"

pass=0
fail=0
fail_names=()

for cmd_file in "$GOLD"/*.cmd; do
    name="$(basename "$cmd_file" .cmd)"
    if [[ -n "$filter" && "$name" != *"$filter"* ]]; then
        continue
    fi
    mapfile -t args < "$cmd_file"
    expected_stdout="$GOLD/$name.stdout"
    expected_exit="$(cat "$GOLD/$name.exit")"
    actual_stdout="$(mktemp)"
    actual_stderr="$(mktemp)"
    "$SUT" "${args[@]}" < "$GOLD/$name.stdin" > "$actual_stdout" 2> "$actual_stderr"
    actual_exit=$?
    if cmp -s "$expected_stdout" "$actual_stdout"; then
        ok=1
    else
        ok=0
    fi
    if [[ "$ok" -eq 1 ]]; then
        pass=$((pass + 1))
    else
        fail=$((fail + 1))
        fail_names+=("$name")
        if [[ -n "$filter" ]]; then
            echo "=== FAIL: $name ==="
            echo "--- ARGS ---"
            printf '%s\n' "${args[@]}"
            echo "--- STDIN ---"
            cat "$GOLD/$name.stdin"; echo
            echo "--- EXPECTED STDOUT (exit $expected_exit) ---"
            od -c "$expected_stdout" | head -5
            echo "--- ACTUAL STDOUT (exit $actual_exit) ---"
            od -c "$actual_stdout" | head -5
            if [[ -s "$actual_stderr" ]]; then
                echo "--- STDERR ---"
                cat "$actual_stderr" | head -5
            fi
            echo
        fi
    fi
    rm -f "$actual_stdout" "$actual_stderr"
done

echo "PASS=$pass FAIL=$fail"
if [[ -n "${fail_names[*]:-}" ]]; then
    echo "Failures:"
    printf '  %s\n' "${fail_names[@]}"
fi
