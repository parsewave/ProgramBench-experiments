#!/usr/bin/env bash
# More diverse probes — corner cases and combinations.
set -u
REF=/workspace/executable
OUT=/work/work/goldens
mkdir -p "$OUT"

probe() {
    local name="$1"; shift
    local input="$1"; shift
    local args=("$@")
    {
        printf '%s\n' "${args[@]}"
    } > "$OUT/${name}.cmd"
    printf '%s' "$input" > "$OUT/${name}.stdin"
    "$REF" "${args[@]}" < "$OUT/${name}.stdin" > "$OUT/${name}.stdout" 2> "$OUT/${name}.stderr"
    echo "$?" > "$OUT/${name}.exit"
}

# === Multiple positionals (joined with space) ===
probe mp1 '<div><p>X</p></div>' div p
probe mp2 '<div><span><p>X</p></span></div>' div span p
probe mp3 '<table><tr><td>X</td></tr></table>' table tr td

# === Combinator placement ===
probe cp1 '<div><p>X</p></div>' 'div>p'
probe cp2 '<p>A</p>+<p>B</p>' 'p+p'
probe cp3 '<p>A</p><p>B</p>' 'p~p'

# === Selectors with whitespace variants ===
probe sw1 '<div><p>X</p></div>' 'div  p'
probe sw2 '<div><p>X</p></div>' 'div > p'
probe sw3 '<div><p>X</p></div>' 'div   >   p'

# === Many classes ===
probe mc1 '<p class="a b c">X</p>' '.a.b'
probe mc2 '<p class="a b c">X</p>' '.a.c'
probe mc3 '<p class="a b c">X</p>' 'p.a.c'

# === Pseudo-class chains ===
probe pc1 '<ul><li>1</li><li>2</li><li>3</li></ul>' 'li:first-child:last-child'
probe pc2 '<ul><li>1</li></ul>' 'li:first-child:last-child'
probe pc3 '<ul><li>1</li><li>2</li></ul>' 'li:nth-child(1):not(:last-child)'

# === Special attributes ===
probe sa1 '<a aria-label="Hi">L</a>' '[aria-label]'
probe sa2 '<a aria-label="Hi">L</a>' '[aria-label="Hi"]'
probe sa3 '<input type="email" pattern="[^@]+@.+">F</input>' '[type="email"]'

# === Pretty with non-trivial structure ===
probe ps1 '<div><ul><li>A</li><li>B</li></ul></div>' -p div
probe ps2 '<div><p><span>X</span></p></div>' -p div
probe ps3 '<section><h1>T</h1><p>Body</p></section>' -p section
probe ps4 '<div><img src="a"><img src="b"></div>' -p div

# === Multiple remove-nodes ===
probe mr1 '<div><script>S</script><p>X</p><style>Y</style></div>' -r script -r style -- div
probe mr2 '<div><a href="x">A</a><a href="y">B</a></div>' -r 'a[href="x"]' -- div

# === Text extraction patterns ===
probe te1 '<article><h1>Title</h1><p>Body</p></article>' -t article
probe te2 '<article><h1>Title</h1><p>Body</p></article>' -t -w article
probe te3 '<p>Line 1</p><p>Line 2</p>' -t p
probe te4 '<p>Line 1</p><p>Line 2</p>' -t -w p

# === Stress with attributes ===
probe sa_many '<div id="x" class="a b c d" data-1="1" data-2="2" data-3="3" data-4="4" data-5="5">X</div>'
probe sa_special '<div data-special="!@#$%^&amp;*()">X</div>'

# === Encoded entities ===
probe ee1 '<p>&lt;tag&gt;</p>' p
probe ee2 '<p>&amp;</p>' p
probe ee3 '<p>&#x20;</p>' p
probe ee4 '<p>&#32;</p>' p
probe ee5 '<p>&nbsp;</p>' p
probe ee6 '<p>caf&eacute;</p>' p

# === Base URL variations ===
probe bu1 '<a href="x">L</a>' -b 'https://example.com:8080/' -a href a
probe bu2 '<a href="/abs">L</a>' -b 'https://example.com:8080/' -a href a
probe bu3 '<a href="user@example.com">L</a>' -b 'mailto:' -a href a
probe bu4 '<a href="x">L</a>' -b 'https://example.com/p?q=1' -a href a

# === Selectors with element types ===
probe et1 '<input type="checkbox" checked>' input
probe et2 '<input type="radio">' input
probe et3 '<input>' input

# === Output to file ===
TMPOUT=/tmp/htmlq_test_$$
probe of1 '<p>X</p>' -o "$TMPOUT" p
[[ -f "$TMPOUT" ]] && cp "$TMPOUT" "$OUT/of1.stdout"
rm -f "$TMPOUT"

# === Long inputs ===
LONG_HTML="<html><body>"
for i in $(seq 1 50); do
    LONG_HTML+="<p>Item $i</p>"
done
LONG_HTML+="</body></html>"
probe long1 "$LONG_HTML" 'p:nth-child(25)'
probe long2 "$LONG_HTML" -t 'p:first-child'

echo "Total now: $(ls "$OUT" | grep -c '\.cmd$')"
