#!/usr/bin/env bash
# More realistic test cases.
set -u
REF=/workspace/executable
OUT=/work/work/goldens
mkdir -p "$OUT"

probe() {
    local name="$1"; shift
    local input="$1"; shift
    local args=("$@")
    {
        printf '%s\n' "${args[@]}"
    } > "$OUT/${name}.cmd"
    printf '%s' "$input" > "$OUT/${name}.stdin"
    "$REF" "${args[@]}" < "$OUT/${name}.stdin" > "$OUT/${name}.stdout" 2> "$OUT/${name}.stderr"
    echo "$?" > "$OUT/${name}.exit"
}

# === RSS-like content extraction ===
RSS_HTML='<html><head><title>Page</title></head><body>
<article>
<h2><a href="/a1">Article 1</a></h2>
<p class="excerpt">First excerpt</p>
<time datetime="2024-01-01">Jan 1</time>
</article>
<article>
<h2><a href="/a2">Article 2</a></h2>
<p class="excerpt">Second excerpt</p>
<time datetime="2024-01-02">Jan 2</time>
</article>
</body></html>'

probe rl_titles "$RSS_HTML" -t 'h2 a'
probe rl_links "$RSS_HTML" -a href 'h2 a'
probe rl_dates "$RSS_HTML" -a datetime time
probe rl_excerpts "$RSS_HTML" -t '.excerpt'

# === Form processing ===
FORM_HTML='<form action="/submit" method="post">
  <label>Name: <input name="name" type="text" required></label>
  <label>Email: <input name="email" type="email"></label>
  <label>Age: <input name="age" type="number" min="0" max="120"></label>
  <select name="country">
    <option value="us">United States</option>
    <option value="uk">United Kingdom</option>
  </select>
  <textarea name="bio" rows="4"></textarea>
  <button type="submit">Send</button>
</form>'

probe form_inputs "$FORM_HTML" -a name 'input, select, textarea'
probe form_required "$FORM_HTML" '[required]'
probe form_options "$FORM_HTML" -a value option
probe form_labels "$FORM_HTML" -t label

# === Tables ===
TABLE_HTML='<table>
<thead><tr><th>Name</th><th>Age</th><th>Email</th></tr></thead>
<tbody>
<tr><td>Alice</td><td>30</td><td>alice@example.com</td></tr>
<tr><td>Bob</td><td>25</td><td>bob@example.com</td></tr>
<tr><td>Carol</td><td>35</td><td>carol@example.com</td></tr>
</tbody>
</table>'

probe table_headers "$TABLE_HTML" -t 'thead th'
probe table_first_col "$TABLE_HTML" -t 'tbody tr td:first-child'
probe table_emails "$TABLE_HTML" -t 'tbody tr td:nth-child(3)'

# === Long attribute values ===
probe long_attr '<div data-content="lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor">X</div>' '[data-content]'

# === Special character handling ===
probe special_lt_text '<p>1 < 2</p>' -t p
probe special_lt_tag '<p>1 < 2 and 3 > 4</p>' p
probe special_amp '<p>A & B</p>' p

# === Common selectors ===
probe cs_button '<button class="btn primary">OK</button>' '.btn'
probe cs_buttons '<button class="btn">A</button><button class="btn">B</button>' '.btn'
probe cs_link_href '<a href="#section">L</a>' -a href a
probe cs_nav '<nav><ul><li><a href="/">Home</a></li></ul></nav>' 'nav a'

# === Different doctypes ===
probe dt_html5 '<!DOCTYPE html><p>x</p>'
probe dt_xhtml '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><p>x</p>'
probe dt_quirks '<p>quirks</p>'

# === Edge cases for selectors ===
probe ec1 '<p><span>X</span></p>' 'p span'
probe ec2 '<div class="a"><div class="b">X</div></div>' '.a > .b'
probe ec3 '<div class="a"><span><div class="b">X</div></span></div>' '.a > .b'
probe ec4 '<h1>X</h1><h2>Y</h2><h3>Z</h3>' 'h1, h2, h3'
probe ec5 '<p>A</p><p>B</p>' 'p:first-child + p'

# === Misc whitespace ===
probe ws1 '<p>
A
B
</p>' -t p
probe ws2 '<pre>  preformatted  </pre>' pre
probe ws3 '<pre>  preformatted  </pre>' -t pre

echo "Total now: $(ls "$OUT" | grep -c '\.cmd$')"
