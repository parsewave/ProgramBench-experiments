#!/usr/bin/env bash
# Generate additional probes to stress-test the implementation.
set -u
REF=/workspace/executable
OUT=/work/work/goldens
mkdir -p "$OUT"

probe() {
    local name="$1"; shift
    local input="$1"; shift
    local args=("$@")
    {
        printf '%s\n' "${args[@]}"
    } > "$OUT/${name}.cmd"
    printf '%s' "$input" > "$OUT/${name}.stdin"
    "$REF" "${args[@]}" < "$OUT/${name}.stdin" > "$OUT/${name}.stdout" 2> "$OUT/${name}.stderr"
    echo "$?" > "$OUT/${name}.exit"
}

# === Real-world HTML snippets ===
probe real_page1 '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Page</title></head><body><h1>Hello</h1><p>World</p></body></html>' 'h1'
probe real_page2 '<!DOCTYPE html><html><head><meta charset="utf-8"><title>T</title></head><body><nav><ul><li><a href="/x">Home</a></li><li><a href="/y">About</a></li></ul></nav></body></html>' 'a'
probe real_links '<a href="/one">One</a> <a href="/two">Two</a> <a href="/three">Three</a>' -a href a
probe real_links_text '<a href="/one">One</a> <a href="/two">Two</a> <a href="/three">Three</a>' -t a

# === More selectors ===
probe sel_universal '<div>X</div>' '*'
probe sel_tag_class '<p class="a">A</p><div class="a">B</div>' 'p.a'
probe sel_id_dot '<p id="hi" class="x">X</p>' '#hi.x'
probe sel_attr_starts '<a href="https://example.com">Z</a><a href="/relative">Y</a>' '[href^="https"]'
probe sel_attr_ends '<a href="/foo.pdf">PDF</a><a href="/foo.html">HTML</a>' '[href$=".pdf"]'
probe sel_attr_contains '<a href="https://x.com/page">X</a><a href="/y">Y</a>' '[href*="x.com"]'
probe sel_attr_dash '<p lang="en-US">X</p><p lang="en">Y</p>' '[lang|="en"]'
probe sel_multi_class '<p class="a b">X</p><p class="a">Y</p>' '.a.b'
probe sel_attr_no_value '<input type="text" required><input type="text">' '[required]'

# === Complex combinators ===
probe combo_complex '<div><p><span>X</span></p></div>' 'div p span'
probe combo_complex2 '<div><p class="a"><span>X</span></p><p class="b"><span>Y</span></p></div>' 'p.a > span'
probe combo_adj_chain '<p>A</p><p>B</p><p>C</p>' 'p + p'
probe combo_gen_chain '<p>A</p><p>B</p><p>C</p>' 'p ~ p'

# === nth-child variants ===
probe nth_a '<div><p>1</p><p>2</p><p>3</p></div>' 'p:nth-child(2n+1)'
probe nth_b '<div><p>1</p><p>2</p><p>3</p></div>' 'p:nth-child(3n+1)'
probe nth_first_of_type '<div><span>S</span><p>1</p><p>2</p></div>' 'p:first-of-type'
probe nth_last_of_type '<div><p>1</p><p>2</p><span>S</span></div>' 'p:last-of-type'
probe nth_only_child '<div><p>1</p></div><div><p>2</p><span>S</span></div>' 'p:only-child'

# === Whitespace + entities ===
probe ws_text_multispace '<p>hello   world</p>' -t p
probe ws_text_tabs '<p>a	b</p>' -t p
probe ws_text_lf '<p>a
b
c</p>' -t p
probe entity_nbsp '<p>a&nbsp;b</p>' p
probe entity_amp_text '<p>a &amp; b</p>' -t p
probe entity_lt '<p>&lt;tag&gt;</p>' p
probe entity_lt_text '<p>&lt;tag&gt;</p>' -t p
probe entity_quot_in_attr '<a title="A &quot;Q&quot; B">x</a>' a

# === Multiple attributes & special values ===
probe attr_html5 '<input type="checkbox" checked>' input
probe attr_disabled '<input disabled>' input
probe attr_dquote_value '<input value="a&quot;b">' input
probe attr_squote_value "<input value='abc'>" input
probe attr_data_attribute '<div data-foo="bar" data-baz="qux">X</div>' '[data-foo]'

# === Text mode edge cases ===
probe text_empty '<p></p>' -t p
probe text_only_ws '<p>   </p>' -t p
probe text_only_ws_w '<p>   </p>' -t -w p
probe text_no_p '<div>X</div>' -t p
probe text_nested_text '<div>A<span>B</span>C</div>' -t div
probe text_nested_text_w '<div>A<span>B</span>C</div>' -t -w div
probe text_deep '<div><p><span><b>X</b></span></p></div>' -t div
probe text_multi '<p>A</p><p>B</p><p>C</p>' -t p
probe text_multi_w '<p>A</p><p>B</p><p>C</p>' -t -w p

# === Pretty edge cases ===
probe pretty_empty_div '<div></div>' -p div
probe pretty_text_only '<div>Hello</div>' -p div
probe pretty_deep '<div><div><div>X</div></div></div>' -p 'div div'
probe pretty_inline_only '<div><span>A</span><em>B</em></div>' -p div
probe pretty_mixed '<div><span>A</span><p>B</p><em>C</em></div>' -p div

# === Output to file ===
TMPOUT=$(mktemp -u)
probe outfile_test '<p>X</p>' -o "$TMPOUT" p
# Read back as stdout
cp "$TMPOUT" "$OUT/outfile_test.stdout"
rm -f "$TMPOUT"

# === Filename input ===
TMPIN=$(mktemp)
printf '<p>X</p>' > "$TMPIN"
probe filename_test '' -f "$TMPIN" p
rm -f "$TMPIN"

# === HTML5 quirks ===
probe q_open_tags '<p>A<p>B<p>C' p
probe q_li_unclosed '<ul><li>1<li>2<li>3</ul>' li
probe q_td_implicit '<table><td>X</td></table>'
probe q_a_in_a '<a href="x"><a href="y">L</a></a>' a
probe q_dl '<dl><dt>k1<dd>v1<dt>k2<dd>v2</dl>' dt

# === Special characters / attributes ===
probe sp_emoji '<p>Hello 😀</p>' p
probe sp_unicode '<p>café</p>' p
probe sp_attr_unicode '<a title="café">x</a>' a
probe sp_lf_in_attr '<a title="line1
line2">x</a>' a

# === Selectors with namespaces ===
# These might not be supported by htmlq's CSS parser
# probe ns_attr '<svg><circle r="10"/></svg>' '[r]'

# === Larger tree ===
probe large_doc '<!DOCTYPE html><html><head><title>T</title></head><body><div class="container"><header><h1>Title</h1></header><main><article id="a1"><h2>Article 1</h2><p>Lorem <strong>ipsum</strong> dolor.</p></article><article id="a2"><h2>Article 2</h2><p>Sit amet.</p></article></main><footer><p>&copy; 2024</p></footer></div></body></html>' 'article h2'
probe large_doc_pretty '<!DOCTYPE html><html><head><title>T</title></head><body><div class="container"><header><h1>Title</h1></header><main><article id="a1"><h2>Article 1</h2><p>Lorem <strong>ipsum</strong> dolor.</p></article></main></div></body></html>' -p article

# === Combined flags ===
probe combo_t_a '<a href="x">L</a>' -t -a href a
probe combo_p_a '<a href="x">L</a>' -p -a href a
probe combo_t_w_a '<a href="x">L</a>' -t -w -a href a

# === Edge cases with -b ===
probe base_fragment '<a href="#frag">F</a>' -b 'https://x.com/page' -a href a
probe base_protocol_rel '<a href="//foo.com">P</a>' -b 'https://x.com/' -a href a
probe base_with_query '<a href="?q=1">Q</a>' -b 'https://x.com/path' -a href a
probe base_src_attr '<img src="img.png">' -b 'https://x.com/p/' -a src img

# === Edge cases with -r ===
probe rem_multi '<div><p>X</p><script>S</script></div>' --remove-nodes script --remove-nodes p -- div

# === Default ===
probe default_doctype '<!doctype html><p>X</p>'
probe default_just_text 'just text'
probe default_with_doctype_html '<!DOCTYPE html><html><body><p>x</p></body></html>'

echo "Generated additional $(ls "$OUT" | grep -c '\.cmd$') total"
