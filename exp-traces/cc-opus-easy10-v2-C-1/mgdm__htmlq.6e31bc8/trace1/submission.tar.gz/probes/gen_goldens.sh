#!/usr/bin/env bash
# Generate golden frames for differential testing.
# Each probe writes to goldens/<name>.{cmd,stdin,stdout,stderr,exit}
set -u
REF=/workspace/executable
OUT=/work/work/goldens
mkdir -p "$OUT"

# probe NAME ARGS... < INPUT
probe() {
    local name="$1"; shift
    local input="$1"; shift
    local args=("$@")
    {
        printf '%s\n' "${args[@]}"
    } > "$OUT/${name}.cmd"
    printf '%s' "$input" > "$OUT/${name}.stdin"
    "$REF" "${args[@]}" < "$OUT/${name}.stdin" > "$OUT/${name}.stdout" 2> "$OUT/${name}.stderr"
    echo "$?" > "$OUT/${name}.exit"
}

# === Basic selectors ===
probe basic_p '<p>X</p>' p
probe basic_p_double '<p>A</p><p>B</p>' p
probe basic_class '<p class="x">A</p><p class="y">B</p>' .x
probe basic_id '<p id="me">A</p><p>B</p>' '#me'
probe basic_tag_class '<p class="x">A</p><div class="x">B</div>' p.x
probe basic_attr_exists '<p class="x">A</p><p>B</p>' '[class]'
probe basic_attr_eq '<p class="x">A</p><p class="y">B</p>' '[class="x"]'
probe basic_attr_includes '<p class="a x b">A</p><p class="y">B</p>' '[class~="x"]'

# === Combinators ===
probe combo_descendant '<div><p>A</p></div><p>B</p>' 'div p'
probe combo_child '<div><p>A</p></div><div><span><p>B</p></span></div>' 'div > p'
probe combo_adj_sibling '<p>A</p><div>B</div><p>C</p>' 'p + div'
probe combo_gen_sibling '<p>A</p><div>B</div><p>C</p>' 'p ~ div'
probe combo_union '<p>A</p><div>B</div><span>C</span>' 'p, span'

# === Pseudo-classes ===
probe pseudo_first '<ul><li>1</li><li>2</li></ul>' 'li:first-child'
probe pseudo_last '<ul><li>1</li><li>2</li></ul>' 'li:last-child'
probe pseudo_nth1 '<ul><li>1</li><li>2</li><li>3</li></ul>' 'li:nth-child(2)'
probe pseudo_nth_odd '<ul><li>1</li><li>2</li><li>3</li><li>4</li></ul>' 'li:nth-child(odd)'
probe pseudo_nth_even '<ul><li>1</li><li>2</li><li>3</li><li>4</li></ul>' 'li:nth-child(even)'
probe pseudo_not '<ul><li>1</li><li>2</li><li>3</li></ul>' 'li:not(:first-child)'

# === Default selector ===
probe default_selector '<p>X</p>'
probe default_html '<html><body><p>X</p></body></html>'
probe default_text 'plain text'

# === -t text ===
probe text_simple '<p>Hello World</p>' -t p
probe text_nested '<p>Hello <b>World</b>!</p>' -t p
probe text_entities '<p>foo &amp; bar</p>' -t p
probe text_multiple '<p>A</p><p>B</p>' -t p

# === -w ignore-whitespace ===
probe ws_only '<p>   </p>' -t -w p
probe ws_mixed '<div>A<span>B</span>C</div>' -t -w div
probe ws_lines '<p>X</p>\n\n<p>Y</p>' -t -w p

# === -a attribute ===
probe attr_basic '<a href="x">L</a>' -a href a
probe attr_missing '<a>L</a><a href="x">M</a>' -a href a
probe attr_multi '<a href="x">L</a><a href="y">M</a>' -a href a
probe attr_entity '<a href="?q=1&amp;b=2">L</a>' -a href a

# === -p pretty ===
probe pretty_p '<div><p>Hi</p></div>' -p div
probe pretty_span '<div><span>X</span></div>' -p div
probe pretty_nested '<div><p>A</p><p>B</p></div>' -p div
probe pretty_text '<div>text</div>' -p div

# === -b base URL ===
probe base_rel '<a href="x">L</a>' -b 'https://example.com/path/' -a href a
probe base_abs '<a href="/abs">L</a>' -b 'https://example.com/path/' -a href a
probe base_full '<a href="https://other.com/">L</a>' -b 'https://example.com/' -a href a
probe base_empty '<a href="x">L</a>' -b '' -a href a

# === -B detect base ===
probe detect_base_found '<base href="https://example.com/"><a href="x">L</a>' -B -a href a
probe detect_base_not '<a href="x">L</a>' -B -a href a
probe detect_base_fallback '<a href="x">L</a>' -B -b 'https://fallback.com/' -a href a
probe detect_base_override '<base href="https://example.com/"><a href="x">L</a>' -B -b 'https://fallback.com/' -a href a

# === -r remove ===
probe remove_simple '<div>A<span>X</span>B</div><span>Y</span>' --remove-nodes span -- span
probe remove_inside '<div><p>A</p><span>B</span></div>' --remove-nodes p div
probe remove_none '<div>X</div>' --remove-nodes nonexistent div

# === Void / self-closing ===
probe void_br '<br>' br
probe void_img '<img src="a.jpg" alt="b">' img
probe void_input '<input type="text" disabled>' input

# === Attribute sorting ===
probe attr_sort '<a z="1" a="2" m="3">A</a>' a
probe attr_quotes '<a href="x" alt="With &quot;quotes&quot;">A</a>' a
probe attr_amp '<a href="?a=1&amp;b=2">A</a>' a

# === Script / style raw text ===
probe script_raw '<script>var x = "<b>"; var y = "&amp;";</script>' script
probe style_raw '<style>a { color: red; }</style>' style

# === Comments / doctype ===
probe comment_inside '<p>X<!--c-->Y</p>' p
probe doctype_basic '<!DOCTYPE html><p>X</p>'

# === Misc ===
probe case_tag '<P>Caps</P>' p
probe unclosed_p '<p>unclosed' p
probe special_table '<table><tr><td>X</td></tr></table>'
probe special_li '<ul><li>1<li>2</ul>'
probe pp_auto_close '<p>a<p>b'

# === Help / version ===
probe help_short '' -h
probe help_long '' --help
probe version_short '' -V
probe version_long '' --version

# === Empty/error ===
probe empty ''
probe invalid_flag '' --bogus
probe invalid_selector 'x' 'div ['

echo "Generated $(ls "$OUT" | grep -c '\.cmd$') golden frames"
