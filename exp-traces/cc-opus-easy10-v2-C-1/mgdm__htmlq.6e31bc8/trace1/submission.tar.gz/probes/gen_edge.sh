#!/usr/bin/env bash
# Edge cases that might trip up the implementation.
set -u
REF=/workspace/executable
OUT=/work/work/goldens
mkdir -p "$OUT"

probe() {
    local name="$1"; shift
    local input="$1"; shift
    local args=("$@")
    {
        printf '%s\n' "${args[@]}"
    } > "$OUT/${name}.cmd"
    printf '%s' "$input" > "$OUT/${name}.stdin"
    "$REF" "${args[@]}" < "$OUT/${name}.stdin" > "$OUT/${name}.stdout" 2> "$OUT/${name}.stderr"
    echo "$?" > "$OUT/${name}.exit"
}

# === HTML5 parser specific ===
probe e_table_full '<table><thead><tr><th>H</th></tr></thead><tbody><tr><td>V</td></tr></tbody></table>'
probe e_select_options '<select><option>A</option><option>B</option></select>' option
probe e_form_inputs '<form><label>L</label><input><textarea>T</textarea><button>B</button></form>'
probe e_pre '<pre>line1
line2
line3</pre>' pre
probe e_pre_text '<pre>line1
line2
line3</pre>' -t pre
probe e_textarea '<textarea>hello</textarea>' textarea

# === Selectors with special chars ===
probe e_id_complex '<p id="foo-bar_baz">X</p>' '#foo-bar_baz'
probe e_class_digits '<p class="grid-3-col">X</p>' '.grid-3-col'
probe e_attr_numeric '<p data-num="42">X</p>' '[data-num="42"]'

# === Document fragments ===
probe e_frag1 '<p>orphan</p>'
probe e_frag2 '<div><p>nested</p></div>'
probe e_frag3 '   <p>with leading whitespace</p>   '

# === Selectors that should NOT match ===
probe e_no_match '<div>X</div>' 'p'
probe e_no_match_class '<p>X</p>' '.nonexistent'

# === Mixed CSS selectors ===
probe e_mix1 '<div class="a b c">X</div>' 'div.a.b.c'
probe e_mix2 '<div id="x" class="a">X</div>' '#x.a'
probe e_mix3 '<div class="container"><p>X</p></div>' '.container > p'
probe e_mix4 '<ul><li>1</li><li class="x">2</li><li>3</li></ul>' 'li.x ~ li'

# === Class normalization ===
probe e_class_ws '<p class="  a   b  ">X</p>' '.a'
probe e_class_one '<p class="a">X</p>' '.a'

# === HTML special parsing ===
probe e_cdata '<script><![CDATA[var x = 1;]]></script>' script
probe e_xmlpi '<?xml version="1.0"?><p>X</p>' p

# === Multiple consecutive elements ===
probe e_many_p '<p>1</p><p>2</p><p>3</p><p>4</p><p>5</p>' p
probe e_many_p_count '<p>1</p><p>2</p><p>3</p><p>4</p><p>5</p>' 'p:nth-of-type(3)'

# === Attribute edge cases ===
probe e_attr_dash_eq '<p lang="en-US">X</p><p lang="en">Y</p>' '[lang|="en"]'
probe e_attr_word '<p class="foo bar baz">X</p>' '[class~="bar"]'
probe e_attr_starts_with '<a href="https://x.com">X</a><a href="http://y.com">Y</a>' '[href^="https"]'
probe e_attr_ends_with '<a href="/pdf.pdf">P</a><a href="/html.html">H</a>' '[href$=".pdf"]'

# === HTML5 attribute parsing ===
probe e_attr_unquoted '<p class=foo>X</p>' 'p'
probe e_attr_squoted "<p class='foo'>X</p>" 'p'

# === Pretty edge cases ===
probe e_pretty_void '<br>' -p br
probe e_pretty_pre '<pre>line1
line2</pre>' -p pre
probe e_pretty_script '<script>var x = 1;</script>' -p script
probe e_pretty_a '<a href="x">L</a>' -p a
probe e_pretty_table '<table><tr><td>A</td><td>B</td></tr></table>' -p table

# === Combined ===
probe e_t_a_p '<a href="/x">L</a>' -t -a href -p a
probe e_remove_keep '<div><script>S</script><p>X</p></div>' -r script -- div

# === Special URLs ===
probe e_url_mailto '<a href="mailto:x@y.com">M</a>' -a href -b 'https://x.com/' a
probe e_url_javascript '<a href="javascript:void(0)">J</a>' -a href -b 'https://x.com/' a
probe e_url_data '<a href="data:text/plain,X">D</a>' -a href -b 'https://x.com/' a

# === Comments inside ===
probe e_comment_only '<!-- only comment -->'
probe e_comment_doctype '<!-- comment --><!DOCTYPE html><p>x</p>'

# === Stress test ===
probe e_long_attrs '<div class="a b c d e f g h i j k l m n o p q r s t u v w x y z">X</div>' '.a.b.c'
probe e_many_attrs '<input type="text" name="q" value="" placeholder="search" required class="form-control" id="search">' 'input'

# === Edge cases with text mode ===
probe e_text_with_br '<p>a<br>b</p>' -t p
probe e_text_with_br_w '<p>a<br>b</p>' -t -w p

# === HTML5 special elements ===
probe e_svg '<svg><circle cx="50" cy="50" r="40"/></svg>' 'svg'
probe e_math '<math><mi>x</mi></math>' 'math'

echo "Total now: $(ls "$OUT" | grep -c '\.cmd$')"
