#!/usr/bin/env bash
# Stress tests using larger, realistic HTML inputs.
set -u
REF=/workspace/executable
OUT=/work/work/goldens
mkdir -p "$OUT"

probe() {
    local name="$1"; shift
    local input="$1"; shift
    local args=("$@")
    {
        printf '%s\n' "${args[@]}"
    } > "$OUT/${name}.cmd"
    printf '%s' "$input" > "$OUT/${name}.stdin"
    "$REF" "${args[@]}" < "$OUT/${name}.stdin" > "$OUT/${name}.stdout" 2> "$OUT/${name}.stderr"
    echo "$?" > "$OUT/${name}.exit"
}

REAL_HTML='<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Example Page</title>
<link rel="stylesheet" href="/style.css">
</head>
<body>
<header>
  <nav>
    <ul>
      <li><a href="/">Home</a></li>
      <li><a href="/about">About</a></li>
      <li><a href="/contact">Contact</a></li>
    </ul>
  </nav>
</header>
<main>
  <article class="post" id="post-1">
    <header>
      <h1>Article Title</h1>
      <p class="meta">Posted by <a href="/users/jane">Jane</a> on <time datetime="2024-01-01">January 1, 2024</time></p>
    </header>
    <p>Lorem ipsum <strong>dolor sit</strong> amet, <em>consectetur</em> adipiscing elit.</p>
    <p>Sed do eiusmod tempor <a href="https://example.com">incididunt</a> ut labore.</p>
    <ul>
      <li>Item 1</li>
      <li>Item 2</li>
      <li>Item 3</li>
    </ul>
  </article>
  <article class="post" id="post-2">
    <header>
      <h1>Second Article</h1>
    </header>
    <p>Another article content.</p>
  </article>
</main>
<footer>
  <p>&copy; 2024 Example Corp.</p>
</footer>
</body>
</html>'

probe sr_full "$REAL_HTML" html
probe sr_articles "$REAL_HTML" article
probe sr_h1 "$REAL_HTML" h1
probe sr_links "$REAL_HTML" -a href a
probe sr_nav_links "$REAL_HTML" -a href 'nav a'
probe sr_text_p "$REAL_HTML" -t p
probe sr_text_p_w "$REAL_HTML" -t -w p
probe sr_first_article "$REAL_HTML" 'article:first-of-type'
probe sr_last_article "$REAL_HTML" 'article:last-of-type'
probe sr_post_class "$REAL_HTML" '.post'
probe sr_post_id "$REAL_HTML" '#post-1'
probe sr_meta_text "$REAL_HTML" -t '.meta'
probe sr_p_meta "$REAL_HTML" 'p.meta'
probe sr_li "$REAL_HTML" 'li'
probe sr_pretty_article "$REAL_HTML" -p 'article:first-of-type'
probe sr_remove_links "$REAL_HTML" -r a -- 'nav'
probe sr_remove_meta "$REAL_HTML" -r '.meta' -- 'article'
probe sr_base "$REAL_HTML" -b 'https://blog.example.org/' -a href 'nav a'
probe sr_detect_base '<html><head><base href="https://x.org/"></head><body><a href="page">L</a></body></html>' -B -a href a

# === Test what htmlq does with malformed HTML ===
probe sr_malformed1 '<p><div>weird</p></div>'
probe sr_malformed2 '<table><div>weird</div></table>'
probe sr_malformed3 '<form><form>nested</form></form>'

# === Selector edge cases ===
probe sr_id_only '<p id="x">A</p>' '#x'
probe sr_id_universal '<p id="x">A</p>' '*#x'
probe sr_class_universal '<p class="c">A</p>' '*.c'
probe sr_negation '<p>A</p><div>B</div>' ':not(p)'
probe sr_complex_pseudo '<ul><li>1</li><li>2</li><li>3</li><li>4</li><li>5</li></ul>' 'li:not(:first-child):not(:last-child)'

# === Various inputs ===
probe sr_no_html '<p>just a p</p>'
probe sr_with_doctype '<!DOCTYPE html>'
probe sr_just_doctype '<!DOCTYPE html><html></html>'

echo "Total now: $(ls "$OUT" | grep -c '\.cmd$')"
