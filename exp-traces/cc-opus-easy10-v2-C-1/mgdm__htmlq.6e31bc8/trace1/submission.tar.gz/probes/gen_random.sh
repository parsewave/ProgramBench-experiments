#!/usr/bin/env bash
# Statistical top-up: random/diverse probes to catch unexpected divergences.
set -u
REF=/workspace/executable
OUT=/work/work/goldens
mkdir -p "$OUT"

probe() {
    local name="$1"; shift
    local input="$1"; shift
    local args=("$@")
    {
        printf '%s\n' "${args[@]}"
    } > "$OUT/${name}.cmd"
    printf '%s' "$input" > "$OUT/${name}.stdin"
    "$REF" "${args[@]}" < "$OUT/${name}.stdin" > "$OUT/${name}.stdout" 2> "$OUT/${name}.stderr"
    echo "$?" > "$OUT/${name}.exit"
}

# === Complex selector combinations ===
probe rs1 '<table><tr><td>A</td><td>B</td></tr><tr><td>C</td><td>D</td></tr></table>' 'tr td:first-child'
probe rs2 '<table><tr><td>A</td><td>B</td></tr><tr><td>C</td><td>D</td></tr></table>' 'tr td:last-child'
probe rs3 '<table><tr class="hdr"><th>H</th></tr><tr><td>V</td></tr></table>' '.hdr th'
probe rs4 '<ul><li class="a">A</li><li class="b">B</li><li class="a b">AB</li></ul>' 'li.a.b'

probe rs5 '<form><input type="text"><input type="checkbox"><input type="submit"></form>' 'input[type="text"]'
probe rs6 '<form><input type="text" required><input type="email"></form>' 'input[required]'
probe rs7 '<form><input type="text"><input type="email" disabled></form>' 'input:disabled'

probe rs8 '<div><p>One</p><p>Two</p><p>Three</p></div>' 'p:not(:first-child)'
probe rs9 '<div><p>One</p><p>Two</p><p>Three</p></div>' 'p:not(:last-child)'

# === Empty selectors and combinations ===
probe rs10 '<p>X</p>' 'p, p'
probe rs11 '<div></div>' 'div'
probe rs12 '<div><p></p></div>' 'div p'

# === Multi-element pages ===
probe rs13 '<html><head><title>T</title></head><body><h1>A</h1><h2>B</h2><h3>C</h3></body></html>' 'h1, h2, h3'
probe rs14 '<header><nav><ul><li>1</li><li>2</li></ul></nav></header><main><section>X</section></main>' 'nav, section'

# === Unicode and special chars ===
probe rs15 '<p title="日本語">テスト</p>' p
probe rs16 '<p>café</p>' -t p
probe rs17 '<p title="quoted &quot;text&quot;">X</p>' -a title p

# === Boundary tests ===
probe rs18 '' html
probe rs19 '<' html
probe rs20 '<<<<>' html
probe rs21 '<p>' p
probe rs22 '</p>' p
probe rs23 '<p>x' p
probe rs24 '<p></p>' p

# === Comments ===
probe rs25 '<!-- comment --><p>X</p>' p
probe rs26 '<p><!-- c -->X</p>' p
probe rs27 '<p>Before<!-- c -->After</p>' -t p

# === Mixed HTML5 quirks ===
probe rs28 '<form><label>A<input></label></form>' 'label'
probe rs29 '<p>start <em>em</em> mid <strong>strong</strong> end</p>' p
probe rs30 '<details><summary>S</summary>D</details>' 'summary'

# === Real-world snippets ===
probe rs31 '<article class="post"><header><h1>Title</h1><time datetime="2024-01-01">Jan 1</time></header><p>Body</p></article>' 'article header h1'
probe rs32 '<article class="post"><header><h1>Title</h1></header><p>Body</p></article>' -t 'article > p'
probe rs33 '<table class="data"><thead><tr><th>K</th><th>V</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr></tbody></table>' 'thead th'

# === Combined options ===
probe rs34 '<a href="/about" class="nav">About</a><a href="/contact" class="nav">Contact</a>' -a href '.nav'
probe rs35 '<a href="/about" class="nav">About</a><a href="/contact" class="nav">Contact</a>' -t '.nav'
probe rs36 '<a href="/about" class="nav">About</a><a href="/contact" class="nav">Contact</a>' -p '.nav'

# === Pretty edge cases ===
probe rs37 '<table><tr><td>X</td></tr></table>' -p table
probe rs38 '<ul><li>A</li><li>B</li></ul>' -p ul
probe rs39 '<form><input type="text" name="q"><button>Go</button></form>' -p form
probe rs40 '<div>A<p>B</p>C<p>D</p>E</div>' -p div

# === -b base ===
probe rs41 '<a href="path/x">L</a>' -b 'https://example.com/' -a href a
probe rs42 '<a href="../up">L</a>' -b 'https://example.com/a/b/' -a href a
probe rs43 '<a href="">L</a>' -b 'https://example.com/x' -a href a

# === Detect base ===
probe rs44 '<head><base href="https://x.com/"></head><a href="path">L</a>' -B -a href a
probe rs45 '<head><base></head><a href="path">L</a>' -B -b 'https://default.com/' -a href a

# === Remove nodes (no bug — non-ancestor) ===
probe rs46 '<div>A</div><script>S</script>' -r script html
probe rs47 '<p>X</p><span>Y</span>' -r span -- p
probe rs48 '<p>X</p><span>Y</span><span>Z</span>' -r span -- p

# === Whitespace handling in -t -w ===
probe rs49 '<p>  hello  </p>' -t -w p
probe rs50 '<p>
  hello
  world
</p>' -t -w p

# === Different selector types in one ===
probe rs51 '<p id="i">X</p><p class="c">Y</p><p>Z</p>' '#i, .c, p:not(#i):not(.c)'

# === Nested with same tag ===
probe rs52 '<div><div><div>X</div></div></div>' 'div'
probe rs53 '<div><div><div>X</div></div></div>' 'div div'
probe rs54 '<div><div><div>X</div></div></div>' 'div > div'

# === Pretty with multiple matches ===
probe rs55 '<div><p>A</p></div><div><p>B</p></div>' -p div
probe rs56 '<div><p>A</p></div><div><p>B</p></div>' -p p

# === Help, version variations ===
probe rs_h '' -h
probe rs_help_long '' --help
probe rs_V '' -V
probe rs_version_long '' --version

# === Stdin variations ===
probe rs_empty_stdin '' html
probe rs_whitespace_stdin '   ' html

echo "Total: $(ls "$OUT" | grep -c '\.cmd$')"
