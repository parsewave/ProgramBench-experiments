-b
https://example.com/p?q=1
-a
href
a
