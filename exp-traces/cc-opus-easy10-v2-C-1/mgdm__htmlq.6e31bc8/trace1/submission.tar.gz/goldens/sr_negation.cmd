:not(p)
