li:not(:first-child):not(:last-child)
