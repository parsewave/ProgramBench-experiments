tr td:first-child
