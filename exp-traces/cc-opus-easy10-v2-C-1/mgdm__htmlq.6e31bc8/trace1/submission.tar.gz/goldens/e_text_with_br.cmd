-t
p
