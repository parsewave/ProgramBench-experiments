li:first-child
