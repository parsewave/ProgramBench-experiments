[href$=".pdf"]
