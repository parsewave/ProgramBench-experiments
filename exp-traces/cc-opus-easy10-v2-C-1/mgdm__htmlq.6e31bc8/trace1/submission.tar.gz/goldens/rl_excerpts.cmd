-t
.excerpt
