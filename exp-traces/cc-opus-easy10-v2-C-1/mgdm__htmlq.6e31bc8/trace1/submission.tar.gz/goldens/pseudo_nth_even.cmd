li:nth-child(even)
