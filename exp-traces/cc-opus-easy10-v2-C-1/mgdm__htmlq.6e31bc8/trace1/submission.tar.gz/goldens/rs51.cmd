#i, .c, p:not(#i):not(.c)
