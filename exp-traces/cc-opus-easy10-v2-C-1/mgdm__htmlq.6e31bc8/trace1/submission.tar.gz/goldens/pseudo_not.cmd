li:not(:first-child)
