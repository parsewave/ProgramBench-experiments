li.x ~ li
