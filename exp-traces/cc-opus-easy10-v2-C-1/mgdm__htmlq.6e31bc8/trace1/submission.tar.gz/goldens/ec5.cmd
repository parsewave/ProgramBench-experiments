p:first-child + p
