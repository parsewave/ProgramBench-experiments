p:first-of-type
