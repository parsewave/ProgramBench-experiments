li:first-child:last-child
