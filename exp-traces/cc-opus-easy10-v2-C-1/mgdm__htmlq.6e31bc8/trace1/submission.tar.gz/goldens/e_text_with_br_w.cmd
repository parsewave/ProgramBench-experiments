-t
-w
p
