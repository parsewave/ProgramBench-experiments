article:first-of-type
