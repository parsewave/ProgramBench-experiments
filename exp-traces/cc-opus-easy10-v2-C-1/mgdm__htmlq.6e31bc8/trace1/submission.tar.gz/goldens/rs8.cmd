p:not(:first-child)
