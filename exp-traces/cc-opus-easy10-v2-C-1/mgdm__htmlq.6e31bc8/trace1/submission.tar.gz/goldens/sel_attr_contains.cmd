[href*="x.com"]
