p:nth-of-type(3)
