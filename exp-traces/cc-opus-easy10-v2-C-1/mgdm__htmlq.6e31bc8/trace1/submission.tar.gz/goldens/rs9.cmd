p:not(:last-child)
