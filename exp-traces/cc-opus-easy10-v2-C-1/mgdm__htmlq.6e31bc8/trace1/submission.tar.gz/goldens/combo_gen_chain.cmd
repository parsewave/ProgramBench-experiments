p ~ p
