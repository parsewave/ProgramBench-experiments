li:nth-child(1):not(:last-child)
