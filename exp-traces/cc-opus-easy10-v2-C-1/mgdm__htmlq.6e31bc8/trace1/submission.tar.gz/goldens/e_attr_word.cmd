[class~="bar"]
