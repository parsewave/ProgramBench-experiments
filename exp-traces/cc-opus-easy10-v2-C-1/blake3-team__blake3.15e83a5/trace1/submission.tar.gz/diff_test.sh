#!/bin/bash
# Differential test: run a probe against both REF and SUT and diff
REF=/workspace/executable
SUT=/work/work/executable
PASS=0
FAIL=0
FAILED_TESTS=()

run_test() {
    local label=$1
    shift
    local ref_stdout ref_stderr ref_exit
    local sut_stdout sut_stderr sut_exit
    ref_stdout=$("$REF" "$@" 2>/tmp/ref_err < /dev/null)
    ref_exit=$?
    ref_stderr=$(cat /tmp/ref_err)
    sut_stdout=$("$SUT" "$@" 2>/tmp/sut_err < /dev/null)
    sut_exit=$?
    sut_stderr=$(cat /tmp/sut_err)
    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_stderr" = "$sut_stderr" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$label")
        echo "FAIL: $label"
        if [ "$ref_stdout" != "$sut_stdout" ]; then
            echo "  STDOUT differs:"
            echo "    REF: $(printf '%s' "$ref_stdout" | head -c 200)"
            echo "    SUT: $(printf '%s' "$sut_stdout" | head -c 200)"
        fi
        if [ "$ref_stderr" != "$sut_stderr" ]; then
            echo "  STDERR differs:"
            echo "    REF: $(printf '%s' "$ref_stderr" | head -c 200)"
            echo "    SUT: $(printf '%s' "$sut_stderr" | head -c 200)"
        fi
        if [ "$ref_exit" != "$sut_exit" ]; then
            echo "  EXIT differs: REF=$ref_exit SUT=$sut_exit"
        fi
    fi
}

run_test_stdin() {
    local label=$1
    local input=$2
    shift 2
    local ref_stdout ref_stderr ref_exit
    local sut_stdout sut_stderr sut_exit
    ref_stdout=$("$REF" "$@" 2>/tmp/ref_err < "$input")
    ref_exit=$?
    ref_stderr=$(cat /tmp/ref_err)
    sut_stdout=$("$SUT" "$@" 2>/tmp/sut_err < "$input")
    sut_exit=$?
    sut_stderr=$(cat /tmp/sut_err)
    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_stderr" = "$sut_stderr" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$label")
        echo "FAIL: $label"
        if [ "$ref_stdout" != "$sut_stdout" ]; then
            echo "  STDOUT differs:"
            diff <(printf '%s' "$ref_stdout") <(printf '%s' "$sut_stdout") | head -20
        fi
        if [ "$ref_stderr" != "$sut_stderr" ]; then
            echo "  STDERR differs:"
            diff <(printf '%s' "$ref_stderr") <(printf '%s' "$sut_stderr") | head -20
        fi
        if [ "$ref_exit" != "$sut_exit" ]; then
            echo "  EXIT differs: REF=$ref_exit SUT=$sut_exit"
        fi
    fi
}

# Basic hash tests
mkdir -p /tmp/test_data
printf "" > /tmp/test_data/empty.bin
printf "a" > /tmp/test_data/a.bin
printf "abc" > /tmp/test_data/abc.bin
python3 -c "import sys; sys.stdout.buffer.write(b'a' * 1024)" > /tmp/test_data/a1024.bin
python3 -c "import sys; sys.stdout.buffer.write(b'a' * 1025)" > /tmp/test_data/a1025.bin
python3 -c "import sys; sys.stdout.buffer.write(b'a' * 4096)" > /tmp/test_data/a4096.bin
python3 -c "import sys; sys.stdout.buffer.write(bytes(range(256)))" > /tmp/test_data/bytes256.bin

run_test_stdin "empty-stdin" /tmp/test_data/empty.bin
run_test_stdin "a-stdin" /tmp/test_data/a.bin
run_test_stdin "abc-stdin" /tmp/test_data/abc.bin
run_test_stdin "a1024-stdin" /tmp/test_data/a1024.bin
run_test_stdin "a1025-stdin" /tmp/test_data/a1025.bin
run_test_stdin "a4096-stdin" /tmp/test_data/a4096.bin
run_test_stdin "bytes256-stdin" /tmp/test_data/bytes256.bin

run_test "file-abc" /tmp/test_data/abc.bin
run_test "file-multi" /tmp/test_data/empty.bin /tmp/test_data/abc.bin /tmp/test_data/a1024.bin
run_test "no-names" --no-names /tmp/test_data/abc.bin
run_test "tag" --tag /tmp/test_data/abc.bin
run_test "tag-multi" --tag /tmp/test_data/empty.bin /tmp/test_data/abc.bin

# Length/seek
run_test_stdin "len-1" /tmp/test_data/abc.bin --length 1
run_test_stdin "len-64" /tmp/test_data/abc.bin --length 64
run_test_stdin "len-100" /tmp/test_data/abc.bin --length 100
run_test_stdin "len-0" /tmp/test_data/abc.bin --length 0
run_test_stdin "seek-16" /tmp/test_data/abc.bin --length 16 --seek 16
run_test_stdin "seek-64" /tmp/test_data/abc.bin --length 32 --seek 64
run_test_stdin "seek-100k" /tmp/test_data/abc.bin --length 8 --seek 100000
run_test_stdin "seek-large" /tmp/test_data/abc.bin --length 8 --seek 999999999

# Keyed
python3 -c "import sys; sys.stdout.buffer.write(b'\\0' * 32)" > /tmp/test_data/zerokey.bin
printf 'whats the Elvish word for friend' > /tmp/test_data/key32.bin
run_test_stdin "keyed-zero-abc" /tmp/test_data/zerokey.bin --keyed /tmp/test_data/abc.bin
run_test_stdin "keyed-k32-abc" /tmp/test_data/key32.bin --keyed /tmp/test_data/abc.bin
run_test_stdin "keyed-k32-multi" /tmp/test_data/key32.bin --keyed /tmp/test_data/abc.bin /tmp/test_data/a1024.bin

# Derive
run_test_stdin "derive-empty-empty" /tmp/test_data/empty.bin --derive-key ""
run_test_stdin "derive-empty-abc" /tmp/test_data/abc.bin --derive-key "ctx"
run_test_stdin "derive-long-empty" /tmp/test_data/empty.bin --derive-key "BLAKE3 2019-12-27 16:29:52 test vectors context"

# Raw
run_test_stdin "raw-abc" /tmp/test_data/abc.bin --raw
run_test_stdin "raw-len5" /tmp/test_data/abc.bin --raw --length 5
run_test_stdin "raw-seek" /tmp/test_data/abc.bin --raw --length 8 --seek 3

# Errors
run_test "err-bogus" --bogus
run_test "err-bad-len" --length abc /tmp/test_data/abc.bin
run_test "err-bad-len-empty" --length= /tmp/test_data/abc.bin
run_test "err-huge-len" --length 99999999999999999999 /tmp/test_data/abc.bin
run_test "err-missing-file" /tmp/nonexistent_xyz
run_test "err-mixed-file" /tmp/test_data/abc.bin /tmp/nonexistent_xyz
run_test "err-keyed-no-file" --keyed
run_test_stdin "err-short-key" /tmp/test_data/abc.bin --keyed /tmp/test_data/abc.bin
run_test_stdin "err-conflict-kd" /tmp/test_data/zerokey.bin --keyed --derive-key "ctx" /tmp/test_data/abc.bin
run_test "err-conflict-ct" --check --tag /tmp/test_data/abc.bin
run_test "err-conflict-cn" --check --no-names /tmp/test_data/abc.bin
run_test "err-conflict-cr" --check --raw /tmp/test_data/abc.bin
run_test "err-conflict-cl" --check --length 16 /tmp/test_data/abc.bin
run_test "err-quiet-alone" --quiet /tmp/test_data/abc.bin
run_test "err-raw-multi" --raw /tmp/test_data/abc.bin /tmp/test_data/abc.bin

# Help/version
run_test "help-long" --help
run_test "help-short" -h
run_test "version" --version
run_test "version-V" -V

# Check mode
HASH_ABC=$("$REF" /tmp/test_data/abc.bin | awk '{print $1}')
HASH_A1024=$("$REF" /tmp/test_data/a1024.bin | awk '{print $1}')
printf "%s  /tmp/test_data/abc.bin\n" "$HASH_ABC" > /tmp/test_data/check_good.txt
printf "0000000000000000000000000000000000000000000000000000000000000000  /tmp/test_data/abc.bin\n" > /tmp/test_data/check_bad.txt
printf "BLAKE3 (/tmp/test_data/abc.bin) = %s\n" "$HASH_ABC" > /tmp/test_data/check_bsd.txt
printf "%s  /tmp/test_data/abc.bin\n%s  /tmp/test_data/a1024.bin\n" "$HASH_ABC" "$HASH_A1024" > /tmp/test_data/check_multi.txt
printf "%s  /tmp/test_data/nonexist_xyz\n" "$HASH_ABC" > /tmp/test_data/check_missing.txt

run_test "check-good" --check /tmp/test_data/check_good.txt
run_test "check-bad" --check /tmp/test_data/check_bad.txt
run_test "check-bsd" --check /tmp/test_data/check_bsd.txt
run_test "check-multi" --check /tmp/test_data/check_multi.txt
run_test "check-quiet-good" --check --quiet /tmp/test_data/check_good.txt
run_test "check-quiet-bad" --check --quiet /tmp/test_data/check_bad.txt
run_test "check-missing" --check /tmp/test_data/check_missing.txt

# Format errors in check
printf "abc\n" > /tmp/test_data/check_bad_fmt.txt
printf "  /tmp/test_data/abc.bin\n" > /tmp/test_data/check_empty_hash.txt
printf "0000000000000000000000000000000000000000000000000000000000000000ZZ  /tmp/test_data/abc.bin\n" > /tmp/test_data/check_bad_hex.txt
printf "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ  /tmp/test_data/abc.bin\n" > /tmp/test_data/check_invalid_hex.txt
printf "%s\t/tmp/test_data/abc.bin\n" "$HASH_ABC" > /tmp/test_data/check_tab.txt
printf "%s /tmp/test_data/abc.bin\n" "$HASH_ABC" > /tmp/test_data/check_onespace.txt

run_test "check-bad-fmt" --check /tmp/test_data/check_bad_fmt.txt
run_test "check-empty-hash" --check /tmp/test_data/check_empty_hash.txt
run_test "check-bad-hex" --check /tmp/test_data/check_bad_hex.txt
run_test "check-invalid-hex" --check /tmp/test_data/check_invalid_hex.txt
run_test "check-tab" --check /tmp/test_data/check_tab.txt
run_test "check-onespace" --check /tmp/test_data/check_onespace.txt

# Special filenames
mkdir -p /tmp/test_data/spnames
touch /tmp/test_data/spnames/normal.txt
touch /tmp/test_data/spnames/"with space.txt"
touch "/tmp/test_data/spnames/with\\backslash.txt"
run_test "name-normal" /tmp/test_data/spnames/normal.txt
run_test "name-space" "/tmp/test_data/spnames/with space.txt"
run_test "name-backslash" "/tmp/test_data/spnames/with\\backslash.txt"
run_test "name-tag-backslash" --tag "/tmp/test_data/spnames/with\\backslash.txt"

# -- and -
run_test "dashdash" --
run_test "dashes" - -
run_test_stdin "dash-only" /tmp/test_data/abc.bin -

echo
echo "RESULTS: $PASS passed, $FAIL failed"
if [ $FAIL -gt 0 ]; then
    echo "Failed tests:"
    for t in "${FAILED_TESTS[@]}"; do echo "  - $t"; done
fi
exit $FAIL
