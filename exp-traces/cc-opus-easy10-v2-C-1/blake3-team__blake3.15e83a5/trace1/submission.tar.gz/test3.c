#include "blake3.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void) {
    /* Test various chunk boundaries with 'a' fill */
    size_t sizes[] = {1, 64, 65, 128, 1024, 1025, 2048, 2049, 4096, 8192, 16384, 32768, 65536, 65537, 131072, 262144, 524288, 1048576};
    for (size_t si = 0; si < sizeof(sizes)/sizeof(*sizes); si++) {
        size_t n = sizes[si];
        uint8_t *buf = malloc(n);
        memset(buf, 'a', n);
        blake3_hasher h;
        blake3_hasher_init(&h);
        blake3_hasher_update(&h, buf, n);
        uint8_t out[32];
        blake3_hasher_finalize(&h, out, 32);
        printf("%zu: ", n);
        for (int i = 0; i < 32; i++) printf("%02x", out[i]);
        printf("\n");
        free(buf);
    }
    return 0;
}
