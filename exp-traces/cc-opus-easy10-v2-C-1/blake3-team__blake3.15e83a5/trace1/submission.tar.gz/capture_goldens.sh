#!/bin/bash
# Capture golden test outputs from the reference binary
set -e
REF=/workspace/executable
DIR=/work/work/goldens
rm -rf $DIR
mkdir -p $DIR

# Make test inputs
mkdir -p $DIR/inputs
printf "" > $DIR/inputs/empty.bin
printf "a" > $DIR/inputs/a.bin
printf "abc" > $DIR/inputs/abc.bin
printf "Hello, World!" > $DIR/inputs/hello.bin
python3 -c "import sys; sys.stdout.buffer.write(b'a' * 1024)" > $DIR/inputs/a1024.bin
python3 -c "import sys; sys.stdout.buffer.write(b'a' * 1025)" > $DIR/inputs/a1025.bin
python3 -c "import sys; sys.stdout.buffer.write(b'a' * 2049)" > $DIR/inputs/a2049.bin
python3 -c "import sys; sys.stdout.buffer.write(bytes(range(256)))" > $DIR/inputs/bytes256.bin
python3 -c "import sys; sys.stdout.buffer.write(b'\\0' * 100000)" > $DIR/inputs/zeros100k.bin
python3 -c "import sys; sys.stdout.buffer.write(bytes(range(256))*4096)" > $DIR/inputs/big1M.bin

# Make standard test vector key: 32 bytes 0..31 cycled? Actually use 32 zeros
python3 -c "import sys; sys.stdout.buffer.write(b'\\0' * 32)" > $DIR/inputs/zerokey.bin
printf 'whats the Elvish word for friend' > $DIR/inputs/key32.bin  # 32-byte ASCII key

# Function to capture probe
probe() {
    local name=$1
    shift
    "$REF" "$@" > $DIR/$name.stdout 2> $DIR/$name.stderr
    echo $? > $DIR/$name.exit
}

probe_stdin() {
    local name=$1
    local input=$2
    shift 2
    "$REF" "$@" < $input > $DIR/$name.stdout 2> $DIR/$name.stderr
    echo $? > $DIR/$name.exit
}

# Various hash probes
probe_stdin hash_empty_stdin $DIR/inputs/empty.bin
probe_stdin hash_a_stdin $DIR/inputs/a.bin
probe_stdin hash_abc_stdin $DIR/inputs/abc.bin
probe_stdin hash_1024_stdin $DIR/inputs/a1024.bin
probe_stdin hash_1025_stdin $DIR/inputs/a1025.bin
probe_stdin hash_2049_stdin $DIR/inputs/a2049.bin
probe_stdin hash_256bytes_stdin $DIR/inputs/bytes256.bin
probe_stdin hash_100k_stdin $DIR/inputs/zeros100k.bin
probe_stdin hash_1M_stdin $DIR/inputs/big1M.bin

probe hash_file $DIR/inputs/abc.bin
probe hash_multi $DIR/inputs/empty.bin $DIR/inputs/abc.bin $DIR/inputs/a1024.bin
probe hash_no_names --no-names $DIR/inputs/abc.bin
probe hash_tag --tag $DIR/inputs/abc.bin

probe_stdin hash_len_1 $DIR/inputs/abc.bin --length 1
probe_stdin hash_len_64 $DIR/inputs/abc.bin --length 64
probe_stdin hash_len_100 $DIR/inputs/abc.bin --length 100
probe_stdin hash_len_0 $DIR/inputs/abc.bin --length 0
probe_stdin hash_seek_16 $DIR/inputs/abc.bin --length 16 --seek 16
probe_stdin hash_seek_64 $DIR/inputs/abc.bin --length 32 --seek 64
probe_stdin hash_seek_65 $DIR/inputs/abc.bin --length 32 --seek 65
probe_stdin hash_seek_1000 $DIR/inputs/abc.bin --length 8 --seek 1000

# Keyed mode
probe_stdin keyed_zero $DIR/inputs/zerokey.bin --keyed $DIR/inputs/abc.bin
probe_stdin keyed_zero_empty $DIR/inputs/zerokey.bin --keyed $DIR/inputs/empty.bin
probe_stdin keyed_k32 $DIR/inputs/key32.bin --keyed $DIR/inputs/abc.bin
probe_stdin keyed_k32_1024 $DIR/inputs/key32.bin --keyed $DIR/inputs/a1024.bin

# Derive-key mode
probe_stdin derive_ctx_empty $DIR/inputs/empty.bin --derive-key ""
probe_stdin derive_ctx_abc $DIR/inputs/abc.bin --derive-key "ctx"
probe_stdin derive_ctx_long $DIR/inputs/empty.bin --derive-key "BLAKE3 2019-12-27 16:29:52 test vectors context"

# Raw mode
probe_stdin raw_abc $DIR/inputs/abc.bin --raw
probe_stdin raw_len_5 $DIR/inputs/abc.bin --raw --length 5
probe_stdin raw_seek_3 $DIR/inputs/abc.bin --raw --length 8 --seek 3

# Errors
probe error_bogus --bogus
probe error_missing_file nonexistent_file_xyz
probe_stdin error_short_key $DIR/inputs/abc.bin --keyed $DIR/inputs/abc.bin  # 3-byte key
probe_stdin error_keyed_no_file $DIR/inputs/zerokey.bin --keyed
probe_stdin error_conflict_keyed_derive $DIR/inputs/zerokey.bin --keyed --derive-key "ctx" $DIR/inputs/abc.bin
probe_stdin error_length_neg $DIR/inputs/abc.bin --length=-1
probe_stdin error_length_abc $DIR/inputs/abc.bin --length abc
probe_stdin error_length_huge $DIR/inputs/abc.bin --length 99999999999999999999
probe_stdin error_check_tag $DIR/inputs/abc.bin --check --tag

# Help/version
probe help_long --help
probe help_short -h
probe version --version

# Check mode
HASH_ABC=$("$REF" $DIR/inputs/abc.bin | awk '{print $1}')
printf "%s  %s\n" "$HASH_ABC" "$DIR/inputs/abc.bin" > $DIR/inputs/check_good.txt
printf "0000000000000000000000000000000000000000000000000000000000000000  %s\n" "$DIR/inputs/abc.bin" > $DIR/inputs/check_bad.txt
printf "BLAKE3 (%s) = %s\n" "$DIR/inputs/abc.bin" "$HASH_ABC" > $DIR/inputs/check_bsd.txt

probe check_good --check $DIR/inputs/check_good.txt
probe check_bad --check $DIR/inputs/check_bad.txt
probe check_bsd --check $DIR/inputs/check_bsd.txt
probe check_quiet_good --check --quiet $DIR/inputs/check_good.txt
probe check_quiet_bad --check --quiet $DIR/inputs/check_bad.txt
probe check_missing_file --check $DIR/inputs/check_good.txt  # change file to nonexistent later

# Special cases
# Empty filename arg
# -- alone
probe dash_dash --
probe dash dash - -
probe_stdin stdin_only $DIR/inputs/abc.bin -
echo "Done. Outputs in $DIR"
ls $DIR | head -30
