/* b3sum reimplementation - CLI wrapper around BLAKE3 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdint.h>
#include <inttypes.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "blake3.h"

/* ------------------------------------------------------------------ */
/* Output helpers (clap-style error printing)                         */
/* ------------------------------------------------------------------ */

static void print_usage_default(FILE *f) {
    fputs("Usage: executable [OPTIONS] [FILE]...\n", f);
}

static void print_more_info(FILE *f) {
    fputs("\nFor more information, try '--help'.\n", f);
}

/* Print "Usage: executable [extra] [FILE]..." line */
static void print_usage_with(FILE *f, const char *extra) {
    if (extra && *extra)
        fprintf(f, "Usage: executable %s\n", extra);
    else
        print_usage_default(f);
}

static int err_unexpected_argument(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n", arg);
    fprintf(stderr, "\n  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    print_usage_default(stderr);
    print_more_info(stderr);
    return 2;
}

/* Like err_unexpected_argument but uses a contextual usage line (extra flags + file pattern). */
static int err_unexpected_argument_ctx(const char *arg, const char *flags_str, int file_count) {
    fprintf(stderr, "error: unexpected argument '%s' found\n", arg);
    fprintf(stderr, "\n  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    if ((flags_str == NULL || !*flags_str) && file_count == 0) {
        print_usage_default(stderr);
    } else if (file_count > 0) {
        fprintf(stderr, "Usage: executable%s%s <FILE>...\n",
                (flags_str && *flags_str) ? " " : "", flags_str ? flags_str : "");
    } else {
        fprintf(stderr, "Usage: executable%s%s [FILE]...\n",
                (flags_str && *flags_str) ? " " : "", flags_str ? flags_str : "");
    }
    print_more_info(stderr);
    return 2;
}

static int err_invalid_value_for(const char *value, const char *flag, const char *reason) {
    fprintf(stderr, "error: invalid value '%s' for '%s': %s\n", value, flag, reason);
    print_more_info(stderr);
    return 2;
}

static int err_required_args_not_provided(const char *which, const char *usage) {
    fprintf(stderr, "error: the following required arguments were not provided:\n  %s\n\n", which);
    print_usage_with(stderr, usage);
    print_more_info(stderr);
    return 2;
}

static int err_conflict(const char *a, const char *b, const char *usage) {
    fprintf(stderr, "error: the argument '%s' cannot be used with '%s'\n\n", a, b);
    print_usage_with(stderr, usage);
    print_more_info(stderr);
    return 2;
}

static int err_multiple_times(const char *flag) {
    fprintf(stderr, "error: the argument '%s' cannot be used multiple times\n\n", flag);
    print_usage_default(stderr);
    print_more_info(stderr);
    return 2;
}

/* ------------------------------------------------------------------ */
/* Long & short help text                                             */
/* ------------------------------------------------------------------ */

static const char *LONG_HELP =
"Usage: executable [OPTIONS] [FILE]...\n"
"\n"
"Arguments:\n"
"  [FILE]...\n"
"          Files to hash, or checkfiles to check\n"
"          \n"
"          When no file is given, or when - is given, read standard input.\n"
"\n"
"Options:\n"
"      --keyed\n"
"          Use the keyed mode, reading the 32-byte key from stdin\n"
"\n"
"      --derive-key <CONTEXT>\n"
"          Use the key derivation mode, with the given context string\n"
"          \n"
"          Cannot be used with --keyed.\n"
"\n"
"  -l, --length <LEN>\n"
"          The number of output bytes, before hex encoding\n"
"          \n"
"          [default: 32]\n"
"\n"
"      --seek <SEEK>\n"
"          The starting output byte offset, before hex encoding\n"
"          \n"
"          [default: 0]\n"
"\n"
"      --num-threads <NUM>\n"
"          The maximum number of threads to use\n"
"          \n"
"          By default, this is the number of logical cores. If this flag is omitted, or if its value\n"
"          is 0, RAYON_NUM_THREADS is also respected.\n"
"\n"
"      --no-mmap\n"
"          Disable memory mapping\n"
"          \n"
"          Currently this also disables multithreading.\n"
"\n"
"      --no-names\n"
"          Omit filenames in the output\n"
"\n"
"      --raw\n"
"          Write raw output bytes to stdout, rather than hex\n"
"          \n"
"          --no-names is implied. In this case, only a single input is allowed.\n"
"\n"
"      --tag\n"
"          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n"
"\n"
"  -c, --check\n"
"          Read BLAKE3 sums from the [FILE]s and check them\n"
"\n"
"      --quiet\n"
"          Skip printing OK for each checked file\n"
"          \n"
"          Must be used with --check.\n"
"\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n"
"\n"
"  -V, --version\n"
"          Print version\n";

static const char *SHORT_HELP =
"Usage: executable [OPTIONS] [FILE]...\n"
"\n"
"Arguments:\n"
"  [FILE]...  Files to hash, or checkfiles to check\n"
"\n"
"Options:\n"
"      --keyed                 Use the keyed mode, reading the 32-byte key from stdin\n"
"      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string\n"
"  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]\n"
"      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]\n"
"      --num-threads <NUM>     The maximum number of threads to use\n"
"      --no-mmap               Disable memory mapping\n"
"      --no-names              Omit filenames in the output\n"
"      --raw                   Write raw output bytes to stdout, rather than hex\n"
"      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n"
"  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them\n"
"      --quiet                 Skip printing OK for each checked file\n"
"  -h, --help                  Print help (see more with '--help')\n"
"  -V, --version               Print version\n";

/* ------------------------------------------------------------------ */
/* Parsed args                                                        */
/* ------------------------------------------------------------------ */

typedef struct {
    int keyed;
    int has_derive_key;
    const char *derive_key_ctx;
    int has_length;
    uint64_t length;
    int has_seek;
    uint64_t seek;
    int has_num_threads;
    uint64_t num_threads;
    int no_mmap;
    int no_names;
    int raw;
    int tag;
    int check;
    int quiet;
    /* count of each repeatable flag, for "cannot be used multiple times" detection */
    int n_keyed;
    int n_check;
    int n_raw;
    int n_tag;
    int n_no_names;
    int n_no_mmap;
    int n_quiet;
    /* positional file args */
    char **files;
    int file_count;
} args_t;

/* Returns 1 if `arg` looks like a known flag (would be parsed as a flag). */
static int looks_like_known_flag(const char *arg) {
    if (arg[0] != '-' || arg[1] == '\0') return 0;
    if (arg[1] == '-') {
        if (arg[2] == '\0') return 1;  /* "--" is the end-of-options marker */
        /* Compare against known long flags */
        const char *known[] = {
            "--keyed", "--derive-key", "--length", "--seek", "--num-threads",
            "--no-mmap", "--no-names", "--raw", "--tag", "--check",
            "--quiet", "--help", "--version", NULL
        };
        for (int k = 0; known[k]; k++) {
            size_t klen = strlen(known[k]);
            if (strncmp(arg, known[k], klen) == 0) {
                if (arg[klen] == '\0' || arg[klen] == '=') return 1;
            }
        }
        return 0;
    }
    /* Short option: check first char */
    char c = arg[1];
    return c == 'c' || c == 'h' || c == 'V' || c == 'l';
}

/* Parse an unsigned 64-bit integer. Returns 0 on success.
 * Sets reason string for error.
 * Matches Rust u64::from_str behavior: accepts optional leading '+'. */
static int parse_u64(const char *s, uint64_t *out, const char **reason) {
    if (!s) { *reason = "cannot parse integer from empty string"; return -1; }
    if (*s == '\0') { *reason = "cannot parse integer from empty string"; return -1; }
    /* Accept leading + (but not -) */
    if (*s == '+') s++;
    if (*s == '\0') { *reason = "invalid digit found in string"; return -1; }
    uint64_t v = 0;
    for (const char *p = s; *p; p++) {
        if (*p < '0' || *p > '9') {
            *reason = "invalid digit found in string";
            return -1;
        }
        unsigned d = (unsigned)(*p - '0');
        if (v > (UINT64_MAX - d) / 10) {
            *reason = "number too large to fit in target type";
            return -1;
        }
        v = v * 10 + d;
    }
    *out = v;
    return 0;
}

/* Argument parser - manual clap-like */
static int parse_args(int argc, char **argv, args_t *a) {
    memset(a, 0, sizeof(*a));
    a->length = 32;
    a->seek = 0;

    /* allocate room for positional files */
    a->files = calloc(argc + 1, sizeof(char*));
    a->file_count = 0;

    /* Buffer for collecting parsed flag tokens (for error usage line) */
    char flags_buf[1024];
    flags_buf[0] = '\0';
    size_t flags_pos = 0;
    #define APPEND_FLAG(s) do { \
        size_t L = strlen(s); \
        if (flags_pos + L + 1 < sizeof(flags_buf)) { \
            if (flags_pos) flags_buf[flags_pos++] = ' '; \
            memcpy(flags_buf + flags_pos, s, L); \
            flags_pos += L; \
            flags_buf[flags_pos] = '\0'; \
        } \
    } while(0)

    int i = 1;
    int positional_only = 0;

    while (i < argc) {
        char *arg = argv[i];

        if (positional_only) {
            if (*arg == '\0') {
                fprintf(stderr, "error: a value is required for '[FILE]...' but none was supplied\n");
                print_more_info(stderr);
                return 2;
            }
            a->files[a->file_count++] = arg;
            i++;
            continue;
        }
        if (strcmp(arg, "--") == 0) {
            positional_only = 1;
            i++;
            continue;
        }
        if (strcmp(arg, "-") == 0) {
            a->files[a->file_count++] = arg;
            i++;
            continue;
        }

        /* long options */
        if (strncmp(arg, "--", 2) == 0) {
            const char *eq = strchr(arg, '=');
            const char *name;
            const char *val;
            char namebuf[64];
            if (eq) {
                size_t nlen = (size_t)(eq - arg);
                if (nlen >= sizeof(namebuf)) return err_unexpected_argument(arg);
                memcpy(namebuf, arg, nlen);
                namebuf[nlen] = '\0';
                name = namebuf;
                val = eq + 1;
            } else {
                name = arg;
                val = NULL;
            }

            #define TAKE_VAL(flag_name) do { \
                if (val == NULL) { \
                    if (i + 1 >= argc) { \
                        fprintf(stderr, "error: a value is required for '%s' but none was supplied\n", flag_name); \
                        print_more_info(stderr); \
                        return 2; \
                    } \
                    const char *_next = argv[i+1]; \
                    if (_next[0] == '-' && _next[1] != '\0') { \
                        if (looks_like_known_flag(_next)) { \
                            fprintf(stderr, "error: a value is required for '%s' but none was supplied\n", flag_name); \
                            print_more_info(stderr); \
                            return 2; \
                        } else { \
                            /* For short options (-Xyz), report just '-X' (first 2 chars) */ \
                            if (_next[1] != '-') { \
                                char _buf[3] = {'-', _next[1], '\0'}; \
                                return err_unexpected_argument_ctx(_buf, flags_buf, a->file_count); \
                            } \
                            return err_unexpected_argument_ctx(_next, flags_buf, a->file_count); \
                        } \
                    } \
                    val = argv[++i]; \
                } \
            } while(0)

            if (strcmp(name, "--keyed") == 0) {
                if (val) return err_unexpected_argument(arg);
                if (a->n_keyed) return err_multiple_times("--keyed");
                a->keyed = 1;
                a->n_keyed = 1;
                APPEND_FLAG("--keyed");
            } else if (strcmp(name, "--derive-key") == 0) {
                TAKE_VAL("--derive-key <CONTEXT>");
                if (a->has_derive_key) return err_multiple_times("--derive-key <CONTEXT>");
                a->has_derive_key = 1;
                a->derive_key_ctx = val;
                APPEND_FLAG("--derive-key <CONTEXT>");
            } else if (strcmp(name, "--length") == 0) {
                TAKE_VAL("--length <LEN>");
                if (a->has_length) return err_multiple_times("--length <LEN>");
                uint64_t v;
                const char *r;
                if (parse_u64(val, &v, &r) != 0) {
                    return err_invalid_value_for(val, "--length <LEN>", r);
                }
                a->length = v;
                a->has_length = 1;
                APPEND_FLAG("--length <LEN>");
            } else if (strcmp(name, "--seek") == 0) {
                TAKE_VAL("--seek <SEEK>");
                if (a->has_seek) return err_multiple_times("--seek <SEEK>");
                uint64_t v;
                const char *r;
                if (parse_u64(val, &v, &r) != 0) {
                    return err_invalid_value_for(val, "--seek <SEEK>", r);
                }
                a->seek = v;
                a->has_seek = 1;
                APPEND_FLAG("--seek <SEEK>");
            } else if (strcmp(name, "--num-threads") == 0) {
                TAKE_VAL("--num-threads <NUM>");
                if (a->has_num_threads) return err_multiple_times("--num-threads <NUM>");
                uint64_t v;
                const char *r;
                if (parse_u64(val, &v, &r) != 0) {
                    return err_invalid_value_for(val, "--num-threads <NUM>", r);
                }
                a->num_threads = v;
                a->has_num_threads = 1;
                APPEND_FLAG("--num-threads <NUM>");
            } else if (strcmp(name, "--no-mmap") == 0) {
                if (val) return err_unexpected_argument(arg);
                if (a->n_no_mmap) return err_multiple_times("--no-mmap");
                a->no_mmap = 1;
                a->n_no_mmap = 1;
                APPEND_FLAG("--no-mmap");
            } else if (strcmp(name, "--no-names") == 0) {
                if (val) return err_unexpected_argument(arg);
                if (a->n_no_names) return err_multiple_times("--no-names");
                a->no_names = 1;
                a->n_no_names = 1;
                APPEND_FLAG("--no-names");
            } else if (strcmp(name, "--raw") == 0) {
                if (val) return err_unexpected_argument(arg);
                if (a->n_raw) return err_multiple_times("--raw");
                a->raw = 1;
                a->n_raw = 1;
                APPEND_FLAG("--raw");
            } else if (strcmp(name, "--tag") == 0) {
                if (val) return err_unexpected_argument(arg);
                if (a->n_tag) return err_multiple_times("--tag");
                a->tag = 1;
                a->n_tag = 1;
                APPEND_FLAG("--tag");
            } else if (strcmp(name, "--check") == 0) {
                if (val) return err_unexpected_argument(arg);
                if (a->n_check) return err_multiple_times("--check");
                a->check = 1;
                a->n_check = 1;
                APPEND_FLAG("--check");
            } else if (strcmp(name, "--quiet") == 0) {
                if (val) return err_unexpected_argument(arg);
                if (a->n_quiet) return err_multiple_times("--quiet");
                a->quiet = 1;
                a->n_quiet = 1;
                APPEND_FLAG("--quiet");
            } else if (strcmp(name, "--help") == 0) {
                fputs(LONG_HELP, stdout);
                exit(0);
            } else if (strcmp(name, "--version") == 0) {
                fputs("b3sum 1.8.4\n", stdout);
                exit(0);
            } else {
                return err_unexpected_argument_ctx(arg, flags_buf, a->file_count);
            }
            i++;
            continue;
            #undef TAKE_VAL
        }

        /* short options */
        if (arg[0] == '-' && arg[1] != '\0' && arg[1] != '-') {
            /* short option may be: -h, -V, -c, -l[N] (where l takes a value) */
            const char *p = arg + 1;
            while (*p) {
                char c = *p;
                if (c == 'h') {
                    fputs(SHORT_HELP, stdout);
                    exit(0);
                } else if (c == 'V') {
                    fputs("b3sum 1.8.4\n", stdout);
                    exit(0);
                } else if (c == 'c') {
                    if (a->n_check) return err_multiple_times("--check");
                    a->check = 1;
                    a->n_check = 1;
                    APPEND_FLAG("--check");
                    p++;
                } else if (c == 'l') {
                    /* takes value */
                    const char *val;
                    if (p[1]) {
                        val = p + 1;
                    } else {
                        if (i + 1 >= argc) {
                            fprintf(stderr, "error: a value is required for '--length <LEN>' but none was supplied\n");
                            print_more_info(stderr);
                            return 2;
                        }
                        const char *next = argv[i+1];
                        if (next[0] == '-' && next[1] != '\0') {
                            if (looks_like_known_flag(next)) {
                                fprintf(stderr, "error: a value is required for '--length <LEN>' but none was supplied\n");
                                print_more_info(stderr);
                                return 2;
                            } else {
                                return err_unexpected_argument_ctx(next, flags_buf, a->file_count);
                            }
                        }
                        val = argv[++i];
                    }
                    if (a->has_length) return err_multiple_times("--length <LEN>");
                    uint64_t v;
                    const char *r;
                    if (parse_u64(val, &v, &r) != 0) {
                        return err_invalid_value_for(val, "--length <LEN>", r);
                    }
                    a->length = v;
                    a->has_length = 1;
                    APPEND_FLAG("--length <LEN>");
                    /* consumed rest of arg */
                    p = "";
                    break;
                } else {
                    /* Unknown short option: usage is the default form */
                    char buf[3] = {'-', c, '\0'};
                    return err_unexpected_argument(buf);
                }
            }
            i++;
            continue;
        }

        /* positional */
        if (*arg == '\0') {
            fprintf(stderr, "error: a value is required for '[FILE]...' but none was supplied\n");
            print_more_info(stderr);
            return 2;
        }
        a->files[a->file_count++] = arg;
        i++;
    }

    return 0;
}

/* ------------------------------------------------------------------ */
/* Filename escape (for output)                                       */
/* Rules: if name contains '\n', '\r', or '\\', the line is prefixed  */
/* with a backslash, and each of those bytes is escaped (n,r,\\).     */
/* ------------------------------------------------------------------ */

static int name_needs_escape(const uint8_t *name, size_t len) {
    for (size_t i = 0; i < len; i++) {
        if (name[i] == '\n' || name[i] == '\r' || name[i] == '\\') return 1;
    }
    return 0;
}

static void write_escaped_name(FILE *f, const uint8_t *name, size_t len) {
    for (size_t i = 0; i < len; i++) {
        uint8_t c = name[i];
        if (c == '\n') { fputc('\\', f); fputc('n', f); }
        else if (c == '\r') { fputc('\\', f); fputc('r', f); }
        else if (c == '\\') { fputc('\\', f); fputc('\\', f); }
        else fputc(c, f);
    }
}

/* ------------------------------------------------------------------ */
/* Hashing helpers                                                    */
/* ------------------------------------------------------------------ */

/* Initialize hasher according to mode */
static int init_hasher(blake3_hasher *h, const args_t *a, const uint8_t *key) {
    if (a->keyed) {
        blake3_hasher_init_keyed(h, key);
    } else if (a->has_derive_key) {
        blake3_hasher_init_derive_key(h, a->derive_key_ctx);
    } else {
        blake3_hasher_init(h);
    }
    return 0;
}

/* Hash a file by path. Returns 0 on success, -1 on error (errno set).
 * Also returns -2 if directory. */
static int hash_file(const char *path, const args_t *a, const uint8_t *key, blake3_hasher *h_out) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;

    struct stat st;
    if (fstat(fd, &st) == 0 && S_ISDIR(st.st_mode)) {
        close(fd);
        errno = EISDIR;
        return -1;
    }

    init_hasher(h_out, a, key);

    char buf[65536];
    for (;;) {
        ssize_t n = read(fd, buf, sizeof(buf));
        if (n < 0) {
            if (errno == EINTR) continue;
            close(fd);
            return -1;
        }
        if (n == 0) break;
        blake3_hasher_update(h_out, buf, (size_t)n);
    }
    close(fd);
    return 0;
}

static int hash_stdin(const args_t *a, const uint8_t *key, blake3_hasher *h_out) {
    init_hasher(h_out, a, key);
    char buf[65536];
    for (;;) {
        ssize_t n = read(STDIN_FILENO, buf, sizeof(buf));
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) break;
        blake3_hasher_update(h_out, buf, (size_t)n);
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* Output                                                             */
/* ------------------------------------------------------------------ */

static void write_hex(FILE *f, const uint8_t *bytes, size_t len) {
    static const char hex[] = "0123456789abcdef";
    for (size_t i = 0; i < len; i++) {
        fputc(hex[bytes[i] >> 4], f);
        fputc(hex[bytes[i] & 0xF], f);
    }
}

/* Generate a hex hash (length bytes, output length*2 hex chars).
 * Returns 1 if the name needed escaping (so output line begins with \) */
static void write_hash_line(FILE *f,
                            const blake3_hasher *h,
                            const args_t *a,
                            const char *name,
                            int is_stdin) {
    /* Compute the hash output bytes (possibly seeked) */
    uint8_t *out = NULL;
    if (a->length > 0) {
        out = malloc((size_t)a->length);
        if (!out) {
            fprintf(stderr, "b3sum: out of memory\n");
            exit(1);
        }
        blake3_hasher_finalize_seek(h, a->seek, out, (size_t)a->length);
    }

    if (a->raw) {
        if (a->length > 0) fwrite(out, 1, (size_t)a->length, f);
        free(out);
        return;
    }

    const char *fname = is_stdin ? "-" : name;
    size_t fname_len = strlen(fname);
    int needs_escape = !is_stdin && name_needs_escape((const uint8_t*)fname, fname_len);

    if (a->no_names) {
        /* --no-names overrides --tag: produce just the hash */
        if (a->length > 0) write_hex(f, out, (size_t)a->length);
        fputc('\n', f);
    } else if (a->tag) {
        if (needs_escape) fputc('\\', f);
        fputs("BLAKE3 (", f);
        write_escaped_name(f, (const uint8_t*)fname, fname_len);
        fputs(") = ", f);
        if (a->length > 0) write_hex(f, out, (size_t)a->length);
        fputc('\n', f);
    } else {
        if (needs_escape) fputc('\\', f);
        if (a->length > 0) write_hex(f, out, (size_t)a->length);
        fputs("  ", f);
        write_escaped_name(f, (const uint8_t*)fname, fname_len);
        fputc('\n', f);
    }
    free(out);
}

/* ------------------------------------------------------------------ */
/* Check mode                                                         */
/* ------------------------------------------------------------------ */

/* Parse a check line. Returns 0 on success, sets *err_msg on parse error.
 * The hash_out is filled with 32 hex-decoded bytes, name_out points to
 * a malloc'd buffer with original (possibly escaped) filename for display
 * and *name_unescaped is the actual filename to open.
 * *escaped_prefix is 1 if the original line started with '\'.
 */
typedef struct {
    uint8_t hash[32];
    uint8_t *display_name;    /* original name (after stripping leading \ if any) - for display */
    size_t display_name_len;
    uint8_t *open_name;       /* unescaped name for opening - null terminated */
    int escaped_prefix;       /* 1 if line started with \ */
} check_entry;

static void free_check_entry(check_entry *e) {
    free(e->display_name);
    free(e->open_name);
    e->display_name = NULL;
    e->open_name = NULL;
}

/* Parse line (without trailing newline). Returns NULL on success, error message on failure. */
static const char *parse_check_line(const uint8_t *line, size_t len, check_entry *out) {
    memset(out, 0, sizeof(*out));
    if (len == 0) return "Empty line";

    int escaped = 0;
    if (line[0] == '\\') {
        escaped = 1;
        line++;
        len--;
    }

    const uint8_t *name_start, *name_end, *hash_start, *hash_end;
    int parsed = 0;

    /* Try BSD format first: starts with "BLAKE3 (" and contains ") = " */
    const char *bsd_prefix = "BLAKE3 (";
    size_t bsd_prefix_len = 8;
    if (len >= bsd_prefix_len + 4 /* min ") = " after prefix */
        && memcmp(line, bsd_prefix, bsd_prefix_len) == 0) {
        const char *sep = ") = ";
        size_t sep_len = 4;
        const uint8_t *match = NULL;
        /* Search rightmost ") = " between (after prefix) and end */
        for (size_t i = len; i >= bsd_prefix_len + sep_len; i--) {
            const uint8_t *p = line + i - sep_len;
            if (memcmp(p, sep, sep_len) == 0) { match = p; break; }
        }
        if (match) {
            name_start = line + bsd_prefix_len;
            name_end = match;
            hash_start = match + sep_len;
            hash_end = line + len;
            if (name_end == name_start) {
                return "empty file path";
            }
            parsed = 1;
        }
    }

    /* Fall back to SHA-style: split at first "  " (two spaces) */
    if (!parsed) {
        const uint8_t *match = NULL;
        for (size_t i = 0; i + 1 < len; i++) {
            if (line[i] == ' ' && line[i+1] == ' ') {
                match = line + i;
                break;
            }
        }
        if (!match) return "Invalid check line format";
        hash_start = line;
        hash_end = match;
        name_start = match + 2;
        name_end = line + len;
    }

    if (hash_end - hash_start != 64) return "Invalid hash length";
    /* Validate hex (lowercase only) and decode */
    for (int i = 0; i < 64; i++) {
        uint8_t c = hash_start[i];
        uint8_t v;
        if (c >= '0' && c <= '9') v = c - '0';
        else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
        else return "Invalid hex";
        if (i & 1) out->hash[i/2] |= v;
        else out->hash[i/2] = v << 4;
    }

    size_t name_len = (size_t)(name_end - name_start);
    out->display_name = malloc(name_len + 1);
    memcpy(out->display_name, name_start, name_len);
    out->display_name[name_len] = '\0';
    out->display_name_len = name_len;
    out->escaped_prefix = escaped;

    /* Build unescaped name */
    uint8_t *open_name = malloc(name_len + 1);
    size_t oi = 0;
    if (escaped) {
        size_t i = 0;
        while (i < name_len) {
            if (name_start[i] == '\\') {
                if (i + 1 >= name_len) {
                    free(open_name);
                    free(out->display_name);
                    out->display_name = NULL;
                    return "Invalid backslash escape";
                }
                if (name_start[i+1] == 'n') { open_name[oi++] = '\n'; i += 2; continue; }
                if (name_start[i+1] == 'r') { open_name[oi++] = '\r'; i += 2; continue; }
                if (name_start[i+1] == '\\') { open_name[oi++] = '\\'; i += 2; continue; }
                free(open_name);
                free(out->display_name);
                out->display_name = NULL;
                return "Invalid backslash escape";
            }
            open_name[oi++] = name_start[i++];
        }
    } else {
        memcpy(open_name, name_start, name_len);
        oi = name_len;
    }
    open_name[oi] = '\0';
    out->open_name = open_name;
    return NULL;
}

/* Print the display name with optional escape prefix */
static void write_display_name(FILE *f, const check_entry *e) {
    if (e->escaped_prefix) fputc('\\', f);
    fwrite(e->display_name, 1, e->display_name_len, f);
}

/* Read whole file (or stdin) into a buffer */
static int slurp_file(const char *path, uint8_t **buf_out, size_t *len_out) {
    int fd;
    int is_stdin = (path == NULL);
    if (is_stdin) {
        fd = STDIN_FILENO;
    } else {
        fd = open(path, O_RDONLY);
        if (fd < 0) return -1;
        struct stat st;
        if (fstat(fd, &st) == 0 && S_ISDIR(st.st_mode)) {
            close(fd);
            errno = EISDIR;
            return -1;
        }
    }
    size_t cap = 4096;
    size_t len = 0;
    uint8_t *buf = malloc(cap);
    if (!buf) { if (!is_stdin) close(fd); return -1; }
    for (;;) {
        if (len == cap) {
            cap *= 2;
            uint8_t *nb = realloc(buf, cap);
            if (!nb) { free(buf); if (!is_stdin) close(fd); return -1; }
            buf = nb;
        }
        ssize_t n = read(fd, buf + len, cap - len);
        if (n < 0) {
            if (errno == EINTR) continue;
            free(buf);
            if (!is_stdin) close(fd);
            return -1;
        }
        if (n == 0) break;
        len += (size_t)n;
    }
    if (!is_stdin) close(fd);
    *buf_out = buf;
    *len_out = len;
    return 0;
}

/* Check a single checkfile. Returns number of failed checksums. */
static long check_one_file(const char *path, const args_t *a) {
    uint8_t *data = NULL;
    size_t data_len = 0;
    int is_stdin = (path == NULL || strcmp(path, "-") == 0);
    int rc = slurp_file(is_stdin ? NULL : path, &data, &data_len);
    if (rc != 0) {
        /* The reference uses "Error: <msg> (os error <n>)" for failing to
           open the checkfile itself (no path prefix). */
        fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
        return -1;  /* indicate file-level error */
    }

    long failed = 0;
    size_t pos = 0;
    while (pos < data_len) {
        size_t line_end = pos;
        while (line_end < data_len && data[line_end] != '\n') line_end++;
        size_t line_len = line_end - pos;
        /* Strip trailing \r (handle CRLF line endings) */
        if (line_len > 0 && data[pos + line_len - 1] == '\r') line_len--;

        check_entry entry;
        const char *err = parse_check_line(data + pos, line_len, &entry);
        if (err) {
            fprintf(stderr, "b3sum: %s\n", err);
            failed++;
        } else {
            /* Compute hash of entry->open_name file */
            blake3_hasher h;
            int hr = hash_file((const char*)entry.open_name, a, NULL, &h);
            if (hr != 0) {
                write_display_name(stdout, &entry);
                fprintf(stdout, ": FAILED (%s (os error %d))\n", strerror(errno), errno);
                fflush(stdout);
                failed++;
            } else {
                uint8_t out[32];
                blake3_hasher_finalize_seek(&h, a->seek, out, 32);
                if (memcmp(out, entry.hash, 32) == 0) {
                    if (!a->quiet) {
                        write_display_name(stdout, &entry);
                        fputs(": OK\n", stdout);
                        fflush(stdout);
                    }
                } else {
                    write_display_name(stdout, &entry);
                    fputs(": FAILED\n", stdout);
                    fflush(stdout);
                    failed++;
                }
            }
            free_check_entry(&entry);
        }
        pos = (line_end < data_len) ? line_end + 1 : line_end;
    }
    free(data);
    return failed;
}

/* Main check mode entry */
static int do_check(const args_t *a) {
    long total_failed = 0;
    int rc = 0;
    if (a->file_count == 0) {
        long f = check_one_file(NULL, a);  /* stdin */
        if (f < 0) { rc = 1; }
        else total_failed += f;
    } else {
        for (int i = 0; i < a->file_count; i++) {
            const char *p = a->files[i];
            long f;
            if (strcmp(p, "-") == 0) f = check_one_file(NULL, a);
            else f = check_one_file(p, a);
            if (f < 0) { rc = 1; }
            else total_failed += f;
        }
    }
    if (total_failed > 0) {
        if (total_failed == 1) {
            fprintf(stderr, "b3sum: WARNING: 1 computed checksum did NOT match\n");
        } else {
            fprintf(stderr, "b3sum: WARNING: %ld computed checksums did NOT match\n", total_failed);
        }
        rc = 1;
    }
    return rc;
}

/* ------------------------------------------------------------------ */
/* Main hash flow                                                     */
/* ------------------------------------------------------------------ */

/* Read 32-byte key from stdin. Returns 0 on success, prints error and returns -1. */
static int read_key_from_stdin(uint8_t key[32]) {
    size_t got = 0;
    while (got < 32) {
        ssize_t n = read(STDIN_FILENO, key + got, 32 - got);
        if (n < 0) {
            if (errno == EINTR) continue;
            fprintf(stderr, "Error: failed to read key from stdin: %s\n", strerror(errno));
            return -1;
        }
        if (n == 0) break;
        got += (size_t)n;
    }
    if (got < 32) {
        fprintf(stderr, "Error: expected 32 key bytes from stdin, found %zu\n", got);
        return -1;
    }
    /* Try one more byte */
    uint8_t extra;
    ssize_t n = read(STDIN_FILENO, &extra, 1);
    if (n > 0) {
        fprintf(stderr, "Error: read more than 32 key bytes from stdin\n");
        return -1;
    }
    return 0;
}

static int do_hash(const args_t *a) {
    /* If --raw, only one input allowed */
    if (a->raw && a->file_count > 1) {
        fprintf(stderr, "Error: Only one filename can be provided when using --raw\n");
        return 1;
    }

    uint8_t key[32];
    if (a->keyed) {
        if (read_key_from_stdin(key) != 0) return 1;
    }

    int rc = 0;
    int has_files = a->file_count > 0;

    if (!has_files) {
        /* stdin */
        blake3_hasher h;
        if (hash_stdin(a, key, &h) != 0) {
            fprintf(stderr, "b3sum: -: %s (os error %d)\n", strerror(errno), errno);
            return 1;
        }
        write_hash_line(stdout, &h, a, "-", 1);
    } else {
        for (int i = 0; i < a->file_count; i++) {
            const char *p = a->files[i];
            int is_stdin = (strcmp(p, "-") == 0);
            if (is_stdin && a->keyed) {
                fprintf(stderr, "b3sum: -: Cannot open `-` in keyed mode\n");
                rc = 1;
                continue;
            }
            blake3_hasher h;
            int hr;
            if (is_stdin) {
                hr = hash_stdin(a, key, &h);
            } else {
                hr = hash_file(p, a, key, &h);
            }
            if (hr != 0) {
                fprintf(stderr, "b3sum: %s: %s (os error %d)\n", p, strerror(errno), errno);
                rc = 1;
                continue;
            }
            write_hash_line(stdout, &h, a, p, is_stdin);
        }
    }
    return rc;
}

/* ------------------------------------------------------------------ */
/* Cross-flag validation                                              */
/* ------------------------------------------------------------------ */

/* Returns 0 on success, exit code on error.
 * Validates argument combinations to match clap-style errors. */
static int validate_args(args_t *a) {
    /* mutex: --keyed vs --derive-key */
    if (a->keyed && a->has_derive_key) {
        return err_conflict("--keyed", "--derive-key <CONTEXT>", "--keyed <FILE>...");
    }

    /* --check conflicts. Usage shows <FILE>... if files were given, else [FILE]... */
    const char *check_usage = (a->file_count > 0) ? "--check <FILE>..." : "--check [FILE]...";
    if (a->check) {
        if (a->tag)            return err_conflict("--check", "--tag", check_usage);
        if (a->no_names)       return err_conflict("--check", "--no-names", check_usage);
        if (a->raw)            return err_conflict("--check", "--raw", check_usage);
        if (a->has_length)     return err_conflict("--check", "--length <LEN>", check_usage);
        if (a->has_derive_key) return err_conflict("--check", "--derive-key <CONTEXT>", check_usage);
        if (a->keyed)          return err_conflict("--check", "--keyed", check_usage);
    }

    /* --quiet requires --check */
    if (a->quiet && !a->check) {
        return err_required_args_not_provided("--check", "--check --quiet <FILE>...");
    }

    /* --keyed requires FILE */
    if (a->keyed && a->file_count == 0) {
        return err_required_args_not_provided("<FILE>...", "--keyed <FILE>...");
    }

    return 0;
}

/* ------------------------------------------------------------------ */
/* Entry point                                                        */
/* ------------------------------------------------------------------ */

int main(int argc, char **argv) {
    args_t a;
    int prc = parse_args(argc, argv, &a);
    if (prc != 0) {
        free(a.files);
        return prc;
    }
    int vrc = validate_args(&a);
    if (vrc != 0) {
        free(a.files);
        return vrc;
    }

    int rc;
    if (a.check) {
        rc = do_check(&a);
    } else {
        rc = do_hash(&a);
    }
    free(a.files);
    return rc;
}
