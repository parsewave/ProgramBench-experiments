#include "blake3.h"
#include <string.h>

/* BLAKE3 flag values */
#define CHUNK_START         (1u << 0)
#define CHUNK_END           (1u << 1)
#define PARENT              (1u << 2)
#define ROOT                (1u << 3)
#define KEYED_HASH          (1u << 4)
#define DERIVE_KEY_CONTEXT  (1u << 5)
#define DERIVE_KEY_MATERIAL (1u << 6)

/* BLAKE3 initialization vector (same as SHA-256 IV) */
static const uint32_t IV[8] = {
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
};

/* Message schedule permutation */
static const uint8_t MSG_PERMUTATION[16] = {
    2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8
};

static inline uint32_t rotr32(uint32_t x, int n) {
    return (x >> n) | (x << (32 - n));
}

static inline uint32_t load32_le(const uint8_t *src) {
    return (uint32_t)src[0]
         | ((uint32_t)src[1] << 8)
         | ((uint32_t)src[2] << 16)
         | ((uint32_t)src[3] << 24);
}

static inline void store32_le(uint8_t *dst, uint32_t v) {
    dst[0] = (uint8_t)(v);
    dst[1] = (uint8_t)(v >> 8);
    dst[2] = (uint8_t)(v >> 16);
    dst[3] = (uint8_t)(v >> 24);
}

/* The G mixing function */
static inline void g(uint32_t *s, int a, int b, int c, int d,
                     uint32_t mx, uint32_t my) {
    s[a] = s[a] + s[b] + mx;
    s[d] = rotr32(s[d] ^ s[a], 16);
    s[c] = s[c] + s[d];
    s[b] = rotr32(s[b] ^ s[c], 12);
    s[a] = s[a] + s[b] + my;
    s[d] = rotr32(s[d] ^ s[a], 8);
    s[c] = s[c] + s[d];
    s[b] = rotr32(s[b] ^ s[c], 7);
}

static inline void round_fn(uint32_t *state, const uint32_t *m) {
    /* Columns */
    g(state, 0, 4,  8, 12, m[ 0], m[ 1]);
    g(state, 1, 5,  9, 13, m[ 2], m[ 3]);
    g(state, 2, 6, 10, 14, m[ 4], m[ 5]);
    g(state, 3, 7, 11, 15, m[ 6], m[ 7]);
    /* Diagonals */
    g(state, 0, 5, 10, 15, m[ 8], m[ 9]);
    g(state, 1, 6, 11, 12, m[10], m[11]);
    g(state, 2, 7,  8, 13, m[12], m[13]);
    g(state, 3, 4,  9, 14, m[14], m[15]);
}

static inline void permute(uint32_t *m) {
    uint32_t tmp[16];
    for (int i = 0; i < 16; i++) tmp[i] = m[MSG_PERMUTATION[i]];
    memcpy(m, tmp, sizeof(tmp));
}

/* Compression function. Produces 16 u32 output state words. */
static void compress(const uint32_t cv[8],
                     const uint8_t block[BLAKE3_BLOCK_LEN],
                     uint8_t block_len,
                     uint64_t counter,
                     uint32_t flags,
                     uint32_t out[16]) {
    uint32_t state[16];
    uint32_t m[16];
    for (int i = 0; i < 16; i++) m[i] = load32_le(block + i * 4);

    state[ 0] = cv[0];
    state[ 1] = cv[1];
    state[ 2] = cv[2];
    state[ 3] = cv[3];
    state[ 4] = cv[4];
    state[ 5] = cv[5];
    state[ 6] = cv[6];
    state[ 7] = cv[7];
    state[ 8] = IV[0];
    state[ 9] = IV[1];
    state[10] = IV[2];
    state[11] = IV[3];
    state[12] = (uint32_t)counter;
    state[13] = (uint32_t)(counter >> 32);
    state[14] = (uint32_t)block_len;
    state[15] = flags;

    for (int i = 0; i < 7; i++) {
        round_fn(state, m);
        if (i < 6) permute(m);
    }
    for (int i = 0; i < 8; i++) {
        state[i]     ^= state[i + 8];
        state[i + 8] ^= cv[i];
    }
    for (int i = 0; i < 16; i++) out[i] = state[i];
}

/* Compute the chaining value (8 u32s) from the full compressed state. */
static void compress_to_cv(const uint32_t cv[8],
                           const uint8_t block[BLAKE3_BLOCK_LEN],
                           uint8_t block_len,
                           uint64_t counter,
                           uint32_t flags,
                           uint32_t out_cv[8]) {
    uint32_t full[16];
    compress(cv, block, block_len, counter, flags, full);
    for (int i = 0; i < 8; i++) out_cv[i] = full[i];
}

/* --- Chunk state --- */
static void chunk_state_init(blake3_chunk_state *cs,
                             const uint32_t key[8],
                             uint64_t chunk_counter,
                             uint32_t flags) {
    memcpy(cs->cv, key, 32);
    cs->chunk_counter = chunk_counter;
    cs->buf_len = 0;
    cs->blocks_compressed = 0;
    cs->flags = flags;
    memset(cs->buf, 0, BLAKE3_BLOCK_LEN);
}

static uint32_t chunk_state_start_flag(const blake3_chunk_state *cs) {
    if (cs->blocks_compressed == 0) return CHUNK_START;
    return 0;
}

static size_t chunk_state_len(const blake3_chunk_state *cs) {
    return (size_t)BLAKE3_BLOCK_LEN * cs->blocks_compressed + cs->buf_len;
}

static void chunk_state_update(blake3_chunk_state *cs, const uint8_t *input, size_t len) {
    while (len > 0) {
        /* If buffer is full, compress it (not the last block since more input is coming) */
        if (cs->buf_len == BLAKE3_BLOCK_LEN) {
            uint32_t flags = cs->flags | chunk_state_start_flag(cs);
            uint32_t new_cv[8];
            compress_to_cv(cs->cv, cs->buf, BLAKE3_BLOCK_LEN,
                          cs->chunk_counter, flags, new_cv);
            memcpy(cs->cv, new_cv, 32);
            cs->blocks_compressed++;
            cs->buf_len = 0;
            memset(cs->buf, 0, BLAKE3_BLOCK_LEN);
        }
        size_t want = BLAKE3_BLOCK_LEN - cs->buf_len;
        if (want > len) want = len;
        memcpy(cs->buf + cs->buf_len, input, want);
        cs->buf_len += (uint8_t)want;
        input += want;
        len -= want;
    }
}

/* "Output" structure: captures inputs for the root compress.
   Allows XOF generation by varying counter for output blocks. */
typedef struct {
    uint32_t input_cv[8];
    uint8_t  block[BLAKE3_BLOCK_LEN];
    uint8_t  block_len;
    uint64_t counter;
    uint32_t flags;
} blake3_output;

static blake3_output chunk_state_output(const blake3_chunk_state *cs) {
    blake3_output out;
    memcpy(out.input_cv, cs->cv, 32);
    memcpy(out.block, cs->buf, BLAKE3_BLOCK_LEN);
    out.block_len = cs->buf_len;
    out.counter = cs->chunk_counter;
    out.flags = cs->flags | chunk_state_start_flag(cs) | CHUNK_END;
    return out;
}

static blake3_output parent_output(const uint8_t block[BLAKE3_BLOCK_LEN],
                                   const uint32_t key[8],
                                   uint32_t flags) {
    blake3_output out;
    memcpy(out.input_cv, key, 32);
    memcpy(out.block, block, BLAKE3_BLOCK_LEN);
    out.block_len = BLAKE3_BLOCK_LEN;
    out.counter = 0;
    out.flags = flags | PARENT;
    return out;
}

/* Compute the parent CV (32 bytes) from two child CVs. */
static void parent_cv(const uint32_t left_cv[8],
                      const uint32_t right_cv[8],
                      const uint32_t key[8],
                      uint32_t flags,
                      uint32_t out_cv[8]) {
    uint8_t block[BLAKE3_BLOCK_LEN];
    for (int i = 0; i < 8; i++) store32_le(block + i * 4, left_cv[i]);
    for (int i = 0; i < 8; i++) store32_le(block + 32 + i * 4, right_cv[i]);
    compress_to_cv(key, block, BLAKE3_BLOCK_LEN, 0, flags | PARENT, out_cv);
}

/* Compute the chunk's final CV (non-root). */
static void chunk_state_chaining_value(const blake3_chunk_state *cs, uint32_t out_cv[8]) {
    uint32_t flags = cs->flags | chunk_state_start_flag(cs) | CHUNK_END;
    compress_to_cv(cs->cv, cs->buf, cs->buf_len, cs->chunk_counter, flags, out_cv);
}

/* --- Hasher --- */

static uint32_t mode_flags(const blake3_hasher *self) {
    return self->chunk.flags;
}

static void hasher_init_internal(blake3_hasher *self, const uint32_t key[8], uint32_t flags) {
    memcpy(self->key, key, 32);
    chunk_state_init(&self->chunk, key, 0, flags);
    self->cv_stack_len = 0;
}

void blake3_hasher_init(blake3_hasher *self) {
    hasher_init_internal(self, IV, 0);
}

void blake3_hasher_init_keyed(blake3_hasher *self, const uint8_t key[BLAKE3_KEY_LEN]) {
    uint32_t kw[8];
    for (int i = 0; i < 8; i++) kw[i] = load32_le(key + i * 4);
    hasher_init_internal(self, kw, KEYED_HASH);
}

void blake3_hasher_init_derive_key_raw(blake3_hasher *self, const void *context, size_t context_len) {
    /* First, hash the context with DERIVE_KEY_CONTEXT flag using IV as key */
    blake3_hasher ctx_hasher;
    hasher_init_internal(&ctx_hasher, IV, DERIVE_KEY_CONTEXT);
    blake3_hasher_update(&ctx_hasher, context, context_len);
    uint8_t context_key[BLAKE3_KEY_LEN];
    blake3_hasher_finalize(&ctx_hasher, context_key, BLAKE3_KEY_LEN);
    /* Then init with that context_key as key + DERIVE_KEY_MATERIAL flag */
    uint32_t kw[8];
    for (int i = 0; i < 8; i++) kw[i] = load32_le(context_key + i * 4);
    hasher_init_internal(self, kw, DERIVE_KEY_MATERIAL);
}

void blake3_hasher_init_derive_key(blake3_hasher *self, const char *context) {
    blake3_hasher_init_derive_key_raw(self, context, strlen(context));
}

/* Push a CV onto the stack */
static void cv_stack_push(blake3_hasher *self, const uint32_t cv[8]) {
    uint8_t *dst = self->cv_stack + (size_t)self->cv_stack_len * 32;
    for (int i = 0; i < 8; i++) store32_le(dst + i * 4, cv[i]);
    self->cv_stack_len++;
}

static void cv_stack_pop(blake3_hasher *self, uint32_t cv[8]) {
    self->cv_stack_len--;
    const uint8_t *src = self->cv_stack + (size_t)self->cv_stack_len * 32;
    for (int i = 0; i < 8; i++) cv[i] = load32_le(src + i * 4);
}

/* Called after finishing a (non-root) chunk to add its CV and merge as needed. */
static void hasher_add_chunk_cv(blake3_hasher *self, uint32_t new_cv[8], uint64_t total_chunks) {
    /* total_chunks = number of chunks processed (including the new one).
       The number of merges is the number of trailing zeros of total_chunks. */
    uint64_t t = total_chunks;
    while ((t & 1) == 0) {
        uint32_t left[8];
        cv_stack_pop(self, left);
        uint32_t merged[8];
        parent_cv(left, new_cv, self->key, mode_flags(self), merged);
        memcpy(new_cv, merged, 32);
        t >>= 1;
    }
    cv_stack_push(self, new_cv);
}

void blake3_hasher_update(blake3_hasher *self, const void *input_, size_t input_len) {
    const uint8_t *input = (const uint8_t *)input_;
    while (input_len > 0) {
        if (chunk_state_len(&self->chunk) == BLAKE3_CHUNK_LEN) {
            /* Current chunk is full; finalize it as a non-root CV */
            uint32_t cv[8];
            chunk_state_chaining_value(&self->chunk, cv);
            uint64_t total_chunks = self->chunk.chunk_counter + 1;
            hasher_add_chunk_cv(self, cv, total_chunks);
            /* Start a new chunk */
            chunk_state_init(&self->chunk, self->key, total_chunks, mode_flags(self));
        }
        size_t want = BLAKE3_CHUNK_LEN - chunk_state_len(&self->chunk);
        if (want > input_len) want = input_len;
        chunk_state_update(&self->chunk, input, want);
        input += want;
        input_len -= want;
    }
}

/* Apply XOF: produce arbitrary length output starting at seek. */
static void output_root_bytes(const blake3_output *out, uint64_t seek, uint8_t *dst, size_t len) {
    uint64_t output_block_counter = seek / BLAKE3_BLOCK_LEN;
    size_t offset = (size_t)(seek % BLAKE3_BLOCK_LEN);
    while (len > 0) {
        uint32_t words[16];
        compress(out->input_cv, out->block, out->block_len,
                output_block_counter, out->flags | ROOT, words);
        uint8_t block_bytes[64];
        for (int i = 0; i < 16; i++) store32_le(block_bytes + i * 4, words[i]);
        size_t take = 64 - offset;
        if (take > len) take = len;
        memcpy(dst, block_bytes + offset, take);
        dst += take;
        len -= take;
        offset = 0;
        output_block_counter++;
    }
}

void blake3_hasher_finalize(const blake3_hasher *self, uint8_t *out, size_t out_len) {
    blake3_hasher_finalize_seek(self, 0, out, out_len);
}

void blake3_hasher_finalize_seek(const blake3_hasher *self, uint64_t seek, uint8_t *out, size_t out_len) {
    /* If no parents on stack, the chunk itself is the root */
    if (self->cv_stack_len == 0) {
        blake3_output o = chunk_state_output(&self->chunk);
        output_root_bytes(&o, seek, out, out_len);
        return;
    }
    /* Otherwise, fold the current chunk's CV with stack entries.
       The TOP merge is the root. */
    uint32_t cv[8];
    chunk_state_chaining_value(&self->chunk, cv);
    /* Walk the stack from top down. For each entry, merge with current cv:
       At the topmost (last) merge, we use parent_output() to produce the ROOT. */
    int idx = self->cv_stack_len;
    while (idx > 1) {
        idx--;
        uint32_t left[8];
        const uint8_t *src = self->cv_stack + (size_t)idx * 32;
        for (int i = 0; i < 8; i++) left[i] = load32_le(src + i * 4);
        uint32_t merged[8];
        parent_cv(left, cv, self->key, mode_flags(self), merged);
        memcpy(cv, merged, 32);
    }
    /* Now idx == 1; the last entry is the root's left, current cv is right */
    uint8_t block[BLAKE3_BLOCK_LEN];
    const uint8_t *src = self->cv_stack;  /* idx==0 entry */
    memcpy(block, src, 32);
    for (int i = 0; i < 8; i++) store32_le(block + 32 + i * 4, cv[i]);
    blake3_output o = parent_output(block, self->key, mode_flags(self));
    output_root_bytes(&o, seek, out, out_len);
}
