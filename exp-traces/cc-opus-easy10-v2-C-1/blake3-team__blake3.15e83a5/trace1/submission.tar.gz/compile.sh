#!/bin/sh
set -e
cd "$(dirname "$0")"
gcc -O2 -Wall -Wextra -std=c11 -o executable blake3.c main.c
