# b3sum 1.8.4 Behavior Map

## Identity
- Tool: b3sum 1.8.4 (BLAKE3 hash CLI)
- Output format: `<hex_hash>  <filename>\n` (two spaces between hash and name)

## CLI flags

```
Usage: executable [OPTIONS] [FILE]...

--keyed                 Use the keyed mode, reading the 32-byte key from stdin
--derive-key <CONTEXT>  Use the key derivation mode, with the given context string
-l, --length <LEN>      The number of output bytes [default: 32]
--seek <SEEK>           The starting output byte offset [default: 0]
--num-threads <NUM>     The maximum number of threads to use (no-op for correctness)
--no-mmap               Disable memory mapping (no-op for correctness)
--no-names              Omit filenames in the output
--raw                   Write raw output bytes, --no-names implied, single input only
--tag                   Output BSD-style: BLAKE3 ([FILE]) = [HASH]
-c, --check             Read BLAKE3 sums from FILEs and check them
--quiet                 Skip printing OK for each checked file (requires --check)
-h, --help / -V, --version
```

## Modes

1. **Hash mode** (default): standard BLAKE3
2. **Keyed mode** (`--keyed`): reads 32-byte key from stdin, then files are inputs (FILE required)
3. **Derive-key mode** (`--derive-key CONTEXT`): uses key derivation with given context

## Mutual exclusion

- `--keyed` + `--derive-key` → "the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'"
- `--check` + `--tag` → "the argument '--check' cannot be used with '--tag'"
- `--check` + `--no-names` → "the argument '--check' cannot be used with '--no-names'"
- `--check` + `--raw` → "the argument '--check' cannot be used with '--raw'"
- `--check` + `--length` → "the argument '--check' cannot be used with '--length <LEN>'"
- `--check` + `--derive-key` → "the argument '--check' cannot be used with '--derive-key <CONTEXT>'"
- `--check` + `--keyed` → "the argument '--check' cannot be used with '--keyed'"
- `--check` + `--seek` → NOT excluded (but seek changes the hash so it FAILs)
- `--keyed` requires FILE: "the following required arguments were not provided: <FILE>..."
- `--quiet` requires `--check`: "the following required arguments were not provided: --check"
- `--length` cannot appear twice: "the argument '--length <LEN>' cannot be used multiple times"

## Output format

### Default
```
<hex_hash>  <filename>\n
```
filename is `-` for stdin.

### With escaping
If filename contains `\n`, `\r`, or `\\` (backslash):
- Line starts with `\` prefix
- `\n` → `\n` (2 chars: backslash, n)
- `\r` → `\r` (2 chars: backslash, r)
- `\\` → `\\` (2 chars: backslash, backslash)
- Other special chars (`\t`, `\x01`, etc.) NOT escaped

### `--tag`
```
BLAKE3 (<filename>) = <hex_hash>\n
```
Same escaping rules apply.

### `--no-names`
```
<hex_hash>\n
```

### `--raw`
- Writes raw bytes (length bytes after seek)
- Implies --no-names
- Only single input allowed → otherwise "Error: Only one filename can be provided when using --raw"

## Errors

### Argument errors (exit 2, clap-style)
- Bad flag: `error: unexpected argument '--bogus' found\n\n  tip: to pass '--bogus' as a value, use '-- --bogus'\n\nUsage: executable [OPTIONS] [FILE]...\n\nFor more information, try '--help'.`
- Bad value: `error: invalid value 'abc' for '--length <LEN>': invalid digit found in string\n\nFor more information, try '--help'.`
- Missing arg: `error: the following required arguments were not provided:\n  <FILE>...\n\nUsage: executable --keyed <FILE>...\n\nFor more information, try '--help'.`
- Conflicting: `error: the argument 'X' cannot be used with 'Y'\n\nUsage: ...\n\nFor more information, try '--help'.`

### Runtime errors (exit 1)
- Missing file (hash mode): `b3sum: <name>: No such file or directory (os error 2)` (stderr)
- Directory (hash mode): `b3sum: <name>: Is a directory (os error 21)` (stderr)
- Missing file (check mode): `<name>: FAILED (No such file or directory (os error 2))` (stdout)
- Directory (check mode): `<name>: FAILED (Is a directory (os error 21))` (stdout)

### Keyed mode errors (exit 1)
- Too short key: `Error: expected 32 key bytes from stdin, found <N>` (stderr)
- Too long key: `Error: read more than 32 key bytes from stdin` (stderr)

### Check parsing errors (continue processing, count as failure)
- Empty line: `b3sum: Empty line` (stderr)
- Bad format: `b3sum: Invalid check line format` (stderr)
- Wrong hex length: `b3sum: Invalid hash length` (stderr)
- Bad hex chars: `b3sum: Invalid hex` (stderr)
- Final summary: `b3sum: WARNING: <N> computed checksum did NOT match` or `... <N> computed checksums did NOT match` (stderr)
  - Singular when N=1, plural for N>1

## Check mode

### Plain format
`<64-hex-hash><SPACE><SPACE><filename>` (exactly two spaces)
- Hash must be exactly 64 lowercase hex chars
- Filename split at FIRST occurrence of `  ` (so filename may contain double-spaces)

### BSD format
`BLAKE3 (<filename>) = <64-hex-hash>`
- Must start exactly with "BLAKE3 ("
- Looking for ") = " separator
- Hash must follow (64 lowercase hex)

### Escaped format
If line starts with `\`, escape decoding applies:
- `\\n` → newline
- `\\r` → CR
- `\\\\` → backslash
- The reported OK/FAILED line shows the original (escaped) form.

### Check output
- Per line: `<filename>: OK` (stdout) or `<filename>: FAILED [(reason)]` (stdout)
- Per error line: `b3sum: <reason>` (stderr)
- Summary: `b3sum: WARNING: <N> computed checksum[s] did NOT match` (stderr) - only when failures > 0

### Exit codes
- 0: all checksums passed
- 1: any failure (bad format, missing file, mismatch)
- 2: arg parse error

## Length and seek

- `--length 0` → empty hash output (still prints `  -` suffix)
- `--length N` → outputs N bytes as 2N hex chars (or N raw bytes with --raw)
- `--length` negative → "invalid digit found in string"
- `--length` too large → "number too large to fit in target type"
- `--length` non-integer → "invalid digit found in string"
- `--length` empty → "cannot parse integer from empty string"
- `--seek` follows same rules
- `--seek N` skips first N bytes of output stream

## Trailing newlines
- All hash output lines end with `\n`
- Error messages end with `\n` (single newline)

## Behavioral notes
- `--num-threads` is parsed but result is identical regardless of value (correctness invariant)
- `--no-mmap` is parsed but result is identical
- `-V` and `--version` both produce `b3sum 1.8.4\n`
- `-h` (short) produces compact help, `--help` produces verbose help
- `-l` is short for `--length`
- `-c` is short for `--check`
- `--` ends option parsing (positional args after)
- `-` as filename → stdin
- Multiple files: each processed independently
- Per-file output ordering matches command-line order
