#include "blake3.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void) {
    /* Empty input + standard BLAKE3 test vectors context */
    blake3_hasher h;
    blake3_hasher_init_derive_key(&h, "BLAKE3 2019-12-27 16:29:52 test vectors context");
    uint8_t out[32];
    blake3_hasher_finalize(&h, out, 32);
    printf("vectors_ctx_empty: ");
    for (int i = 0; i < 32; i++) printf("%02x", out[i]);
    printf("\n");
    /* expected: 2cc39783c223154fea8dfb7c1b1660f2ac2dcbd1c1de8277b0b0dd39b7e50d7d */

    /* Now with 1 byte input (0x00) */
    blake3_hasher_init_derive_key(&h, "BLAKE3 2019-12-27 16:29:52 test vectors context");
    uint8_t b1 = 0;
    blake3_hasher_update(&h, &b1, 1);
    blake3_hasher_finalize(&h, out, 32);
    printf("vectors_ctx_1byte: ");
    for (int i = 0; i < 32; i++) printf("%02x", out[i]);
    printf("\n");
    /* expected: b3e2e340a117a499c6cf2398a19ee0d29cca2bb7404c73063382693bf66cb06c */

    return 0;
}
