#include "blake3.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static void print_hex(const uint8_t *bytes, size_t len) {
    for (size_t i = 0; i < len; i++) printf("%02x", bytes[i]);
}

static void test_input(const char *label, const uint8_t *input, size_t len) {
    blake3_hasher h;
    blake3_hasher_init(&h);
    blake3_hasher_update(&h, input, len);
    uint8_t out[32];
    blake3_hasher_finalize(&h, out, 32);
    printf("%s: ", label);
    print_hex(out, 32);
    printf("\n");
}

int main(void) {
    /* Empty */
    test_input("empty", (const uint8_t*)"", 0);
    /* "a" */
    test_input("a", (const uint8_t*)"a", 1);
    /* "abc" */
    test_input("abc", (const uint8_t*)"abc", 3);
    /* "Hello, World!" */
    test_input("hello", (const uint8_t*)"Hello, World!", 13);

    /* Bytes 0..255 */
    uint8_t b256[256];
    for (int i = 0; i < 256; i++) b256[i] = (uint8_t)i;
    test_input("bytes256", b256, 256);

    /* 1024 'a's */
    uint8_t a1024[1024];
    memset(a1024, 'a', 1024);
    test_input("a1024", a1024, 1024);

    /* 1025 'a's */
    uint8_t a1025[1025];
    memset(a1025, 'a', 1025);
    test_input("a1025", a1025, 1025);

    /* 2049 'a's */
    uint8_t *a2049 = (uint8_t*)malloc(2049);
    memset(a2049, 'a', 2049);
    test_input("a2049", a2049, 2049);
    free(a2049);

    /* 100000 zeros */
    uint8_t *z100k = (uint8_t*)calloc(100000, 1);
    test_input("z100k", z100k, 100000);
    free(z100k);

    /* Keyed mode: zero key on empty */
    {
        uint8_t key[32] = {0};
        blake3_hasher h;
        blake3_hasher_init_keyed(&h, key);
        uint8_t out[32];
        blake3_hasher_finalize(&h, out, 32);
        printf("keyed_zero_empty: ");
        print_hex(out, 32);
        printf("\n");
    }
    /* Keyed mode: zero key on abc */
    {
        uint8_t key[32] = {0};
        blake3_hasher h;
        blake3_hasher_init_keyed(&h, key);
        blake3_hasher_update(&h, "abc", 3);
        uint8_t out[32];
        blake3_hasher_finalize(&h, out, 32);
        printf("keyed_zero_abc: ");
        print_hex(out, 32);
        printf("\n");
    }

    /* Derive-key empty context, empty input */
    {
        blake3_hasher h;
        blake3_hasher_init_derive_key(&h, "");
        uint8_t out[32];
        blake3_hasher_finalize(&h, out, 32);
        printf("derive_empty_empty: ");
        print_hex(out, 32);
        printf("\n");
    }
    /* Derive-key 'ctx' context, 'abc' input */
    {
        blake3_hasher h;
        blake3_hasher_init_derive_key(&h, "ctx");
        blake3_hasher_update(&h, "abc", 3);
        uint8_t out[32];
        blake3_hasher_finalize(&h, out, 32);
        printf("derive_ctx_abc: ");
        print_hex(out, 32);
        printf("\n");
    }

    /* Length 64 on abc */
    {
        blake3_hasher h;
        blake3_hasher_init(&h);
        blake3_hasher_update(&h, "abc", 3);
        uint8_t out[64];
        blake3_hasher_finalize(&h, out, 64);
        printf("len64_abc: ");
        print_hex(out, 64);
        printf("\n");
    }
    /* Length 16, seek 16 on abc */
    {
        blake3_hasher h;
        blake3_hasher_init(&h);
        blake3_hasher_update(&h, "abc", 3);
        uint8_t out[16];
        blake3_hasher_finalize_seek(&h, 16, out, 16);
        printf("seek16_len16_abc: ");
        print_hex(out, 16);
        printf("\n");
    }
    /* Length 32, seek 64 on abc */
    {
        blake3_hasher h;
        blake3_hasher_init(&h);
        blake3_hasher_update(&h, "abc", 3);
        uint8_t out[32];
        blake3_hasher_finalize_seek(&h, 64, out, 32);
        printf("seek64_abc: ");
        print_hex(out, 32);
        printf("\n");
    }

    return 0;
}
