# b3sum 1.8.4 Behavior Map

## Process model

One-shot CLI. Reads files or stdin, prints hex (or raw) hash, exits.
Multithreaded by default but deterministic.

## CLI surface (Clap derive)

```
Usage: <argv0> [OPTIONS] [FILE]...
```

The program name in Usage / Usage in error output is taken from argv[0]
(basename). Help and error formatting is Clap (Rust) standard.

Flags:
- `--keyed` (bool) -- read 32-byte key from stdin then hash file(s). REQUIRES `<FILE>...`.
- `--derive-key <CONTEXT>` -- KDF. Reads material from stdin. Conflicts with `--keyed`.
- `-l, --length <LEN>` u64, default 32. 0 allowed.
- `--seek <SEEK>` u64, default 0.
- `--num-threads <NUM>` u64. 0 = auto.
- `--no-mmap` bool.
- `--no-names` bool. Conflicts with `--check`.
- `--raw` bool. Conflicts with `--check`. Implies `--no-names`. Single input only.
- `--tag` bool. Conflicts with `--check`.
- `-c, --check` bool. Conflicts with `--no-names`, `--raw`, `--tag`, `--length`, `--keyed`, `--derive-key`.
- `--quiet` bool. Requires `--check`.
- `-h, --help` Print help. Long with `--help`, short with `-h`.
- `-V, --version` Print "b3sum 1.8.4\n".

Positional `[FILE]...`. When absent, or when `-`, read stdin.

## Output formats

Default: `<hex>  <filename>\n` (two spaces).
`--tag`: `BLAKE3 (<filename>) = <hex>\n`.
`--no-names`: `<hex>\n` (no filename).
`--raw`: raw bytes, no trailing newline. Implies `--no-names`. Only one input allowed.

Precedence when conflict-not-forbidden: --raw > --no-names > --tag.

## Filename escaping (GNU md5sum-style)

If filename contains `\n`, `\r`, or `\` (backslash), the line is prefixed with `\`
and each `\n` -> `\n`, `\r` -> `\r`, `\` -> `\\` in the filename.
Tabs and other bytes are NOT escaped.

This applies to:
- Default output: `\<hex>  <escaped-filename>\n`
- Tag output: `\BLAKE3 (<escaped-filename>) = <hex>\n`
- Check OK/FAILED output: prefix with `\` if filename was escaped

## Check mode (`-c`)

Reads lines from check file(s). Default line format: `<hex>  <name>\n` (must be two spaces, NOT space+star, NOT single space, NOT tab).
Also accepts BSD/tag form: `BLAKE3 (<name>) = <hex>\n` (parsed alongside).
Escaped lines (start with `\`): treat `\\`, `\n`, `\r` as escape sequences in name.

Per line emit `<escaped-name>: OK\n` (stdout) on match (suppressed when `--quiet`).
On mismatch: `<escaped-name>: FAILED\n` (stdout).
On file open error during check: `<escaped-name>: FAILED (<err>)\n` (stdout).
On parse error: stderr `b3sum: <reason>\n` where reasons include:
  - `Invalid check line format`
  - `Empty line`
  - additional like `Bad hex` etc.
After processing all files, if any failed: `b3sum: WARNING: N computed checksum(s) did NOT match\n` to stderr.
Exit 0 if all OK, 1 if any fail.

Trailing CRLF allowed in check lines (the trailing `\r` is stripped).

## Error message patterns

Clap-format on argparse errors (stderr), exit 2:
- `error: unexpected argument 'X' found\n\n  tip: to pass 'X' as a value, use '-- X'\n\nUsage: ...\n\nFor more information, try '--help'.\n`
- `error: invalid value 'X' for '--FLAG <META>': <reason>\n\nFor more information, try '--help'.\n`
- `error: a value is required for '--FLAG <META>' but none was supplied\n\nFor more information, try '--help'.\n`
- `error: the argument 'A' cannot be used with 'B'\n\nUsage: ...\n\nFor more information, try '--help'.\n`
- `error: the following required arguments were not provided:\n  ARGNAME\n\nUsage: ...\n\nFor more information, try '--help'.\n`
- `error: invalid UTF-8 was detected in one or more arguments\n\n...`

Numeric parse: `invalid digit found in string` or `number too large to fit in target type`.

Runtime errors:
- I/O error opening file (stderr): `b3sum: <path>: <message> (os error <errno>)\n`, exit 1.
- Other Errors (stderr) -- when Result-returning main fails: `Error: <message>\n`, exit 1.
  - `Error: Only one filename can be provided when using --raw`
  - `Error: expected 32 key bytes from stdin, found <n>`
  - `Error: read more than 32 key bytes from stdin`
  - `Error: No such file or directory (os error 2)` -- for missing checkfile

## Hashing

Standard BLAKE3:
- IV = first 8 words of SHA-256 IV
- chunk=1024 bytes (16 blocks of 64)
- 7 rounds of G with permutation [2,6,3,10,7,0,4,13,1,11,12,5,9,14,15,8]
- flags: CHUNK_START=1, CHUNK_END=2, PARENT=4, ROOT=8, KEYED=16, DERIVE_CTX=32, DERIVE_MAT=64
- Variable output (XOF): seek into stream of 64-byte blocks indexed by counter

Empty hash: af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262
"abc": 6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85

## Stdin handling

- No FILE arg: read all of stdin, hash as `-`.
- `-` as FILE: same as stdin, displayed as `-`.
- In `--keyed` mode, stdin is the 32-byte key. `-` as a FILE then becomes invalid:
  `b3sum: -: Cannot open `-` in keyed mode\n` to stderr, exit 1.
- In `--derive-key` mode, stdin gives material when filename is `-` or absent; otherwise files are hashed with derived key. Both work.

## Streaming

Files can be hashed via mmap by default. `--no-mmap` disables this.
Functionally identical output.

## Exit codes

- 0: success
- 1: I/O error or check failure
- 2: argparse error

## Edge cases verified

- Length 0: empty hex, format preserved.
- Length up to many KB via XOF.
- Seek >= 64 jumps to later XOF blocks.
- Multiple files: hash each in order. One failing keeps going. Exit 1 if any failed.
- Missing target file in check: `<name>: FAILED (No such file or directory (os error 2))\n`.
- Empty check file: silent success exit 0.
- Empty line in check file: `b3sum: Empty line\n` stderr (counts as failure).
- Lines without two spaces between hash and name: `Invalid check line format` (NOT GNU md5sum's `*` binary marker; b3sum is strict two-space).

