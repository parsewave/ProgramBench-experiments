#!/bin/sh
set -e
cd "$(dirname "$0")"
gcc -O2 -Wall -Wextra -o executable main.c blake3.c
