#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#include "blake3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>

/* ----------------------- options & parsing ----------------------- */

typedef struct {
    bool keyed;
    bool derive_key;
    char *derive_ctx;       /* freed at exit */
    bool length_set;
    uint64_t length;
    bool seek_set;
    uint64_t seek;
    bool num_threads_set;
    uint64_t num_threads;
    bool no_mmap;
    bool no_names;
    bool raw;
    bool tag;
    bool check;
    bool quiet;
    /* file args */
    char **files;
    size_t n_files;
    size_t cap_files;
    /* program name */
    const char *progname;
} options_t;

/* Tracks first-seen order for usage line and conflict detection. */
typedef enum {
    F_KEYED,
    F_DERIVE_KEY,
    F_LENGTH,
    F_SEEK,
    F_NUM_THREADS,
    F_NO_MMAP,
    F_NO_NAMES,
    F_RAW,
    F_TAG,
    F_CHECK,
    F_QUIET,
    F_NONE
} flag_id_t;

typedef struct {
    flag_id_t id;
    const char *display;
} flag_info_t;

static const flag_info_t FLAG_INFO[] = {
    [F_KEYED]       = {F_KEYED,       "--keyed"},
    [F_DERIVE_KEY]  = {F_DERIVE_KEY,  "--derive-key <CONTEXT>"},
    [F_LENGTH]      = {F_LENGTH,      "--length <LEN>"},
    [F_SEEK]        = {F_SEEK,        "--seek <SEEK>"},
    [F_NUM_THREADS] = {F_NUM_THREADS, "--num-threads <NUM>"},
    [F_NO_MMAP]     = {F_NO_MMAP,     "--no-mmap"},
    [F_NO_NAMES]    = {F_NO_NAMES,    "--no-names"},
    [F_RAW]         = {F_RAW,         "--raw"},
    [F_TAG]         = {F_TAG,         "--tag"},
    [F_CHECK]       = {F_CHECK,       "--check"},
    [F_QUIET]       = {F_QUIET,       "--quiet"},
};

/* Order in which flags first appeared (for building usage line) */
static flag_id_t seen_order[16];
static int seen_count = 0;

static void mark_seen(flag_id_t id) {
    for (int i = 0; i < seen_count; i++) if (seen_order[i] == id) return;
    seen_order[seen_count++] = id;
}

static const char *flag_usage_frag(flag_id_t id) {
    switch (id) {
        case F_KEYED: return "--keyed";
        case F_DERIVE_KEY: return "--derive-key <CONTEXT>";
        case F_CHECK: return "--check";
        case F_QUIET: return "--quiet";
        case F_TAG: return "--tag";
        case F_RAW: return "--raw";
        case F_NO_NAMES: return "--no-names";
        case F_NO_MMAP: return "--no-mmap";
        case F_LENGTH: return "--length <LEN>";
        case F_SEEK: return "--seek <SEEK>";
        case F_NUM_THREADS: return "--num-threads <NUM>";
        default: return NULL;
    }
}

/* Has the parser seen any positional file argument? */
static bool g_positional_seen = false;

/* Build usage with a custom list of flag IDs and positional rendering.
   If any flag in the list is F_KEYED, FILE is required (<FILE>...).
   Otherwise, FILE is optional ([FILE]...) -- unless override is non-NULL.
   If positional_seen, FILE is rendered required. */
static void build_usage_custom(const char *progname,
                               const flag_id_t *flags, int n_flags,
                               bool keyed_makes_file_required,
                               const char *pos_override,
                               char *out, size_t cap) {
    char buf[256];
    buf[0] = '\0';
    size_t blen = 0;
    bool any = false;
    bool has_keyed = false;
    for (int i = 0; i < n_flags; i++) {
        const char *frag = flag_usage_frag(flags[i]);
        if (frag) {
            size_t flen = strlen(frag);
            if (blen + flen + 2 < sizeof(buf)) {
                buf[blen++] = ' ';
                memcpy(buf + blen, frag, flen);
                blen += flen;
                buf[blen] = '\0';
                any = true;
            }
            if (flags[i] == F_KEYED) has_keyed = true;
        }
    }
    bool file_required = (keyed_makes_file_required && has_keyed) || g_positional_seen;
    const char *pos = pos_override ? pos_override : (file_required ? "<FILE>..." : "[FILE]...");
    if (!any) {
        if (g_positional_seen) {
            snprintf(out, cap, "Usage: %s %s", progname, pos);
        } else {
            snprintf(out, cap, "Usage: %s [OPTIONS] %s", progname, pos);
        }
    } else {
        snprintf(out, cap, "Usage: %s%s %s", progname, buf, pos);
    }
}

/* Build usage from seen-order (FILE rendering auto-decided) */
static void build_usage(const char *progname, const char *pos, char *out, size_t cap) {
    build_usage_custom(progname, seen_order, seen_count, false, pos, out, cap);
}

/* Build usage with auto-FILE rendering (no override). */
static void build_usage_auto(const char *progname, char *out, size_t cap) {
    build_usage_custom(progname, seen_order, seen_count, false, NULL, out, cap);
}

/* Print clap-style "unexpected argument" error */
static void err_unexpected(const char *progname, const char *arg) {
    char usage[512];
    build_usage_auto(progname, usage, sizeof(usage));
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    fprintf(stderr, "%s\n\n", usage);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

/* For invalid value errors */
static void err_invalid_value(const char *flag, const char *value, const char *reason) {
    fprintf(stderr, "error: invalid value '%s' for '%s': %s\n\n", value, flag, reason);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

/* For missing value errors */
static void err_missing_value(const char *flag) {
    fprintf(stderr, "error: a value is required for '%s' but none was supplied\n\n", flag);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

/* For "missing required" errors. missing_flag is F_NONE if missing is FILE positional. */
static void err_missing_required(const char *progname, flag_id_t missing_flag,
                                  const char *missing_label, bool missing_is_positional) {
    /* Build the usage line: missing_flag (if any) + seen flags + pos */
    flag_id_t combined[32];
    int n = 0;
    if (!missing_is_positional && missing_flag != F_NONE) {
        combined[n++] = missing_flag;
    }
    for (int i = 0; i < seen_count && n < 32; i++) combined[n++] = seen_order[i];
    char usage[512];
    /* If FILE is the missing thing, render it required. Otherwise keep [FILE]... */
    const char *pos = missing_is_positional ? "<FILE>..."
                      : ((seen_count > 0 && seen_order[0] == F_KEYED) ? "<FILE>..." : "[FILE]...");
    /* Actually -- for keyed, we want <FILE>... in this path */
    bool any_keyed = false;
    for (int i = 0; i < seen_count; i++) if (seen_order[i] == F_KEYED) any_keyed = true;
    if (any_keyed) pos = "<FILE>...";
    build_usage_custom(progname, combined, n, true, pos, usage, sizeof(usage));
    fprintf(stderr, "error: the following required arguments were not provided:\n");
    fprintf(stderr, "  %s\n\n", missing_label);
    fprintf(stderr, "%s\n\n", usage);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

/* For conflict errors. first_id is the already-seen flag. */
static void err_conflict(const char *progname, flag_id_t first_id, flag_id_t second_id) {
    flag_id_t single[1] = { first_id };
    char usage[512];
    build_usage_custom(progname, single, 1, true, NULL, usage, sizeof(usage));

    fprintf(stderr, "error: the argument '%s' cannot be used with '%s'\n\n",
            FLAG_INFO[first_id].display, FLAG_INFO[second_id].display);
    fprintf(stderr, "%s\n\n", usage);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

/* For invalid UTF-8 */
static void err_invalid_utf8(const char *progname) {
    char usage[512];
    build_usage(progname, "[FILE]...", usage, sizeof(usage));
    fprintf(stderr, "error: invalid UTF-8 was detected in one or more arguments\n\n");
    fprintf(stderr, "%s\n\n", usage);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

/* Parse a u64 - returns 0 on success, sets reason on failure. */
static int parse_u64(const char *s, uint64_t *out, const char **reason) {
    if (s == NULL || *s == '\0') { *reason = "cannot parse integer from empty string"; return -1; }
    const char *p = s;
    uint64_t v = 0;
    while (*p) {
        if (!(*p >= '0' && *p <= '9')) {
            *reason = "invalid digit found in string";
            return -1;
        }
        unsigned d = (unsigned)(*p - '0');
        if (v > (UINT64_MAX - d) / 10) {
            *reason = "number too large to fit in target type";
            return -1;
        }
        v = v * 10 + d;
        p++;
    }
    *out = v;
    return 0;
}

/* Check UTF-8 validity. Returns 1 if valid, 0 if invalid. */
static int valid_utf8(const char *s) {
    const unsigned char *p = (const unsigned char *)s;
    while (*p) {
        if (*p < 0x80) { p++; continue; }
        int n = 0;
        if ((*p & 0xE0) == 0xC0 && *p >= 0xC2) n = 1;
        else if ((*p & 0xF0) == 0xE0) n = 2;
        else if ((*p & 0xF8) == 0xF0 && *p <= 0xF4) n = 3;
        else return 0;
        unsigned cp = *p & (0xFF >> (n + 2));
        for (int i = 0; i < n; i++) {
            p++;
            if ((*p & 0xC0) != 0x80) return 0;
            cp = (cp << 6) | (*p & 0x3F);
        }
        /* Range checks */
        if (n == 1 && cp < 0x80) return 0;
        if (n == 2 && (cp < 0x800 || (cp >= 0xD800 && cp <= 0xDFFF))) return 0;
        if (n == 3 && (cp < 0x10000 || cp > 0x10FFFF)) return 0;
        p++;
    }
    return 1;
}

static void add_file(options_t *o, char *f) {
    if (o->n_files == o->cap_files) {
        o->cap_files = o->cap_files ? o->cap_files * 2 : 8;
        o->files = (char **)realloc(o->files, o->cap_files * sizeof(char *));
    }
    o->files[o->n_files++] = f;
}

/* Check if an arg is a known flag (long or short). Used to disambiguate value-vs-flag. */
static bool is_known_flag(const char *s) {
    if (s[0] != '-') return false;
    if (s[1] == '\0') return false; /* single - is positional */
    if (s[1] == '-') {
        if (s[2] == '\0') return false; /* "--" is end marker */
        /* Long flag */
        const char *name = s + 2;
        size_t nlen = strlen(name);
        const char *eq = strchr(name, '=');
        if (eq) nlen = (size_t)(eq - name);
        char buf[64];
        if (nlen >= sizeof(buf)) return false;
        memcpy(buf, name, nlen);
        buf[nlen] = '\0';
        if (strcmp(buf, "help") == 0 ||
            strcmp(buf, "version") == 0 ||
            strcmp(buf, "keyed") == 0 ||
            strcmp(buf, "derive-key") == 0 ||
            strcmp(buf, "length") == 0 ||
            strcmp(buf, "seek") == 0 ||
            strcmp(buf, "num-threads") == 0 ||
            strcmp(buf, "no-mmap") == 0 ||
            strcmp(buf, "no-names") == 0 ||
            strcmp(buf, "raw") == 0 ||
            strcmp(buf, "tag") == 0 ||
            strcmp(buf, "check") == 0 ||
            strcmp(buf, "quiet") == 0) return true;
        return false;
    }
    /* Short flag: -h, -V, -c, -l (with possible value) */
    char c = s[1];
    if (c == 'h' || c == 'V' || c == 'c' || c == 'l') return true;
    return false;
}

/* Consume a value for a value-taking long option. Updates *i.
   Returns the value pointer (or fatal error). */
static const char *consume_value(int argc, char **argv, int *i, const char *flag_label,
                                  char *value_inline, const char *progname) {
    if (value_inline) {
        (*i)++;
        return value_inline;
    }
    if (*i + 1 >= argc) {
        err_missing_value(flag_label);
    }
    const char *next = argv[*i + 1];
    /* Disambiguate value-vs-flag: if next starts with '-' and isn't just '-' or '--' */
    if (next[0] == '-' && next[1] != '\0' && !(next[0] == '-' && next[1] == '-' && next[2] == '\0')) {
        if (is_known_flag(next)) {
            err_missing_value(flag_label);
        } else {
            err_unexpected(progname, next);
        }
    }
    /* Allow '-' alone as value (single dash, will fail downstream perhaps) */
    *i += 2;
    return next;
}

/* Print "argument used multiple times" error */
static void err_duplicate(const char *progname, flag_id_t id) {
    fprintf(stderr, "error: the argument '%s' cannot be used multiple times\n\n",
            FLAG_INFO[id].display);
    fprintf(stderr, "Usage: %s [OPTIONS] [FILE]...\n\n", progname);
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

static void set_flag(options_t *opts, flag_id_t id) {
    /* Duplicate detection */
    switch (id) {
        case F_KEYED: if (opts->keyed) err_duplicate(opts->progname, id); break;
        case F_DERIVE_KEY: if (opts->derive_key) err_duplicate(opts->progname, id); break;
        case F_LENGTH: if (opts->length_set) err_duplicate(opts->progname, id); break;
        case F_SEEK: if (opts->seek_set) err_duplicate(opts->progname, id); break;
        case F_NUM_THREADS: if (opts->num_threads_set) err_duplicate(opts->progname, id); break;
        case F_NO_MMAP: if (opts->no_mmap) err_duplicate(opts->progname, id); break;
        case F_NO_NAMES: if (opts->no_names) err_duplicate(opts->progname, id); break;
        case F_RAW: if (opts->raw) err_duplicate(opts->progname, id); break;
        case F_TAG: if (opts->tag) err_duplicate(opts->progname, id); break;
        case F_CHECK: if (opts->check) err_duplicate(opts->progname, id); break;
        case F_QUIET: if (opts->quiet) err_duplicate(opts->progname, id); break;
        default: break;
    }
    /* Conflict rules */
    if (id == F_KEYED && opts->derive_key) err_conflict(opts->progname, F_DERIVE_KEY, F_KEYED);
    if (id == F_DERIVE_KEY && opts->keyed) err_conflict(opts->progname, F_KEYED, F_DERIVE_KEY);
    if (id == F_CHECK) {
        if (opts->raw)       err_conflict(opts->progname, F_RAW, F_CHECK);
        if (opts->no_names)  err_conflict(opts->progname, F_NO_NAMES, F_CHECK);
        if (opts->tag)       err_conflict(opts->progname, F_TAG, F_CHECK);
        if (opts->length_set)err_conflict(opts->progname, F_LENGTH, F_CHECK);
        if (opts->keyed)     err_conflict(opts->progname, F_KEYED, F_CHECK);
        if (opts->derive_key)err_conflict(opts->progname, F_DERIVE_KEY, F_CHECK);
    }
    if (opts->check) {
        if (id == F_RAW)       err_conflict(opts->progname, F_CHECK, F_RAW);
        if (id == F_NO_NAMES)  err_conflict(opts->progname, F_CHECK, F_NO_NAMES);
        if (id == F_TAG)       err_conflict(opts->progname, F_CHECK, F_TAG);
        if (id == F_LENGTH)    err_conflict(opts->progname, F_CHECK, F_LENGTH);
        if (id == F_KEYED)     err_conflict(opts->progname, F_CHECK, F_KEYED);
        if (id == F_DERIVE_KEY)err_conflict(opts->progname, F_CHECK, F_DERIVE_KEY);
    }
    mark_seen(id);
    switch (id) {
        case F_KEYED: opts->keyed = true; break;
        case F_DERIVE_KEY: opts->derive_key = true; break;
        case F_LENGTH: opts->length_set = true; break;
        case F_SEEK: opts->seek_set = true; break;
        case F_NUM_THREADS: opts->num_threads_set = true; break;
        case F_NO_MMAP: opts->no_mmap = true; break;
        case F_NO_NAMES: opts->no_names = true; break;
        case F_RAW: opts->raw = true; break;
        case F_TAG: opts->tag = true; break;
        case F_CHECK: opts->check = true; break;
        case F_QUIET: opts->quiet = true; break;
        default: break;
    }
}

/* Help text */
static void print_help_short(const char *progname) {
    printf("Usage: %s [OPTIONS] [FILE]...\n\n", progname);
    printf("Arguments:\n");
    printf("  [FILE]...  Files to hash, or checkfiles to check\n\n");
    printf("Options:\n");
    printf("      --keyed                 Use the keyed mode, reading the 32-byte key from stdin\n");
    printf("      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string\n");
    printf("  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]\n");
    printf("      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]\n");
    printf("      --num-threads <NUM>     The maximum number of threads to use\n");
    printf("      --no-mmap               Disable memory mapping\n");
    printf("      --no-names              Omit filenames in the output\n");
    printf("      --raw                   Write raw output bytes to stdout, rather than hex\n");
    printf("      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n");
    printf("  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them\n");
    printf("      --quiet                 Skip printing OK for each checked file\n");
    printf("  -h, --help                  Print help (see more with '--help')\n");
    printf("  -V, --version               Print version\n");
}

static void print_help_long(const char *progname) {
    printf("Usage: %s [OPTIONS] [FILE]...\n\n", progname);
    printf("Arguments:\n");
    printf("  [FILE]...\n");
    printf("          Files to hash, or checkfiles to check\n");
    printf("          \n");
    printf("          When no file is given, or when - is given, read standard input.\n");
    printf("\n");
    printf("Options:\n");
    printf("      --keyed\n");
    printf("          Use the keyed mode, reading the 32-byte key from stdin\n");
    printf("\n");
    printf("      --derive-key <CONTEXT>\n");
    printf("          Use the key derivation mode, with the given context string\n");
    printf("          \n");
    printf("          Cannot be used with --keyed.\n");
    printf("\n");
    printf("  -l, --length <LEN>\n");
    printf("          The number of output bytes, before hex encoding\n");
    printf("          \n");
    printf("          [default: 32]\n");
    printf("\n");
    printf("      --seek <SEEK>\n");
    printf("          The starting output byte offset, before hex encoding\n");
    printf("          \n");
    printf("          [default: 0]\n");
    printf("\n");
    printf("      --num-threads <NUM>\n");
    printf("          The maximum number of threads to use\n");
    printf("          \n");
    printf("          By default, this is the number of logical cores. If this flag is omitted, or if its value\n");
    printf("          is 0, RAYON_NUM_THREADS is also respected.\n");
    printf("\n");
    printf("      --no-mmap\n");
    printf("          Disable memory mapping\n");
    printf("          \n");
    printf("          Currently this also disables multithreading.\n");
    printf("\n");
    printf("      --no-names\n");
    printf("          Omit filenames in the output\n");
    printf("\n");
    printf("      --raw\n");
    printf("          Write raw output bytes to stdout, rather than hex\n");
    printf("          \n");
    printf("          --no-names is implied. In this case, only a single input is allowed.\n");
    printf("\n");
    printf("      --tag\n");
    printf("          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n");
    printf("\n");
    printf("  -c, --check\n");
    printf("          Read BLAKE3 sums from the [FILE]s and check them\n");
    printf("\n");
    printf("      --quiet\n");
    printf("          Skip printing OK for each checked file\n");
    printf("          \n");
    printf("          Must be used with --check.\n");
    printf("\n");
    printf("  -h, --help\n");
    printf("          Print help (see a summary with '-h')\n");
    printf("\n");
    printf("  -V, --version\n");
    printf("          Print version\n");
}

static const char *basename_of(const char *p) {
    const char *b = strrchr(p, '/');
    return b ? b + 1 : p;
}

/* Pre-validate utf8 over all argv. */
static void check_utf8(int argc, char **argv, const char *progname) {
    for (int i = 1; i < argc; i++) {
        if (!valid_utf8(argv[i])) err_invalid_utf8(progname);
    }
}

static void parse_args(int argc, char **argv, options_t *opts) {
    opts->progname = basename_of(argv[0]);
    opts->length = 32;
    opts->seek = 0;
    check_utf8(argc, argv, opts->progname);

    bool after_double_dash = false;
    int i = 1;
    while (i < argc) {
        char *a = argv[i];
        if (after_double_dash) {
            if (*a == '\0') {
                fprintf(stderr, "error: a value is required for '[FILE]...' but none was supplied\n\n");
                fprintf(stderr, "For more information, try '--help'.\n");
                exit(2);
            }
            g_positional_seen = true;
            add_file(opts, a);
            i++;
            continue;
        }
        if (strcmp(a, "--") == 0) {
            after_double_dash = true;
            i++;
            continue;
        }
        if (strcmp(a, "-") == 0) {
            /* stdin marker, positional */
            add_file(opts, a);
            i++;
            continue;
        }
        if (strncmp(a, "--", 2) == 0) {
            /* Long option, possibly with =value */
            char *eq = strchr(a, '=');
            char *name = a + 2;
            char *value = NULL;
            char name_buf[64];
            if (eq) {
                size_t nlen = (size_t)(eq - name);
                if (nlen >= sizeof(name_buf)) err_unexpected(opts->progname, a);
                memcpy(name_buf, name, nlen);
                name_buf[nlen] = '\0';
                name = name_buf;
                value = eq + 1;
            }
            if (strcmp(name, "help") == 0) {
                print_help_long(opts->progname); exit(0);
            } else if (strcmp(name, "version") == 0) {
                printf("b3sum 1.8.4\n"); exit(0);
            } else if (strcmp(name, "keyed") == 0) {
                if (value) err_unexpected(opts->progname, a);
                set_flag(opts, F_KEYED); i++;
            } else if (strcmp(name, "derive-key") == 0) {
                if (opts->derive_key) err_duplicate(opts->progname, F_DERIVE_KEY);
                const char *v = consume_value(argc, argv, &i, "--derive-key <CONTEXT>", value, opts->progname);
                set_flag(opts, F_DERIVE_KEY);
                opts->derive_ctx = strdup(v);
            } else if (strcmp(name, "length") == 0) {
                if (opts->length_set) err_duplicate(opts->progname, F_LENGTH);
                const char *vs = consume_value(argc, argv, &i, "--length <LEN>", value, opts->progname);
                uint64_t v; const char *reason;
                if (parse_u64(vs, &v, &reason) != 0) err_invalid_value("--length <LEN>", vs, reason);
                set_flag(opts, F_LENGTH);
                opts->length = v;
            } else if (strcmp(name, "seek") == 0) {
                if (opts->seek_set) err_duplicate(opts->progname, F_SEEK);
                const char *vs = consume_value(argc, argv, &i, "--seek <SEEK>", value, opts->progname);
                uint64_t v; const char *reason;
                if (parse_u64(vs, &v, &reason) != 0) err_invalid_value("--seek <SEEK>", vs, reason);
                set_flag(opts, F_SEEK);
                opts->seek = v;
            } else if (strcmp(name, "num-threads") == 0) {
                if (opts->num_threads_set) err_duplicate(opts->progname, F_NUM_THREADS);
                const char *vs = consume_value(argc, argv, &i, "--num-threads <NUM>", value, opts->progname);
                uint64_t v; const char *reason;
                if (parse_u64(vs, &v, &reason) != 0) err_invalid_value("--num-threads <NUM>", vs, reason);
                set_flag(opts, F_NUM_THREADS);
                opts->num_threads = v;
            } else if (strcmp(name, "no-mmap") == 0) {
                if (value) err_unexpected(opts->progname, a);
                set_flag(opts, F_NO_MMAP); i++;
            } else if (strcmp(name, "no-names") == 0) {
                if (value) err_unexpected(opts->progname, a);
                set_flag(opts, F_NO_NAMES); i++;
            } else if (strcmp(name, "raw") == 0) {
                if (value) err_unexpected(opts->progname, a);
                set_flag(opts, F_RAW); i++;
            } else if (strcmp(name, "tag") == 0) {
                if (value) err_unexpected(opts->progname, a);
                set_flag(opts, F_TAG); i++;
            } else if (strcmp(name, "check") == 0) {
                if (value) err_unexpected(opts->progname, a);
                set_flag(opts, F_CHECK); i++;
            } else if (strcmp(name, "quiet") == 0) {
                if (value) err_unexpected(opts->progname, a);
                set_flag(opts, F_QUIET); i++;
            } else {
                err_unexpected(opts->progname, a);
            }
        } else if (a[0] == '-' && a[1] != '\0') {
            /* Short option(s). Could be -l, -c, -h, -V, possibly bundled. */
            const char *p = a + 1;
            while (*p) {
                char c = *p;
                if (c == 'h') {
                    print_help_short(opts->progname); exit(0);
                } else if (c == 'V') {
                    printf("b3sum 1.8.4\n"); exit(0);
                } else if (c == 'c') {
                    set_flag(opts, F_CHECK); p++;
                } else if (c == 'l') {
                    /* --length, takes a value */
                    if (opts->length_set) err_duplicate(opts->progname, F_LENGTH);
                    const char *val = p + 1;
                    if (*val == '\0') {
                        if (i + 1 >= argc) err_missing_value("--length <LEN>");
                        const char *next = argv[i+1];
                        if (next[0] == '-' && next[1] != '\0' &&
                            !(next[0] == '-' && next[1] == '-' && next[2] == '\0')) {
                            if (is_known_flag(next)) err_missing_value("--length <LEN>");
                            else err_unexpected(opts->progname, next);
                        }
                        val = argv[i+1];
                        i++;
                    }
                    uint64_t v; const char *reason;
                    if (parse_u64(val, &v, &reason) != 0) err_invalid_value("--length <LEN>", val, reason);
                    set_flag(opts, F_LENGTH);
                    opts->length = v;
                    /* consume rest of arg */
                    p = ""; /* break the loop */
                    break;
                } else {
                    /* Unknown short option -- pass the whole "-x" arg */
                    char tmp[3] = {'-', c, '\0'};
                    err_unexpected(opts->progname, tmp);
                }
            }
            i++;
        } else {
            /* Positional */
            if (*a == '\0') {
                /* Empty positional argument */
                fprintf(stderr, "error: a value is required for '[FILE]...' but none was supplied\n\n");
                fprintf(stderr, "For more information, try '--help'.\n");
                exit(2);
            }
            g_positional_seen = true;
            add_file(opts, a);
            i++;
        }
    }

    /* After parsing, enforce "--quiet requires --check" */
    if (opts->quiet && !opts->check) {
        err_missing_required(opts->progname, F_CHECK, "--check", false);
    }

    /* --keyed requires <FILE>... (when no FILE given) */
    if (opts->keyed && opts->n_files == 0) {
        err_missing_required(opts->progname, F_NONE, "<FILE>...", true);
    }

    /* --raw allows only one input */
    /* Validation will happen later when actually iterating files; but the actual
       check is done at the start (before reading stdin). Let's defer to main. */
}

/* ----------------------- hashing helpers ----------------------- */

/* Hash a file (or stdin if path is "-") with the given hasher. */
static int hash_file_into(blake3_hasher *h, const char *path, bool no_mmap, char **errmsg) {
    int fd;
    if (strcmp(path, "-") == 0) {
        fd = 0;
    } else {
        fd = open(path, O_RDONLY);
        if (fd < 0) {
            *errmsg = strdup(strerror(errno));
            return -1;
        }
    }
    /* Stat to check if it's a directory */
    struct stat st;
    if (fstat(fd, &st) == 0) {
        if (S_ISDIR(st.st_mode)) {
            if (fd != 0) close(fd);
            *errmsg = strdup(strerror(EISDIR));
            errno = EISDIR;
            return -1;
        }
    }

    /* Try mmap for regular files */
    if (!no_mmap && fd != 0 && S_ISREG(st.st_mode) && st.st_size > 0) {
        void *map = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
        if (map != MAP_FAILED) {
            blake3_hasher_update(h, map, (size_t)st.st_size);
            munmap(map, (size_t)st.st_size);
            close(fd);
            return 0;
        }
    }

    /* Streaming read */
    uint8_t buf[65536];
    while (1) {
        ssize_t n = read(fd, buf, sizeof(buf));
        if (n < 0) {
            if (errno == EINTR) continue;
            int saved = errno;
            *errmsg = strdup(strerror(errno));
            if (fd != 0) close(fd);
            errno = saved;
            return -1;
        }
        if (n == 0) break;
        blake3_hasher_update(h, buf, (size_t)n);
    }
    if (fd != 0) close(fd);
    return 0;
}

/* ----------------------- filename escaping ----------------------- */

static bool needs_escape(const char *name) {
    for (const char *p = name; *p; p++) {
        if (*p == '\\' || *p == '\n' || *p == '\r') return true;
    }
    return false;
}

/* Escape into a heap buffer. Caller frees. */
static char *escape_name(const char *name) {
    size_t n = strlen(name);
    char *out = (char *)malloc(n * 2 + 1);
    char *q = out;
    for (size_t i = 0; i < n; i++) {
        unsigned char c = (unsigned char)name[i];
        if (c == '\\') { *q++ = '\\'; *q++ = '\\'; }
        else if (c == '\n') { *q++ = '\\'; *q++ = 'n'; }
        else if (c == '\r') { *q++ = '\\'; *q++ = 'r'; }
        else { *q++ = c; }
    }
    *q = '\0';
    return out;
}

/* Unescape an escaped name (used when reading check file lines).
   The input slice is given by ptr+len. Returns a heap buffer (caller frees). */
static char *unescape_name(const char *p, size_t n) {
    char *out = (char *)malloc(n + 1);
    char *q = out;
    for (size_t i = 0; i < n; i++) {
        if (p[i] == '\\' && i + 1 < n) {
            char c = p[i+1];
            if (c == '\\') { *q++ = '\\'; i++; }
            else if (c == 'n') { *q++ = '\n'; i++; }
            else if (c == 'r') { *q++ = '\r'; i++; }
            else { *q++ = p[i]; }
        } else {
            *q++ = p[i];
        }
    }
    *q = '\0';
    return out;
}

/* ----------------------- main hashing path ----------------------- */

static const char *HEX = "0123456789abcdef";

static void write_hex(FILE *f, const uint8_t *p, size_t n) {
    for (size_t i = 0; i < n; i++) {
        fputc(HEX[(p[i] >> 4) & 0xF], f);
        fputc(HEX[p[i] & 0xF], f);
    }
}

static void print_hash_default(const uint8_t *hash, size_t hash_len, const char *name) {
    bool esc = needs_escape(name);
    if (esc) {
        char *en = escape_name(name);
        fputc('\\', stdout);
        write_hex(stdout, hash, hash_len);
        fputs("  ", stdout);
        fputs(en, stdout);
        fputc('\n', stdout);
        free(en);
    } else {
        write_hex(stdout, hash, hash_len);
        fputs("  ", stdout);
        fputs(name, stdout);
        fputc('\n', stdout);
    }
}

static void print_hash_tag(const uint8_t *hash, size_t hash_len, const char *name) {
    bool esc = needs_escape(name);
    if (esc) {
        char *en = escape_name(name);
        fputc('\\', stdout);
        fputs("BLAKE3 (", stdout);
        fputs(en, stdout);
        fputs(") = ", stdout);
        write_hex(stdout, hash, hash_len);
        fputc('\n', stdout);
        free(en);
    } else {
        fputs("BLAKE3 (", stdout);
        fputs(name, stdout);
        fputs(") = ", stdout);
        write_hex(stdout, hash, hash_len);
        fputc('\n', stdout);
    }
}

static void print_hash_noname(const uint8_t *hash, size_t hash_len) {
    write_hex(stdout, hash, hash_len);
    fputc('\n', stdout);
}

static void print_hash_raw(const uint8_t *hash, size_t hash_len) {
    fwrite(hash, 1, hash_len, stdout);
}

/* ----------------------- check mode ----------------------- */

/* Lowercase-only hex decoder (matches b3sum check mode) */
static int hex_to_byte(int c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

/* Parse a check line into hash bytes (variable length) and name.
   The name buf is heap-allocated (caller frees).
   Returns 0 on success, -1 on parse failure. Sets *reason on failure. */
static int parse_check_line(const char *line, size_t len,
                            uint8_t **hash_out, size_t *hash_len_out,
                            char **name_out, const char **reason) {
    /* Strip trailing \r */
    while (len > 0 && (line[len-1] == '\r')) len--;
    if (len == 0) { *reason = "Empty line"; return -1; }

    bool escaped = false;
    size_t off = 0;
    if (line[0] == '\\') {
        escaped = true;
        off = 1;
    }

    /* Try BSD/tag form first: starts with "BLAKE3 (" */
    const char prefix[] = "BLAKE3 (";
    if (len - off >= sizeof(prefix) - 1 &&
        memcmp(line + off, prefix, sizeof(prefix) - 1) == 0) {
        size_t name_start = off + sizeof(prefix) - 1;
        const char *rest = line + name_start;
        size_t rest_len = len - name_start;
        if (rest_len < 4) { *reason = "Invalid check line format"; return -1; }
        ssize_t close_idx = -1;
        for (ssize_t i = (ssize_t)rest_len - 4; i >= 0; i--) {
            if (rest[i] == ')' && rest[i+1] == ' ' && rest[i+2] == '=' && rest[i+3] == ' ') {
                close_idx = i;
                break;
            }
        }
        if (close_idx < 0) { *reason = "Invalid check line format"; return -1; }
        size_t name_len = (size_t)close_idx;
        size_t hex_off = name_start + (size_t)close_idx + 4;
        size_t hex_len = len - hex_off;
        if (hex_len != 64) { *reason = "Invalid hash length"; return -1; }
        uint8_t *hash = (uint8_t *)malloc(hex_len / 2);
        for (size_t i = 0; i < hex_len; i += 2) {
            int hi = hex_to_byte(line[hex_off + i]);
            int lo = hex_to_byte(line[hex_off + i + 1]);
            if (hi < 0 || lo < 0) { free(hash); *reason = "Invalid hex"; return -1; }
            hash[i/2] = (uint8_t)((hi << 4) | lo);
        }
        char *name;
        if (escaped) {
            name = unescape_name(line + name_start, name_len);
        } else {
            name = (char *)malloc(name_len + 1);
            memcpy(name, line + name_start, name_len);
            name[name_len] = '\0';
        }
        *hash_out = hash;
        *hash_len_out = hex_len / 2;
        *name_out = name;
        return 0;
    }

    /* Default form: <hex>  <name> */
    if (len <= off + 2) { *reason = "Invalid check line format"; return -1; }
    size_t sep = (size_t)-1;
    for (size_t i = off; i + 1 < len; i++) {
        if (line[i] == ' ' && line[i+1] == ' ') {
            sep = i;
            break;
        }
    }
    if (sep == (size_t)-1) { *reason = "Invalid check line format"; return -1; }
    size_t hex_off = off;
    size_t hex_len = sep - off;
    size_t name_start = sep + 2;
    size_t name_len = len - name_start;
    if (name_len == 0) { *reason = "Invalid check line format"; return -1; }
    if (hex_len != 64) { *reason = "Invalid hash length"; return -1; }
    uint8_t *hash = (uint8_t *)malloc(hex_len / 2);
    for (size_t i = 0; i < hex_len; i += 2) {
        int hi = hex_to_byte(line[hex_off + i]);
        int lo = hex_to_byte(line[hex_off + i + 1]);
        if (hi < 0 || lo < 0) { free(hash); *reason = "Invalid hex"; return -1; }
        hash[i/2] = (uint8_t)((hi << 4) | lo);
    }
    char *name;
    if (escaped) {
        name = unescape_name(line + name_start, name_len);
    } else {
        name = (char *)malloc(name_len + 1);
        memcpy(name, line + name_start, name_len);
        name[name_len] = '\0';
    }
    *hash_out = hash;
    *hash_len_out = hex_len / 2;
    *name_out = name;
    return 0;
}

/* Process check file (or stdin). Returns count of failures + parse-errors. */
static long process_check_file(const char *path, bool quiet, bool no_mmap) {
    FILE *f;
    if (strcmp(path, "-") == 0) {
        f = stdin;
    } else {
        f = fopen(path, "r");
        if (!f) {
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
            exit(1);
        }
    }

    long failures = 0;
    char *line = NULL;
    size_t cap = 0;
    ssize_t nread;
    while ((nread = getline(&line, &cap, f)) != -1) {
        size_t len = (size_t)nread;
        /* strip trailing newline */
        while (len > 0 && (line[len-1] == '\n')) len--;
        uint8_t *expected;
        size_t expected_len;
        char *name;
        const char *reason;
        if (parse_check_line(line, len, &expected, &expected_len, &name, &reason) != 0) {
            fflush(stdout);
            fprintf(stderr, "b3sum: %s\n", reason);
            failures++;
            continue;
        }

        /* Hash the file with the expected output length */
        blake3_hasher h;
        blake3_hasher_init(&h);
        char *errmsg = NULL;
        int rc = hash_file_into(&h, name, no_mmap, &errmsg);
        char *display = needs_escape(name) ? NULL : NULL;
        bool esc = needs_escape(name);
        char *en = esc ? escape_name(name) : NULL;
        const char *disp = esc ? en : name;
        const char *prefix = esc ? "\\" : "";

        if (rc != 0) {
            fprintf(stdout, "%s%s: FAILED (%s (os error %d))\n", prefix, disp, errmsg, errno);
            failures++;
            free(errmsg);
        } else {
            uint8_t *actual = (uint8_t *)malloc(expected_len ? expected_len : 1);
            blake3_hasher_finalize_seek(&h, 0, actual, expected_len);
            if (memcmp(actual, expected, expected_len) == 0) {
                if (!quiet) {
                    fprintf(stdout, "%s%s: OK\n", prefix, disp);
                }
            } else {
                fprintf(stdout, "%s%s: FAILED\n", prefix, disp);
                failures++;
            }
            free(actual);
        }
        if (en) free(en);
        (void)display;
        free(expected);
        free(name);
    }
    free(line);
    if (f != stdin) fclose(f);
    return failures;
}

static int run_check_mode(const options_t *opts) {
    char *stdin_marker = "-";
    char **inputs;
    size_t n_inputs;
    if (opts->n_files == 0) {
        inputs = &stdin_marker;
        n_inputs = 1;
    } else {
        inputs = opts->files;
        n_inputs = opts->n_files;
    }
    long total_failures = 0;
    for (size_t i = 0; i < n_inputs; i++) {
        total_failures += process_check_file(inputs[i], opts->quiet, opts->no_mmap);
    }
    fflush(stdout);
    if (total_failures > 0) {
        if (total_failures == 1) {
            fprintf(stderr, "b3sum: WARNING: 1 computed checksum did NOT match\n");
        } else {
            fprintf(stderr, "b3sum: WARNING: %ld computed checksums did NOT match\n", total_failures);
        }
        return 1;
    }
    return 0;
}

/* ----------------------- main ----------------------- */

/* Save keyed-key bytes globally so we can reinit between files. */
static uint8_t g_keyed_key[32];
static bool g_keyed_loaded = false;

static int run_hash_mode2(const options_t *opts) {
    char *stdin_marker = "-";
    char **inputs;
    size_t n_inputs;
    if (opts->n_files == 0) {
        inputs = &stdin_marker;
        n_inputs = 1;
    } else {
        inputs = opts->files;
        n_inputs = opts->n_files;
    }

    if (opts->raw && n_inputs > 1) {
        fprintf(stderr, "Error: Only one filename can be provided when using --raw\n");
        return 1;
    }

    /* If keyed, read 32 bytes from stdin once */
    if (opts->keyed && !g_keyed_loaded) {
        uint8_t k[33];
        size_t got = 0;
        while (got < 33) {
            ssize_t n = read(0, k + got, 33 - got);
            if (n < 0) {
                if (errno == EINTR) continue;
                fprintf(stderr, "Error: %s\n", strerror(errno));
                return 1;
            }
            if (n == 0) break;
            got += (size_t)n;
        }
        if (got < 32) {
            fprintf(stderr, "Error: expected 32 key bytes from stdin, found %zu\n", got);
            return 1;
        }
        if (got > 32) {
            fprintf(stderr, "Error: read more than 32 key bytes from stdin\n");
            return 1;
        }
        memcpy(g_keyed_key, k, 32);
        g_keyed_loaded = true;
    }

    int exit_code = 0;
    for (size_t i = 0; i < n_inputs; i++) {
        const char *path = inputs[i];
        if (opts->keyed && strcmp(path, "-") == 0) {
            fflush(stdout);
            fprintf(stderr, "b3sum: -: Cannot open `-` in keyed mode\n");
            exit_code = 1;
            continue;
        }

        blake3_hasher h;
        if (opts->keyed) {
            blake3_hasher_init_keyed(&h, g_keyed_key);
        } else if (opts->derive_key) {
            blake3_hasher_init_derive_key(&h, opts->derive_ctx);
        } else {
            blake3_hasher_init(&h);
        }

        char *errmsg = NULL;
        int rc = hash_file_into(&h, path, opts->no_mmap, &errmsg);
        if (rc != 0) {
            int saved_errno = errno;
            char *escaped = needs_escape(path) ? escape_name(path) : NULL;
            const char *disp = escaped ? escaped : path;
            const char *pre = escaped ? "\\" : "";
            fflush(stdout);
            fprintf(stderr, "b3sum: %s%s: %s (os error %d)\n", pre, disp, errmsg ? errmsg : "error", saved_errno);
            if (escaped) free(escaped);
            free(errmsg);
            exit_code = 1;
            continue;
        }

        size_t out_len = (size_t)opts->length;
        uint8_t *out = (uint8_t *)malloc(out_len ? out_len : 1);
        blake3_hasher_finalize_seek(&h, opts->seek, out, out_len);

        if (opts->raw) print_hash_raw(out, out_len);
        else if (opts->no_names) print_hash_noname(out, out_len);
        else if (opts->tag) print_hash_tag(out, out_len, path);
        else print_hash_default(out, out_len, path);

        free(out);
    }
    return exit_code;
}

int main(int argc, char **argv) {
    options_t opts;
    memset(&opts, 0, sizeof(opts));
    parse_args(argc, argv, &opts);

    int rc;
    if (opts.check) {
        rc = run_check_mode(&opts);
    } else {
        rc = run_hash_mode2(&opts);
    }
    fflush(stdout);
    /* Free stuff */
    free(opts.derive_ctx);
    free(opts.files);
    return rc;
}
