#ifndef BLAKE3_H
#define BLAKE3_H

#include <stddef.h>
#include <stdint.h>

#define BLAKE3_KEY_LEN 32
#define BLAKE3_OUT_LEN 32
#define BLAKE3_BLOCK_LEN 64
#define BLAKE3_CHUNK_LEN 1024
#define BLAKE3_MAX_DEPTH 54

#define CHUNK_START         (1u << 0)
#define CHUNK_END           (1u << 1)
#define PARENT              (1u << 2)
#define ROOT                (1u << 3)
#define KEYED_HASH          (1u << 4)
#define DERIVE_KEY_CONTEXT  (1u << 5)
#define DERIVE_KEY_MATERIAL (1u << 6)

typedef struct {
    uint32_t cv[8];
    uint64_t chunk_counter;
    uint8_t  buf[BLAKE3_BLOCK_LEN];
    uint8_t  buf_len;
    uint8_t  blocks_compressed;
    uint8_t  flags;
} chunk_state_t;

typedef struct {
    uint32_t key[8];
    chunk_state_t chunk;
    /* Merkle stack of chaining values, max depth 54 (covers 2^54 chunks) */
    uint8_t cv_stack[BLAKE3_MAX_DEPTH * 32];
    uint8_t cv_stack_len;
    uint8_t flags;
} blake3_hasher;

void blake3_hasher_init(blake3_hasher *self);
void blake3_hasher_init_keyed(blake3_hasher *self, const uint8_t key[BLAKE3_KEY_LEN]);
void blake3_hasher_init_derive_key(blake3_hasher *self, const char *context);
void blake3_hasher_init_derive_key_raw(blake3_hasher *self, const void *context, size_t context_len);

void blake3_hasher_update(blake3_hasher *self, const void *input, size_t input_len);

/* Finalize at the given seek offset, writing out_len bytes. */
void blake3_hasher_finalize_seek(const blake3_hasher *self, uint64_t seek, uint8_t *out, size_t out_len);

#endif
