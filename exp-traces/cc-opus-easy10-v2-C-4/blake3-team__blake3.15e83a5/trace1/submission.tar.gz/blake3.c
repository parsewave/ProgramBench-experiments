#include "blake3.h"
#include <string.h>

static const uint32_t IV[8] = {
    0x6A09E667u, 0xBB67AE85u, 0x3C6EF372u, 0xA54FF53Au,
    0x510E527Fu, 0x9B05688Cu, 0x1F83D9ABu, 0x5BE0CD19u
};

static const uint8_t MSG_PERM[16] = {2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8};

static inline uint32_t rotr32(uint32_t x, unsigned n) {
    return (x >> n) | (x << (32 - n));
}

static inline uint32_t load32_le(const uint8_t *p) {
    return ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static inline void store32_le(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

static inline void g(uint32_t *st, int a, int b, int c, int d, uint32_t mx, uint32_t my) {
    st[a] = st[a] + st[b] + mx;
    st[d] = rotr32(st[d] ^ st[a], 16);
    st[c] = st[c] + st[d];
    st[b] = rotr32(st[b] ^ st[c], 12);
    st[a] = st[a] + st[b] + my;
    st[d] = rotr32(st[d] ^ st[a], 8);
    st[c] = st[c] + st[d];
    st[b] = rotr32(st[b] ^ st[c], 7);
}

static void round_fn(uint32_t *st, const uint32_t *m) {
    g(st, 0, 4,  8, 12, m[0],  m[1]);
    g(st, 1, 5,  9, 13, m[2],  m[3]);
    g(st, 2, 6, 10, 14, m[4],  m[5]);
    g(st, 3, 7, 11, 15, m[6],  m[7]);
    g(st, 0, 5, 10, 15, m[8],  m[9]);
    g(st, 1, 6, 11, 12, m[10], m[11]);
    g(st, 2, 7,  8, 13, m[12], m[13]);
    g(st, 3, 4,  9, 14, m[14], m[15]);
}

static void permute(uint32_t *m) {
    uint32_t tmp[16];
    for (int i = 0; i < 16; i++) tmp[i] = m[MSG_PERM[i]];
    memcpy(m, tmp, sizeof(tmp));
}

/* compress: output is 16 words (full state) */
static void compress(const uint32_t cv[8], const uint8_t block[BLAKE3_BLOCK_LEN],
                     uint64_t counter, uint32_t block_len, uint32_t flags,
                     uint32_t out[16]) {
    uint32_t st[16];
    uint32_t m[16];

    st[0] = cv[0]; st[1] = cv[1]; st[2] = cv[2]; st[3] = cv[3];
    st[4] = cv[4]; st[5] = cv[5]; st[6] = cv[6]; st[7] = cv[7];
    st[8] = IV[0]; st[9] = IV[1]; st[10] = IV[2]; st[11] = IV[3];
    st[12] = (uint32_t)(counter & 0xFFFFFFFFu);
    st[13] = (uint32_t)(counter >> 32);
    st[14] = block_len;
    st[15] = flags;

    for (int i = 0; i < 16; i++) m[i] = load32_le(block + 4*i);

    round_fn(st, m); permute(m);
    round_fn(st, m); permute(m);
    round_fn(st, m); permute(m);
    round_fn(st, m); permute(m);
    round_fn(st, m); permute(m);
    round_fn(st, m); permute(m);
    round_fn(st, m);
    /* No permute after the last round. */

    for (int i = 0; i < 8; i++) {
        out[i] = st[i] ^ st[i + 8];
        out[i + 8] = st[i + 8] ^ cv[i];
    }
}

/* --- Chunk state helpers --- */

static void chunk_state_reset(chunk_state_t *cs, const uint32_t key[8], uint64_t counter, uint8_t flags) {
    for (int i = 0; i < 8; i++) cs->cv[i] = key[i];
    cs->chunk_counter = counter;
    cs->buf_len = 0;
    cs->blocks_compressed = 0;
    cs->flags = flags;
    memset(cs->buf, 0, sizeof(cs->buf));
}

static uint8_t chunk_start_flag(const chunk_state_t *cs) {
    return cs->blocks_compressed == 0 ? CHUNK_START : 0;
}

static size_t chunk_state_len(const chunk_state_t *cs) {
    return (size_t)BLAKE3_BLOCK_LEN * cs->blocks_compressed + (size_t)cs->buf_len;
}

static void chunk_state_update(chunk_state_t *cs, const uint8_t *input, size_t len) {
    while (len > 0) {
        /* If the buffer is full, compress it before adding more. */
        if (cs->buf_len == BLAKE3_BLOCK_LEN) {
            uint32_t out[16];
            uint32_t block_flags = cs->flags | chunk_start_flag(cs);
            compress(cs->cv, cs->buf, cs->chunk_counter, BLAKE3_BLOCK_LEN, block_flags, out);
            for (int i = 0; i < 8; i++) cs->cv[i] = out[i];
            cs->blocks_compressed++;
            cs->buf_len = 0;
            memset(cs->buf, 0, sizeof(cs->buf));
        }
        size_t want = (size_t)BLAKE3_BLOCK_LEN - cs->buf_len;
        size_t take = len < want ? len : want;
        memcpy(cs->buf + cs->buf_len, input, take);
        cs->buf_len += (uint8_t)take;
        input += take;
        len -= take;
    }
}

/* Output (XOF) helpers */
typedef struct {
    uint32_t input_cv[8];
    uint8_t  block[BLAKE3_BLOCK_LEN];
    uint32_t block_len;
    uint64_t counter;
    uint32_t flags;
} output_t;

static void chunk_state_output(const chunk_state_t *cs, output_t *o) {
    for (int i = 0; i < 8; i++) o->input_cv[i] = cs->cv[i];
    memcpy(o->block, cs->buf, BLAKE3_BLOCK_LEN);
    o->block_len = cs->buf_len;
    o->counter = cs->chunk_counter;
    o->flags = cs->flags | chunk_start_flag(cs) | CHUNK_END;
}

static void parent_output(const uint8_t left[32], const uint8_t right[32],
                          const uint32_t key[8], uint8_t flags, output_t *o) {
    for (int i = 0; i < 8; i++) o->input_cv[i] = key[i];
    memcpy(o->block, left, 32);
    memcpy(o->block + 32, right, 32);
    o->block_len = BLAKE3_BLOCK_LEN;
    o->counter = 0;
    o->flags = flags | PARENT;
}

static void parent_cv(const uint8_t left[32], const uint8_t right[32],
                      const uint32_t key[8], uint8_t flags, uint8_t out[32]) {
    output_t o;
    parent_output(left, right, key, flags, &o);
    uint32_t cv[16];
    compress(o.input_cv, o.block, o.counter, o.block_len, o.flags, cv);
    for (int i = 0; i < 8; i++) store32_le(out + 4*i, cv[i]);
}

/* --- Hasher --- */

static void hasher_init_internal(blake3_hasher *self, const uint32_t key[8], uint8_t flags) {
    for (int i = 0; i < 8; i++) self->key[i] = key[i];
    chunk_state_reset(&self->chunk, key, 0, flags);
    self->cv_stack_len = 0;
    self->flags = flags;
}

void blake3_hasher_init(blake3_hasher *self) {
    hasher_init_internal(self, IV, 0);
}

void blake3_hasher_init_keyed(blake3_hasher *self, const uint8_t key[BLAKE3_KEY_LEN]) {
    uint32_t k[8];
    for (int i = 0; i < 8; i++) k[i] = load32_le(key + 4*i);
    hasher_init_internal(self, k, KEYED_HASH);
}

void blake3_hasher_init_derive_key_raw(blake3_hasher *self, const void *context, size_t context_len) {
    blake3_hasher ctx_hasher;
    hasher_init_internal(&ctx_hasher, IV, DERIVE_KEY_CONTEXT);
    blake3_hasher_update(&ctx_hasher, context, context_len);
    uint8_t ctx_key[32];
    blake3_hasher_finalize_seek(&ctx_hasher, 0, ctx_key, 32);
    uint32_t k[8];
    for (int i = 0; i < 8; i++) k[i] = load32_le(ctx_key + 4*i);
    hasher_init_internal(self, k, DERIVE_KEY_MATERIAL);
}

void blake3_hasher_init_derive_key(blake3_hasher *self, const char *context) {
    blake3_hasher_init_derive_key_raw(self, context, strlen(context));
}

/* Push a chunk CV onto the stack, merging right-siblings up the tree. */
static void push_cv(blake3_hasher *self, const uint8_t new_cv[32], uint64_t chunk_counter) {
    uint8_t current[32];
    memcpy(current, new_cv, 32);
    uint64_t cc = chunk_counter;
    while ((cc & 1) == 1) {
        uint8_t left[32];
        memcpy(left, &self->cv_stack[(self->cv_stack_len - 1) * 32], 32);
        self->cv_stack_len--;
        uint8_t merged[32];
        parent_cv(left, current, self->key, self->flags, merged);
        memcpy(current, merged, 32);
        cc >>= 1;
    }
    memcpy(&self->cv_stack[self->cv_stack_len * 32], current, 32);
    self->cv_stack_len++;
}

void blake3_hasher_update(blake3_hasher *self, const void *input_v, size_t input_len) {
    const uint8_t *input = (const uint8_t *)input_v;
    while (input_len > 0) {
        /* If current chunk is full (1024 bytes), finalize it and push CV. */
        if (chunk_state_len(&self->chunk) == BLAKE3_CHUNK_LEN) {
            output_t out;
            chunk_state_output(&self->chunk, &out);
            uint32_t cv16[16];
            compress(out.input_cv, out.block, out.counter, out.block_len, out.flags, cv16);
            uint8_t cv_bytes[32];
            for (int i = 0; i < 8; i++) store32_le(cv_bytes + 4*i, cv16[i]);

            uint64_t chunk_counter = self->chunk.chunk_counter;
            push_cv(self, cv_bytes, chunk_counter);

            /* Reset chunk state for next chunk */
            chunk_state_reset(&self->chunk, self->key, chunk_counter + 1, self->flags);
        }
        size_t want = BLAKE3_CHUNK_LEN - chunk_state_len(&self->chunk);
        size_t take = input_len < want ? input_len : want;
        chunk_state_update(&self->chunk, input, take);
        input += take;
        input_len -= take;
    }
}

/* Build the final Output struct from the current state. */
static void hasher_final_output(const blake3_hasher *self, output_t *out) {
    /* Edge case: no chunks pushed yet, current chunk is the root. */
    if (self->cv_stack_len == 0) {
        chunk_state_output(&self->chunk, out);
        return;
    }

    /* If the current chunk has content (or we've never produced one), finalize it first as a chaining value
       and zip it up the right side. */
    output_t cur_out;
    /* Get the current chunk's output (it might be empty -- but if we have anything in stack, this chunk has content). */
    chunk_state_output(&self->chunk, &cur_out);

    /* Compute the chunk's CV */
    uint32_t cv16[16];
    compress(cur_out.input_cv, cur_out.block, cur_out.counter, cur_out.block_len, cur_out.flags, cv16);
    uint8_t right_cv[32];
    for (int i = 0; i < 8; i++) store32_le(right_cv + 4*i, cv16[i]);

    /* Now merge with stack from top down. The last merge gives the root output. */
    int stack_idx = self->cv_stack_len;
    /* Walk down: the topmost stack entry pairs with the new CV */
    output_t out_struct;
    /* First merge: left = stack[top-1], right = right_cv -- produces output */
    stack_idx--;
    parent_output(&self->cv_stack[stack_idx * 32], right_cv, self->key, self->flags, &out_struct);

    while (stack_idx > 0) {
        /* Compute CV from out_struct */
        uint32_t cv2[16];
        compress(out_struct.input_cv, out_struct.block, out_struct.counter, out_struct.block_len, out_struct.flags, cv2);
        uint8_t merged_cv[32];
        for (int i = 0; i < 8; i++) store32_le(merged_cv + 4*i, cv2[i]);
        stack_idx--;
        parent_output(&self->cv_stack[stack_idx * 32], merged_cv, self->key, self->flags, &out_struct);
    }
    *out = out_struct;
}

void blake3_hasher_finalize_seek(const blake3_hasher *self, uint64_t seek, uint8_t *out, size_t out_len) {
    output_t fo;
    hasher_final_output(self, &fo);
    uint32_t root_flags = fo.flags | ROOT;

    /* Emit 64-byte blocks starting at block index seek/64, then skip the first seek%64 bytes. */
    uint64_t block_idx = seek / BLAKE3_BLOCK_LEN;
    size_t block_off = (size_t)(seek % BLAKE3_BLOCK_LEN);
    size_t written = 0;

    while (written < out_len) {
        uint32_t words[16];
        compress(fo.input_cv, fo.block, block_idx, fo.block_len, root_flags, words);
        uint8_t block_bytes[BLAKE3_BLOCK_LEN];
        for (int i = 0; i < 16; i++) store32_le(block_bytes + 4*i, words[i]);

        size_t available = BLAKE3_BLOCK_LEN - block_off;
        size_t take = (out_len - written) < available ? (out_len - written) : available;
        memcpy(out + written, block_bytes + block_off, take);
        written += take;
        block_off = 0;
        block_idx++;
    }
}
