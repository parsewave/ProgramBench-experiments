#!/bin/bash
set -e
cd "$(dirname "$0")"
export PATH="/usr/local/cargo/bin:$PATH"
export CARGO_TARGET_DIR=target
cargo build --release --offline
cp target/release/executable ./executable
