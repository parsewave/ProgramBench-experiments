use clap::{App, AppSettings, Arg, ArgMatches, SubCommand};
use serde_derive::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::Command;

#[derive(Serialize, Deserialize, Clone, Debug, Default)]
struct Script {
    command: String,
    #[serde(skip_serializing_if = "Option::is_none", default)]
    description: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none", default)]
    tags: Option<Vec<String>>,
    #[serde(skip_serializing, default)]
    alias: Option<String>,
    #[serde(skip_serializing, default)]
    reference: Option<String>,
}

#[derive(Serialize, Deserialize, Clone, Debug, Default)]
#[serde(default)]
struct Defaults {
    #[serde(skip_serializing_if = "Option::is_none")]
    interpreter: Option<Vec<String>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    command_width: Option<usize>,
}

#[derive(Serialize, Deserialize, Clone, Debug, Default)]
#[serde(default)]
struct Config {
    #[serde(skip_serializing_if = "BTreeMap::is_empty")]
    scripts: BTreeMap<String, Script>,
    default: Defaults,
}

fn die(msg: &str) -> ! {
    eprintln!("error: {}", msg);
    std::process::exit(1);
}

fn build_cli() -> App<'static, 'static> {
    let long_help_main = "Sets a custom config file.

DEFAULT PATH is otherwise determined in this order:

- $PIER_CONFIG_PATH (environment variable if set)

- pier.toml (in the current directory)

- $XDG_CONFIG_HOME/pier/config.toml

- $XDG_CONFIG_HOME/pier/config

- $XDG_CONFIG_HOME/pier.toml

- $HOME/.pier.toml

- $HOME/.pier

";

    let list_about = "alias: ls - List scripts\n\n\
        Display options are determined by priority in this order:\n\n\
        1. List only aliases\n\n\
        2. Show full command\n\n\
        3. Command display with (cli option)\n\n\
        4. Command display with (config option)";

    App::new("pier")
        .version("0.1.6")
        .author("Benjamin Scholtz, Isak Johansson")
        .about("A simple script management CLI")
        .setting(AppSettings::GlobalVersion)
        .setting(AppSettings::ArgRequiredElseHelp)
        .setting(AppSettings::SubcommandsNegateReqs)
        .arg(
            Arg::with_name("verbose")
                .short("v")
                .long("verbose")
                .help("The level of verbosity"),
        )
        .arg(
            Arg::with_name("config-file")
                .short("c")
                .long("config-file")
                .value_name("path")
                .help("Sets a custom config file")
                .long_help(long_help_main)
                .env("PIER_CONFIG_PATH")
                .takes_value(true),
        )
        .arg(
            Arg::with_name("alias")
                .help("The alias or name for the script.")
                .required(true)
                .index(1),
        )
        .arg(
            Arg::with_name("args")
                .help("The positional arguments to send to script.")
                .multiple(true)
                .required(false)
                .index(2),
        )
        .subcommand(
            SubCommand::with_name("add")
                .about("Add a new script to config.")
                
                .arg(Arg::with_name("force").short("f").long("force")
                     .help("Allows to overwrite the existing script"))
                .arg(Arg::with_name("alias").short("a").long("alias")
                     .value_name("alias").takes_value(true).required(true)
                     .help("The alias or name for the script."))
                .arg(Arg::with_name("description").short("d").long("description")
                     .value_name("description").takes_value(true)
                     .help("The description for the script."))
                .arg(Arg::with_name("tag").short("t").long("tag")
                     .value_name("tags").takes_value(true).multiple(true)
                     .number_of_values(1)
                     .help("Set which tags the script belongs to."))
                .arg(Arg::with_name("command").index(1)
                     .help("The command/script content to be executed. If this argument is not found it will open your $EDITOR for you to enter the script into.")),
        )
        .subcommand(
            SubCommand::with_name("list")
                .alias("ls")
                .about("alias: ls - List scripts")
                .long_about(list_about)
                
                .arg(Arg::with_name("cmd_full").short("l").long("cmd_full")
                     .help("Display the full command."))
                .arg(Arg::with_name("list_aliases").short("q").long("list_aliases")
                     .help("Only displays aliases of the scripts."))
                .arg(Arg::with_name("cmd_width").short("c").long("cmd_width")
                     .value_name("cmd-width").takes_value(true)
                     .validator(|s| s.parse::<usize>().map(|_| ()).map_err(|e| e.to_string()))
                     .help("The max number of characters to display from the command."))
                .arg(Arg::with_name("tag").short("t").long("tag")
                     .value_name("tags").takes_value(true).multiple(true)
                     .number_of_values(1)
                     .help("Filter based on tags.")),
        )
        .subcommand(
            SubCommand::with_name("run")
                .about("Run a script matching alias.")
                
                .arg(Arg::with_name("alias").required(true).index(1)
                     .help("The alias or name for the script."))
                .arg(Arg::with_name("args").multiple(true).required(false).index(2)
                     .help("The positional arguments to send to script.")),
        )
        .subcommand(
            SubCommand::with_name("remove")
                .alias("rm")
                .about("alias: rm - Remove a script matching alias.")
                
                .arg(Arg::with_name("alias").required(true).index(1)
                     .help("The alias or name for the script.")),
        )
        .subcommand(
            SubCommand::with_name("edit")
                .about("Edit a script matching alias.")
                
                .arg(Arg::with_name("alias").required(true).index(1)
                     .help("The alias or name for the script.")),
        )
        .subcommand(
            SubCommand::with_name("show")
                .about("Show a script matching alias.")
                
                .arg(Arg::with_name("alias").required(true).index(1)
                     .help("The alias or name for the script.")),
        )
        .subcommand(
            SubCommand::with_name("copy")
                .alias("cp")
                .about("alias: cp - Copy existing alias to the new one")
                
                .arg(Arg::with_name("from-alias").required(true).index(1)
                     .help("The alias of the script that will be copied."))
                .arg(Arg::with_name("to-alias").required(true).index(2)
                     .help("The new alias of the copy of the script.")),
        )
        .subcommand(
            SubCommand::with_name("move")
                .aliases(&["mv", "rename"])
                .about("alias: mv, rename - Move/rename existing alias to the new one")
                
                .arg(Arg::with_name("force").short("f").long("force")
                     .help("Allows to overwrite the existing script"))
                .arg(Arg::with_name("from-alias").required(true).index(1)
                     .help("The alias of the script that will be moved."))
                .arg(Arg::with_name("to-alias").required(true).index(2)
                     .help("The new alias of the script.")),
        )
        .subcommand(
            SubCommand::with_name("config-init")
                .alias("init")
                .about("alias: init - Add a config file."),
        )
}

fn resolve_config_path(cli_path: Option<&str>) -> Option<PathBuf> {
    if let Some(p) = cli_path {
        return Some(PathBuf::from(p));
    }

    let pier_cwd = PathBuf::from("pier.toml");
    if pier_cwd.exists() {
        return Some(pier_cwd);
    }

    let xdg = env::var("XDG_CONFIG_HOME").ok();
    if let Some(x) = xdg.as_deref() {
        for c in &[
            format!("{}/pier/config.toml", x),
            format!("{}/pier/config", x),
            format!("{}/pier.toml", x),
        ] {
            let p = PathBuf::from(c);
            if p.exists() {
                return Some(p);
            }
        }
    }

    if let Ok(h) = env::var("HOME") {
        for c in &[format!("{}/.pier.toml", h), format!("{}/.pier", h)] {
            let p = PathBuf::from(c);
            if p.exists() {
                return Some(p);
            }
        }
    }

    None
}

fn default_config_write_path() -> Option<PathBuf> {
    if let Ok(p) = env::var("PIER_CONFIG_PATH") {
        return Some(PathBuf::from(p));
    }
    if let Ok(x) = env::var("XDG_CONFIG_HOME") {
        return Some(PathBuf::from(format!("{}/pier/config.toml", x)));
    }
    if let Ok(h) = env::var("HOME") {
        return Some(PathBuf::from(format!("{}/.config/pier/config.toml", h)));
    }
    None
}

fn read_config_file(path: &Path) -> Config {
    let s = match fs::read_to_string(path) {
        Ok(s) => s,
        Err(e) => die(&format!("Unable to read config from file {}: {} ", path.display(), e)),
    };
    let cfg: Config = match toml::from_str(&s) {
        Ok(c) => c,
        Err(e) => die(&format!("Unable to parse toml config from file {}: {}", path.display(), e)),
    };
    cfg
}

fn write_config_file(path: &Path, cfg: &Config) {
    let body = serialize_config(cfg);
    if let Err(e) = fs::write(path, body) {
        die(&format!("Unable to write config to {}: {}", path.display(), e));
    }
}

fn serialize_config(cfg: &Config) -> String {
    let mut out = String::new();
    if cfg.scripts.is_empty() {
        out.push_str("[scripts]\n\n");
    }
    for (name, sc) in &cfg.scripts {
        out.push_str(&format!("[scripts.{}]\n", toml_quote_key(name)));
        out.push_str(&format!("command = {}\n", toml_string_value(&sc.command)));
        if let Some(d) = &sc.description {
            out.push_str(&format!("description = {}\n", toml_string_value(d)));
        }
        if let Some(tags) = &sc.tags {
            out.push_str(&format_tags(tags));
        }
        out.push_str("\n");
    }
    out.push_str("[default]\n");
    if let Some(ipr) = &cfg.default.interpreter {
        out.push_str(&format!("interpreter = {}\n", format_string_array_inline(ipr)));
    }
    if let Some(cw) = &cfg.default.command_width {
        out.push_str(&format!("command_width = {}\n", cw));
    }
    out
}

fn is_bare_key(s: &str) -> bool {
    !s.is_empty() && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-')
}

fn toml_quote_key(s: &str) -> String {
    if is_bare_key(s) {
        s.to_string()
    } else {
        let mut out = String::from("\"");
        for c in s.chars() {
            match c {
                '"' => out.push_str("\\\""),
                '\\' => out.push_str("\\\\"),
                '\n' => out.push_str("\\n"),
                '\r' => out.push_str("\\r"),
                '\t' => out.push_str("\\t"),
                '\x08' => out.push_str("\\b"),
                '\x0c' => out.push_str("\\f"),
                c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04X}", c as u32)),
                c => out.push(c),
            }
        }
        out.push('"');
        out
    }
}

// Replicates toml-rs 0.4 pretty string serialization (see ser.rs::emit_str)
fn toml_string_value(s: &str) -> String {
    #[derive(PartialEq, Clone, Copy)]
    enum Ty { NewlineTripple, OnelineTripple, OnelineSingle }
    let mut ty = Ty::OnelineSingle;
    let mut max_found_singles = 0u32;
    let mut found_singles = 0u32;
    let mut can_be_pretty = true;
    for ch in s.chars() {
        if can_be_pretty {
            if ch == '\'' {
                found_singles += 1;
                if found_singles >= 3 {
                    can_be_pretty = false;
                }
            } else {
                if found_singles > max_found_singles {
                    max_found_singles = found_singles;
                }
                found_singles = 0;
            }
            match ch {
                '\t' => {}
                '\n' => ty = Ty::NewlineTripple,
                c if (c as u32) < 0x1f => can_be_pretty = false,
                _ => {}
            }
        } else {
            if ch == '\n' {
                ty = Ty::NewlineTripple;
            }
        }
    }
    if can_be_pretty && found_singles > 0 && s.ends_with('\'') {
        can_be_pretty = false;
    }
    if can_be_pretty {
        if found_singles > max_found_singles {
            max_found_singles = found_singles;
        }
        if ty == Ty::OnelineSingle && max_found_singles >= 1 {
            ty = Ty::OnelineTripple;
        }
        // Emit as literal
        let mut out = String::new();
        match ty {
            Ty::NewlineTripple => out.push_str("'''\n"),
            Ty::OnelineTripple => out.push_str("'''"),
            Ty::OnelineSingle => out.push('\''),
        }
        out.push_str(s);
        match ty {
            Ty::OnelineSingle => out.push('\''),
            _ => out.push_str("'''"),
        }
        return out;
    }
    // Std (basic-string)
    let mut out = String::new();
    match ty {
        Ty::NewlineTripple => out.push_str("\"\"\"\n"),
        _ => out.push('"'),
    }
    for ch in s.chars() {
        match ch {
            '\u{8}' => out.push_str("\\b"),
            '\u{9}' => out.push_str("\\t"),
            '\u{a}' => match ty {
                Ty::NewlineTripple => out.push('\n'),
                _ => out.push_str("\\n"),
            },
            '\u{c}' => out.push_str("\\f"),
            '\u{d}' => out.push_str("\\r"),
            '\u{22}' => out.push_str("\\\""),
            '\u{5c}' => out.push_str("\\\\"),
            c if (c as u32) < 0x1f => out.push_str(&format!("\\u{:04X}", c as u32)),
            ch => out.push(ch),
        }
    }
    match ty {
        Ty::NewlineTripple => out.push_str("\"\"\""),
        _ => out.push('"'),
    }
    out
}

fn format_string_array_inline(arr: &[String]) -> String {
    let items: Vec<String> = arr.iter().map(|s| toml_string_value(s)).collect();
    format!("[{}]", items.join(", "))
}

fn format_tags(tags: &[String]) -> String {
    if tags.len() == 1 {
        return format!("tags = [{}]\n", toml_string_value(&tags[0]));
    }
    let mut out = String::from("tags = [\n");
    for t in tags {
        out.push_str(&format!("    {},\n", toml_string_value(t)));
    }
    out.push_str("]\n");
    out
}

fn char_width(c: char) -> usize {
    let cp = c as u32;
    if cp == 0 {
        return 0;
    }
    if cp < 0x20 || (cp >= 0x7f && cp < 0xa0) {
        return 0;
    }
    let wide_ranges: &[(u32, u32)] = &[
        (0x1100, 0x115F),
        (0x2329, 0x232A),
        (0x2E80, 0x303E),
        (0x3041, 0x33FF),
        (0x3400, 0x4DBF),
        (0x4E00, 0x9FFF),
        (0xA000, 0xA4CF),
        (0xAC00, 0xD7A3),
        (0xF900, 0xFAFF),
        (0xFE30, 0xFE4F),
        (0xFF00, 0xFF60),
        (0xFFE0, 0xFFE6),
        (0x20000, 0x2FFFD),
        (0x30000, 0x3FFFD),
    ];
    for &(lo, hi) in wide_ranges {
        if cp >= lo && cp <= hi {
            return 2;
        }
    }
    let zero_ranges: &[(u32, u32)] = &[
        (0x0300, 0x036F),
        (0x0483, 0x0489),
        (0x0591, 0x05BD),
        (0x200B, 0x200F),
        (0x202A, 0x202E),
        (0xFE00, 0xFE0F),
        (0xFEFF, 0xFEFF),
    ];
    for &(lo, hi) in zero_ranges {
        if cp >= lo && cp <= hi {
            return 0;
        }
    }
    1
}

fn str_width(s: &str) -> usize {
    s.chars().map(char_width).sum()
}

fn render_table(headers: &[&str], rows: &[Vec<String>]) -> String {
    let ncols = headers.len();
    let mut cells: Vec<Vec<Vec<String>>> = Vec::with_capacity(rows.len());
    for r in rows {
        let mut row: Vec<Vec<String>> = Vec::with_capacity(ncols);
        for i in 0..ncols {
            let v = r.get(i).cloned().unwrap_or_default();
            let lines: Vec<String> = if v.is_empty() {
                vec![String::new()]
            } else {
                // Strip a single trailing newline before splitting so a trailing \n doesn't
                // produce a final empty row.
                let s = if v.ends_with('\n') { &v[..v.len()-1] } else { v.as_str() };
                s.split('\n').map(|x| x.to_string()).collect()
            };
            row.push(lines);
        }
        cells.push(row);
    }

    let mut widths: Vec<usize> = headers.iter().map(|h| str_width(h)).collect();
    for row in &cells {
        for (i, col) in row.iter().enumerate() {
            for line in col {
                let w = str_width(line);
                if w > widths[i] {
                    widths[i] = w;
                }
            }
        }
    }

    let sep = "⋮";
    let border_char = "≖";
    let mut total_width = ncols + 1;
    for w in &widths {
        total_width += w + 2;
    }
    let border_line: String = border_char.repeat(total_width);

    let render_row = |cells_row: &Vec<Vec<String>>| -> String {
        let max_lines = cells_row.iter().map(|c| c.len()).max().unwrap_or(1);
        let mut out = String::new();
        for li in 0..max_lines {
            out.push_str(sep);
            for (ci, col) in cells_row.iter().enumerate() {
                let line = col.get(li).map(|s| s.as_str()).unwrap_or("");
                let w = str_width(line);
                let pad = widths[ci].saturating_sub(w);
                out.push(' ');
                out.push_str(line);
                for _ in 0..pad {
                    out.push(' ');
                }
                out.push(' ');
                out.push_str(sep);
            }
            out.push('\n');
        }
        out
    };

    let header_row: Vec<Vec<String>> = headers.iter().map(|h| vec![h.to_string()]).collect();

    let mut out = String::new();
    out.push_str(&border_line);
    out.push('\n');
    out.push_str(&render_row(&header_row));
    out.push_str(&border_line);
    out.push('\n');
    for row in &cells {
        out.push_str(&render_row(row));
    }
    out.push_str(&border_line);
    out.push('\n');
    out
}

fn cmd_list(cfg: &Config, matches: &ArgMatches) {
    if cfg.scripts.is_empty() {
        die("No scripts exist. Would you like to add a new script?");
    }
    let list_aliases = matches.is_present("list_aliases");
    let cmd_full = matches.is_present("cmd_full");
    let cli_cmd_width = matches.value_of("cmd_width");
    let cfg_cmd_width = cfg.default.command_width;
    let filter_tags: Option<Vec<&str>> = matches.values_of("tag").map(|v| v.collect());

    let mut filtered: Vec<(&String, &Script)> = cfg
        .scripts
        .iter()
        .filter(|(_, sc)| {
            if let Some(ft) = &filter_tags {
                if let Some(st) = &sc.tags {
                    ft.iter().any(|t| st.iter().any(|s| s == t))
                } else {
                    false
                }
            } else {
                true
            }
        })
        .collect();
    filtered.sort_by(|a, b| a.0.cmp(b.0));

    if list_aliases {
        for (n, _) in &filtered {
            println!("{}", n);
        }
        return;
    }

    let cmd_width_apply: Option<usize> = if cmd_full {
        None
    } else if let Some(s) = cli_cmd_width {
        s.parse::<usize>().ok()
    } else {
        cfg_cmd_width
    };

    let headers = ["Alias", "Tags", "Command", "Description"];

    let mut rows: Vec<Vec<String>> = Vec::with_capacity(filtered.len());
    for (alias, sc) in &filtered {
        let tags_str = sc
            .tags
            .as_ref()
            .map(|t| t.join(","))
            .unwrap_or_default();
        let mut command = sc.command.clone();
        let desc = sc.description.clone().unwrap_or_default();
        if !cmd_full {
            let first_line = command.split('\n').next().unwrap_or("").to_string();
            command = if let Some(width) = cmd_width_apply {
                truncate_bytes(&first_line, width)
            } else {
                first_line
            };
        }
        rows.push(vec![alias.to_string(), tags_str, command, desc]);
    }

    let table = render_table(&headers, &rows);
    print!("{}", table);
}

fn truncate_bytes(s: &str, n: usize) -> String {
    if s.len() <= n {
        return s.to_string();
    }
    let mut end = n;
    while end > 0 && !s.is_char_boundary(end) {
        end -= 1;
    }
    s[..end].to_string()
}

fn cmd_add(cfg: &mut Config, matches: &ArgMatches, write_path: &Path) {
    let alias = matches.value_of("alias").unwrap().to_string();
    let description = matches.value_of("description").map(|s| s.to_string());
    let tags: Option<Vec<String>> = matches
        .values_of("tag")
        .map(|v| v.map(|s| s.to_string()).collect());
    let force = matches.is_present("force");

    if !force && cfg.scripts.contains_key(&alias) {
        die(&format!("AliasAlreadyExists:  {}", alias));
    }

    let command = match matches.value_of("command") {
        Some(c) => c.to_string(),
        None => prompt_editor("").unwrap_or_else(|e| die(&e)),
    };

    let script = Script {
        command,
        description,
        tags,
        alias: None,
        reference: None,
    };
    cfg.scripts.insert(alias.clone(), script);
    write_config_file(write_path, cfg);
    println!("Added {}", alias);
}

fn prompt_editor(initial: &str) -> Result<String, String> {
    let editor = env::var("EDITOR").unwrap_or_else(|_| "vi".to_string());
    let mut tmp = env::temp_dir();
    tmp.push(format!("pier-{}.sh", std::process::id()));
    if let Err(e) = fs::write(&tmp, initial) {
        return Err(format!("EditorError: Failed when trying to get input from editor {}", e));
    }
    let status = Command::new(&editor).arg(&tmp).status();
    match status {
        Ok(s) if s.success() => {
            let content = fs::read_to_string(&tmp).unwrap_or_default();
            let _ = fs::remove_file(&tmp);
            let trimmed = if content.ends_with('\n') {
                content[..content.len() - 1].to_string()
            } else {
                content
            };
            Ok(trimmed)
        }
        _ => {
            let _ = fs::remove_file(&tmp);
            Err(format!(
                "EditorError: Failed when trying to get input from editor Failed to open `{}` as a text editor or editor was terminated with errors.",
                editor
            ))
        }
    }
}

fn cmd_remove(cfg: &mut Config, matches: &ArgMatches, write_path: &Path) {
    if cfg.scripts.is_empty() {
        die("No scripts exist. Would you like to add a new script?");
    }
    let alias = matches.value_of("alias").unwrap().to_string();
    if !cfg.scripts.contains_key(&alias) {
        die(&format!("AliasNotFound: No script found by alias {}", alias));
    }
    cfg.scripts.remove(&alias);
    write_config_file(write_path, cfg);
    println!("Removed {}", alias);
}

fn cmd_show(cfg: &Config, matches: &ArgMatches) {
    if cfg.scripts.is_empty() {
        die("No scripts exist. Would you like to add a new script?");
    }
    let alias = matches.value_of("alias").unwrap();
    match cfg.scripts.get(alias) {
        Some(sc) => {
            println!("{}", sc.command);
        }
        None => die(&format!("AliasNotFound: No script found by alias {}", alias)),
    }
}

fn cmd_copy(cfg: &mut Config, matches: &ArgMatches, write_path: &Path) {
    let from = matches.value_of("from-alias").unwrap().to_string();
    let to = matches.value_of("to-alias").unwrap().to_string();
    if cfg.scripts.contains_key(&to) {
        die(&format!("AliasAlreadyExists:  {}", to));
    }
    let src = match cfg.scripts.get(&from) {
        Some(s) => s.clone(),
        None => die(&format!("AliasNotFound: No script found by alias {}", from)),
    };
    cfg.scripts.insert(to.clone(), src);
    write_config_file(write_path, cfg);
    println!("Copy from alias {} to new alias {}", from, to);
}

fn cmd_move(cfg: &mut Config, matches: &ArgMatches, write_path: &Path) {
    let from = matches.value_of("from-alias").unwrap().to_string();
    let to = matches.value_of("to-alias").unwrap().to_string();
    let force = matches.is_present("force");
    if !force && cfg.scripts.contains_key(&to) {
        die(&format!("AliasAlreadyExists:  {}", to));
    }
    let src = match cfg.scripts.get(&from) {
        Some(s) => s.clone(),
        None => die(&format!("AliasNotFound: No script found by alias {}", from)),
    };
    cfg.scripts.remove(&from);
    cfg.scripts.insert(to.clone(), src);
    write_config_file(write_path, cfg);
    println!("Move from alias {} to new alias {}", from, to);
}

fn cmd_run(cfg: &Config, alias: &str, args: Vec<&str>, verbose: bool) {
    if cfg.scripts.is_empty() {
        die("No scripts exist. Would you like to add a new script?");
    }
    let script = match cfg.scripts.get(alias) {
        Some(s) => s,
        None => die(&format!("AliasNotFound: No script found by alias {}", alias)),
    };

    let interpreter: Vec<String> = if let Some(ipr) = &cfg.default.interpreter {
        ipr.clone()
    } else {
        let shell = env::var("SHELL").unwrap_or_else(|_| "/bin/sh".to_string());
        vec![shell, "-c".to_string()]
    };

    if interpreter.is_empty() {
        die("Command execution failed with: No such file or directory (os error 2)");
    }

    if verbose {
        println!("Starting script \"{}\"", alias);
        println!("-------------------------");
        std::io::stdout().flush().ok();
    }

    let mut cmd = Command::new(&interpreter[0]);
    for arg in &interpreter[1..] {
        cmd.arg(arg);
    }
    cmd.arg(&script.command);
    cmd.arg(alias);
    for a in args {
        cmd.arg(a);
    }
    // Capture stderr so we can re-emit with a trailing newline to match pier's behavior.
    // Inherit stdout/stdin so they stream through unmodified.
    cmd.stderr(std::process::Stdio::piped());
    cmd.stdout(std::process::Stdio::inherit());
    cmd.stdin(std::process::Stdio::inherit());

    let child = match cmd.spawn() {
        Ok(c) => c,
        Err(e) => {
            if verbose {
                println!("-------------------------");
                println!("Script complete");
            }
            die(&format!("Command execution failed with: {}", e));
        }
    };

    let output = match child.wait_with_output() {
        Ok(o) => o,
        Err(e) => {
            if verbose {
                println!("-------------------------");
                println!("Script complete");
            }
            die(&format!("Command execution failed with: {}", e));
        }
    };
    let exit_code = output.status.code().unwrap_or(1);

    if !output.stderr.is_empty() {
        use std::io::Write;
        let stderr = std::io::stderr();
        let mut h = stderr.lock();
        let _ = h.write_all(&output.stderr);
        let _ = h.write_all(b"\n");
    }

    if verbose {
        println!("-------------------------");
        println!("Script complete");
    }
    std::process::exit(exit_code);
}

fn cmd_edit(cfg: &mut Config, matches: &ArgMatches, write_path: &Path) {
    let alias = matches.value_of("alias").unwrap().to_string();
    let mut script = match cfg.scripts.get(&alias) {
        Some(s) => s.clone(),
        None => die(&format!("AliasNotFound: No script found by alias {}", alias)),
    };
    let new_cmd = prompt_editor(&script.command).unwrap_or_else(|e| die(&e));
    script.command = new_cmd;
    cfg.scripts.insert(alias, script);
    write_config_file(write_path, cfg);
}

fn cmd_config_init() {
    let path = match default_config_write_path() {
        Some(p) => p,
        None => die("No default config file found. See help for more info."),
    };

    let example_script = Script {
        command: "echo Hello, Pier!".to_string(),
        description: Some("This is an example command.".to_string()),
        tags: None,
        alias: None,
        reference: None,
    };
    let mut cfg = Config::default();
    cfg.scripts.insert("hello-pier".to_string(), example_script);

    if let Some(parent) = path.parent() {
        if !parent.as_os_str().is_empty() && !parent.exists() {
            if let Err(e) = fs::create_dir(parent) {
                die(&format!("Failed to create directory. {}", e));
            }
        }
    }

    println!("Added hello-pier");
    let body = serialize_config(&cfg);
    if let Err(e) = fs::write(&path, body) {
        die(&format!("Unable to write config to {}: {}", path.display(), e));
    }
}

fn run_main() {
    let app = build_cli();
    let matches = app.get_matches();

    let cli_path = matches.value_of("config-file").map(|s| s.to_string());
    let verbose = matches.is_present("verbose");

    match matches.subcommand() {
        ("config-init", Some(_)) => {
            cmd_config_init();
        }
        ("add", Some(sub)) => {
            let path = resolve_config_path(cli_path.as_deref())
                .unwrap_or_else(|| die("No default config file found. See help for more info."));
            let mut cfg = read_config_file(&path);
            cmd_add(&mut cfg, sub, &path);
        }
        ("list", Some(sub)) => {
            let path = resolve_config_path(cli_path.as_deref())
                .unwrap_or_else(|| die("No default config file found. See help for more info."));
            let cfg = read_config_file(&path);
            cmd_list(&cfg, sub);
        }
        ("run", Some(sub)) => {
            let path = resolve_config_path(cli_path.as_deref())
                .unwrap_or_else(|| die("No default config file found. See help for more info."));
            let cfg = read_config_file(&path);
            let alias = sub.value_of("alias").unwrap();
            let args: Vec<&str> = sub.values_of("args").map(|v| v.collect()).unwrap_or_default();
            cmd_run(&cfg, alias, args, verbose);
        }
        ("remove", Some(sub)) => {
            let path = resolve_config_path(cli_path.as_deref())
                .unwrap_or_else(|| die("No default config file found. See help for more info."));
            let mut cfg = read_config_file(&path);
            cmd_remove(&mut cfg, sub, &path);
        }
        ("edit", Some(sub)) => {
            let path = resolve_config_path(cli_path.as_deref())
                .unwrap_or_else(|| die("No default config file found. See help for more info."));
            let mut cfg = read_config_file(&path);
            cmd_edit(&mut cfg, sub, &path);
        }
        ("show", Some(sub)) => {
            let path = resolve_config_path(cli_path.as_deref())
                .unwrap_or_else(|| die("No default config file found. See help for more info."));
            let cfg = read_config_file(&path);
            cmd_show(&cfg, sub);
        }
        ("copy", Some(sub)) => {
            let path = resolve_config_path(cli_path.as_deref())
                .unwrap_or_else(|| die("No default config file found. See help for more info."));
            let mut cfg = read_config_file(&path);
            cmd_copy(&mut cfg, sub, &path);
        }
        ("move", Some(sub)) => {
            let path = resolve_config_path(cli_path.as_deref())
                .unwrap_or_else(|| die("No default config file found. See help for more info."));
            let mut cfg = read_config_file(&path);
            cmd_move(&mut cfg, sub, &path);
        }
        _ => {
            if let Some(alias) = matches.value_of("alias") {
                let path = resolve_config_path(cli_path.as_deref())
                    .unwrap_or_else(|| die("No default config file found. See help for more info."));
                let cfg = read_config_file(&path);
                let args: Vec<&str> = matches.values_of("args").map(|v| v.collect()).unwrap_or_default();
                cmd_run(&cfg, alias, args, verbose);
            }
        }
    }
}

fn main() {
    run_main();
}
