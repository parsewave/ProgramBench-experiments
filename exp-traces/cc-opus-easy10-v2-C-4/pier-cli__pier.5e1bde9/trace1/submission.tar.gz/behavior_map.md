# Pier 0.1.6 behavior map (clean-room recovered)

## Binary identity
- `executable --version` → `pier 0.1.6\n`
- Authors: Benjamin Scholtz, Isak Johansson
- Description: A simple script management CLI
- TOML-based config; tracks named scripts (alias→command+description+tags).

## CLI structure (clap 2.x)
- Top level: `executable [FLAGS] [OPTIONS] <alias> [args]...` OR `executable [FLAGS] [OPTIONS] <SUBCOMMAND>`
- Global FLAGS: `-h/--help`, `-V/--version`, `-v/--verbose`
- Global OPTIONS: `-c/--config-file <path>` (env: PIER_CONFIG_PATH)
- Top positional: `<alias>` then `<args>...` (implicit run)

## Subcommands
- `add [-f] -a <alias> [-d <desc>] [-t <tag>...] [--] [command]` — open editor if command absent. Force overwrite with -f.
- `list` (alias `ls`) `[-l] [-q] [-c <cmd-width>] [-t <tag>...]`
  Priority: `-q` (only aliases) > `-l` (full cmd) > `-c` (cli truncate) > config `command_width`
- `run <alias> [args]...`
- `remove <alias>` (alias `rm`)
- `edit <alias>`
- `show <alias>`
- `copy <from> <to>` (alias `cp`)
- `move [-f] <from> <to>` (alias `mv`, `rename`)
- `config-init` (alias `init`)
- `help [subcmd]...`

## Config file resolution order
1. `--config-file <path>` / `PIER_CONFIG_PATH`
2. `./pier.toml`
3. `$XDG_CONFIG_HOME/pier/config.toml`
4. `$XDG_CONFIG_HOME/pier/config`
5. `$XDG_CONFIG_HOME/pier.toml`
6. `$HOME/.pier.toml`
7. `$HOME/.pier`

If none found and command other than `config-init` runs: `error: No default config file found. See help for more info.`

## Config file format

```toml
[scripts.<alias>]
command = '...'
description = '...'   # optional
tags = ['t1', 't2']   # optional

[default]
interpreter = ['/bin/sh', '-c']   # optional
command_width = 80                 # optional
```

- Scripts serialized in alphabetical order by alias.
- Field order: command, description, tags.
- `[default]` section is always emitted.
- TOML strings: `'literal'` by default; `'''multi-line'''` if value contains `'`; `"basic"` if contains `'''`.
- Single tag inline: `tags = ['x']`. Multiple tags multi-line with 4-space indent.
- Alias used as bare key when `[A-Za-z0-9_-]+`, else basic-quoted with `\n`, `\"` escapes.

## Errors (verbatim, all to stderr, exit code 1)
- `error: AliasAlreadyExists:  <alias>` (note double space)
- `error: AliasNotFound: No script found by alias <alias>`
- `error: No scripts exist. Would you like to add a new script?`
- `error: Unable to parse toml config from file <path>: <toml_error>`
- `error: Unable to read config from file <path>: <io_error>` (note trailing space)
- `error: Unable to write config to <path>: <io_error>` (when create_dir fails)
- `error: Failed to create directory. <io_error>` (config-init when dir missing)
- `error: Command execution failed with: <io_error>` (exec failure)
- `error: EditorError: Failed when trying to get input from editor Failed to open \`<editor>\` as a text editor or editor was terminated with errors.`
- `error: No default config file found. See help for more info.`

## Success messages (stdout)
- `Added <alias>`
- `Removed <alias>`
- `Copy from alias <from> to new alias <to>`
- `Move from alias <from> to new alias <to>`

## `show <alias>` → command bytes + `\n`

## `list` (table)
- Custom prettytable format:
  - Top, header-separator, bottom borders: line of `≖` (U+2256), length = total table width
  - Column separator: `⋮` (U+22EE), also at row start and end
  - Cell padding: 1 space each side
- Columns: Alias | Tags | Command | Description
- Tags shown comma-joined (no space).
- Sort: alphabetical (lexicographic) by alias.
- Multi-line cells: split into multiple rows; continuation rows blank other columns.
- Truncate command to `command_width` (cli or default) byte-wise.
- Empty filter (no scripts match) → still emits top/header/sep/bottom.
- No scripts at all → `error: No scripts exist. Would you like to add a new script?\n` (stderr) exit 1.

## `list -q` (aliases only)
- Each alias on a line, sorted alphabetically.

## `run`
- Invocation: `<interpreter[0]> <interpreter[1..]> <command> <alias> [args...]`
  - Default interpreter = `[$SHELL, "-c"]` if SHELL set, else `["/bin/sh", "-c"]`.
  - If `[default].interpreter` set in config, that's used instead.
- Stdin/stdout/stderr forwarded; exit code propagated.
- Verbose (`-v run` or `-v <alias>`):
  - stdout: `Starting script "<alias>"\n-------------------------\n` (25 dashes)
  - script's stdout/stderr
  - stdout: `-------------------------\nScript complete\n`

## `add` / `remove` / `copy` / `move`
- All trigger config rewrite (with canonical field order).
- `add` without `-f` errors if alias exists.
- `move` without `-f` errors if dest exists. With `-f` overwrites.
- `copy` always errors if dest exists.
- After rewrite, unrecognized fields are dropped (only command/description/tags kept).

## `config-init`
- Creates the default config with one example script:
  ```toml
  [scripts.hello-pier]
  command = 'echo Hello, Pier!'
  description = 'This is an example command.'

  [default]
  ```
- stdout: `Added hello-pier\n`
- If directory doesn't exist: `error: Failed to create directory. <err>` then `error: Unable to write config to <path>: <err>` (or similar).

## Shell invocation details
- Process: `executable` directly invokes shell (no intermediate).
- `<command>` is passed as the script string; `<alias>` becomes $0; positional args $1, $2...
- With interpreter `["/bin/bash", "-c"]`, command becomes shell -c string.

## Edge cases
- Empty alias `""` is accepted by add (writes `[scripts.]`) but corrupts config.
- Aliases starting with `-` allowed (just `-` alone, single-dash); `--` rejected (treated as missing value).
- Aliases with dots, spaces, quotes, newlines: quoted in TOML using basic-string.
- Multi-line command in show preserves embedded `\n`.
- Multi-line description in list spans multiple rows even without `-l`.
- CJK chars: visual width 2 (East Asian Wide). Table aligns by display width via unicode-width.
- Unrecognized fields silently dropped on rewrite.

## Misc
- `executable --` errors "required arguments not provided".
- `executable hello a b c` works as implicit run if `c` isn't a recognized subcommand prefix; clap may grab args as subcommand if they look like one.
- `executable -- <alias> <args>` always treats as alias+args.
