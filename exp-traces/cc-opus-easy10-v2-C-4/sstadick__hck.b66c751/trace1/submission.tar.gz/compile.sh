#!/bin/bash
set -e

cd "$(dirname "$0")"

export PATH=/usr/local/cargo/bin:$PATH
export CARGO_HOME=/usr/local/cargo

cargo build --offline --release

cp target/release/hck ./executable
chmod +x ./executable
