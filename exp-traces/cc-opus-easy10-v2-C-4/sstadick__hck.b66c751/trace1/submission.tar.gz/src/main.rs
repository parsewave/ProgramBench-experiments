use anyhow::{anyhow, Result};
use clap::Parser;
use regex::bytes::Regex as ByteRegex;
use std::fs::File;
use std::io::{self, BufRead, BufReader, BufWriter, Read, Write};
use std::path::PathBuf;

#[derive(Debug)]
enum HckError {
    // Errors that go through env_logger as ERROR hck
    Logged(String),
    // Errors that print as "Error: ..." (anyhow-style)
    Plain(String),
}

impl std::fmt::Display for HckError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            HckError::Logged(s) => write!(f, "{}", s),
            HckError::Plain(s) => write!(f, "{}", s),
        }
    }
}

impl std::error::Error for HckError {}

const LONG_ABOUT: &str = "* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

## Selection by headers

Instead of specifying fields to output by index ranges (i.e `1-2,4-`), you can specify a regex or string literal to select a headered column to output with the `-F` option. By default `-F` options are treated as string literals. To treat them as regexs add the `-r` flag.

## Ordering of outputs

*Values are written only once*. So for a `fields` value of `4-,1,5-8`, which translates to \"print columns 4 through the end and then the last column and then columns 5 through 8\", columns 5-8 won't be printed again because they were already consumed by the `4-` range.

If `field-headers` is used as a regex then the headers will be be grouped together in groups that all matched the same regex, and in the order of the regex as specified on the CLI.";

const SHORT_ABOUT: &str = "* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`";

#[derive(Parser, Debug)]
#[command(
    name = "hck",
    version = "git:23bebe8-modified",
    about = SHORT_ABOUT,
    long_about = LONG_ABOUT,
    disable_version_flag = false,
    disable_help_flag = false,
)]
struct Opts {
    /// Input files to parse, defaults to stdin.
    ///
    /// If a file has a recognizable file extension indicating that it is compressed, and a local binary to perform decompression is found, decompression will occur automagically. This requires with `-z`.
    #[arg(value_name = "INPUT")]
    inputs: Vec<PathBuf>,

    /// Output file to write to, defaults to stdout
    #[arg(short = 'o', long = "output", value_name = "OUTPUT")]
    output: Option<PathBuf>,

    /// Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag
    #[arg(
        short = 'd',
        long = "delimiter",
        value_name = "DELIMITER",
        default_value = "\\s+",
        allow_hyphen_values = true
    )]
    delimiter: String,

    /// Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
    #[arg(short = 'L', long = "delim-is-literal")]
    delim_is_literal: bool,

    /// Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
    #[arg(short = 'I', long = "use-input-delim")]
    use_input_delim: bool,

    /// Delimiter string to use on outputs
    #[arg(
        short = 'D',
        long = "output-delimiter",
        value_name = "OUTPUT_DELIMITER",
        default_value = "\t",
        allow_hyphen_values = true
    )]
    output_delimiter: String,

    /// Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
    #[arg(short = 'f', long = "fields", value_name = "FIELDS", allow_hyphen_values = true)]
    fields: Option<String>,

    /// Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`
    #[arg(short = 'e', long = "exclude", value_name = "EXCLUDE", allow_hyphen_values = true)]
    exclude: Option<String>,

    /// Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex
    #[arg(short = 'E', long = "exclude-header", value_name = "EXCLUDE_HEADER", allow_hyphen_values = true)]
    exclude_header: Vec<String>,

    /// A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex
    #[arg(short = 'F', long = "header-field", value_name = "HEADER_FIELD", allow_hyphen_values = true)]
    header_field: Vec<String>,

    /// Treat the header_fields as regexs instead of string literals
    #[arg(short = 'r', long = "header-is-regex")]
    header_is_regex: bool,

    /// Try to find the correct decompression method based on the file extensions
    #[arg(short = 'z', long = "try-decompress")]
    try_decompress: bool,

    /// Try to gzip compress the output
    #[arg(short = 'Z', long = "try-compress")]
    try_compress: bool,

    /// Threads to use for compression, 0 will result in `hck` staying single threaded
    #[arg(
        short = 't',
        long = "compression-threads",
        value_name = "COMPRESSION_THREADS",
        default_value = "4"
    )]
    compression_threads: u32,

    /// Compression level
    #[arg(
        short = 'l',
        long = "compression-level",
        value_name = "COMPRESSION_LEVEL",
        default_value = "6"
    )]
    compression_level: u32,

    /// Disallow the possibility of using mmap
    #[arg(long = "no-mmap")]
    no_mmap: bool,

    /// Support CRLF newlines
    #[arg(long = "crlf")]
    crlf: bool,
}

#[derive(Debug, Clone, Copy)]
struct FieldRange {
    start: usize, // 1-based
    end: usize,   // 1-based, inclusive; usize::MAX means open-ended
}

fn parse_field_ranges(s: &str) -> Result<Vec<FieldRange>, HckError> {
    let mut ranges = Vec::new();
    for part in s.split(',') {
        if let Some(dash_idx) = part.find('-') {
            let (a, b) = (&part[..dash_idx], &part[dash_idx + 1..]);
            if !a.is_empty() && !is_all_digits(a) {
                return Err(HckError::Logged(format!("Failed to parse field: {}", part)));
            }
            if !b.is_empty() && !is_all_digits(b) {
                return Err(HckError::Logged(format!("Failed to parse field: {}", part)));
            }
            let start: usize = if a.is_empty() {
                1
            } else {
                a.parse().map_err(|_| HckError::Logged(format!("Failed to parse field: {}", part)))?
            };
            let end: usize = if b.is_empty() {
                usize::MAX
            } else {
                b.parse().map_err(|_| HckError::Logged(format!("Failed to parse field: {}", part)))?
            };
            if start == 0 || (end != usize::MAX && end == 0) {
                return Err(HckError::Logged("Fields and positions are numbered from 1: 0".to_string()));
            }
            if end != usize::MAX && end < start {
                return Err(HckError::Logged(format!("High end of range less than low end of range: {}", part)));
            }
            ranges.push(FieldRange { start, end });
        } else {
            if !is_all_digits(part) {
                return Err(HckError::Logged(format!("Failed to parse field: {}", part)));
            }
            let v: usize = part.parse().map_err(|_| HckError::Logged(format!("Failed to parse field: {}", part)))?;
            if v == 0 {
                return Err(HckError::Logged("Fields and positions are numbered from 1: 0".to_string()));
            }
            ranges.push(FieldRange { start: v, end: v });
        }
    }
    Ok(ranges)
}

fn is_all_digits(s: &str) -> bool {
    !s.is_empty() && s.bytes().all(|b| b.is_ascii_digit())
}

/// Decode escape sequences like \n, \t, \0, \xHH, \\ in a delimiter string.
/// Returns bytes.
fn decode_escape_bytes(s: &str) -> Vec<u8> {
    let mut out = Vec::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\\' {
            if let Some(&nc) = chars.peek() {
                match nc {
                    'n' => { chars.next(); out.push(b'\n'); }
                    't' => { chars.next(); out.push(b'\t'); }
                    'r' => { chars.next(); out.push(b'\r'); }
                    '0' => { chars.next(); out.push(0u8); }
                    '\\' => { chars.next(); out.push(b'\\'); }
                    '\'' => { chars.next(); out.push(b'\''); }
                    '"' => { chars.next(); out.push(b'"'); }
                    'x' => {
                        chars.next();
                        let h1 = chars.next();
                        let h2 = chars.next();
                        if let (Some(h1), Some(h2)) = (h1, h2) {
                            let s2: String = [h1, h2].iter().collect();
                            if let Ok(v) = u8::from_str_radix(&s2, 16) {
                                out.push(v);
                            } else {
                                out.push(b'\\');
                                out.push(b'x');
                                for ch in s2.chars() {
                                    out.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes());
                                }
                            }
                        } else {
                            out.push(b'\\');
                            out.push(b'x');
                        }
                    }
                    _ => {
                        // Unknown escape: keep the backslash and the char
                        out.push(b'\\');
                    }
                }
            } else {
                out.push(b'\\');
            }
        } else {
            out.extend_from_slice(c.encode_utf8(&mut [0; 4]).as_bytes());
        }
    }
    out
}

/// Indicates whether output should be terminated with \r\n (CRLF) or \n
#[derive(Copy, Clone, Debug)]
enum LineEnding {
    Lf,
    Crlf,
}

enum Splitter {
    Literal(Vec<u8>),
    Regex(ByteRegex),
}

impl Splitter {
    fn split<'a>(&self, line: &'a [u8]) -> Vec<&'a [u8]> {
        match self {
            Splitter::Literal(d) => {
                if d.is_empty() {
                    // Default whitespace not handled here; assumed: split between every byte
                    let mut parts = Vec::with_capacity(line.len() + 2);
                    parts.push(&line[..0]);
                    for i in 0..line.len() {
                        parts.push(&line[i..i + 1]);
                    }
                    parts.push(&line[line.len()..]);
                    parts
                } else {
                    let mut parts = Vec::new();
                    let mut start = 0;
                    let dlen = d.len();
                    let mut i = 0;
                    while i + dlen <= line.len() {
                        if &line[i..i + dlen] == d.as_slice() {
                            parts.push(&line[start..i]);
                            i += dlen;
                            start = i;
                        } else {
                            i += 1;
                        }
                    }
                    parts.push(&line[start..]);
                    parts
                }
            }
            Splitter::Regex(re) => {
                // Use regex's split; but it requires byte regex
                let parts: Vec<&[u8]> = re.split(line).collect();
                parts
            }
        }
    }
}

fn make_splitter(s: &str, literal: bool) -> Result<Splitter, HckError> {
    if literal {
        Ok(Splitter::Literal(decode_escape_bytes(s)))
    } else {
        let decoded = decode_escape_bytes(s);
        let pat = String::from_utf8_lossy(&decoded).into_owned();
        let re = ByteRegex::new(&pat)
            .map_err(|e| HckError::Plain(format!("{}", e)))?;
        Ok(Splitter::Regex(re))
    }
}

/// Compute the list of 0-based field indices to output.
/// `num_fields` is the total fields in the current line.
fn compute_indices(
    ranges: &[FieldRange],
    excludes: &[FieldRange],
    num_fields: usize,
) -> Vec<usize> {
    let mut chosen = Vec::new();
    let mut seen = vec![false; num_fields];
    for r in ranges {
        let lo = r.start.saturating_sub(1);
        let hi_excl = if r.end == usize::MAX {
            num_fields
        } else {
            r.end.min(num_fields)
        };
        if lo >= num_fields {
            continue;
        }
        for i in lo..hi_excl {
            if !seen[i] {
                seen[i] = true;
                chosen.push(i);
            }
        }
    }
    // Apply excludes
    if !excludes.is_empty() {
        let mut excluded = vec![false; num_fields];
        for r in excludes {
            let lo = r.start.saturating_sub(1);
            let hi_excl = if r.end == usize::MAX {
                num_fields
            } else {
                r.end.min(num_fields)
            };
            if lo >= num_fields {
                continue;
            }
            for i in lo..hi_excl {
                excluded[i] = true;
            }
        }
        chosen.retain(|&i| !excluded[i]);
    }
    chosen
}

fn compute_default_indices(
    ranges: &[FieldRange],
    excludes: &[FieldRange],
    num_fields: usize,
) -> Vec<usize> {
    if ranges.is_empty() && excludes.is_empty() {
        return (0..num_fields).collect();
    }
    if ranges.is_empty() {
        let all = vec![FieldRange { start: 1, end: usize::MAX }];
        return compute_indices(&all, excludes, num_fields);
    }
    compute_indices(ranges, excludes, num_fields)
}

fn resolve_header_fields(
    headers: &[Vec<u8>],
    header_field: &[String],
    exclude_header: &[String],
    is_regex: bool,
) -> Result<(Vec<FieldRange>, Vec<FieldRange>), HckError> {
    let mut f_ranges: Vec<FieldRange> = Vec::new();
    let mut e_ranges: Vec<FieldRange> = Vec::new();
    let mut per_selector_match_counts: Vec<(String, usize)> = Vec::new();
    if !header_field.is_empty() {
        for pat in header_field {
            let mut matched = Vec::new();
            if is_regex {
                let re = ByteRegex::new(pat)
                    .map_err(|e| HckError::Plain(format!("{}", e)))?;
                for (i, h) in headers.iter().enumerate() {
                    if re.is_match(h) {
                        matched.push(i + 1);
                    }
                }
            } else {
                let pat_bytes = pat.as_bytes();
                for (i, h) in headers.iter().enumerate() {
                    if h == pat_bytes {
                        matched.push(i + 1);
                    }
                }
            }
            per_selector_match_counts.push((pat.clone(), matched.len()));
            for m in matched {
                f_ranges.push(FieldRange { start: m, end: m });
            }
        }
        if f_ranges.is_empty() {
            return Err(HckError::Logged("No headers matched".to_string()));
        }
        // If some -F selector had 0 matches but at least one had >0, error with first 0-match pattern.
        if let Some((pat, _)) = per_selector_match_counts.iter().find(|(_, n)| *n == 0) {
            return Err(HckError::Logged(format!("Header not found: {}", pat)));
        }
    }
    if !exclude_header.is_empty() {
        for pat in exclude_header {
            if is_regex {
                let re = ByteRegex::new(pat)
                    .map_err(|e| HckError::Plain(format!("{}", e)))?;
                for (i, h) in headers.iter().enumerate() {
                    if re.is_match(h) {
                        e_ranges.push(FieldRange { start: i + 1, end: i + 1 });
                    }
                }
            } else {
                let pat_bytes = pat.as_bytes();
                for (i, h) in headers.iter().enumerate() {
                    if h == pat_bytes {
                        e_ranges.push(FieldRange { start: i + 1, end: i + 1 });
                    }
                }
            }
        }
    }
    Ok((f_ranges, e_ranges))
}

fn parse_line<'a>(line: &'a [u8], splitter: &Splitter) -> Vec<&'a [u8]> {
    splitter.split(line)
}

struct ProcessConfig {
    output_delim: Vec<u8>,
    line_ending: LineEnding,
    // If headers will be processed, we have these ranges already resolved per-line basis
    fields: Vec<FieldRange>,
    excludes: Vec<FieldRange>,
    has_header_selectors: bool,
    header_field: Vec<String>,
    exclude_header: Vec<String>,
    header_is_regex: bool,
}

fn write_output_line<W: Write>(
    w: &mut W,
    parts: &[&[u8]],
    indices: &[usize],
    output_delim: &[u8],
    line_ending: LineEnding,
) -> io::Result<()> {
    for (i, &idx) in indices.iter().enumerate() {
        if i > 0 {
            w.write_all(output_delim)?;
        }
        if idx < parts.len() {
            w.write_all(parts[idx])?;
        }
    }
    match line_ending {
        LineEnding::Lf => w.write_all(b"\n")?,
        LineEnding::Crlf => w.write_all(b"\r\n")?,
    }
    Ok(())
}

fn process_reader<R: BufRead, W: Write>(
    reader: &mut R,
    writer: &mut W,
    splitter: &Splitter,
    cfg: &ProcessConfig,
    header_resolved: &mut Option<(Vec<FieldRange>, Vec<FieldRange>)>,
) -> Result<(), HckError> {
    let mut line_buf = Vec::new();
    let mut is_first_line = true;
    let crlf = matches!(cfg.line_ending, LineEnding::Crlf);
    // If headers are required and we have no input yet, try to resolve from empty
    let mut had_any_input = header_resolved.is_some();
    loop {
        line_buf.clear();
        let n = reader.read_until(b'\n', &mut line_buf)
            .map_err(|e| HckError::Logged(format!("{}", e)))?;
        if n == 0 {
            if !had_any_input && cfg.has_header_selectors && !cfg.header_field.is_empty() {
                // Reference produces "No headers matched" when there's no input but -F was given
                let (_f, _e) = resolve_header_fields(
                    &Vec::<Vec<u8>>::new(),
                    &cfg.header_field,
                    &cfg.exclude_header,
                    cfg.header_is_regex,
                )?;
            }
            break;
        }
        had_any_input = true;
        // Strip line ending
        let mut content_len = line_buf.len();
        if crlf {
            if content_len >= 2 && &line_buf[content_len - 2..content_len] == b"\r\n" {
                content_len -= 2;
            } else if content_len >= 1 && line_buf[content_len - 1] == b'\n' {
                // Treat as still-CRLF input but missing \r -- don't strip the \n
                // Actually based on observation, the \n is NOT stripped in CRLF mode if no \r before it.
                // Then split will create extra fields if there's trailing whitespace.
                // Mimicking observed behavior:
                // For consistent behavior, strip just the \n
                content_len -= 1;
                // BUT we need to keep the \n in the content so that splitting treats it as content
                // Actually re-reading observations: with --crlf, `a b c\n` -> `a\tb\tc\t\r\n` (4 fields).
                // That means line content was `a b c\n` (not stripping \n), which split by \s+ gives [a, b, c, ''].
                // So we should NOT strip the \n in this case. Let me revert.
                content_len += 1;
            }
        } else {
            if content_len >= 1 && line_buf[content_len - 1] == b'\n' {
                content_len -= 1;
            }
        }
        let content = &line_buf[..content_len];

        if is_first_line && cfg.has_header_selectors {
            is_first_line = false;
            let parts = parse_line(content, splitter);
            let headers: Vec<Vec<u8>> = parts.iter().map(|p| p.to_vec()).collect();
            let (mut f_from_header, e_from_header) = resolve_header_fields(
                &headers,
                &cfg.header_field,
                &cfg.exclude_header,
                cfg.header_is_regex,
            )?;
            // Combine -F (header-derived) and -f ranges.
            // If -f is empty, use -F in CLI order alone.
            // If both present, start with -f's order, then insert each -F at the first
            // position where current list element has greater start col.
            let mut combined: Vec<FieldRange> = if cfg.fields.is_empty() {
                f_from_header.clone()
            } else {
                let mut c = cfg.fields.clone();
                for fh in &f_from_header {
                    let target = fh.start;
                    let pos = c.iter().position(|r| r.start > target).unwrap_or(c.len());
                    c.insert(pos, *fh);
                }
                c
            };
            let _ = &mut combined;
            let mut combined_e: Vec<FieldRange> = cfg.excludes.clone();
            for e in &e_from_header {
                combined_e.push(*e);
            }
            *header_resolved = Some((combined, combined_e));
            let (ref f, ref e) = header_resolved.as_ref().unwrap();
            let indices = compute_default_indices(f, e, parts.len());
            write_output_line(writer, &parts, &indices, &cfg.output_delim, cfg.line_ending)
                .map_err(|e| HckError::Logged(format!("{}", e)))?;
            continue;
        }
        is_first_line = false;

        let parts = parse_line(content, splitter);
        let (ranges, excludes): (&[FieldRange], &[FieldRange]) =
            if let Some((f, e)) = header_resolved.as_ref() {
                (f.as_slice(), e.as_slice())
            } else {
                (cfg.fields.as_slice(), cfg.excludes.as_slice())
            };
        let indices = compute_default_indices(ranges, excludes, parts.len());
        write_output_line(writer, &parts, &indices, &cfg.output_delim, cfg.line_ending)
            .map_err(|e| HckError::Logged(format!("{}", e)))?;
    }
    Ok(())
}

fn open_input(path: &PathBuf, _try_decompress: bool) -> Result<Box<dyn BufRead>, HckError> {
    let f = File::open(path)
        .map_err(|e| HckError::Logged(format!("{}", e)))?;
    Ok(Box::new(BufReader::new(f)))
}

fn run() -> Result<(), HckError> {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("error"))
        .format(|buf, record| {
            let ts = jiff_like_timestamp();
            writeln!(buf, "[{} {} {}] {}", ts, record.level(), record.target(), record.args())
        })
        .init();

    let opts = Opts::parse();

    let splitter = make_splitter(&opts.delimiter, opts.delim_is_literal)?;

    // Compute output delimiter
    let mut output_delim_bytes: Vec<u8> = decode_escape_bytes(&opts.output_delimiter);
    // Handle -I: use input delim as output delim if -L and -D not explicitly set
    // Detecting "not explicitly set" is tricky with clap defaults; we'll approximate:
    if opts.use_input_delim && opts.delim_is_literal && opts.output_delimiter == "\t" {
        output_delim_bytes = decode_escape_bytes(&opts.delimiter);
    }

    // Parse field ranges
    let fields = if let Some(s) = &opts.fields {
        parse_field_ranges(s)?
    } else {
        Vec::new()
    };
    let excludes = if let Some(s) = &opts.exclude {
        parse_field_ranges(s)?
    } else {
        Vec::new()
    };

    let has_header_selectors = !opts.header_field.is_empty() || !opts.exclude_header.is_empty();

    let cfg = ProcessConfig {
        output_delim: output_delim_bytes,
        line_ending: if opts.crlf { LineEnding::Crlf } else { LineEnding::Lf },
        fields,
        excludes,
        has_header_selectors,
        header_field: opts.header_field.clone(),
        exclude_header: opts.exclude_header.clone(),
        header_is_regex: opts.header_is_regex,
    };

    let writer: Box<dyn Write> = if let Some(p) = &opts.output {
        let f = File::create(p).map_err(|e| HckError::Logged(format!("Failed to open {} for writing. {}", p.display(), e)))?;
        Box::new(BufWriter::new(f))
    } else {
        Box::new(BufWriter::new(io::stdout().lock()))
    };
    let mut writer = writer;

    // Process inputs. Each file (or stdin) re-resolves its own header from its first line.
    if opts.inputs.is_empty() {
        let stdin = io::stdin();
        let mut handle = BufReader::new(stdin.lock());
        let mut header_resolved: Option<(Vec<FieldRange>, Vec<FieldRange>)> = None;
        process_reader(&mut handle, &mut writer, &splitter, &cfg, &mut header_resolved)?;
    } else {
        for path in &opts.inputs {
            let mut header_resolved: Option<(Vec<FieldRange>, Vec<FieldRange>)> = None;
            if path.as_os_str() == "-" {
                let stdin = io::stdin();
                let mut handle = BufReader::new(stdin.lock());
                process_reader(&mut handle, &mut writer, &splitter, &cfg, &mut header_resolved)?;
            } else {
                let mut handle = open_input(path, opts.try_decompress)?;
                process_reader(&mut handle, &mut writer, &splitter, &cfg, &mut header_resolved)?;
            }
        }
    }

    writer.flush().map_err(|e| HckError::Logged(format!("{}", e)))?;
    Ok(())
}

fn jiff_like_timestamp() -> String {
    // Format like 2026-05-23T03:31:50Z (RFC3339 with Z suffix, no fractional)
    use std::time::SystemTime;
    let now = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).unwrap_or_default();
    let secs = now.as_secs();
    // Convert to UTC date/time without external lib
    let (y, mo, d, h, mi, s) = unix_to_utc(secs as i64);
    format!("{:04}-{:02}-{:02}T{:02}:{:02}:{:02}Z", y, mo, d, h, mi, s)
}

fn unix_to_utc(t: i64) -> (i32, u32, u32, u32, u32, u32) {
    // Simple proleptic Gregorian conversion (handles dates >= 1970-01-01)
    let mut days = t.div_euclid(86400);
    let secs_of_day = t.rem_euclid(86400) as u32;
    let h = secs_of_day / 3600;
    let mi = (secs_of_day % 3600) / 60;
    let s = secs_of_day % 60;
    // Compute year/month/day from days since 1970-01-01
    let mut year: i64 = 1970;
    loop {
        let days_in_year = if is_leap(year) { 366 } else { 365 };
        if days < days_in_year {
            break;
        }
        days -= days_in_year;
        year += 1;
    }
    // Now days is day-of-year (0-based)
    let month_days = if is_leap(year) {
        [31u32, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    } else {
        [31u32, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    };
    let mut month = 1u32;
    let mut day = days as u32;
    for &md in &month_days {
        if day < md {
            break;
        }
        day -= md;
        month += 1;
    }
    (year as i32, month, day + 1, h, mi, s)
}

fn is_leap(y: i64) -> bool {
    (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
}

fn main() {
    if let Err(e) = run() {
        match e {
            HckError::Logged(msg) => log::error!("{}", msg),
            HckError::Plain(msg) => eprintln!("Error: {}", msg),
        }
        std::process::exit(1);
    }
}
