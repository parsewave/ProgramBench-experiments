#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

export PATH=/usr/local/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin:$PATH

# Use a per-build CARGO_HOME populated from the system cache, since the
# system extracted source dirs aren't readable by the build user.
CARGO_HOME_LOCAL="$PWD/.cargo-home"
mkdir -p "$CARGO_HOME_LOCAL/registry/cache/index.crates.io-1949cf8c6b5b557f"
mkdir -p "$CARGO_HOME_LOCAL/registry/index"

# Copy crate archives (cheap) but only the first time.
if [ -z "$(ls -A "$CARGO_HOME_LOCAL/registry/cache/index.crates.io-1949cf8c6b5b557f" 2>/dev/null)" ]; then
  cp /usr/local/cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/*.crate \
     "$CARGO_HOME_LOCAL/registry/cache/index.crates.io-1949cf8c6b5b557f/"
fi
if [ ! -d "$CARGO_HOME_LOCAL/registry/index/index.crates.io-1949cf8c6b5b557f" ]; then
  cp -r /usr/local/cargo/registry/index/index.crates.io-1949cf8c6b5b557f \
     "$CARGO_HOME_LOCAL/registry/index/"
fi

export CARGO_HOME="$CARGO_HOME_LOCAL"
cargo build --release --offline

cp target/release/executable ./executable
