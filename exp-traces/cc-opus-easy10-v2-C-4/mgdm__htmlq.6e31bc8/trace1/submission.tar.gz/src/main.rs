use std::fs::File;
use std::io::{self, Read, Write};

use clap::{App, AppSettings, Arg};
use html5ever::tendril::TendrilSink;
use html5ever::tree_builder::TreeBuilderOpts;
use kuchiki::NodeRef;
use kuchiki::ParseOpts;
use url::Url;

fn main() {
    let matches = App::new("htmlq")
        .version("0.4.0")
        .author("Michael Maclean <michael@mgdm.net>")
        .about("Runs CSS selectors on HTML")
        .setting(AppSettings::TrailingVarArg)
        .arg(
            Arg::with_name("filename")
                .short("f")
                .long("filename")
                .takes_value(true)
                .value_name("FILE")
                .help("The input file. Defaults to stdin"),
        )
        .arg(
            Arg::with_name("output")
                .short("o")
                .long("output")
                .takes_value(true)
                .value_name("FILE")
                .help("The output file. Defaults to stdout"),
        )
        .arg(
            Arg::with_name("pretty")
                .short("p")
                .long("pretty")
                .help("Pretty-print the serialised output"),
        )
        .arg(
            Arg::with_name("text")
                .short("t")
                .long("text")
                .help("Output only the contents of text nodes inside selected elements"),
        )
        .arg(
            Arg::with_name("ignore_whitespace")
                .short("w")
                .long("ignore-whitespace")
                .help("When printing text nodes, ignore those that consist entirely of whitespace"),
        )
        .arg(
            Arg::with_name("attribute")
                .short("a")
                .long("attribute")
                .takes_value(true)
                .help("Only return this attribute (if present) from selected elements"),
        )
        .arg(
            Arg::with_name("base")
                .short("b")
                .long("base")
                .takes_value(true)
                .help("Use this URL as the base for links"),
        )
        .arg(
            Arg::with_name("detect_base")
                .short("B")
                .long("detect-base")
                .help("Try to detect the base URL from the <base> tag in the document. If not found, default to the value of --base, if supplied"),
        )
        .arg(
            Arg::with_name("remove_nodes")
                .short("r")
                .long("remove-nodes")
                .takes_value(true)
                .multiple(true)
                .number_of_values(1)
                .value_name("SELECTOR")
                .help("Remove nodes matching this expression before output. May be specified multiple times"),
        )
        .arg(
            Arg::with_name("selector")
                .multiple(true)
                .default_value("html")
                .help("The CSS expression to select"),
        )
        .get_matches();

    let input_path = matches.value_of("filename");
    let output_path = matches.value_of("output");
    let pretty = matches.is_present("pretty");
    let text_only = matches.is_present("text");
    let ignore_whitespace = matches.is_present("ignore_whitespace");
    let attribute = matches.value_of("attribute");
    let base = matches.value_of("base");
    let detect_base = matches.is_present("detect_base");
    let remove_nodes: Vec<&str> = matches
        .values_of("remove_nodes")
        .map(|v| v.collect())
        .unwrap_or_default();
    let selectors: Vec<&str> = matches
        .values_of("selector")
        .map(|v| v.collect())
        .unwrap_or_default();
    let selector = selectors.join(" ");

    let mut input = String::new();
    if let Some(path) = input_path {
        if path == "-" {
            io::stdin().read_to_string(&mut input).unwrap();
        } else {
            let mut file =
                File::open(path).expect("should have opened input file");
            file.read_to_string(&mut input).unwrap();
        }
    } else {
        io::stdin().read_to_string(&mut input).unwrap();
    }

    let mut output_writer: Box<dyn Write> = if let Some(path) = output_path {
        Box::new(File::create(path).expect("should have created output file"))
    } else {
        Box::new(io::stdout())
    };

    let parser = kuchiki::parse_html_with_options(ParseOpts {
        tree_builder: TreeBuilderOpts {
            drop_doctype: true,
            ..Default::default()
        },
        ..Default::default()
    });
    let document = parser.one(input);

    let base_url = resolve_base_url(&document, detect_base, base);

    let css = selector.as_str();
    let _ = kuchiki::Selectors::compile(css).expect("Failed to parse CSS selector");

    let mut output_buf: Vec<u8> = Vec::new();

    'outer: for css_match in document.select(css).unwrap() {
        for r in &remove_nodes {
            if let Ok(selected) = css_match.as_node().select(r) {
                for n in selected {
                    n.as_node().detach();
                    break 'outer;
                }
            }
        }
        let node = css_match.as_node();
        emit_match(
            node,
            &mut output_buf,
            attribute,
            text_only,
            ignore_whitespace,
            pretty,
            base_url.as_ref(),
        );
    }

    output_writer.write_all(&output_buf).unwrap();
}

fn resolve_base_url(document: &NodeRef, detect_base: bool, base: Option<&str>) -> Option<Url> {
    if detect_base {
        if let Ok(b) = document.select_first("base") {
            let attrs = b.attributes.borrow();
            if let Some(href) = attrs.get("href") {
                if let Ok(u) = Url::parse(href) {
                    return Some(u);
                }
            }
        }
    }
    if let Some(b) = base {
        if let Ok(u) = Url::parse(b) {
            return Some(u);
        }
    }
    None
}

fn emit_match(
    node: &NodeRef,
    out: &mut Vec<u8>,
    attribute: Option<&str>,
    text_only: bool,
    ignore_whitespace: bool,
    pretty: bool,
    base_url: Option<&Url>,
) {
    if let Some(base) = base_url {
        rewrite_base_urls(node, base);
    }

    if let Some(attr) = attribute {
        if let Some(elem) = node.as_element() {
            if let Some(v) = elem.attributes.borrow().get(attr) {
                out.extend_from_slice(v.as_bytes());
                out.push(b'\n');
            }
        }
        return;
    }

    if text_only {
        if ignore_whitespace {
            for n in node.inclusive_descendants() {
                if let Some(t) = n.as_text() {
                    let s = t.borrow();
                    if !s.chars().all(|c| c.is_whitespace()) {
                        out.extend_from_slice(s.as_bytes());
                        out.push(b'\n');
                    }
                }
            }
            out.push(b'\n');
        } else {
            for n in node.inclusive_descendants() {
                if let Some(t) = n.as_text() {
                    out.extend_from_slice(t.borrow().as_bytes());
                }
            }
            out.push(b'\n');
        }
        return;
    }

    if pretty {
        pretty_print(node, out, 0);
        out.push(b'\n');
        return;
    }

    node.serialize(out).unwrap();
    out.push(b'\n');
}

fn rewrite_base_urls(node: &NodeRef, base: &Url) {
    for n in node.inclusive_descendants() {
        if let Some(elem) = n.as_element() {
            let name = elem.name.local.as_ref();
            if matches!(name, "a" | "area" | "link") {
                let mut attrs = elem.attributes.borrow_mut();
                if let Some(href) = attrs.get("href").map(|s| s.to_string()) {
                    if let Ok(joined) = base.join(&href) {
                        attrs.insert("href", joined.to_string());
                    }
                }
            }
        }
    }
}

fn pretty_print(node: &NodeRef, out: &mut Vec<u8>, depth: usize) {
    if let Some(elem) = node.as_element() {
        let name = elem.name.local.as_ref();

        if depth > 0 && is_inline(name) {
            // Inline element nested under a block: serialize raw.
            node.serialize(out).unwrap();
            return;
        }

        let indent_unit = "  ";
        let indent = indent_unit.repeat(depth);

        out.push(b'\n');
        out.extend_from_slice(indent.as_bytes());
        write_open_tag(out, name, &elem.attributes.borrow());

        let is_top = depth == 0;

        for c in node.children() {
            if let Some(t) = c.as_text() {
                if is_top {
                    out.extend_from_slice(t.borrow().as_bytes());
                } else {
                    let inner = indent_unit.repeat(depth + 1);
                    out.push(b'\n');
                    out.extend_from_slice(inner.as_bytes());
                    out.extend_from_slice(t.borrow().as_bytes());
                }
            } else if let Some(_) = c.as_element() {
                if is_top && is_inline(c.as_element().unwrap().name.local.as_ref()) {
                    c.serialize(out).unwrap();
                } else {
                    pretty_print(&c, out, depth + 1);
                }
            }
        }

        if is_void(name) {
            return;
        }

        out.push(b'\n');
        out.extend_from_slice(indent.as_bytes());
        out.extend_from_slice(b"</");
        out.extend_from_slice(name.as_bytes());
        out.push(b'>');
    } else if let Some(t) = node.as_text() {
        let indent_unit = "  ";
        let indent = indent_unit.repeat(depth);
        out.push(b'\n');
        out.extend_from_slice(indent.as_bytes());
        out.extend_from_slice(t.borrow().as_bytes());
    }
}

fn write_open_tag(out: &mut Vec<u8>, name: &str, attrs: &kuchiki::Attributes) {
    out.push(b'<');
    out.extend_from_slice(name.as_bytes());
    for (qname, attr) in attrs.map.iter() {
        out.push(b' ');
        out.extend_from_slice(qname.local.as_ref().as_bytes());
        out.push(b'=');
        out.push(b'"');
        for c in attr.value.chars() {
            match c {
                '&' => out.extend_from_slice(b"&amp;"),
                '"' => out.extend_from_slice(b"&quot;"),
                '\u{a0}' => out.extend_from_slice(b"&nbsp;"),
                _ => {
                    let mut buf = [0; 4];
                    out.extend_from_slice(c.encode_utf8(&mut buf).as_bytes());
                }
            }
        }
        out.push(b'"');
    }
    out.push(b'>');
}

fn is_inline(name: &str) -> bool {
    matches!(
        name,
        "a" | "abbr"
            | "b"
            | "bdi"
            | "bdo"
            | "br"
            | "cite"
            | "code"
            | "data"
            | "dfn"
            | "em"
            | "i"
            | "kbd"
            | "mark"
            | "q"
            | "ruby"
            | "rp"
            | "rt"
            | "s"
            | "samp"
            | "small"
            | "span"
            | "strong"
            | "sub"
            | "sup"
            | "time"
            | "u"
            | "var"
            | "wbr"
    )
}

fn is_void(name: &str) -> bool {
    matches!(
        name,
        "area" | "base" | "br" | "col" | "embed" | "hr" | "img" | "input"
            | "link" | "meta" | "param" | "source" | "track" | "wbr"
    )
}
