#!/usr/bin/env bash
set -u
REF=/workspace/executable
SUT=/work/work/executable
PASS=0
FAIL=0

run_case() {
    local name="$1"
    local input="$2"
    shift 2
    local args=("$@")
    local ref_out ref_err ref_code sut_out sut_err sut_code
    ref_out=$(mktemp); ref_err=$(mktemp)
    sut_out=$(mktemp); sut_err=$(mktemp)
    printf '%s' "$input" | timeout 5 "$REF" "${args[@]}" >"$ref_out" 2>"$ref_err"
    ref_code=$?
    printf '%s' "$input" | timeout 5 "$SUT" "${args[@]}" >"$sut_out" 2>"$sut_err"
    sut_code=$?
    local out_match=0 err_match=0 code_match=0
    cmp -s "$ref_out" "$sut_out" && out_match=1
    [ "$ref_code" = "$sut_code" ] && code_match=1
    if [ "$ref_code" = "101" ] && [ "$sut_code" = "101" ]; then
        err_match=1
    else
        cmp -s "$ref_err" "$sut_err" && err_match=1
    fi
    if [ $out_match -eq 1 ] && [ $code_match -eq 1 ] && [ $err_match -eq 1 ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        echo "FAIL: $name"
        echo "  args: ${args[*]}"
        echo "  ref code: $ref_code, sut code: $sut_code"
        if [ $out_match -eq 0 ]; then
            echo "  ref:"
            cat -A "$ref_out" | head -10 | sed 's/^/    /'
            echo "  sut:"
            cat -A "$sut_out" | head -10 | sed 's/^/    /'
        fi
        if [ $err_match -eq 0 ]; then
            echo "  ref err:"; cat "$ref_err" | head -1 | sed 's/^/    /'
            echo "  sut err:"; cat "$sut_err" | head -1 | sed 's/^/    /'
        fi
    fi
    rm -f "$ref_out" "$ref_err" "$sut_out" "$sut_err"
}

# Pretty edge cases
run_case "p span pretty" "<p><span>x</span></p>" -p p
run_case "p inline div pretty" "<p>hello<span>x</span>after</p>" -p p
run_case "p empty pretty" "<p></p>" -p p
run_case "div span pretty" "<div><span>x</span></div>" -p div
run_case "div p text pretty" "<div><p>x</p></div>" -p div
run_case "deep nested pretty" "<div><div><div><p>x</p></div></div></div>" -p
run_case "void br pretty" "<p>a<br>b</p>" -p p
run_case "many siblings pretty" "<div><p>a</p><p>b</p><p>c</p></div>" -p div

# Remove nodes - reproduce weird bug behavior
run_case "r descendant" "<div><p>x</p></div>" -r p -- div
run_case "r non-descendant" "<head><meta></head><body><div><p>x</p></div></body>" -r meta -- div
run_case "r first match removes whole output" "<div><p>1</p></div><div><span>2</span></div>" -r p -- div
run_case "r in second match" "<div><span>1</span></div><div><p>2</p></div>" -r p -- div
run_case "r where * matches all" "<html><body><p>X</p></body></html>" -r '*' -- body
run_case "r body where body is main" "<html><body><p>X</p></body></html>" -r p -- body

# Various selectors
run_case "complex chained" '<div class="a"><div class="b">X</div></div>' '.a .b'
run_case ":nth-child" '<ul><li>1</li><li>2</li><li>3</li></ul>' 'li:nth-child(2)'
run_case "selector with star" '<div><p>x</p></div>' '*'
run_case "comma list multi" '<a>1</a><b>2</b><c>3</c>' 'a, b, c'

# Special characters
run_case "tab in text" $'<p>a\tb</p>' -t p
run_case "Form feed in text" $'<p>a\x0Cb</p>' -t p
run_case "high unicode" $'<p>\xe6\xbc\xa2\xe5\xad\x97</p>' -t p
run_case "emoji" $'<p>\xf0\x9f\x98\x80</p>' -t p

# Complex documents
run_case "html5 doc" '<!DOCTYPE html><html lang="en"><head><title>T</title></head><body><h1>H</h1></body></html>'
run_case "form" '<form action="/x"><input type=text name=a></form>' input
run_case "img with alt" '<img src=x alt="My img">' -a alt img
run_case "img with empty alt" '<img src=x alt="">' -a alt img

# Many matches
run_case "many p" '<p>1</p><p>2</p><p>3</p><p>4</p><p>5</p>' p
run_case "many p text" '<p>1</p><p>2</p><p>3</p>' -t p
run_case "many p text -w" '<p>  </p><p>x</p><p>  </p><p>y</p>' -tw p
run_case "many a href" '<a href=1>a</a><a href=2>b</a><a href=3>c</a>' -a href a

# Edge HTML cases
run_case "table implicit tbody" '<table><tr><td>x</td></tr></table>' tbody
run_case "p with implicit close" '<p>1<div>2</div>3</p>' p

# Empty cases
run_case "empty stdin" "" -t p

echo "Results: PASS=$PASS FAIL=$FAIL"
