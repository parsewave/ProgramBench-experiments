#!/usr/bin/env bash
# Differential test: run an array of cases against ref and sut.

set -u
REF=/workspace/executable
SUT=/work/work/executable
PASS=0
FAIL=0

run_case() {
    local name="$1"
    local input="$2"
    shift 2
    local args=("$@")

    local ref_out ref_err ref_code sut_out sut_err sut_code
    ref_out=$(mktemp); ref_err=$(mktemp)
    sut_out=$(mktemp); sut_err=$(mktemp)

    printf '%s' "$input" | timeout 5 "$REF" "${args[@]}" >"$ref_out" 2>"$ref_err"
    ref_code=$?
    printf '%s' "$input" | timeout 5 "$SUT" "${args[@]}" >"$sut_out" 2>"$sut_err"
    sut_code=$?

    local out_match=0 err_match=0 code_match=0
    cmp -s "$ref_out" "$sut_out" && out_match=1
    [ "$ref_code" = "$sut_code" ] && code_match=1
    if [ "$ref_code" = "101" ] && [ "$sut_code" = "101" ]; then
        err_match=1
    else
        cmp -s "$ref_err" "$sut_err" && err_match=1
    fi

    if [ $out_match -eq 1 ] && [ $code_match -eq 1 ] && [ $err_match -eq 1 ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        echo "FAIL: $name (out=$out_match code=$code_match err=$err_match)"
        echo "  args: ${args[*]}"
        echo "  ref code: $ref_code, sut code: $sut_code"
        if [ $out_match -eq 0 ]; then
            echo "  --- ref out ---"; cat -A "$ref_out" | head -3 | sed 's/^/  /'
            echo "  --- sut out ---"; cat -A "$sut_out" | head -3 | sed 's/^/  /'
        fi
        if [ $err_match -eq 0 ]; then
            echo "  ref err:"; cat "$ref_err" | head -2 | sed 's/^/    /'
            echo "  sut err:"; cat "$sut_err" | head -2 | sed 's/^/    /'
        fi
    fi

    rm -f "$ref_out" "$ref_err" "$sut_out" "$sut_err"
}

# Basic cases
run_case "default html on empty" ""
run_case "default html on simple" "<p>hi</p>"
run_case "simple p selector" "<p>hi</p>" p
run_case "ID selector" '<p id="x">hi</p>' "#x"
run_case "class selector" '<p class="x">hi</p>' ".x"
run_case "multi positional" "<div><p>p</p></div>" div p
run_case "comma union" "<p>1</p><span>2</span>" "p, span"

# Text mode
run_case "text mode basic" "<p>hello world</p>" -t p
run_case "text -w mixed" "<p>  </p><p>hi</p>" -tw p
run_case "text nested" "<div>a<p>b</p>c</div>" -t div
run_case "text -w nested" "<div>  <p>x</p>  </div>" -tw div

# Attribute mode
run_case "-a href" '<a href="x.html">L</a>' -a href a
run_case "-a missing" '<a>L</a>' -a href a

# Pretty
run_case "pretty simple" "<p>hi</p>" -p p
run_case "pretty html" "<html><body><p>hi</p></body></html>" -p

# Base URL
run_case "base url" '<a href="x">L</a>' -b "https://e.com/" a
run_case "detect base" '<base href="https://d.com/"><a href="x">L</a>' -B a
run_case "base+a" '<a href="x">L</a>' -b "https://e.com/" -a href a

# Remove nodes
run_case "remove inside main" '<div><p>x</p></div>' -r p -- div
run_case "remove outside main" '<head><meta></head><body><p>x</p></body>' -r meta -- body
run_case "remove nothing" '<div><p>x</p></div>' -r ".nope" -- div
run_case "remove multiple" '<div><p>1</p><span>2</span></div>' -r p -r span -- div

# Errors
run_case "bad selector" "<p>x</p>" "a,"
run_case "empty selector" "<p>x</p>" ""
run_case "double dash only" "<p>x</p>" --
run_case "default selector empty input" ""

# Special inputs
run_case "BOM" $'\xef\xbb\xbf<p>x</p>'
run_case "CRLF" $'<p>x</p>\r\n'
run_case "UTF-8" "<p>héllo</p>" -t p
run_case "entities" "<p>&amp;&lt;&gt;</p>" -t p
run_case "void elements" "<br><hr><img src=x>"

# Help/version
run_case "help" "" --help
run_case "version" "" --version

# Comments and doctype
run_case "doctype" "<!DOCTYPE html><p>x</p>"
run_case "comment top" "<!-- comment --><p>x</p>"
run_case "comment in body" "<html><body><p>x</p><!-- foo --></body></html>"

# More extensive tests
run_case "tw with deeply nested" "<div><p>1<span>x</span>2</p></div>" -tw div
run_case "text with multiple text nodes" "<p>a<i>b</i>c<i>d</i>e</p>" -t p
run_case "attribute selector eq" '<a href="x">L</a>' '[href]'
run_case "complex selector" '<div class="a b"><p>X</p></div>' '.a > p'
run_case "pseudo selector" '<p>1</p><p>2</p>' 'p:first-child'
run_case "attr selector with value" '<a href="/x">L</a>' 'a[href="/x"]'

# Edge cases for -t
run_case "t with comments inside" "<p>before<!--c-->after</p>" -t p
run_case "t -w with comments" "<p>before<!--c-->after</p>" -tw p

# Mixed -t -p (text takes priority)
run_case "t and p flags" "<p>x</p>" -tp p

# -r various
run_case "r with comma selector" "<div><p>1</p><span>2</span></div>" -r "p, span" -- div
run_case "r matching multiple" "<div><b>1</b><b>2</b></div>" -r b -- div

# attribute with empty value
run_case "empty attribute value" '<a href="">L</a>' -a href a

# -B and -b combined
run_case "B with no base tag has -b fallback" '<a href="x">L</a>' -B -b 'https://e.com/' a
run_case "B with base tag overrides -b" '<base href="https://from-tag.com/"><a href="x">L</a>' -B -b 'https://fallback.com/' a

# Special CSS
run_case "wildcard" '<p>x</p>' '*'
run_case "descendant selector explicit" '<div><p>x</p></div>' 'div p'
run_case "child selector" '<div><p>x</p><span><p>y</p></span></div>' 'div > p'

# attribute output
run_case "attribute with newline" $'<a title="line1\nline2">L</a>' -a title a

echo ""
echo "================================"
echo "Results: PASS=$PASS FAIL=$FAIL"
echo "================================"
