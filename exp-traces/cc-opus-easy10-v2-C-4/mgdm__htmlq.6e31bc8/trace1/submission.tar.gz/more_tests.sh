#!/usr/bin/env bash
set -u
REF=/workspace/executable
SUT=/work/work/executable
PASS=0
FAIL=0

run_case() {
    local name="$1"
    local input="$2"
    shift 2
    local args=("$@")
    local ref_out ref_err ref_code sut_out sut_err sut_code
    ref_out=$(mktemp); ref_err=$(mktemp)
    sut_out=$(mktemp); sut_err=$(mktemp)
    printf '%s' "$input" | timeout 5 "$REF" "${args[@]}" >"$ref_out" 2>"$ref_err"
    ref_code=$?
    printf '%s' "$input" | timeout 5 "$SUT" "${args[@]}" >"$sut_out" 2>"$sut_err"
    sut_code=$?
    local out_match=0 err_match=0 code_match=0
    cmp -s "$ref_out" "$sut_out" && out_match=1
    [ "$ref_code" = "$sut_code" ] && code_match=1
    if [ "$ref_code" = "101" ] && [ "$sut_code" = "101" ]; then
        err_match=1
    else
        cmp -s "$ref_err" "$sut_err" && err_match=1
    fi
    if [ $out_match -eq 1 ] && [ $code_match -eq 1 ] && [ $err_match -eq 1 ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        echo "FAIL: $name"
        echo "  args: ${args[*]}"
        echo "  ref code: $ref_code, sut code: $sut_code"
        if [ $out_match -eq 0 ]; then
            echo "  ref out: $(cat -A "$ref_out" | head -2 | tr '\n' ' ')"
            echo "  sut out: $(cat -A "$sut_out" | head -2 | tr '\n' ' ')"
        fi
        if [ $err_match -eq 0 ]; then
            echo "  ref err: $(cat "$ref_err" | head -1)"
            echo "  sut err: $(cat "$sut_err" | head -1)"
        fi
    fi
    rm -f "$ref_out" "$ref_err" "$sut_out" "$sut_err"
}

# More text mode
run_case "t empty element" "<p></p>" -t p
run_case "t with newlines" $'<p>line1\nline2</p>' -t p
run_case "tw with newlines" $'<p>line1\nline2</p>' -tw p
run_case "t script content" '<script>var x = 1;</script>' -t script
run_case "t multiple matches text" '<p>1</p><div><p>2</p></div>' -t p

# Attribute mode
run_case "a id" '<p id="x">y</p>' -a id p
run_case "a class" '<p class="a b">y</p>' -a class p
run_case "a data-x" '<p data-foo="bar">y</p>' -a data-foo p
run_case "a no match" '<p>x</p>' -a href p

# Output to file (use temp)
TMPFILE=$(mktemp)
run_case "output to file" "<p>x</p>" -o "$TMPFILE" p
rm -f "$TMPFILE"

# Input from file
TMPIN=$(mktemp)
printf '<p>filecontent</p>' > "$TMPIN"
run_case "input from file" "" -f "$TMPIN" p
rm -f "$TMPIN"

# -B detection edge cases
run_case "B no base no fallback" '<a href="x">L</a>' -B a
run_case "B invalid base" '<base href="not a url"><a href="x">L</a>' -B a

# More CSS
run_case "or selector" '<p>1</p><div>2</div>' 'p, div'
run_case "no match" '<p>x</p>' 'nonexistent'

# More html
run_case "table" '<table><tr><td>x</td></tr></table>' td
run_case "nested div" '<div><div><div>x</div></div></div>' 'div div div'

# Edge errors
run_case "unknown short flag" "" -X
run_case "value missing for -a" "" -a
run_case "value missing for -f" "" -f
run_case "value missing for -o" "" -o
run_case "value missing for -b" "" -b
run_case "value missing for -r" "" -r

# Long option forms
run_case "long --text" "<p>x</p>" --text p
run_case "long --attribute" '<a href="x">L</a>' --attribute href a
run_case "long --pretty" '<p>x</p>' --pretty p

echo "================================"
echo "Results: PASS=$PASS FAIL=$FAIL"
echo "================================"
