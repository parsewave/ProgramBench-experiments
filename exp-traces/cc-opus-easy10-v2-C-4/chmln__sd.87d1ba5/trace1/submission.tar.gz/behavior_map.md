# sd reimplementation behavior map

Reference: `sd` v1.0.0 - search/replace CLI in Rust using `regex` + `clap` + `memmap2`.

## CLI shape
```
USAGE: sd [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

  -p, --preview            stdout-only mode
  -F, --fixed-strings      treat FIND/REPLACE as literal
  -n, --max-replacements <LIMIT>  0 = unlimited (default 0)
  -f, --flags <FLAGS>      combined regex flags
  -h, --help
  -V, --version
```

Help title: `sd v1.0.0`. Version output: `sd 1.0.0\n`.
Usage line uses argv[0] basename (so `executable` for us).

## Flags string semantics
Iterate the chars, but the rules are:
- `i` → case_insensitive(true)
- `c` → case_insensitive(false)
- `s` → dot_matches_new_line(true)
- `w` → wrap pattern as `\bPATTERN\b`
- `m` → set multi_line(true)
- `e` → set multi_line(false)
- unknown chars → ignored

Multi-line default ON, but the *natural code path* gives:
- ML stays ON unless one of `e`, `w`, or `s` (without `m`) appears.
- Specifically: ml=true; if `s` in flags AND `m` NOT in flags → ml=false; if `w` in flags → ml=false; if `e` in flags → ml=false.

Observed truth table verified for {i,c,m,e,s,w} singletons, all 2-char, and `mm/ee` repeats.

Last write wins for `i`/`c` (e.g. `ic`→case-sensitive, `ci`→case-insensitive).

## Regex behavior
- Engine: Rust regex 1.x with `regex::bytes::Regex` (operates on `&[u8]`).
- Default multi-line ON in sd (unlike Rust regex default OFF).
- Inline flags `(?...)` accepted (regex crate syntax).
- Lookaround, backreferences NOT supported (regex crate limitation).
- Bytes outside valid UTF-8 pass through unchanged.

### Replacement string syntax (when NOT -F)
- `$N` (N is a number) → group N. If next char is `[A-Za-z_]`, **error**.
- `$NN` (multiple digits) → group NN (digits extend number).
- `${N}` / `${name}` → unambiguous group ref.
- `$name` → group `name` (consumed while next chars are word chars).
- `$$` → literal `$`.
- Bare `$` not followed by digit/letter/_/`{` → literal `$`.
- `\\n` → newline byte (0x0A)
- `\\r` → CR (0x0D)
- `\\t` → tab (0x09)
- `\\xNN` → Unicode codepoint U+00NN, UTF-8 encoded
- `\\\\` → literal `\`
- Other `\\X` → literal two chars (`\` + `X`).

### Ambiguous capture group error format:
```
error: The numbered capture group `$N` in the replacement text is ambiguous.
hint: Use curly braces to disambiguate it `${N}rest`.
[full replacement with control chars visualized]
[caret line aligned to N + identifier chars]
```
Control chars in the diagnostic line are replaced with Unicode "control pictures":
- `\n` (0x0A) → `\xe2\x90\x8a` (U+240A)
- `\t` (0x09) → `\xe2\x90\x89` (U+2409)

### Fixed-strings mode (-F)
- Pattern: literal (escape regex meta chars)
- Replacement: literal (no `$N`, no `\\n` escapes - everything literal)
- `-f w` with `-F`: pattern is escaped THEN wrapped with `\b`s.

## I/O behavior
- No files → read stdin, write to stdout.
- Files given:
  - Default: in-place modification. NO stdout output. Preserves file permissions/owner.
  - `-p`: write to stdout instead; if multiple files, header `----- FILE <path> -----\n` per file. Single file: no header.
  - File doesn't exist → error before any processing: `error: invalid path: <path>\n`, exit 1.
- In-place implementation: writes to temp file `.tmpXXXXXX` in same dir, renames over original. Breaks hardlinks. Symlink: follows and overwrites the target file (rename happens on the path though, not on resolved-target, so it may replace the symlink itself).

## Errors
- Invalid regex: `error: invalid regex <regex crate error display>\n`, exit 1. Regex crate format:
  ```
  regex parse error:
      <pattern>
      ^
  error: <msg>
  ```
- Missing args / bad flags: clap default error, exit 2.
- Invalid UTF-8 in args: `error: invalid UTF-8 was detected in one or more arguments\n\nUsage: ...\nFor more information, try '--help'.\n`, exit 2.
- Repeated flags: clap default `error: the argument '...' cannot be used multiple times\n...`, exit 2.
- File errors during processing aggregated: `error: Failed processing some inputs\n    <path>: <err> at path "<temp path>"\n\n`, exit 1.

## Exit codes
- 0: success
- 1: runtime error (invalid path, invalid regex, file IO error, ambiguous capture group)
- 2: arg-parsing error (clap)
- 101: panic (per manpage; not produced normally)

## Process model
- One-shot. Read fully, then write. No streaming chunking. Blocks on stdin until EOF.
