use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};

use crate::replacer::Replacer;

/// A source file that has been pre-opened/mmap'd.
pub struct Source {
    pub path: PathBuf,
    pub bytes: Vec<u8>,
    pub permissions: Option<fs::Permissions>,
}

/// Open and mmap a file. Returns its bytes plus permission info for later writing.
/// On mmap/open failure, returns the formatted error string in sd style.
pub fn open_source(path: &Path) -> Result<Source, String> {
    let f = match fs::File::open(path) {
        Ok(f) => f,
        Err(e) => return Err(io_err_format(&e)),
    };
    let metadata = f.metadata().ok();
    let permissions = metadata.as_ref().map(|m| m.permissions());

    // Empty regular file: skip mmap (which would fail with len=0 on most platforms).
    if let Some(m) = &metadata {
        if m.len() == 0 && m.file_type().is_file() {
            return Ok(Source {
                path: path.to_path_buf(),
                bytes: Vec::new(),
                permissions,
            });
        }
    }

    let mm = unsafe { memmap2::Mmap::map(&f) };
    let bytes = match mm {
        Ok(map) => map.to_vec(),
        Err(e) => return Err(io_err_format(&e)),
    };
    Ok(Source {
        path: path.to_path_buf(),
        bytes,
        permissions,
    })
}

/// Open all sources, returning a Vec of sources or the first error.
pub fn open_sources(paths: &[PathBuf]) -> Result<Vec<Source>, String> {
    let mut sources = Vec::with_capacity(paths.len());
    for p in paths {
        sources.push(open_source(p)?);
    }
    Ok(sources)
}

/// Write replacement contents to a temp file in the same dir and rename over target.
/// On failure, returns an error string in sd's "<path>: <err> at path \"<temp>\"" format.
pub fn write_in_place(source: &Source, replacer: &Replacer) -> Result<(), String> {
    let out = replacer.replace(&source.bytes);
    // Determine target dir (parent of the path, follow symlink for atomic rename to target)
    let target = match fs::canonicalize(&source.path) {
        Ok(p) => p,
        Err(_) => source.path.clone(),
    };
    let parent = target.parent().unwrap_or(Path::new("."));
    let temp_path = parent.join(format!(".tmp{}", random_suffix(6)));

    let res = (|| -> std::io::Result<()> {
        let mut f = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temp_path)?;
        f.write_all(&out)?;
        f.sync_all()?;
        drop(f);
        if let Some(perm) = &source.permissions {
            let _ = fs::set_permissions(&temp_path, perm.clone());
        }
        fs::rename(&temp_path, &target)?;
        Ok(())
    })();

    if let Err(e) = res {
        let _ = fs::remove_file(&temp_path);
        return Err(format!(
            "{}: {} at path \"{}\"",
            source.path.display(),
            io_err_format(&e),
            temp_path.display()
        ));
    }
    Ok(())
}

fn io_err_format(e: &std::io::Error) -> String {
    if let Some(code) = e.raw_os_error() {
        format!("{} (os error {})", strerror(code), code)
    } else {
        format!("{}", e)
    }
}

fn strerror(code: i32) -> &'static str {
    match code {
        1 => "Operation not permitted",
        2 => "No such file or directory",
        5 => "Input/output error",
        9 => "Bad file descriptor",
        13 => "Permission denied",
        17 => "File exists",
        19 => "No such device",
        21 => "Is a directory",
        28 => "No space left on device",
        30 => "Read-only file system",
        32 => "Broken pipe",
        _ => "Unknown error",
    }
}

fn random_suffix(n: usize) -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let mut seed = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0);
    seed ^= std::process::id() as u64;
    seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
    let mut s = String::with_capacity(n);
    let alphabet: &[u8] = b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for _ in 0..n {
        seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        let idx = ((seed >> 32) as usize) % alphabet.len();
        s.push(alphabet[idx] as char);
    }
    s
}
