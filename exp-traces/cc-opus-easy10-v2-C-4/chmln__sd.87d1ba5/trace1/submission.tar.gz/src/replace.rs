// Replacement string parsing for sd.

pub fn decode_replacement_escapes(s: &str) -> Vec<u8> {
    // Process C-style escapes: \n \r \t \\ \xNN
    // Leave $N alone for regex's replacement engine to handle.
    let bytes = s.as_bytes();
    let mut out: Vec<u8> = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'\\' && i + 1 < bytes.len() {
            let next = bytes[i + 1];
            match next {
                b'n' => {
                    out.push(b'\n');
                    i += 2;
                    continue;
                }
                b'r' => {
                    out.push(b'\r');
                    i += 2;
                    continue;
                }
                b't' => {
                    out.push(b'\t');
                    i += 2;
                    continue;
                }
                b'\\' => {
                    out.push(b'\\');
                    i += 2;
                    continue;
                }
                b'x' => {
                    if i + 3 < bytes.len() && is_hex(bytes[i + 2]) && is_hex(bytes[i + 3]) {
                        let h1 = hex_digit(bytes[i + 2]);
                        let h2 = hex_digit(bytes[i + 3]);
                        let codepoint = (h1 << 4) | h2;
                        // Encode as UTF-8 codepoint (since regex crate works with strings)
                        if let Some(c) = char::from_u32(codepoint as u32) {
                            let mut buf = [0u8; 4];
                            let encoded = c.encode_utf8(&mut buf);
                            out.extend_from_slice(encoded.as_bytes());
                        }
                        i += 4;
                        continue;
                    }
                    out.push(b'\\');
                    i += 1;
                }
                _ => {
                    out.push(b'\\');
                    i += 1;
                }
            }
        } else {
            out.push(bytes[i]);
            i += 1;
        }
    }
    out
}

fn is_hex(b: u8) -> bool {
    matches!(b, b'0'..=b'9' | b'a'..=b'f' | b'A'..=b'F')
}

fn hex_digit(b: u8) -> u8 {
    match b {
        b'0'..=b'9' => b - b'0',
        b'a'..=b'f' => 10 + (b - b'a'),
        b'A'..=b'F' => 10 + (b - b'A'),
        _ => 0,
    }
}

/// Scan replacement string for ambiguous numbered group references like $1abc.
/// Returns the formatted error message if found.
pub fn check_ambiguous_groups(s: &str) -> Option<String> {
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '$' {
            // Skip $$
            if i + 1 < chars.len() && chars[i + 1] == '$' {
                i += 2;
                continue;
            }
            // Skip ${
            if i + 1 < chars.len() && chars[i + 1] == '{' {
                // Skip until matching }
                let mut j = i + 1;
                while j < chars.len() && chars[j] != '}' {
                    j += 1;
                }
                i = if j < chars.len() { j + 1 } else { j };
                continue;
            }
            // Parse digits after $
            let start = i + 1;
            let mut j = start;
            while j < chars.len() && chars[j].is_ascii_digit() {
                j += 1;
            }
            if j > start {
                // Has $N or $NN... where N are digits.
                // Check next char: if letter or underscore, ambiguous.
                if j < chars.len() && (chars[j].is_ascii_alphabetic() || chars[j] == '_') {
                    // Find end of identifier-like chars
                    let mut k = j;
                    while k < chars.len()
                        && (chars[k].is_ascii_alphanumeric() || chars[k] == '_')
                    {
                        k += 1;
                    }
                    let num: String = chars[start..j].iter().collect();
                    let rest: String = chars[j..k].iter().collect();
                    let full: String = chars[..].iter().collect();
                    let prefix: String = chars[..start].iter().collect();
                    let caret_offset = prefix
                        .chars()
                        .map(|c| display_width(c))
                        .sum::<usize>();
                    let ambiguous_part: String = chars[start..k].iter().collect();
                    let caret_count = ambiguous_part.chars().count();
                    let visualized = visualize_controls(&full);
                    let mut err = String::new();
                    err.push_str(&format!(
                        "error: The numbered capture group `${}` in the replacement text is ambiguous.\n",
                        num
                    ));
                    err.push_str(&format!(
                        "hint: Use curly braces to disambiguate it `${{{}}}{}`.\n",
                        num, rest
                    ));
                    err.push_str(&visualized);
                    err.push('\n');
                    for _ in 0..caret_offset {
                        err.push(' ');
                    }
                    for _ in 0..caret_count {
                        err.push('^');
                    }
                    return Some(err);
                }
                i = j;
                continue;
            }
            // $ followed by letter/_/digit/anything else - not ambiguous (handled by regex)
            i += 1;
        } else {
            i += 1;
        }
    }
    None
}

/// Replace control chars with Unicode "control pictures" for diagnostic output.
fn visualize_controls(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '\n' => out.push('\u{240A}'),
            '\t' => out.push('\u{2409}'),
            '\r' => out.push('\u{240D}'),
            _ => out.push(c),
        }
    }
    out
}

fn display_width(c: char) -> usize {
    // Approximate display width: control chars become 1-wide (control pictures).
    // All ASCII = 1. For now treat everything as 1.
    let _ = c;
    1
}
