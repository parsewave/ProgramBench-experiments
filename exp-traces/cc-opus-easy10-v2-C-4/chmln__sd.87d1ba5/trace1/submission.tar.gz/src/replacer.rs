use regex::bytes::{Regex, RegexBuilder};
use std::borrow::Cow;

use crate::replace::{check_ambiguous_groups, decode_replacement_escapes};

pub struct Replacer {
    regex: Regex,
    replace_with: Vec<u8>,
    is_literal: bool,
    max_replacements: usize,
}

impl Replacer {
    pub fn new(
        find: String,
        replace_with: String,
        is_literal: bool,
        flags: Option<&str>,
        max_replacements: usize,
    ) -> Result<Self, String> {
        // Process the find pattern
        let pattern = if is_literal {
            regex::escape(&find)
        } else {
            find
        };

        // Build regex based on flags
        let (pattern, builder_settings) = apply_flag_string(pattern, flags);

        let mut builder = RegexBuilder::new(&pattern);
        builder.multi_line(builder_settings.multi_line);
        builder.case_insensitive(builder_settings.case_insensitive);
        builder.dot_matches_new_line(builder_settings.dot_matches_new_line);

        let regex = match builder.build() {
            Ok(r) => r,
            Err(e) => {
                return Err(format!("error: invalid regex {}", e));
            }
        };

        // Process replacement
        let replace_with_bytes = if is_literal {
            replace_with.into_bytes()
        } else {
            // Check for ambiguous group references
            if let Some(err) = check_ambiguous_groups(&replace_with) {
                return Err(err);
            }
            decode_replacement_escapes(&replace_with)
        };

        Ok(Self {
            regex,
            replace_with: replace_with_bytes,
            is_literal,
            max_replacements,
        })
    }

    pub fn replace<'a>(&self, input: &'a [u8]) -> Cow<'a, [u8]> {
        let limit = if self.max_replacements == 0 {
            usize::MAX
        } else {
            self.max_replacements
        };

        if self.is_literal {
            // Literal replacement (no $N expansion)
            let lit = &self.replace_with[..];
            let mut result: Vec<u8> = Vec::new();
            let mut last = 0;
            let mut count = 0;
            for m in self.regex.find_iter(input) {
                if count >= limit {
                    break;
                }
                result.extend_from_slice(&input[last..m.start()]);
                result.extend_from_slice(lit);
                last = m.end();
                count += 1;
            }
            if count == 0 {
                return Cow::Borrowed(input);
            }
            result.extend_from_slice(&input[last..]);
            Cow::Owned(result)
        } else {
            // Use regex's replacement with $ support
            self.regex.replacen(input, limit, &self.replace_with[..])
        }
    }
}

#[derive(Default)]
pub struct BuilderSettings {
    pub multi_line: bool,
    pub case_insensitive: bool,
    pub dot_matches_new_line: bool,
}

pub fn apply_flag_string(pattern: String, flags: Option<&str>) -> (String, BuilderSettings) {
    let mut settings = BuilderSettings {
        multi_line: true,
        case_insensitive: false,
        dot_matches_new_line: false,
    };

    let mut word = false;

    if let Some(flags) = flags {
        let has_e = flags.contains('e');
        let has_w = flags.contains('w');
        let has_s = flags.contains('s');
        let has_m = flags.contains('m');

        if has_e || has_w || (has_s && !has_m) {
            settings.multi_line = false;
        }

        for c in flags.chars() {
            match c {
                'i' => settings.case_insensitive = true,
                'c' => settings.case_insensitive = false,
                's' => settings.dot_matches_new_line = true,
                'w' => {
                    settings.dot_matches_new_line = false;
                    word = true;
                }
                _ => {}
            }
        }
    }

    let final_pattern = if word {
        format!(r"\b{}\b", pattern)
    } else {
        pattern
    };

    (final_pattern, settings)
}
