use clap::Parser;
use std::io::{self, Read, Write};
use std::path::PathBuf;
use std::process::ExitCode;

mod input;
mod replace;
mod replacer;

use replacer::Replacer;

const ABOUT: &str = "An intuitive find & replace CLI";

#[derive(Parser)]
#[command(
    version = "1.0.0",
    about = ABOUT,
    long_about = None,
    disable_help_flag = false,
)]
struct Args {
    /// Display changes in a human reviewable format (the specifics of the format are likely to change in the future)
    #[arg(short, long)]
    preview: bool,

    /// Treat FIND and REPLACE_WITH args as literal strings
    #[arg(short = 'F', long)]
    fixed_strings: bool,

    /// Limit the number of replacements that can occur per file. 0 indicates unlimited replacements
    #[arg(short = 'n', long = "max-replacements", value_name = "LIMIT", default_value_t = 0)]
    max_replacements: usize,

    #[arg(short = 'f', long, value_name = "FLAGS",
          help = "Regex flags. May be combined (like `-f mc`).",
          long_help = "Regex flags. May be combined (like `-f mc`).\n\nc - case-sensitive\n\ne - disable multi-line matching\n\ni - case-insensitive\n\nm - multi-line matching\n\ns - make `.` match newlines\n\nw - match full words only")]
    flags: Option<String>,

    /// The regexp or string (if using `-F`) to search for
    find: String,

    /// What to replace each match with. Unless in string mode, you may use captured values like $1, $2, etc
    replace_with: String,

    /// The path to file(s). This is optional - sd can also read from STDIN.
    ///
    /// Note: sd modifies files in-place by default. See documentation for examples.
    files: Vec<PathBuf>,
}

fn main() -> ExitCode {
    // Override the version line printed by --version to "sd 1.0.0"
    let args = match try_parse() {
        Ok(a) => a,
        Err(code) => return ExitCode::from(code),
    };

    match run(args) {
        Ok(()) => ExitCode::from(0),
        Err(code) => ExitCode::from(code),
    }
}

fn try_parse() -> Result<Args, u8> {
    use clap::error::ErrorKind;
    // We can't easily override the help title via clap derive. Use command_for_update.
    let mut cmd = <Args as clap::CommandFactory>::command();
    // Set custom long_about (the help title is part of the help template).
    cmd = cmd
        .name("executable")
        .version("1.0.0")
        // Override default version flag handler so we print "sd 1.0.0" not "executable 1.0.0".
        .long_version("1.0.0");

    // Customize the help template to begin with `sd v1.0.0` line.
    cmd = cmd.help_template(
        "sd v1.0.0\n\
         {about}\n\n\
         {usage-heading} {usage}\n\n\
         {all-args}{after-help}",
    );

    // For version output, we want exactly: "sd 1.0.0\n"
    // clap by default prints `{name} {version}\n`. Override via mut_arg on version?
    // We'll handle by intercepting the ErrorKind::DisplayVersion path.
    let m = cmd.try_get_matches();
    match m {
        Ok(matches) => {
            let args = <Args as clap::FromArgMatches>::from_arg_matches(&matches)
                .expect("clap derive should succeed if matches succeeded");
            Ok(args)
        }
        Err(e) => {
            match e.kind() {
                ErrorKind::DisplayVersion => {
                    // Print "sd 1.0.0\n" instead of "executable 1.0.0\n"
                    print!("sd 1.0.0\n");
                    Err(0)
                }
                ErrorKind::DisplayHelp => {
                    // clap prints the help via its template; just exit 0.
                    let _ = e.print();
                    Err(0)
                }
                _ => {
                    let _ = e.print();
                    Err(2)
                }
            }
        }
    }
}

fn run(args: Args) -> Result<(), u8> {
    // Build the regex from FIND + flags
    let replacer = match Replacer::new(
        args.find,
        args.replace_with,
        args.fixed_strings,
        args.flags.as_deref(),
        args.max_replacements,
    ) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("{}", e);
            return Err(1);
        }
    };

    if args.files.is_empty() {
        // stdin -> stdout
        let mut buf = Vec::new();
        if io::stdin().read_to_end(&mut buf).is_err() {
            eprintln!("error: failed to read stdin");
            return Err(1);
        }
        let out = replacer.replace(&buf);
        if io::stdout().write_all(&out).is_err() {
            eprintln!("error: Broken pipe (os error 32)");
            return Err(1);
        }
        return Ok(());
    }

    // Validate all paths first: must exist
    for p in &args.files {
        if !p.exists() {
            eprintln!("error: invalid path: {}", p.display());
            return Err(1);
        }
    }

    // Open all files via mmap up front; if any fail, abort
    let sources = match input::open_sources(&args.files) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("error: {}", e);
            return Err(1);
        }
    };

    if args.preview {
        let multi = sources.len() > 1;
        let mut stdout = io::stdout().lock();
        for src in &sources {
            let out = replacer.replace(&src.bytes);
            if multi {
                let _ = writeln!(stdout, "----- FILE {} -----", src.path.display());
            }
            let _ = stdout.write_all(&out);
        }
        return Ok(());
    }

    // In-place modification
    let mut errors: Vec<String> = Vec::new();
    for src in &sources {
        if let Err(e) = input::write_in_place(src, &replacer) {
            errors.push(e);
        }
    }

    if !errors.is_empty() {
        eprintln!("error: Failed processing some inputs");
        for e in errors {
            eprintln!("    {}", e);
        }
        eprintln!();
        return Err(1);
    }

    Ok(())
}
