#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

export PATH=/usr/local/cargo/bin:${PATH}
export CARGO_HOME=/usr/local/cargo
export CARGO_TARGET_DIR="$(pwd)/target"

cargo build --release --offline 1>&2

cp -f target/release/executable ./executable
chmod +x ./executable
