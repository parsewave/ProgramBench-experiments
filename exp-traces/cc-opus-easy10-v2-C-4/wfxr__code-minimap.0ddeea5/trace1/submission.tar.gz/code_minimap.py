#!/usr/bin/env python3
"""Clean-room reimplementation of code-minimap."""

import math
import os
import sys


VERSION = "code-minimap 0.6.8"
USAGE_MAIN = "Usage: executable [OPTIONS] [FILE] [COMMAND]"
USAGE_COMPLETION = "Usage: executable completion <SHELL>"
USAGE_HELP = "Usage: executable help [COMMAND]..."

SHELLS = ("bash", "elvish", "fish", "powershell", "zsh")


def script_data_dir():
    here = os.path.dirname(os.path.realpath(sys.argv[0]))
    return os.path.join(here, "data")


def read_data(name):
    path = os.path.join(script_data_dir(), name)
    with open(path, "rb") as f:
        return f.read()


def write_stdout_bytes(b):
    sys.stdout.buffer.write(b)
    sys.stdout.buffer.flush()


def write_stderr_bytes(b):
    sys.stderr.buffer.write(b)
    sys.stderr.buffer.flush()


def show_help_main():
    write_stdout_bytes(read_data("help_main"))


def show_help_completion():
    write_stdout_bytes(read_data("help_completion"))


def show_help_help():
    write_stdout_bytes(read_data("help_help"))


def show_version():
    write_stdout_bytes(VERSION.encode("utf-8") + b"\n")


def show_completion(shell):
    write_stdout_bytes(read_data("comp_" + shell))


def err_print(msg, exit_code):
    if not msg.endswith("\n"):
        msg += "\n"
    write_stderr_bytes(msg.encode("utf-8"))
    sys.exit(exit_code)


def err_unexpected_arg(arg, with_tip=False, usage=USAGE_MAIN, with_more_info=True):
    msg = f"error: unexpected argument '{arg}' found\n\n"
    if with_tip:
        msg += f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n"
    msg += f"{usage}\n"
    if with_more_info:
        msg += "\nFor more information, try '--help'.\n"
    err_print(msg, 2)


def err_invalid_value(value, name, reason=None, possible=None):
    msg = f"error: invalid value '{value}' for '{name}'"
    if reason:
        msg += f": {reason}\n"
    else:
        msg += "\n"
    if possible:
        msg += f"  [possible values: {possible}]\n"
    msg += "\nFor more information, try '--help'.\n"
    err_print(msg, 2)


def err_value_required(name):
    msg = (
        f"error: a value is required for '{name}' but none was supplied\n"
        "\nFor more information, try '--help'.\n"
    )
    err_print(msg, 2)


def err_repeated(name):
    msg = (
        f"error: the argument '{name}' cannot be used multiple times\n\n"
        f"{USAGE_MAIN}\n\n"
        "For more information, try '--help'.\n"
    )
    err_print(msg, 2)


def err_required_missing_shell():
    msg = (
        "error: the following required arguments were not provided:\n"
        "  <SHELL>\n\n"
        f"{USAGE_COMPLETION}\n\n"
        "For more information, try '--help'.\n"
    )
    err_print(msg, 2)


def err_unrecognized_subcommand(name, usage=USAGE_MAIN, with_more_info=True):
    msg = f"error: unrecognized subcommand '{name}'\n\n{usage}\n"
    if with_more_info:
        msg += "\nFor more information, try '--help'.\n"
    err_print(msg, 2)


def err_io(message):
    write_stderr_bytes(b"code-minimap: " + message.encode("utf-8") + b"\n")
    sys.exit(1)


def parse_float(value, name):
    try:
        return float(value)
    except ValueError:
        err_invalid_value(value, name, reason="invalid float literal")


def parse_int(value, name):
    if not value:
        err_invalid_value(value, name, reason="invalid digit found in string")
    s = value
    sign = 1
    if s[0] in "+-":
        if len(s) == 1:
            err_invalid_value(value, name, reason="invalid digit found in string")
        if s[0] == "-":
            sign = -1
        s = s[1:]
    if not s.isdigit():
        err_invalid_value(value, name, reason="invalid digit found in string")
    return sign * int(s)


def parse_padding(value):
    name = "--padding <PADDING>"
    n = parse_int(value, name)
    if n < 0:
        err_invalid_value(value, name, reason="invalid digit found in string")
    return n


# --- Argument parsing ---

LONG_FLAGS_MAIN = {
    "--horizontal-scale": ("hscale", True),
    "--vertical-scale": ("vscale", True),
    "--padding": ("padding", True),
    "--encoding": ("encoding", True),
    "--version": ("version", False),
    "--help": ("help", False),
}

SHORT_FLAGS_MAIN = {
    "H": ("hscale", True, "--horizontal-scale"),
    "V": ("vscale", True, "--vertical-scale"),
    "h": ("help", False, "--help"),
}

OPTION_NAME = {
    "hscale": "--horizontal-scale <HSCALE>",
    "vscale": "--vertical-scale <VSCALE>",
    "padding": "--padding <PADDING>",
    "encoding": "--encoding <ENCODING>",
}


def parse_main_args(argv):
    """Parse main args. Returns dict with parsed values or routes to subcommand."""
    options = {
        "hscale": None,
        "vscale": None,
        "padding": None,
        "encoding": None,
        "file": None,
    }
    seen = set()

    i = 0
    after_dash = False
    positional = []

    while i < len(argv):
        a = argv[i]

        if not after_dash and a == "--":
            after_dash = True
            i += 1
            continue

        if not after_dash and a.startswith("--"):
            # Long flag
            if "=" in a:
                flag, _, val = a.partition("=")
                has_val = True
            else:
                flag = a
                val = None
                has_val = False

            if flag in LONG_FLAGS_MAIN:
                key, needs_val = LONG_FLAGS_MAIN[flag]
                if key in seen and needs_val:
                    err_repeated(OPTION_NAME.get(key, flag))
                seen.add(key)
                if key == "help":
                    show_help_main()
                    sys.exit(0)
                if key == "version":
                    show_version()
                    sys.exit(0)
                if not needs_val:
                    i += 1
                    continue
                if not has_val:
                    if i + 1 >= len(argv):
                        err_value_required(OPTION_NAME[key])
                    nxt = argv[i + 1]
                    if nxt.startswith("-") and nxt != "-":
                        err_value_required(OPTION_NAME[key])
                    val = nxt
                    i += 2
                else:
                    i += 1
                options[key] = val
                continue
            else:
                err_unexpected_arg(a, with_tip=True)

        if not after_dash and a.startswith("-") and a != "-" and len(a) > 1:
            # Short flag(s)
            # Handle -X=value or -Xvalue or -X value
            rest = a[1:]
            short_char = rest[0]
            if short_char not in SHORT_FLAGS_MAIN:
                err_unexpected_arg(a, with_tip=True)
            key, needs_val, long_name = SHORT_FLAGS_MAIN[short_char]
            if key == "help":
                show_help_main()
                sys.exit(0)
            if needs_val:
                if key in seen:
                    err_repeated(OPTION_NAME[key])
                seen.add(key)
                remainder = rest[1:]
                if remainder.startswith("="):
                    val = remainder[1:]
                elif remainder:
                    val = remainder
                else:
                    if i + 1 >= len(argv):
                        err_value_required(OPTION_NAME[key])
                    nxt = argv[i + 1]
                    if nxt.startswith("-") and nxt != "-":
                        err_value_required(OPTION_NAME[key])
                    val = nxt
                    i += 1
                options[key] = val
                i += 1
                continue
            else:
                # help: stop parsing
                i += 1
                continue

        # Positional or subcommand
        if not after_dash and not positional and a in ("completion", "help"):
            # Subcommand
            return ("subcommand", a, argv[i + 1:])

        positional.append(a)
        i += 1

    # Process positional args (only FILE allowed)
    if len(positional) > 1:
        err_unexpected_arg(positional[1])
    if positional:
        options["file"] = positional[0]

    # Parse numeric/encoding values
    if options["hscale"] is not None:
        options["hscale"] = parse_float(options["hscale"], OPTION_NAME["hscale"])
    else:
        options["hscale"] = 1.0
    if options["vscale"] is not None:
        options["vscale"] = parse_float(options["vscale"], OPTION_NAME["vscale"])
    else:
        options["vscale"] = 1.0
    if options["padding"] is not None:
        options["padding"] = parse_padding(options["padding"])
    else:
        options["padding"] = 0
    if options["encoding"] is not None:
        if options["encoding"] not in ("utf8-lossy", "utf8"):
            err_invalid_value(
                options["encoding"],
                "--encoding <ENCODING>",
                possible="utf8-lossy, utf8",
            )
    else:
        options["encoding"] = "utf8-lossy"

    return ("run", options)


def parse_completion_args(argv):
    """Parse args for 'completion' subcommand. Returns shell name."""
    shell = None
    i = 0
    after_dash = False
    while i < len(argv):
        a = argv[i]
        if not after_dash and a == "--":
            after_dash = True
            i += 1
            continue
        if not after_dash and a.startswith("--"):
            if a == "--help":
                show_help_completion()
                sys.exit(0)
            err_unexpected_arg(a, with_tip=True, usage=USAGE_COMPLETION)
        if not after_dash and a.startswith("-") and a != "-" and len(a) > 1:
            if a == "-h":
                show_help_completion()
                sys.exit(0)
            err_unexpected_arg(a, with_tip=True, usage=USAGE_COMPLETION)
        if shell is None:
            shell = a
            i += 1
            continue
        err_unexpected_arg(a, with_tip=False, usage=USAGE_COMPLETION)

    if shell is None:
        err_required_missing_shell()
    if shell not in SHELLS:
        err_invalid_value(shell, "<SHELL>", possible="bash, elvish, fish, powershell, zsh")
    show_completion(shell)
    sys.exit(0)


def parse_help_args(argv):
    """Parse args for 'help' subcommand. argv is what's after 'help'."""
    if not argv:
        show_help_main()
        sys.exit(0)
    first = argv[0]
    if first in ("completion",):
        # `help completion` or `help completion <subcmd>`
        if len(argv) > 1:
            sub = argv[1]
            err_unrecognized_subcommand(sub, usage=USAGE_COMPLETION)
        show_help_completion()
        sys.exit(0)
    if first == "help":
        # `help help` or `help help <subcmd>`
        if len(argv) > 1:
            sub = argv[1]
            err_unrecognized_subcommand(sub, usage=USAGE_HELP, with_more_info=False)
        show_help_help()
        sys.exit(0)
    err_unrecognized_subcommand(first)


# --- Input decoding ---

def decode_input(data, encoding):
    if encoding == "utf8":
        try:
            return data.decode("utf-8")
        except UnicodeDecodeError:
            err_io("stream did not contain valid UTF-8")
    else:
        return data.decode("utf-8", errors="replace")


# --- Line splitting (Rust str::lines() semantics) ---

def split_lines(s):
    if not s:
        return []
    parts = s.split("\n")
    if parts and parts[-1] == "":
        parts = parts[:-1]
    return [p[:-1] if p.endswith("\r") else p for p in parts]


# --- Minimap algorithm ---

def is_whitespace_codepoint(cp):
    """Approximation of Rust char::is_whitespace() (Unicode White_Space property)."""
    return cp in WHITESPACE_CODEPOINTS


# Unicode White_Space codepoints (from PropList.txt)
WHITESPACE_CODEPOINTS = frozenset([
    0x0009, 0x000A, 0x000B, 0x000C, 0x000D,
    0x0020,
    0x0085,
    0x00A0,
    0x1680,
    0x2000, 0x2001, 0x2002, 0x2003, 0x2004, 0x2005, 0x2006,
    0x2007, 0x2008, 0x2009, 0x200A,
    0x2028, 0x2029,
    0x202F,
    0x205F,
    0x3000,
])


def line_span(line):
    """Return (first_byte_offset, last_byte_offset) of non-ws chars, or (None, None) if all ws.
    Byte offsets are within the UTF-8 encoded form of the line."""
    first = None
    last = None
    byte_off = 0
    for ch in line:
        cp = ord(ch)
        if not is_whitespace_codepoint(cp):
            if first is None:
                first = byte_off
            last = byte_off
        byte_off += len(ch.encode("utf-8"))
    return first, last, byte_off  # also return total bytes (for width calc edge case)


def render(text, H, V, padding):
    """Render minimap of text. Returns bytes."""
    lines = split_lines(text)
    if not lines:
        return b""

    # Cap V at 1 (V > 1 acts as 1)
    v_cap = V if V <= 1.0 else 1.0

    # For each line, compute span info
    line_info = []  # list of (first, last, width) where width = last+1 or 0
    for line in lines:
        first, last, _ = line_span(line)
        if first is None:
            line_info.append((None, None, 0))
        else:
            line_info.append((first, last, last + 1))

    # Map each line to a dot row
    def dot_row_for_line(i):
        # Compute floor(i * v_cap). Handle special cases.
        if math.isnan(v_cap):
            return 0
        prod = i * v_cap
        if prod != prod:  # NaN
            return 0
        if math.isinf(prod):
            return sys.maxsize if prod > 0 else 0
        if prod < 0:
            return 0
        return int(math.floor(prod))

    dot_rows = [dot_row_for_line(i) for i in range(len(lines))]
    max_dot_row = max(dot_rows) if dot_rows else 0
    # Cap: dot row shouldn't exceed (n-1) (i.e., V > 1 effectively doesn't extend)
    # The cap on V > 1 limits max_dot_row to n-1.
    if max_dot_row >= len(lines):
        # Re-clamp dot rows
        max_dot_row = len(lines) - 1
        dot_rows = [min(d, len(lines) - 1) for d in dot_rows]

    total_dot_rows = max_dot_row + 1
    num_cell_rows = (total_dot_rows + 3) // 4

    output = []

    # Group lines by cell row
    lines_in_cell_row = [[] for _ in range(num_cell_rows)]
    line_dot_row_within = [0] * len(lines)
    for i, dr in enumerate(dot_rows):
        cr = dr // 4
        if cr >= num_cell_rows:
            continue
        lines_in_cell_row[cr].append(i)
        line_dot_row_within[i] = dr - cr * 4

    for r in range(num_cell_rows):
        lines_here = lines_in_cell_row[r]
        # Determine row width
        widths = [line_info[i][2] for i in lines_here]
        row_max_width = max(widths) if widths else 0
        if row_max_width == 0:
            row_max_width = 1

        if H <= 0 or math.isnan(H):
            dot_width = 0
        elif math.isinf(H):
            dot_width = sys.maxsize
        else:
            dot_width = int(math.floor(row_max_width * H))
            if dot_width < 0:
                dot_width = 0

        cell_width = (dot_width + 1) // 2

        # Compute dot ranges per dot row within this cell row
        # dot_row_dots[dr] = set of dot indices ON
        dot_row_dots = [None] * 4
        for i in lines_here:
            first, last, _ = line_info[i]
            if first is None:
                continue
            dr = line_dot_row_within[i]
            if H <= 0 or math.isnan(H) or math.isinf(H):
                # Edge cases - skip for now
                if math.isinf(H) and H > 0:
                    # H=inf: every input col makes dot_width huge; treat each col as filling many dots
                    # Just set all dots for span to ON
                    min_dot = 0
                    max_dot = dot_width - 1
                else:
                    continue
            else:
                min_dot = int(math.floor(first * H))
                max_dot = int(math.floor((last + 1) * H)) - 1
                if max_dot < 0:
                    continue
                min_dot = max(0, min_dot)
                max_dot = min(dot_width - 1, max_dot)
                if min_dot > max_dot:
                    continue
            if dot_row_dots[dr] is None:
                dot_row_dots[dr] = (min_dot, max_dot)
            else:
                lo, hi = dot_row_dots[dr]
                dot_row_dots[dr] = (min(lo, min_dot), max(hi, max_dot))

        # Build cells
        cells = bytearray()
        for c in range(cell_width):
            bits = 0
            for dr in range(4):
                if dot_row_dots[dr] is None:
                    continue
                lo, hi = dot_row_dots[dr]
                for dc in range(2):
                    dot_col_global = c * 2 + dc
                    if dot_col_global >= dot_width:
                        continue
                    if lo <= dot_col_global <= hi:
                        if dr == 3:
                            bit = 6 + dc
                        else:
                            bit = dr + dc * 3
                        bits |= (1 << bit)
            cp = 0x2800 + bits
            cells.extend(chr(cp).encode("utf-8"))

        # Padding
        if padding > cell_width:
            cells.extend(b" " * (padding - cell_width))

        cells.extend(b"\n")
        output.append(bytes(cells))

    return b"".join(output)


def read_input(file_path):
    if file_path is None:
        return sys.stdin.buffer.read()
    try:
        with open(file_path, "rb") as f:
            return f.read()
    except FileNotFoundError:
        err_io("No such file or directory (os error 2)")
    except IsADirectoryError:
        err_io("Is a directory (os error 21)")
    except PermissionError:
        err_io("Permission denied (os error 13)")
    except OSError as e:
        err_io(f"{e.strerror} (os error {e.errno})")


def main():
    argv = sys.argv[1:]
    result = parse_main_args(argv)
    if result[0] == "subcommand":
        _, sub, rest = result
        if sub == "completion":
            parse_completion_args(rest)
        elif sub == "help":
            parse_help_args(rest)
        return

    _, options = result
    data = read_input(options["file"])
    text = decode_input(data, options["encoding"])
    out = render(text, options["hscale"], options["vscale"], options["padding"])
    try:
        write_stdout_bytes(out)
    except BrokenPipeError:
        # Match Rust default behavior - silently exit
        try:
            sys.stdout.close()
        except Exception:
            pass
        sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        try:
            sys.stdout.close()
        except Exception:
            pass
        sys.exit(0)
