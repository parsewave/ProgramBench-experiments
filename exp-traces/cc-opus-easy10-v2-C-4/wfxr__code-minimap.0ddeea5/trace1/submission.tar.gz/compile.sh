#!/bin/sh
set -e
cd "$(dirname "$0")"
cp code_minimap.py executable
chmod +x executable
