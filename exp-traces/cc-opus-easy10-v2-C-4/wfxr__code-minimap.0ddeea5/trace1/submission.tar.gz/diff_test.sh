#!/bin/bash
# Differential testing: compare REF and SUT outputs
set -u
REF=/workspace/executable
SUT=/work/work/executable
FAIL=0
PASS=0

check() {
    local name="$1"
    shift
    local args=("$@")

    local ref_stdout ref_stderr ref_exit
    local sut_stdout sut_stderr sut_exit

    ref_stdout=$("$REF" "${args[@]}" 2>/tmp/ref_stderr <"$INPUT_FILE")
    ref_exit=$?
    ref_stderr=$(cat /tmp/ref_stderr)

    sut_stdout=$("$SUT" "${args[@]}" 2>/tmp/sut_stderr <"$INPUT_FILE")
    sut_exit=$?
    sut_stderr=$(cat /tmp/sut_stderr)

    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_stderr" = "$sut_stderr" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        echo "FAIL: $name"
        if [ "$ref_stdout" != "$sut_stdout" ]; then
            echo "  stdout differs:"
            diff <(echo "$ref_stdout" | od -An -tx1) <(echo "$sut_stdout" | od -An -tx1) | head -10
        fi
        if [ "$ref_stderr" != "$sut_stderr" ]; then
            echo "  stderr differs:"
            echo "    REF: $ref_stderr"
            echo "    SUT: $sut_stderr"
        fi
        if [ "$ref_exit" != "$sut_exit" ]; then
            echo "  exit differs: REF=$ref_exit SUT=$sut_exit"
        fi
    fi
}

# Test cases with different inputs
test_input() {
    local input_data="$1"
    shift
    local label="$1"
    shift

    INPUT_FILE=/tmp/diff_input
    printf "$input_data" > $INPUT_FILE

    check "$label" "$@"
}

# Simple cases
test_input "" "empty-noargs"
test_input "" "empty-help" --help
test_input "" "empty-version" --version
test_input "hello\n" "hello"
test_input "hello world\n" "hello-world"
test_input "ab\ncd\n" "ab-cd"
test_input "a\nb\nc\nd\n" "vertical"
test_input "abc\ndef\nghi\njkl\n" "grid"
test_input "  a\n" "leading-space"
test_input "a  \n" "trailing-space"
test_input "       \n" "whitespace-line"
test_input "\n" "newline-only"
test_input "\n\n\n\n\n" "5-newlines"

# Scaling
test_input "abcdefgh\n" "h-default"
test_input "abcdefgh\n" "h-2" -H 2
test_input "abcdefgh\n" "h-0.5" -H 0.5
test_input "abcdefgh\n" "h-3" -H 3
test_input "abcdefgh\n" "h-0.3" -H 0.3
test_input "a\nb\nc\nd\n" "v-1"
test_input "a\nb\nc\nd\n" "v-0.5" -V 0.5
test_input "a\nb\nc\nd\ne\nf\ng\nh\n" "v-0.5-8lines" -V 0.5
test_input "a\nb\nc\nd\n" "v-2" -V 2

# Padding
test_input "ab\n" "padding-3" --padding 3
test_input "ab\n" "padding-0" --padding 0
test_input "ab\n" "padding-100" --padding 100
test_input "" "empty-padding" --padding 3

# Encoding
test_input "ab\n" "encoding-utf8" --encoding utf8
test_input "ab\n" "encoding-lossy" --encoding utf8-lossy
test_input '\xff\n' "invalid-lossy" --encoding utf8-lossy
test_input '\xff\n' "invalid-strict" --encoding utf8

# Multi-byte
test_input "a☃\n" "snowman-end"
test_input "☃a\n" "snowman-start"
test_input "é\n" "e-acute"
test_input "☃☃\n" "two-snowman"

# Errors
test_input "ab\n" "err-bogus" --bogus
test_input "ab\n" "err-bad-float" -H abc
test_input "ab\n" "err-bad-int" --padding 2.5
test_input "ab\n" "err-bad-encoding" --encoding bogus

# Subcommands
test_input "" "completion-bash" completion bash
test_input "" "completion-zsh" completion zsh
test_input "" "completion-fish" completion fish
test_input "" "completion-elvish" completion elvish
test_input "" "completion-powershell" completion powershell
test_input "" "help-help" help
test_input "" "help-completion" help completion
test_input "" "help-help-help" help help

# File arg
echo "abc" > /tmp/diff_test.txt
INPUT_FILE=/dev/null
check "file-arg" /tmp/diff_test.txt
check "file-notfound" /tmp/diff_test_nope_xyz

echo ""
echo "Results: $PASS passed, $FAIL failed"
