# Behavior Map for code-minimap

## CLI Interface (clap v4 style)

```
executable [OPTIONS] [FILE] [COMMAND]
```

Options (all optional):
- `-H, --horizontal-scale <HSCALE>` — float, default 1.0
- `-V, --vertical-scale <VSCALE>` — float, default 1.0
- `--padding <PADDING>` — non-negative integer, optional
- `--encoding <ENCODING>` — `utf8-lossy` (default) or `utf8`
- `--version` — print "code-minimap 0.6.8"
- `-h, --help` — print help

Subcommands:
- `completion <SHELL>` — shells: bash, elvish, fish, powershell, zsh
- `help [COMMAND]...` — print help

Positional: `[FILE]` — file to read; defaults to stdin.

## Algorithm

### Input decoding
- Read entire input (file or stdin) as bytes.
- `utf8`: decode strictly. On invalid UTF-8, print `code-minimap: stream did not contain valid UTF-8` to stderr and exit 1.
- `utf8-lossy`: decode replacing invalid sequences with U+FFFD.

### Line splitting
- Split using Rust-style `.lines()`: split on `\n`, also stripping a preceding `\r` (CRLF), trailing newline does NOT add an extra empty line.
- Lone `\r` not followed by `\n` is kept as part of the line content.

### Per-line span
- Find byte offsets of non-whitespace chars in the decoded string.
- Whitespace per Rust's `char::is_whitespace()` (Unicode White_Space property; includes ' ', '\t', '\n', '\r', '\x0b', '\x0c', NBSP, etc.).
- `first_off` = byte offset of first non-ws char (None if all ws).
- `last_off` = byte offset of last non-ws char (None if all ws).
- `width` = `last_off + 1` if any non-ws, else 0.
- The span `[first_off, last_off]` is "on" for that line (bytes inside this range, even whitespace ones).

### Vertical mapping
- Each input line `i` (0-indexed) maps to output dot row `floor(i * V)`, where V is capped at 1.0 (so V > 1 acts as 1).
- Multiple input lines may map to the same dot row; their bits are OR'd.

### Cell rows
- Total output dot rows = max dot row + 1 = `floor((n-1) * V) + 1`, capped so it doesn't exceed `n`.
- Cells stack 4 dot rows tall. Number of output cell rows = `ceil(dot_rows / 4)`.

### Per cell-row processing
- For each cell row `r`:
  - Collect input lines whose dot row falls into `[4r, 4r+3]`.
  - Compute `width` per line as above.
  - `row_max_width` = max of widths; if no non-ws in any line of the cell row, treat as `1`.
  - `dot_width` = `floor(row_max_width * H)`.
  - `cell_width` = `ceil(dot_width / 2)`.
  - For each cell column `c` in `0..cell_width`:
    - For each of the 8 dots in the cell (positions row 0..3, col 0..1):
      - `dot_col_global` = `c * 2 + cell_col`
      - `dot_row_within_row` = the row 0..3 within the cell row
      - `input_col` (byte offset) = `floor(dot_col_global / H)`
      - If `input_col < dot_width / H` and any input line at `dot_row_global = r*4 + dot_row_within_row` has `first_off <= input_col <= last_off`, set the dot.
    - Emit U+2800 + bits.
  - Pad with ASCII spaces if `cell_width < padding`.
  - Emit newline.

### Special cases
- Empty input (zero bytes): no output (not even a newline).
- All-whitespace input or all-empty lines: emit row(s) with `row_max_width = 1` and proceed; dots all off, so cells are ⠀ (or empty if `dot_width = 0`).

### Padding
- `--padding N`: each output row is padded with ASCII spaces so total chars (cells + spaces) >= N.
- N=0 or unspecified: no padding.
- Negative N is rejected by the parser.
- Non-integer is rejected.

## Bit mapping (8-dot braille at U+2800 + bits)
- (row 0, col 0) → bit 0 (dot 1)
- (row 1, col 0) → bit 1 (dot 2)
- (row 2, col 0) → bit 2 (dot 3)
- (row 0, col 1) → bit 3 (dot 4)
- (row 1, col 1) → bit 4 (dot 5)
- (row 2, col 1) → bit 5 (dot 6)
- (row 3, col 0) → bit 6 (dot 7)
- (row 3, col 1) → bit 7 (dot 8)

## H scaling details

- `dot_width = floor(line_width * H)` per cell row's max line width.
- Each output dot col `j` samples input byte offset `i = floor(j / H)`.
- Dot is on if `i in [first_off, last_off]` of any input line at that dot row.

## V scaling details

- For V > 1, V is treated as 1 (no upscaling vertically).
- For V <= 1, input line `i` → dot row `floor(i * V)`.

## Error message catalog

- Bad arg (e.g., `--bogus`): clap "unexpected argument" with optional tip.
- File not found: `code-minimap: No such file or directory (os error 2)` + exit 1.
- Bad UTF-8 (strict): `code-minimap: stream did not contain valid UTF-8` + exit 1.
- Bad encoding value: clap "invalid value 'X' for '--encoding <ENCODING>'" with `[possible values: utf8-lossy, utf8]`.
- Bad float: clap "invalid value 'X' for '--horizontal-scale <HSCALE>': invalid float literal".
- Bad int: clap "invalid value 'X' for '--padding <PADDING>': invalid digit found in string".
- Repeated flag: "the argument '--xxx <YYY>' cannot be used multiple times".
- Extra positional: "unexpected argument 'X' found".
- Missing required: "the following required arguments were not provided:\n  <SHELL>".
- Bad shell: "invalid value 'X' for '<SHELL>'" with `[possible values: bash, elvish, fish, powershell, zsh]`.
