#!/usr/bin/env python3
"""code-minimap reimplementation: clean-room render minimap from text."""
import sys
import os
import math

USIZE_MAX = 2**64 - 1

HELP_TEXT = """A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
"""

VERSION_TEXT = "code-minimap 0.6.8\n"

HELP_COMPLETION_TEXT = """Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
"""

USAGE_TOP = "Usage: executable [OPTIONS] [FILE] [COMMAND]"
USAGE_COMPLETION = "Usage: executable completion <SHELL>"

ENCODING_VALUES = ("utf8-lossy", "utf8")
SHELLS = ("bash", "elvish", "fish", "powershell", "zsh")


def is_unicode_whitespace(cp):
    """Match Rust's char::is_whitespace (Unicode WSpace property)."""
    if cp < 0x80:
        return cp in (0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x20)
    if cp == 0x85 or cp == 0xA0 or cp == 0x1680:
        return True
    if 0x2000 <= cp <= 0x200A:
        return True
    if cp in (0x2028, 0x2029, 0x202F, 0x205F, 0x3000):
        return True
    return False


def rust_lines(s):
    """Match Rust's str::lines: split on \\n or \\r\\n; trailing \\n no extra empty."""
    out = []
    start = 0
    i = 0
    n = len(s)
    while i < n:
        c = s[i]
        if c == '\n':
            out.append(s[start:i])
            start = i + 1
            i += 1
        elif c == '\r' and i + 1 < n and s[i + 1] == '\n':
            out.append(s[start:i])
            start = i + 2
            i += 2
        else:
            i += 1
    if start < n:
        out.append(s[start:])
    return out


def sat_floor(x):
    """Saturating floor-then-cast-to-usize."""
    if x != x:
        return 0
    if x < 0:
        return 0
    if x == math.inf:
        return USIZE_MAX
    return math.floor(x)


def line_byte_info(line, h_scale):
    """Compute (first_byte, last_byte, total_width) for one line.

    first_byte and last_byte are byte offsets of the first and last
    non-whitespace characters (last is the starting byte of that char).
    Returns first=last=None when no non-WS chars: width then derives from
    the reference's empty-line default (floor(1*H)).
    """
    first_byte = None
    last_byte = None
    byte_pos = 0
    for c in line:
        cp = ord(c)
        if not is_unicode_whitespace(cp):
            if first_byte is None:
                first_byte = byte_pos
            last_byte = byte_pos
        byte_pos += len(c.encode('utf-8'))
    if last_byte is None:
        width = sat_floor(1.0 * h_scale)
        return (None, None, width)
    width = sat_floor((last_byte + 1) * h_scale)
    return (first_byte, last_byte, width)


def assign_dot_rows(n, v_scale):
    """Compute dot row per line using dense-rank of floor(i*V)."""
    raws = [sat_floor(i * v_scale) for i in range(n)]
    rows = []
    current = 0
    prev = None
    for r in raws:
        if prev is not None and r != prev:
            current += 1
        rows.append(current)
        prev = r
    return rows


SUBROW_BITS = [(0, 3), (1, 4), (2, 5), (6, 7)]


MAX_REASONABLE_WIDTH = 1 << 28  # match reference's panic-on-overflow boundary


def render_minimap(text, h_scale, v_scale, padding):
    lines = rust_lines(text)
    n = len(lines)
    if n == 0:
        return ""

    if math.isinf(h_scale):
        # Reference panics with "capacity overflow" when allocating Vec at
        # inf-width; mimic the abort signal exit code (101) without trying
        # to byte-match the non-deterministic panic message.
        sys.stderr.write(
            "\nthread 'main' panicked at library/alloc/src/raw_vec/mod.rs:28:5:\n"
            "capacity overflow\n"
            "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
        )
        sys.exit(101)

    infos = [line_byte_info(line, h_scale) for line in lines]
    dot_rows = assign_dot_rows(n, v_scale)
    num_dot_rows = dot_rows[-1] + 1
    num_braille_rows = (num_dot_rows + 3) // 4

    out_parts = []
    for br in range(num_braille_rows):
        first_dr = br * 4
        last_dr = first_dr + 3
        max_width = 0
        # Per dot_row in this Braille row: merged byte range across lines.
        merged = {}
        for i in range(n):
            dr = dot_rows[i]
            if not (first_dr <= dr <= last_dr):
                continue
            fb, lb, w = infos[i]
            if w > max_width:
                max_width = w
            if fb is None:
                continue
            sub = dr - first_dr
            if sub in merged:
                cur_f, cur_l = merged[sub]
                merged[sub] = (min(cur_f, fb), max(cur_l, lb))
            else:
                merged[sub] = (fb, lb)
        num_cells = (max_width + 1) // 2
        cells = [0] * num_cells
        for sub, (fb, lb) in merged.items():
            dot_start = sat_floor(fb * h_scale)
            dot_end = sat_floor((lb + 1) * h_scale) - 1
            if dot_end < dot_start:
                continue
            bit_a, bit_b = SUBROW_BITS[sub]
            for col in range(dot_start, dot_end + 1):
                cell_idx = col >> 1
                if col & 1 == 0:
                    cells[cell_idx] |= (1 << bit_a)
                else:
                    cells[cell_idx] |= (1 << bit_b)
        line = ''.join(chr(0x2800 + c) for c in cells)
        if padding is not None and len(cells) < padding:
            line += ' ' * (padding - len(cells))
        out_parts.append(line + '\n')
    return ''.join(out_parts)


class CliError(Exception):
    def __init__(self, msg, code=2):
        self.msg = msg
        self.code = code


def err_unknown_flag(arg, ctx_usage):
    return CliError(
        f"error: unexpected argument '{arg}' found\n"
        f"\n"
        f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n"
        f"\n"
        f"{ctx_usage}\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def err_unknown_positional(arg, ctx_usage):
    return CliError(
        f"error: unexpected argument '{arg}' found\n"
        f"\n"
        f"{ctx_usage}\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def err_missing_value(long, val_name, ctx_usage):
    return CliError(
        f"error: a value is required for '{long} <{val_name}>' but none was supplied\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def err_invalid_float(value, long, val_name):
    return CliError(
        f"error: invalid value '{value}' for '{long} <{val_name}>': invalid float literal\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def err_invalid_uint(value, long, val_name):
    return CliError(
        f"error: invalid value '{value}' for '{long} <{val_name}>': invalid digit found in string\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def err_invalid_enum(value, long, val_name, values):
    return CliError(
        f"error: invalid value '{value}' for '{long} <{val_name}>'\n"
        f"  [possible values: {', '.join(values)}]\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def err_dup_arg(long, val_name, ctx_usage):
    return CliError(
        f"error: the argument '{long} <{val_name}>' cannot be used multiple times\n"
        f"\n"
        f"{ctx_usage}\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def err_missing_required(name, ctx_usage):
    return CliError(
        f"error: the following required arguments were not provided:\n"
        f"  <{name}>\n"
        f"\n"
        f"{ctx_usage}\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def parse_float(value, long, val_name):
    """Match Rust's f64 FromStr parser as closely as needed."""
    s = value.strip()
    # Reject hex/octal prefixes (Rust f64 doesn't accept 0x...).
    # Rust accepts: optional sign, then either:
    #   inf / infinity / nan (case-insensitive),
    #   or [digits][.[digits]][e[+|-]digits]
    # We approximate via Python float() with extra rejection of empty strings.
    if not s:
        raise err_invalid_float(value, long, val_name)
    try:
        return float(s)
    except ValueError:
        raise err_invalid_float(value, long, val_name)


def parse_uint(value, long, val_name):
    s = value.strip()
    if not s or not s.lstrip().lstrip('+').isdigit():
        # Match the "invalid digit found in string" error for any non-digit
        # (including leading minus).
        raise err_invalid_uint(value, long, val_name)
    try:
        n = int(s)
    except ValueError:
        raise err_invalid_uint(value, long, val_name)
    if n < 0 or n > USIZE_MAX:
        raise err_invalid_uint(value, long, val_name)
    return n


OPT_DEFS = {
    '-H': ('--horizontal-scale', 'HSCALE', 'float'),
    '--horizontal-scale': ('--horizontal-scale', 'HSCALE', 'float'),
    '-V': ('--vertical-scale', 'VSCALE', 'float'),
    '--vertical-scale': ('--vertical-scale', 'VSCALE', 'float'),
    '--padding': ('--padding', 'PADDING', 'uint'),
    '--encoding': ('--encoding', 'ENCODING', 'enum'),
}


def parse_args(argv):
    """Returns dict {h_scale, v_scale, padding, encoding, file, subcmd}."""
    # State
    result = {
        'h_scale': 1.0,
        'v_scale': 1.0,
        'padding': None,
        'encoding': 'utf8-lossy',
        'file': None,
        'subcmd': None,
        'sub_shell': None,
        'help': False,
        'version': False,
    }
    seen = set()
    i = 0
    n = len(argv)
    end_of_opts = False
    while i < n:
        a = argv[i]
        if not end_of_opts and a == '--':
            end_of_opts = True
            i += 1
            continue
        if not end_of_opts and a in ('-h', '--help'):
            result['help'] = True
            result['help_target'] = 'top'
            return result
        if not end_of_opts and a == '--version':
            result['version'] = True
            return result
        # Try matching options including =-form and concatenated short form
        if not end_of_opts:
            opt_name = None
            opt_value = None
            consume_next = False
            # Long option with =
            if a.startswith('--') and '=' in a:
                head, sep, val = a.partition('=')
                if head in OPT_DEFS:
                    opt_name = head
                    opt_value = val
            # Long option without =
            elif a.startswith('--') and a in OPT_DEFS:
                opt_name = a
                consume_next = True
            # Short option with =
            elif a.startswith('-') and len(a) >= 2 and not a.startswith('--') and a[1] != '-':
                # -V=value form
                if len(a) >= 3 and a[2] == '=':
                    short = a[:2]
                    if short in OPT_DEFS:
                        opt_name = short
                        opt_value = a[3:]
                # -V1.0 form (concatenated)
                elif len(a) >= 3 and a[:2] in OPT_DEFS:
                    opt_name = a[:2]
                    opt_value = a[2:]
                # plain -V (value next)
                elif a in OPT_DEFS:
                    opt_name = a
                    consume_next = True
            if opt_name is not None:
                long_name, val_name, val_kind = OPT_DEFS[opt_name]
                if consume_next:
                    if i + 1 >= n:
                        raise err_missing_value(long_name, val_name, USAGE_TOP)
                    opt_value = argv[i + 1]
                    i += 1
                if long_name in seen:
                    raise err_dup_arg(long_name, val_name, USAGE_TOP)
                seen.add(long_name)
                if val_kind == 'float':
                    parsed = parse_float(opt_value, long_name, val_name)
                    if long_name == '--horizontal-scale':
                        result['h_scale'] = parsed
                    else:
                        result['v_scale'] = parsed
                elif val_kind == 'uint':
                    result['padding'] = parse_uint(opt_value, long_name, val_name)
                elif val_kind == 'enum':
                    if opt_value not in ENCODING_VALUES:
                        raise err_invalid_enum(opt_value, long_name, val_name,
                                               ENCODING_VALUES)
                    result['encoding'] = opt_value
                i += 1
                continue
            # Unknown flag
            if a.startswith('-') and a != '-':
                raise err_unknown_flag(a, USAGE_TOP)
        # Positional
        if result['subcmd'] is None and result['file'] is None and a in ('completion', 'help'):
            # Subcommand
            result['subcmd'] = a
            rest = argv[i + 1:]
            if a == 'completion':
                _parse_completion(rest, result)
            else:
                _parse_help(rest, result)
            return result
        if result['file'] is None:
            result['file'] = a
        else:
            raise err_unknown_positional(a, USAGE_TOP)
        i += 1
    return result


def _parse_completion(rest, result):
    """Parse `completion <SHELL>` subcommand args."""
    shell = None
    i = 0
    while i < len(rest):
        a = rest[i]
        if a in ('-h', '--help'):
            result['help'] = True
            result['subcmd_help'] = 'completion'
            return
        if a.startswith('-') and a != '-':
            raise err_unknown_flag(a, USAGE_COMPLETION)
        if shell is not None:
            raise err_unknown_positional(a, USAGE_COMPLETION)
        if a not in SHELLS:
            raise err_invalid_enum_shell(a)
        shell = a
        i += 1
    if shell is None:
        raise err_missing_required('SHELL', USAGE_COMPLETION)
    result['sub_shell'] = shell


HELP_HELP_TEXT = """Print this message or the help of the given subcommand(s)

Usage: executable help [COMMAND]...

Arguments:
  [COMMAND]...
          Print help for the subcommand(s)
"""

USAGE_HELP_HELP = "Usage: executable help [COMMAND]..."


def _parse_help(rest, result):
    """Parse `help [COMMAND]...` subcommand recursively.

    Always sets result['help'] = True and result['help_target']; or raises
    CliError for an unrecognized chain.
    """
    result['help'] = True
    if not rest:
        result['help_target'] = 'top'
        return
    first = rest[0]
    sub_rest = rest[1:]
    if first == 'completion':
        if not sub_rest:
            result['help_target'] = 'completion'
            return
        # completion has no subcommands; further args are unrecognized.
        raise err_unrecognized_subcmd(sub_rest[0], USAGE_COMPLETION, footer=True)
    if first == 'help':
        if not sub_rest:
            result['help_target'] = 'help'
            return
        # help has no further subcommands; unrecognized without footer.
        raise err_unrecognized_subcmd(sub_rest[0], USAGE_HELP_HELP, footer=False)
    raise err_unrecognized_subcmd(first, USAGE_TOP, footer=True)


def err_unrecognized_subcmd(name, usage, footer=True):
    body = (
        f"error: unrecognized subcommand '{name}'\n"
        f"\n"
        f"{usage}\n"
    )
    if footer:
        body += "\nFor more information, try '--help'.\n"
    return CliError(body, 2)


def _emit_invalid_enum_shell(value):
    """Error format used by clap for invalid <SHELL>."""
    msg = (
        f"error: invalid value '{value}' for '<SHELL>'\n"
        f"  [possible values: {', '.join(SHELLS)}]\n"
        f"\n"
        f"For more information, try '--help'.\n"
    )
    sys.stderr.write(msg)
    sys.exit(2)


def err_invalid_enum_shell(value):
    return CliError(
        f"error: invalid value '{value}' for '<SHELL>'\n"
        f"  [possible values: {', '.join(SHELLS)}]\n"
        f"\n"
        f"For more information, try '--help'.\n",
        2,
    )


def completion_script(shell):
    """Return the completion script for the given shell."""
    # These are large and shell-specific; load from resource file written next to script.
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, 'completions', f'{shell}.txt')
    with open(path, 'rb') as f:
        return f.read()


def read_input(file_arg):
    if file_arg is None:
        return sys.stdin.buffer.read()
    try:
        with open(file_arg, 'rb') as f:
            return f.read()
    except FileNotFoundError:
        sys.stderr.write("code-minimap: No such file or directory (os error 2)\n")
        sys.exit(1)
    except IsADirectoryError:
        sys.stderr.write("code-minimap: Is a directory (os error 21)\n")
        sys.exit(1)
    except PermissionError:
        sys.stderr.write("code-minimap: Permission denied (os error 13)\n")
        sys.exit(1)
    except OSError as e:
        eno = e.errno or 0
        sys.stderr.write(f"code-minimap: {os.strerror(eno)} (os error {eno})\n")
        sys.exit(1)


def decode(content, encoding):
    if encoding == 'utf8':
        try:
            return content.decode('utf-8')
        except UnicodeDecodeError:
            sys.stderr.write("code-minimap: stream did not contain valid UTF-8\n")
            sys.exit(1)
    return content.decode('utf-8', errors='replace')


def main(argv):
    try:
        args = parse_args(argv[1:])
    except CliError as e:
        # Print to stderr, exit with code
        # Match clap: errors go to stderr; help/version go to stdout (handled separately)
        sys.stderr.write(e.msg)
        sys.exit(e.code)

    if args.get('version'):
        sys.stdout.write(VERSION_TEXT)
        sys.exit(0)
    if args.get('help'):
        target = args.get('help_target')
        if target == 'completion':
            sys.stdout.write(HELP_COMPLETION_TEXT)
        elif target == 'help':
            sys.stdout.write(HELP_HELP_TEXT)
        else:
            sys.stdout.write(HELP_TEXT)
        sys.exit(0)

    if args.get('subcmd') == 'completion':
        shell = args['sub_shell']
        try:
            content = completion_script(shell)
        except OSError:
            sys.stderr.write(f"code-minimap: failed to load completion for {shell}\n")
            sys.exit(1)
        sys.stdout.buffer.write(content)
        sys.exit(0)

    content = read_input(args.get('file'))
    text = decode(content, args.get('encoding'))
    out = render_minimap(text, args['h_scale'], args['v_scale'], args['padding'])
    sys.stdout.write(out)


if __name__ == '__main__':
    main(sys.argv)
