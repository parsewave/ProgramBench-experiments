# Behavior map: code-minimap 0.6.8 (reference: /workspace/executable)

## Top-level CLI

```
Usage: executable [OPTIONS] [FILE] [COMMAND]
```

- Single optional positional FILE; reads stdin if absent.
- `-` as FILE is treated as a literal filename (not stdin).
- Unknown positionals after FILE: clap error "unexpected argument 'X' found" (exit 2).

### Options (clap-style)
- `-H, --horizontal-scale <HSCALE>` float, default 1.0
- `-V, --vertical-scale <VSCALE>` float, default 1.0
- `--padding <PADDING>` u64, default unset
- `--encoding <ENCODING>` enum {utf8-lossy, utf8}, default utf8-lossy
- `--version` flag (short-circuits, prints `code-minimap 0.6.8\n`, exit 0)
- `-h, --help` flag (short-circuits, prints help text, exit 0)

### Flag forms accepted
- `-V 1.0`, `-V=1.0`, `-V1.0`, `--vertical-scale 1.0`, `--vertical-scale=1.0`

### Subcommands
- `completion <SHELL>` SHELL in {bash, elvish, fish, powershell, zsh}
- `help [COMMAND]`

## Output algorithm (default H=V=1.0)

Output is a Braille-character rendering of input lines.

### Line splitting
- Use Rust `str::lines()` semantics: split on `\n` or `\r\n`. A trailing
  newline does NOT produce an extra empty line. `\r` alone in the middle
  of a line is just internal whitespace (not a line separator).
- Empty input (no bytes) → no output, exit 0.

### Per-line dot positions (horizontal axis)
Each line maps to a set of "dot columns" in its Braille row:
- Compute byte offsets of each character (in the lossily-decoded string).
- `first` = byte offset of the FIRST non-whitespace char (None if all WS).
- `last` = byte offset (starting byte) of the LAST non-whitespace char.
- If `first` is None: no dots set; line width contributes 0 cols.
- Otherwise:
  - `dot_col_start = floor(first × H)`
  - `dot_col_end = floor((last + 1) × H) - 1`
  - Fill all dot columns in `[dot_col_start, dot_col_end]` inclusive.
- Whitespace classification uses Unicode WSpace property
  (Rust `char::is_whitespace()`). NBSP, EM SPACE, etc. count as
  whitespace; ZWSP (U+200B) does not.

### Per-line dot row (vertical axis)
- `N` = number of input lines.
- `effective_V = min(V, 1.0)` when V > 0; for V <= 0 or NaN treat as 0
  (collapses all rows to dot_row=0).
- `dot_row[i] = floor(i × effective_V)`.
- All lines mapping to the same dot row OR their dot-column sets together.

### Braille cell layout
Each Braille cell is 2 dot columns wide and 4 dot rows tall.
Dot bit assignments (cell value = U+2800 + bits):
- Row 0 col 0 → dot 1 → bit 0
- Row 1 col 0 → dot 2 → bit 1
- Row 2 col 0 → dot 3 → bit 2
- Row 0 col 1 → dot 4 → bit 3
- Row 1 col 1 → dot 5 → bit 4
- Row 2 col 1 → dot 6 → bit 5
- Row 3 col 0 → dot 7 → bit 6
- Row 3 col 1 → dot 8 → bit 7

### Output rows
- Number of Braille rows = `ceil((max(dot_row[i]) + 1) / 4)`, but at
  least 1 row if any input line exists.
- Each Braille row has its own width determined by the maximum
  `dot_col_end + 1` across lines mapping to that row.
- A Braille row that has no dot columns still emits 1 empty cell `⠀`.

### Padding
- `--padding N` pads each Braille row with U+0020 spaces so its total
  character count (Braille cells + spaces) is at least N.
- Padding only adds spaces; it does not trim if row is already wider.

### Encoding
- `utf8-lossy` (default): invalid UTF-8 bytes are replaced by
  U+FFFD before processing (each replacement is 3 bytes in UTF-8).
- `utf8`: invalid bytes → "code-minimap: stream did not contain valid
  UTF-8\n" on stderr, exit 1, no stdout.

## Error / edge-case bytes

### Help / version
- `--help`, `-h`, `help` all print the full help text (711 bytes
  captured) to stdout; exit 0. See `goldens/help.txt`.
- `--version` prints `code-minimap 0.6.8\n`; exit 0.
- `help completion` prints completion subcommand help; exit 0.

### Missing file / "-"
- Any file argument that fails to open → stderr:
  `code-minimap: No such file or directory (os error 2)\n`
  exit 1, no stdout (well, maybe partial — verified no stdout for missing).

### Clap errors (exit 2)
All match the standard clap v4 format:
- Unknown flag: `error: unexpected argument '--bogus' found\n\n  tip: to pass '--bogus' as a value, use '-- --bogus'\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n`
- Extra positional: `error: unexpected argument 'X' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n`
- Missing value: `error: a value is required for '--vertical-scale <VSCALE>' but none was supplied\n\nFor more information, try '--help'.\n`
- Bad value: `error: invalid value 'abc' for '--vertical-scale <VSCALE>': invalid float literal\n\nFor more information, try '--help'.\n`
- Bad enum: `error: invalid value 'xyz' for '--encoding <ENCODING>'\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.\n`
- Duplicate flag: `error: the argument '--horizontal-scale <HSCALE>' cannot be used multiple times\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n`
- `completion` no shell: `error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completion <SHELL>\n\nFor more information, try '--help'.\n`

### Edge cases
- Empty input (zero bytes): no output, exit 0.
- Empty line input `"\n"`: emits `⠀\n`.
- All-whitespace input: emits `⠀\n` row(s).
- H = 0 or close to 0: 0 dot cols → empty line `\n` (per Braille row).
- H = inf: Rust panics. (Don't replicate — just don't crash.)
- H, V = NaN or negative: total dot cols / rows become 0 (no dots), but
  each non-empty row still emits 1 empty cell.
- `-H`/`-V` with no value: clap error.
- `--padding` with non-digit: clap error.

## Numbers and rounding
- Floor division (`floor`) for all integer dot positions.
- Float parser accepts: `1`, `1.0`, `1.5`, `1e3`, `inf`, `NaN`, `0.0`,
  `1.0e3`, etc. (Rust's f64 parser.)
- Integer parser for padding: u64-like.

## Outputs always end with LF (`\n`)
- Each Braille row ends with `\n`.
- Help, version, errors all end with `\n`.
- Empty stdin → empty output (no final `\n`).
