#!/bin/sh
# Produce /work/work/executable: a tiny wrapper that runs main.py via python3.
set -e
cd "$(dirname "$0")"
cat > executable <<'EOF'
#!/bin/sh
exec /usr/bin/env python3 "$(dirname "$0")/main.py" "$@"
EOF
chmod +x executable
