#!/bin/bash
# Differential testing harness: compares reference and reimpl on a list of probes.
# Usage: ./diff_test.sh
set -u

REF="/workspace/executable"
SUT="/work/work/executable"
PASS=0
FAIL=0
FAILED_TESTS=()

run_test() {
    local name="$1"
    shift
    local stdin_data="${1:-}"
    shift || true
    local args=("$@")

    local ref_stdout ref_stderr ref_exit
    local sut_stdout sut_stderr sut_exit

    ref_stdout=$(mktemp)
    ref_stderr=$(mktemp)
    sut_stdout=$(mktemp)
    sut_stderr=$(mktemp)

    printf '%s' "$stdin_data" | timeout 5 "$REF" "${args[@]}" > "$ref_stdout" 2> "$ref_stderr"
    ref_exit=$?
    printf '%s' "$stdin_data" | timeout 5 "$SUT" "${args[@]}" > "$sut_stdout" 2> "$sut_stderr"
    sut_exit=$?

    if [[ "$ref_exit" -eq "$sut_exit" ]] && cmp -s "$ref_stdout" "$sut_stdout" && cmp -s "$ref_stderr" "$sut_stderr"; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$name")
        echo "FAIL: $name"
        echo "  args: ${args[*]}"
        echo "  ref_exit=$ref_exit, sut_exit=$sut_exit"
        if ! cmp -s "$ref_stdout" "$sut_stdout"; then
            echo "  --- stdout diff ---"
            diff <(od -An -tx1 -w200 "$ref_stdout") <(od -An -tx1 -w200 "$sut_stdout") | head -20
        fi
        if ! cmp -s "$ref_stderr" "$sut_stderr"; then
            echo "  --- stderr diff ---"
            diff "$ref_stderr" "$sut_stderr" | head -10
        fi
    fi
    rm -f "$ref_stdout" "$ref_stderr" "$sut_stdout" "$sut_stderr"
}

# Test cases
run_test "empty"          ""
run_test "abc"            "abc"
run_test "10 bytes"       "abcdefghij"
run_test "tiny.bin file"  "" /workspace/assets/tiny.bin
run_test "26 bytes"       "abcdefghijklmnopqrstuvwxyz"
run_test "high bytes"     "$(printf '\x00\x01\x80\xff')"

# Format
run_test "-f o"           "abc" -f o
run_test "-f x"           "abc" -f x
run_test "-f X"           "$(printf '\xab\xcd')" -f X
run_test "-f b"           "abc" -f b

# Prefix
run_test "-r 0"           "abc" -r 0
run_test "-r 1"           "abc" -r 1
run_test "-r 0 -f X"      "$(printf '\xab\xcd')" -r 0 -f X
run_test "-r 0 -f o"      "abc" -r 0 -f o
run_test "-r 0 -f b"      "abc" -r 0 -f b

# Cols
run_test "-c 5"           "abcdefghij" -c 5
run_test "-c 1"           "abc" -c 1
run_test "-c 0"           "abc" -c 0
run_test "-c 0 empty"     "" -c 0
run_test "-c 100"         "abc" -c 100

# Len
run_test "-l 5"           "abcdefghij" -l 5
run_test "-l 0"           "abc" -l 0
run_test "-l 100"         "abc" -l 100

# Color
run_test "-t 0"           "abc" -t 0
run_test "-t 1"           "abc" -t 1
run_test "-t 1 high"      "$(printf '\x00\x01\xff')" -t 1

# Array
run_test "-a r"           "abc" -a r
run_test "-a c"           "abc" -a c
run_test "-a g"           "abc" -a g
run_test "-a p"           "abc" -a p
run_test "-a k"           "abc" -a k
run_test "-a j"           "abc" -a j
run_test "-a s"           "abc" -a s
run_test "-a f"           "abc" -a f
run_test "-a r empty"     "" -a r
run_test "-a g 6 c=6"     "abcdef" -a g -c 6
run_test "-a r 10 c=10"   "abcdefghij" -a r
run_test "-a r 26 c=10"   "abcdefghijklmnopqrstuvwxyz" -a r
run_test "-a r 26 c=5"    "abcdefghijklmnopqrstuvwxyz" -a r -c 5
run_test "-a r 26 c=3"    "abcdefghijklmnopqrstuvwxyz" -a r -c 3

# Func wave
run_test "-u 5"           "" -u 5
run_test "-u 5 -p 3"      "" -u 5 -p 3
run_test "-u 1"           "" -u 1
run_test "-u 0"           "" -u 0
run_test "-u 10 -p 3"     "" -u 10 -p 3
run_test "-u 20 -p 3"     "" -u 20 -p 3
run_test "-u 11 -p 3"     "" -u 11 -p 3
run_test "-u 100 -p 1"    "" -u 100 -p 1
run_test "-u 3 -p 20"     "" -u 3 -p 20
run_test "-u 3 -p 0"      "" -u 3 -p 0

# Errors
run_test "err -f Q"       "" -f Q
run_test "err -c abc"     "" -c abc
run_test "err -l xyz"     "" -l xyz
run_test "err -u q"       "" -u q
run_test "err -a Q"       "" -a Q
run_test "err nofile"     "" /nonexistent

# Help / version
run_test "help"           "" --help
run_test "version"        "" --version
run_test "-h"             "" -h
run_test "-V"             "" -V

# Combinations
run_test "-c 5 -f b"      "abc" -c 5 -f b
run_test "-c 2 -f b 3by"  "abc" -c 2 -f b
run_test "-a r -l 2"      "abc" -a r -l 2
run_test "-a g -c 3"      "abcdefghijklmnopqrstuvwxyz" -a g -c 3
run_test "-c 1 -t 1"      "abc" -c 1 -t 1
run_test "-u 5 -p 3 -a r" "" -u 5 -p 3 -a r

echo ""
echo "PASS: $PASS / FAIL: $FAIL"
