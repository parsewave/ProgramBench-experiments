#!/bin/bash
# Comprehensive differential test using files for binary input.
set -u

REF="/workspace/executable"
SUT="/work/work/executable"
PASS=0
FAIL=0
FAILED_TESTS=()

# Create test data files
mkdir -p /tmp/hxtest
cd /tmp/hxtest
printf '' > empty.bin
printf 'a' > one.bin
printf 'ab' > two.bin
printf 'abc' > three.bin
printf 'abcdefghij' > ten.bin
printf 'abcdefghijklmnopqrstuvwxyz' > alpha.bin
printf '\x00\x01\x02\xfd\xfe\xff' > extreme.bin
printf '\x00' > nul.bin
printf '\xff' > high.bin
printf '\x7f\x80\x20\x21\x7e' > border.bin
printf 'hello\nworld\n' > nl.bin
# 256 byte values
python3 -c "import sys; sys.stdout.buffer.write(bytes(range(256)))" > all256.bin

run_test() {
    local name="$1"
    shift
    local stdin_file="$1"
    shift
    local args=("$@")

    local ref_stdout ref_stderr ref_exit
    local sut_stdout sut_stderr sut_exit

    ref_stdout=$(mktemp)
    ref_stderr=$(mktemp)
    sut_stdout=$(mktemp)
    sut_stderr=$(mktemp)

    timeout 5 "$REF" "${args[@]}" < "$stdin_file" > "$ref_stdout" 2> "$ref_stderr"
    ref_exit=$?
    timeout 5 "$SUT" "${args[@]}" < "$stdin_file" > "$sut_stdout" 2> "$sut_stderr"
    sut_exit=$?

    if [[ "$ref_exit" -eq "$sut_exit" ]] && cmp -s "$ref_stdout" "$sut_stdout" && cmp -s "$ref_stderr" "$sut_stderr"; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$name")
        echo "FAIL: $name | args: ${args[*]} | stdin: $stdin_file"
        echo "  ref_exit=$ref_exit, sut_exit=$sut_exit"
        if ! cmp -s "$ref_stdout" "$sut_stdout"; then
            echo "  --- stdout diff (first 200 bytes hex) ---"
            diff <(od -An -tx1 -w100 "$ref_stdout" | head -3) <(od -An -tx1 -w100 "$sut_stdout" | head -3)
        fi
        if ! cmp -s "$ref_stderr" "$sut_stderr"; then
            echo "  --- stderr diff ---"
            diff "$ref_stderr" "$sut_stderr" | head -10
        fi
    fi
    rm -f "$ref_stdout" "$ref_stderr" "$sut_stdout" "$sut_stderr"
}

# Basic
for f in empty one two three ten alpha extreme nul high border nl all256; do
    run_test "basic $f"  /tmp/hxtest/$f.bin
done

# Format combinations
for fmt in o x X b; do
    for f in empty one three ten alpha extreme all256; do
        run_test "$f -f $fmt"  /tmp/hxtest/$f.bin -f "$fmt"
    done
done

# Prefix
for p in 0 1; do
    for f in three ten extreme; do
        run_test "$f -r $p"  /tmp/hxtest/$f.bin -r "$p"
    done
    for fmt in o x X b; do
        for f in three extreme; do
            run_test "$f -r $p -f $fmt"  /tmp/hxtest/$f.bin -r "$p" -f "$fmt"
        done
    done
done

# Cols
for c in 0 1 2 3 5 7 10 16 20 32; do
    for f in empty three ten alpha all256; do
        run_test "$f -c $c"  /tmp/hxtest/$f.bin -c "$c"
    done
done

# Len
for l in 0 1 2 3 5 10 100 1000; do
    for f in three ten alpha all256; do
        run_test "$f -l $l"  /tmp/hxtest/$f.bin -l "$l"
    done
done

# Color
for t in 0 1; do
    for f in empty three ten extreme all256; do
        run_test "$f -t $t"  /tmp/hxtest/$f.bin -t "$t"
    done
done

# Array
for lang in r c g p k j s f; do
    for f in empty one three ten alpha; do
        run_test "$f -a $lang"  /tmp/hxtest/$f.bin -a "$lang"
    done
    for c in 0 1 3 5 10 26; do
        run_test "alpha -a $lang -c $c"  /tmp/hxtest/alpha.bin -a "$lang" -c "$c"
    done
done

# Func wave
for u in 0 1 2 3 5 10 11 20 50 100; do
    for p in 0 1 2 3 4 5 10; do
        run_test "func u=$u p=$p"  /tmp/hxtest/empty.bin -u "$u" -p "$p"
    done
done

# Just -u (no -p)
for u in 1 5 10 20; do
    run_test "func u=$u no p"  /tmp/hxtest/empty.bin -u "$u"
done

# All format + prefix combinations with all256
for fmt in o x X b; do
    for p in 0 1; do
        run_test "all256 -f $fmt -r $p"  /tmp/hxtest/all256.bin -f "$fmt" -r "$p"
    done
done

# Combinations
run_test "complex 1"  /tmp/hxtest/alpha.bin -c 8 -f b -r 0 -l 16
run_test "complex 2"  /tmp/hxtest/all256.bin -c 16 -f X -r 1 -t 0
run_test "complex 3"  /tmp/hxtest/all256.bin -c 4 -f o -r 0
run_test "complex 4"  /tmp/hxtest/alpha.bin -a c -c 4 -l 12

# File arg + flags
run_test "file arg + flags"  /tmp/hxtest/empty.bin -c 5 /tmp/hxtest/alpha.bin

# Errors
run_test "err -f Q"      /tmp/hxtest/empty.bin -f Q
run_test "err -c abc"    /tmp/hxtest/empty.bin -c abc
run_test "err -l xyz"    /tmp/hxtest/empty.bin -l xyz
run_test "err -u q"      /tmp/hxtest/empty.bin -u q
run_test "err -a Q"      /tmp/hxtest/empty.bin -a Q
run_test "err -t 2"      /tmp/hxtest/empty.bin -t 2
run_test "err -r 2"      /tmp/hxtest/empty.bin -r 2
run_test "err nofile"    /tmp/hxtest/empty.bin /nonexistent

# Help / version
run_test "--help"        /tmp/hxtest/empty.bin --help
run_test "--version"     /tmp/hxtest/empty.bin --version
run_test "-h"            /tmp/hxtest/empty.bin -h
run_test "-V"            /tmp/hxtest/empty.bin -V

echo ""
echo "PASS: $PASS / FAIL: $FAIL"
if [[ $FAIL -gt 0 ]]; then
    echo "Failed tests:"
    printf '  - %s\n' "${FAILED_TESTS[@]}"
fi
