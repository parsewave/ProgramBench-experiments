# hx 0.7.0 — behavior spec (clean-room derived)

## Modes

The binary has three operating modes, evaluated in this priority order:

1. **func wave mode** (when `-u/--func` is given): always wins, ignores all input.
2. **array mode** (when `-a/--array` is given and no `-u`).
3. **hex dump mode** (default).

## CLI

Built with clap 4.x (`Usage: executable [OPTIONS] [INPUTFILE]`). Options in this order:

- `-c, --cols <columns>` — column length (string; lazily parsed to int when needed)
- `-l, --len <len>` — bytes to read (string; lazily parsed)
- `-f, --format <format>` — `{o, x, X, b}`, clap-validated possible values
- `-t, --color <color>` — `{0, 1}`, clap-validated possible values
- `-a, --array <array_format>` — `{r, c, g, p, k, j, s, f}`, clap-validated possible values
- `-u, --func <func_length>` — string; lazily parsed
- `-p, --places <func_places>` — string; lazily parsed (only when -u set)
- `-r, --prefix <prefix>` — `{0, 1}`, clap-validated possible values
- `-h, --help` / `-V, --version` — clap defaults
- positional `[INPUTFILE]` — optional

`about`: `"Futuristic take on hexdump, made in Rust.\n"` (trailing newline produces
2 blank lines between description and Usage in `--help`).

### Integer parse errors (lazy)

When -c, -l, -u, -p with non-integer values, AND the mode actually uses that
flag, the binary emits (to stderr) then exits 1:
```
-X, --name <integer> expected. ParseIntError { kind: InvalidDigit }
error: invalid digit found in string
```

When the flag's value isn't used by the mode (e.g., `-c abc -u 5`), no parse
error is raised. So:
- func wave mode uses: -u, -p (also -t for color, but -t is clap-validated)
- array mode uses: -a, -c, -l (also -t)
- hex mode uses: -c, -l, -f, -t, -r

### Clap-validated invalid values

Exit 2, stderr like:
```
error: invalid value 'Q' for '--format <format>'
  [possible values: o, x, X, b]

For more information, try '--help'.
```

### Missing file

Exit 1, stderr: `error: No such file or directory (os error 2)`

## Input source

- If an `[INPUTFILE]` positional arg is given: read from that file.
- Else: read from stdin.
- Then apply `-l N` truncation (if N > 0; default reads all).

`-l 0` is treated as "no limit" — reads all input.

## Color decision

- If `-t` given: explicit win (`-t 1` → ON, `-t 0` → OFF).
- Else: ON iff stdout is a TTY AND NO_COLOR env var is unset OR empty.

Array mode and func wave mode never emit color regardless of -t.

### Color escape

Each byte is wrapped: `\x1b[38;5;{N}m{TEXT}\x1b[0m`

Color index N = byte value (decimal), **except** byte 0x00 → N = 22.

Color is applied to both the hex slot AND the ASCII rendering of that byte.

## Hex dump mode

Layout per line:

```
0x{addr:06x}: {byte_slots} {ascii}
```

Where:
- Address: 9 chars total — `"0x"` + 6 lowercase hex digits + `:`.
- After address: 1 space.
- Then `cols` byte slots, each of width depending on format/prefix:
  - hex (x/X), prefix=1: 5 chars (`0xXX `)
  - hex (x/X), prefix=0: 3 chars (`XX `)
  - octal (o), prefix=1: 7 chars (`0oXXXX `)
  - octal (o), prefix=0: 5 chars (`XXXX `)
  - binary (b), prefix=1: 11 chars (`0bXXXXXXXX `)
  - binary (b), prefix=0: 9 chars (`XXXXXXXX `)
- Each filled slot includes one trailing space (part of the slot width).
- Each EMPTY slot is **always 5 chars of spaces**, regardless of format.
- ASCII chars come immediately after the slots (no extra separator).
- ASCII chars only for bytes present; non-printable (< 0x20 or > 0x7e) → `.`
- Line terminated by `\n`.

### Trailing empty line

If `data_length % cols == 0` (including data_length == 0), an extra "empty" line
is emitted at address `data_length`:
- normal case: `"0x{addr:06x}: " + (cols × 5 spaces)\n`
- special case `cols == 0`: just `"0x{addr:06x}: \n"` (no slots).

### Footer

`   bytes: {N}\n` (3 leading spaces + `bytes: ` + integer + newline)

### Address formatting

Lowercase hex, 6 digits zero-padded. Default cols=10. The address still uses
lowercase even with `-f X`.

### `cols == 0` quirk

In hex dump mode, `cols == 0` is treated as 1 for emitting data lines, but the
empty trailing line uses 0 slots (just `0x000003: \n`).

In array mode, `cols == 0` is treated as 1 for wrapping, but the trailing
"empty content line" always fires (since data_len % 1 == 0).

## Array mode

Templates (open / item / close):
- `r` (rust):    `let ARRAY: [u8; {N}] = [\n` ... `\n];\n`     (sep: `, `, item: `0x{b:02x}`)
- `c` (C):       `unsigned char ARRAY[{N}] = {\n` ... `\n};\n` (sep: `, `, item: `0x{b:02x}`)
- `g` (golang):  `a := [{N}]byte{\n` ... `\n}\n`               (sep: `, `, item: `0x{b:02x}`, **trailing sep always**)
- `p` (python):  `a = [\n` ... `\n]\n`                          (sep: `, `, item: `0x{b:02x}`)
- `k` (kotlin):  `val a = byteArrayOf(\n` ... `\n)\n`           (sep: `, `, item: `0x{b:02x}`)
- `j` (java):    `byte[] a = new byte[]{\n` ... `\n};\n`        (sep: `, `, item: `0x{b:02x}`)
- `s` (swift):   `let a: [UInt8] = [\n` ... `\n]\n`             (sep: `, `, item: `0x{b:02x}`)
- `f` (fsharp):  `let a = [|\n` ... `\n|]\n`                    (sep: `; `, item: `0x{b:02x}uy`)

### Wrapping rule (per line)

- Each line starts with `    ` (4 spaces indent).
- Items joined by separator (`, ` or `; ` for fsharp).
- Lines wrap every `cols` items (default cols=10).
- Non-last lines end with `<sep>\n` (trailing separator + newline).
- The last item:
  - If golang: trailing separator always (`0xXX, ` then `\n`).
  - Else: no trailing separator (just `0xXX\n`).
- If `data_length == 0` OR `data_length % cols == 0`, an extra empty
  content line `    \n` is emitted before the closing.

### Body always lowercase 0x hex

`-f`, `-r`, `-t` flags are ignored in array mode. Bytes always formatted as
`0x{b:02x}`. No color escapes.

## Func wave mode

Computes `sin(π * i / (2 * u))` as f64 for `i = 0..u-1`, formats each with `p`
decimal places (Rust's `{:.p}`), separates by `,` (no space), wraps every 10
values with `\n`.

- Default `p = 4`.
- Each value followed by `,` immediately (no space).
- After every 10th value during the loop, emit `\n`.
- Always emit `\n` at end (one final newline), unless we just emitted one.
- Equivalent algorithm:
  ```
  for i in 0..u:
      print value + ","
      if (i + 1) % 10 == 0 and i < u - 1:
          print "\n"
  print "\n"
  ```
- `u == 0` → output is just `\n`.

Never colored. Ignores file argument and stdin.

## NO_COLOR / TTY

- `-t 0` → no color (overrides everything).
- `-t 1` → color (overrides NO_COLOR / TTY).
- No `-t`:
  - If stdout is not a TTY → no color.
  - Else if NO_COLOR env var is set and non-empty → no color.
  - Else → color.

## Byte values, character classes

- Address: lowercase hex `0x000000` to `0xffffff` (6 digits).
- Format X: uppercase hex `0xAB`.
- Format x: lowercase hex `0xab`.
- Format o: octal `0o0141` (4 digits, leading zeros).
- Format b: binary `0b01100001` (8 digits, leading zeros).
- ASCII printable range: 0x20 .. 0x7e (inclusive). Outside → `.`.
- 0x7f (DEL) → `.` (non-printable).
