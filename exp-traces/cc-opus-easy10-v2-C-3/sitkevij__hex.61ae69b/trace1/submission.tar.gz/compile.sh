#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PATH="/usr/local/cargo/bin:$PATH"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export RUSTUP_HOME="${RUSTUP_HOME:-/usr/local/rustup}"
cargo build --release --offline --target-dir target
cp target/release/executable ./executable
chmod +x ./executable
