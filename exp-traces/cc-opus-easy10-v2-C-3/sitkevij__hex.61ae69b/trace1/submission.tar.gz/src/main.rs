use clap::{Arg, ArgMatches, Command};
use std::env;
use std::fs::File;
use std::io::{self, IsTerminal, Read, Write};
use std::process::ExitCode;

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::from(0),
        Err(code) => ExitCode::from(code),
    }
}

fn build_cli() -> Command {
    Command::new("hx")
        .version("0.7.0")
        .about("Futuristic take on hexdump, made in Rust.\n")
        .arg(
            Arg::new("cols")
                .short('c')
                .long("cols")
                .value_name("columns")
                .help("Set column length")
                .num_args(1),
        )
        .arg(
            Arg::new("len")
                .short('l')
                .long("len")
                .value_name("len")
                .help("Set <len> bytes to read")
                .num_args(1),
        )
        .arg(
            Arg::new("format")
                .short('f')
                .long("format")
                .value_name("format")
                .help("Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b)")
                .num_args(1)
                .value_parser(["o", "x", "X", "b"]),
        )
        .arg(
            Arg::new("color")
                .short('t')
                .long("color")
                .value_name("color")
                .help("Set color tint terminal output. 0 to disable, 1 to enable")
                .num_args(1)
                .value_parser(["0", "1"]),
        )
        .arg(
            Arg::new("array")
                .short('a')
                .long("array")
                .value_name("array_format")
                .help("Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f)")
                .num_args(1)
                .value_parser(["r", "c", "g", "p", "k", "j", "s", "f"]),
        )
        .arg(
            Arg::new("func")
                .short('u')
                .long("func")
                .value_name("func_length")
                .help("Set function wave length")
                .num_args(1),
        )
        .arg(
            Arg::new("places")
                .short('p')
                .long("places")
                .value_name("func_places")
                .help("Set function wave output decimal places")
                .num_args(1),
        )
        .arg(
            Arg::new("prefix")
                .short('r')
                .long("prefix")
                .value_name("prefix")
                .help("Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable")
                .num_args(1)
                .value_parser(["0", "1"]),
        )
        .arg(
            Arg::new("inputfile")
                .value_name("INPUTFILE")
                .help("Pass file path as an argument, or input data may be passed via stdin")
                .num_args(0..=1),
        )
}

fn run() -> Result<(), u8> {
    let matches = build_cli().try_get_matches().map_err(|e| {
        let _ = e.print();
        match e.kind() {
            clap::error::ErrorKind::DisplayHelp | clap::error::ErrorKind::DisplayVersion => 0u8,
            _ => 2u8,
        }
    })?;

    // Func wave mode: highest priority
    if let Some(u_str) = matches.get_one::<String>("func") {
        let u: u64 = parse_int(u_str, "-u, --func")?;
        let p: u64 = match matches.get_one::<String>("places") {
            Some(p_str) => parse_int(p_str, "-p, --places")?,
            None => 4,
        };
        print_func_wave(u, p as usize);
        return Ok(());
    }

    // Parse cols (used by both array and hex dump modes)
    let cols: u64 = match matches.get_one::<String>("cols") {
        Some(c_str) => parse_int(c_str, "-c, --cols")?,
        None => 10,
    };

    // Parse len
    let len: u64 = match matches.get_one::<String>("len") {
        Some(l_str) => parse_int(l_str, "-l, --len")?,
        None => 0,
    };

    // Read input
    let data = read_input(&matches, len)?;

    // Array mode
    if let Some(array_fmt) = matches.get_one::<String>("array") {
        print_array(&data, array_fmt.as_str(), cols as usize);
        return Ok(());
    }

    // Default hex dump
    let format = matches
        .get_one::<String>("format")
        .map(String::as_str)
        .unwrap_or("x");
    let prefix_on = matches
        .get_one::<String>("prefix")
        .map(|s| s == "1")
        .unwrap_or(true);
    let color_on = decide_color(&matches);

    print_hexdump(&data, cols as usize, format, prefix_on, color_on);
    Ok(())
}

fn parse_int(s: &str, name: &str) -> Result<u64, u8> {
    match s.parse::<u64>() {
        Ok(n) => Ok(n),
        Err(e) => {
            eprintln!("{} <integer> expected. {:?}", name, e);
            eprintln!("error: {}", e);
            Err(1)
        }
    }
}

fn read_input(matches: &ArgMatches, len: u64) -> Result<Vec<u8>, u8> {
    let mut data = Vec::new();
    if let Some(path) = matches.get_one::<String>("inputfile") {
        let mut f = match File::open(path) {
            Ok(f) => f,
            Err(e) => {
                eprintln!("error: {}", e);
                return Err(1);
            }
        };
        if let Err(e) = f.read_to_end(&mut data) {
            eprintln!("error: {}", e);
            return Err(1);
        }
    } else if let Err(e) = io::stdin().read_to_end(&mut data) {
        eprintln!("error: {}", e);
        return Err(1);
    }

    if len > 0 && (len as usize) < data.len() {
        data.truncate(len as usize);
    }

    Ok(data)
}

fn decide_color(matches: &ArgMatches) -> bool {
    if let Some(c) = matches.get_one::<String>("color") {
        return c == "1";
    }
    if !io::stdout().is_terminal() {
        return false;
    }
    match env::var("NO_COLOR") {
        Ok(s) if !s.is_empty() => false,
        _ => true,
    }
}

fn color_for_byte(b: u8) -> u8 {
    if b == 0 {
        22
    } else {
        b
    }
}

fn ascii_repr(b: u8) -> char {
    if (0x20..=0x7e).contains(&b) {
        b as char
    } else {
        '.'
    }
}

fn print_hexdump(data: &[u8], cols: usize, format: &str, prefix_on: bool, color_on: bool) {
    let stdout = io::stdout();
    let mut out = stdout.lock();
    let _ = print_hexdump_to(&mut out, data, cols, format, prefix_on, color_on);
    let _ = out.flush();
}

fn print_hexdump_to<W: Write>(
    out: &mut W,
    data: &[u8],
    cols: usize,
    format: &str,
    prefix_on: bool,
    color_on: bool,
) -> io::Result<()> {
    // cols == 0 is treated as cols == 1 for data lines, but the trailing empty
    // line uses 0 slots. We handle this by using effective_cols=1 for iterating,
    // and emitting an empty line with cols=0 at the end if needed.
    let effective_cols = if cols == 0 { 1 } else { cols };

    let total = data.len();
    let mut i: usize = 0;
    while i < total {
        let chunk_end = (i + effective_cols).min(total);
        write!(out, "0x{:06x}: ", i)?;
        // Hex slots
        for slot in 0..effective_cols {
            let pos = i + slot;
            if pos < chunk_end {
                let b = data[pos];
                emit_byte_slot(out, b, format, prefix_on, color_on, slot == effective_cols - 1)?;
            } else {
                // Empty slot: always 5 chars of spaces
                write!(out, "     ")?;
            }
        }
        // ASCII representation
        for slot in 0..effective_cols {
            let pos = i + slot;
            if pos < chunk_end {
                let b = data[pos];
                emit_ascii(out, b, color_on)?;
            }
            // No padding for empty ASCII slots
        }
        writeln!(out)?;
        i = chunk_end;
    }

    // Trailing empty line if data ended exactly at a cols boundary
    if cols == 0 || total % cols == 0 {
        write!(out, "0x{:06x}: ", total)?;
        // If cols == 0, no slot output. Else: cols empty slots (5 spaces each).
        if cols != 0 {
            for _ in 0..cols {
                write!(out, "     ")?;
            }
        }
        writeln!(out)?;
    }

    writeln!(out, "   bytes: {}", total)?;
    Ok(())
}

fn emit_byte_slot<W: Write>(
    out: &mut W,
    b: u8,
    format: &str,
    prefix_on: bool,
    color_on: bool,
    _is_last: bool,
) -> io::Result<()> {
    let color = color_for_byte(b);
    let prefix = if prefix_on {
        match format {
            "o" => "0o",
            "b" => "0b",
            _ => "0x",
        }
    } else {
        ""
    };

    if color_on {
        write!(out, "\x1b[38;5;{}m", color)?;
    }
    match format {
        "o" => write!(out, "{}{:04o}", prefix, b)?,
        "X" => write!(out, "{}{:02X}", prefix, b)?,
        "b" => write!(out, "{}{:08b}", prefix, b)?,
        _ => write!(out, "{}{:02x}", prefix, b)?,
    }
    if color_on {
        write!(out, "\x1b[0m")?;
    }
    write!(out, " ")?;
    Ok(())
}

fn emit_ascii<W: Write>(out: &mut W, b: u8, color_on: bool) -> io::Result<()> {
    let c = ascii_repr(b);
    if color_on {
        write!(out, "\x1b[38;5;{}m{}\x1b[0m", color_for_byte(b), c)?;
    } else {
        write!(out, "{}", c)?;
    }
    Ok(())
}

fn print_array(data: &[u8], lang: &str, cols: usize) {
    let stdout = io::stdout();
    let mut out = stdout.lock();
    let _ = print_array_to(&mut out, data, lang, cols);
    let _ = out.flush();
}

fn print_array_to<W: Write>(out: &mut W, data: &[u8], lang: &str, cols: usize) -> io::Result<()> {
    let n = data.len();
    // Header, footer, separator, item format
    let (header, footer, sep, item_fmt): (String, &str, &str, &str) = match lang {
        "r" => (format!("let ARRAY: [u8; {}] = [\n", n), "];\n", ", ", "0xRR"),
        "c" => (format!("unsigned char ARRAY[{}] = {{\n", n), "};\n", ", ", "0xRR"),
        "g" => (format!("a := [{}]byte{{\n", n), "}\n", ", ", "0xRR"),
        "p" => ("a = [\n".to_string(), "]\n", ", ", "0xRR"),
        "k" => ("val a = byteArrayOf(\n".to_string(), ")\n", ", ", "0xRR"),
        "j" => ("byte[] a = new byte[]{\n".to_string(), "};\n", ", ", "0xRR"),
        "s" => ("let a: [UInt8] = [\n".to_string(), "]\n", ", ", "0xRR"),
        "f" => ("let a = [|\n".to_string(), "|]\n", "; ", "0xRRuy"),
        _ => unreachable!(),
    };

    out.write_all(header.as_bytes())?;

    let always_trail = lang == "g";
    let effective_cols = if cols == 0 { 1 } else { cols };

    // Emit items
    for i in 0..n {
        if i % effective_cols == 0 {
            out.write_all(b"    ")?;
        }
        let item = format_item(data[i], item_fmt);
        out.write_all(item.as_bytes())?;
        let is_last = i == n - 1;
        if !is_last || always_trail {
            out.write_all(sep.as_bytes())?;
        }
        if (i + 1) % effective_cols == 0 && !is_last {
            out.write_all(b"\n")?;
        }
    }

    if n == 0 || n % effective_cols == 0 {
        // Trailing empty content line
        if n > 0 {
            out.write_all(b"\n")?;
        }
        out.write_all(b"    \n")?;
    } else {
        out.write_all(b"\n")?;
    }

    out.write_all(footer.as_bytes())?;
    Ok(())
}

fn format_item(b: u8, fmt: &str) -> String {
    match fmt {
        "0xRRuy" => format!("0x{:02x}uy", b),
        _ => format!("0x{:02x}", b),
    }
}

fn print_func_wave(u: u64, p: usize) {
    let stdout = io::stdout();
    let mut out = stdout.lock();
    let _ = print_func_wave_to(&mut out, u, p);
    let _ = out.flush();
}

fn print_func_wave_to<W: Write>(out: &mut W, u: u64, p: usize) -> io::Result<()> {
    use std::f64::consts::PI;
    let denom = 2.0 * (u as f64);
    for i in 0..u {
        let x = PI * (i as f64) / denom;
        let v = x.sin();
        write!(out, "{:.*},", p, v)?;
        if (i + 1) % 10 == 0 {
            out.write_all(b"\n")?;
        }
    }
    out.write_all(b"\n")?;
    Ok(())
}
