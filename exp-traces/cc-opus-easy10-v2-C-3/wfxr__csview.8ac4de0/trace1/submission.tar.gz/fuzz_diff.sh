#!/usr/bin/env bash
# Fuzz comparison between reference and SUT.
# Generates random inputs/args and checks both produce identical output.
set -u

REF=${REF_BIN:-/workspace/executable}
SUT=${SUT:-/work/work/executable}

PASS=0
FAIL=0
FAILED_INPUTS=()

run_one() {
  local input="$1"; shift
  local args=("$@")
  printf '%s' "$input" | timeout 5 "$REF" "${args[@]}" > /tmp/ref_out 2> /tmp/ref_err
  local ref_exit=$?
  printf '%s' "$input" | timeout 5 "$SUT" "${args[@]}" > /tmp/sut_out 2> /tmp/sut_err
  local sut_exit=$?
  if cmp -s /tmp/ref_out /tmp/sut_out && cmp -s /tmp/ref_err /tmp/sut_err && [ "$ref_exit" = "$sut_exit" ]; then
    PASS=$((PASS+1))
  else
    FAIL=$((FAIL+1))
    if [ "${VERBOSE:-0}" = "1" ]; then
      echo "FAIL: args=(${args[*]}) input=$(printf '%q' "$input")"
      echo "  ref_exit=$ref_exit, sut_exit=$sut_exit"
      diff /tmp/ref_out /tmp/sut_out | head -10 | sed 's/^/    /'
      diff /tmp/ref_err /tmp/sut_err | head -5 | sed 's/^/    /'
    fi
    FAILED_INPUTS+=("$(printf '%q' "$input") | ${args[*]}")
  fi
}

# Tests covering more combinations of styles + alignments + padding + indent
for style in none ascii ascii2 sharp rounded reinforced markdown grid; do
  for p in 0 1 2 4; do
    for i in 0 2 5; do
      for ha in left center right; do
        for ba in left center right; do
          run_one $'a,b,c\n1,2,3\n4,5,6\n' -s "$style" -p "$p" -i "$i" --header-align "$ha" --body-align "$ba"
        done
      done
    done
  done
done

# Edge widths
run_one $'long header here,b\n1,2\n3,4\n'
run_one $'a,b\nthis is a longer cell,2\nshort,3\n'
run_one $'a,b\n  spaces  ,2\n'

# Quoted
run_one $'a,b,c\n"a,b","c\nd","e""f"\n'

# CJK/Emoji combinations
run_one $'name,desc\n你好,test\n龙,2\n世界,3\n'
run_one $'a,b\n👨‍👩‍👧,family\n'
run_one $'a,b\n🇺🇸,USA\n🇯🇵,Japan\n'
run_one $'a,b\n☃️,winter\n☀️,summer\n'

# Numbered + various
run_one $'a,b,c\n1,2,3\n' -n
run_one $'a,b,c\n1,2,3\n' -n -s grid
run_one $'a,b,c\n1,2,3\n' -n -H
run_one $'a,b,c\n1,2,3\n' -n --header-align right
run_one $'a,b,c\n1,2,3\n' -n --body-align center

# TSV
run_one $'a\tb\n1\t2\n' -t
run_one $'a\tb\n1\t2\n3\t4\n' -t -s grid

# Sniff combinations
run_one $'a,b\n1,2\nlong cell content,3\n' --sniff 0
run_one $'a,b\n1,2\nlong cell content,3\n' --sniff 1
run_one $'a,b\n1,2\nlong cell content,3\n' --sniff 2
run_one $'a,b\n1,2\n中文,3\nABCDEFG,4\n' --sniff 1
run_one $'a,b\n1,2\n中文,3\nABCDEFG,4\n' --sniff 0

# Error paths
run_one $'a,b\n1,2,3\n'
run_one $'a,b,c\n1,2\n'
run_one $'a,b\n1\n2\n'

# Empty / edge
run_one ''
run_one $'\n'
run_one $'\n\n'
run_one $'a\n'
run_one $',\n'
run_one $',\n,\n'

# Various delimiters
run_one $'a|b|c\n1|2|3\n' -d '|'
run_one $'a:b\n1:2\n' -d ':'

# Help vs version
run_one '' --help
run_one '' -h
run_one '' --version

# Bad args
run_one '' --bogus
run_one '' -d ''
run_one '' -d 'xx'
run_one '' -s wrong
run_one '' --sniff abc
run_one '' --padding -1
run_one '' --indent abc

# Conflicts
run_one $'a,b\n1,2\n' -t -d ','
run_one $'a,b\n1,2\n' -d ',' -t

# Padding/indent extremes
run_one $'a,b\n1,2\n' -p 0
run_one $'a,b\n1,2\n' -p 10
run_one $'a,b\n1,2\n' -i 10
run_one $'a,b\n1,2\n' -i 100

# BOM / CRLF
run_one $'\xef\xbb\xbfa,b\n1,2\n'
run_one $'a,b\r\n1,2\r\n'
run_one $'a,b\r1,2\r'

# Quoted edge
run_one $'a,b\n"" ,2\n'
run_one $'a,b\n" leading",2\n'
run_one $'a,b\n"trailing ",2\n'
run_one $'a,b\n"a""b""c",2\n'

# Many cols
cols=$(seq 1 20 | tr '\n' ',' | sed 's/,$//')
run_one "${cols}"$'\n'"${cols}"$'\n'

# Single col
run_one $'just_one\n1\n2\n3\n'
run_one $'just_one\n1\n2\n3\n' -s markdown
run_one $'just_one\n1\n2\n3\n' -s grid

# Combined sniff + truncation styles
run_one $'a,b\n1,2\n中文测试,3\nlong,4\n' --sniff 1 -s grid
run_one $'a,b\n1,2\n中文测试,3\nlong,4\n' --sniff 1 -s markdown
run_one $'a,b\n1,2\n中文测试,3\nlong,4\n' --sniff 1 -s ascii2

# Stress: large input
yes "a,b,c,d,e" | head -20 | /workspace/executable >/dev/null 2>&1
yes "a,b,c,d,e" | head -20 | /work/work/executable >/dev/null 2>&1
# Diff with subshells (since input is large)
yes "a,b,c,d,e" | head -100 > /tmp/big_input
diff <(/workspace/executable /tmp/big_input) <(/work/work/executable /tmp/big_input) > /dev/null && echo "big input matches" || echo "big input differs"

echo "PASS: $PASS"
echo "FAIL: $FAIL"
if [ $FAIL -gt 0 ] && [ "${VERBOSE:-0}" != "1" ]; then
  echo "First 10 failures:"
  for f in "${FAILED_INPUTS[@]:0:10}"; do
    echo "  $f"
  done
fi
