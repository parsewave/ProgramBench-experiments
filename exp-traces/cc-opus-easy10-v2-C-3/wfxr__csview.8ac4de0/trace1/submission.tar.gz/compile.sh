#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PATH="/usr/local/cargo/bin:$PATH"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export CARGO_NET_OFFLINE=1
cargo build --release --offline
cp target/release/csview ./executable
