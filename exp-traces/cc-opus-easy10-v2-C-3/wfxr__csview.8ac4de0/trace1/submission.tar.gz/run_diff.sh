#!/usr/bin/env bash
# Run all goldens through both reference and SUT, compare.
# Each golden dir has args.txt (newline-separated args, empty lines preserved).
set -u

SUT=${1:-/work/work/executable}
REF=${REF_BIN:-/workspace/executable}
GOLDENS=/work/work/goldens
VERBOSE=${VERBOSE:-0}

PASS=0
FAIL=0
FAILED=()

for dir in "$GOLDENS"/*/; do
  name=$(basename "$dir")

  # Read args, preserving empty arguments. If all are empty, treat as zero args.
  args=()
  if [ -s "$dir/args.txt" ]; then
    while IFS= read -r line || [ -n "$line" ]; do
      args+=("$line")
    done < "$dir/args.txt"
    # Strip trailing empty entries that came from a single trailing newline
    # (mapfile/read includes the final empty after the trailing newline)
    # But preserve empties if there is at least one non-empty arg before/around them.
    # Simple rule: if all entries are empty, set args to zero.
    any_nonempty=false
    for a in "${args[@]}"; do
      if [ -n "$a" ]; then any_nonempty=true; break; fi
    done
    if ! $any_nonempty; then
      args=()
    fi
  fi

  stdin_file="$dir/stdin.bin"
  if [ ! -f "$stdin_file" ]; then
    stdin_file=/dev/null
  fi

  expected_stdout_file="$dir/expected_stdout.bin"
  expected_stderr_file="$dir/expected_stderr.bin"
  expected_exit=$(cat "$dir/expected_exit.txt")

  # Run SUT
  "$SUT" "${args[@]}" < "$stdin_file" >/tmp/sut_out 2>/tmp/sut_err
  actual_exit=$?

  # Byte-exact compare via cmp
  ok=true
  if ! cmp -s /tmp/sut_out "$expected_stdout_file"; then
    ok=false
  fi
  if ! cmp -s /tmp/sut_err "$expected_stderr_file"; then
    ok=false
  fi
  if [ "$actual_exit" != "$expected_exit" ]; then
    ok=false
  fi

  if $ok; then
    PASS=$((PASS+1))
  else
    FAIL=$((FAIL+1))
    FAILED+=("$name")
    if [ "$VERBOSE" = "1" ]; then
      echo "FAIL: $name"
      echo "  args: ${args[*]}"
      echo "  expected exit: $expected_exit, got $actual_exit"
      if ! cmp -s /tmp/sut_out "$expected_stdout_file"; then
        echo "  stdout differs:"
        diff <(cat "$expected_stdout_file") /tmp/sut_out | head -20 | sed 's/^/    /'
      fi
      if ! cmp -s /tmp/sut_err "$expected_stderr_file"; then
        echo "  stderr differs:"
        diff <(cat "$expected_stderr_file") /tmp/sut_err | head -20 | sed 's/^/    /'
      fi
    fi
  fi
done

echo "PASS: $PASS"
echo "FAIL: $FAIL"
if [ $FAIL -gt 0 ] && [ "$VERBOSE" != "1" ]; then
  echo ""
  echo "Failed tests:"
  for f in "${FAILED[@]}"; do
    echo "  $f"
  done
fi
