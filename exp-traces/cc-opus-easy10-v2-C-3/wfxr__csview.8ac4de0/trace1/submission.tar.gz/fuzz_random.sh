#!/usr/bin/env bash
set -u
SEED=${SEED:-1}
N=${N:-200}
export N SEED
python3 /work/work/fuzz_random.py
