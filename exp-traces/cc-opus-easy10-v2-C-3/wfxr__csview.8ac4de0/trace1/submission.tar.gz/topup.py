#!/usr/bin/env python3
"""Statistical top-up: 10 realistic usage probes from a usage Markov chain."""
import os
import random
import subprocess
import sys

REF = os.environ.get('REF_BIN', '/workspace/executable')
SUT = os.environ.get('SUT', '/work/work/executable')

random.seed(2026)

# Realistic CSV samples (mimicking different usage modes)
samples = [
    # Mode 1: Simple tabular data with headers (most common)
    ('simple', b'Name,Age,Email\nAlice,30,alice@example.com\nBob,25,bob@example.com\nCarol,28,carol@example.com\n', []),

    # Mode 2: TSV with -t
    ('tsv', b'col1\tcol2\tcol3\n1\t2\t3\n4\t5\t6\n', ['-t']),

    # Mode 3: Custom delimiter
    ('delim', b'a;b;c\n1;2;3\n4;5;6\n', ['-d', ';']),

    # Mode 4: Numbered rows with -n
    ('numbered', b'Item,Price\nApple,1.50\nBanana,0.75\nCherry,3.00\nDate,2.25\n', ['-n']),

    # Mode 5: No header (-H)
    ('noheader', b'foo,bar,baz\nbar,baz,foo\nbaz,foo,bar\n', ['-H']),

    # Mode 6: Markdown style
    ('markdown', b'Feature,Status,Notes\nLogin,Done,OK\nSearch,WIP,Refactor\nProfile,Todo,Plan\n', ['-s', 'markdown']),

    # Mode 7: Grid style with CJK
    ('grid_cjk', b'Name,City\nAlice,New York\n\xe9\xbe\x99,\xe5\x8c\x97\xe4\xba\xac\nBob,London\n', ['-s', 'grid']),

    # Mode 8: Custom alignment + padding
    ('align_pad', b'A,B,C\n100,200,300\n4,5,6\n', ['--header-align', 'right', '--body-align', 'right', '-p', '2']),

    # Mode 9: Quoted multiline cell
    ('multiline', b'a,b\n"hello\\nworld",2\nshort,3\n', []),

    # Mode 10: File argument (need to test file read)
    ('file', None, None),  # special, handled below
]

pass_n = 0
fail_n = 0
failures = []

import tempfile

for label, csv, args_or_none in samples:
    if label == 'file':
        # Use tempfile
        with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix='.csv') as f:
            f.write(b'name,age\nAlice,30\nBob,25\n')
            file_path = f.name
        try:
            r1 = subprocess.run([REF, file_path], capture_output=True, timeout=5)
            r2 = subprocess.run([SUT, file_path], capture_output=True, timeout=5)
        finally:
            os.unlink(file_path)
    else:
        r1 = subprocess.run([REF] + args_or_none, input=csv, capture_output=True, timeout=5)
        r2 = subprocess.run([SUT] + args_or_none, input=csv, capture_output=True, timeout=5)

    if r1.stdout == r2.stdout and r1.stderr == r2.stderr and r1.returncode == r2.returncode:
        pass_n += 1
        print(f'[PASS] {label}')
    else:
        fail_n += 1
        print(f'[FAIL] {label}')
        if r1.stdout != r2.stdout:
            print(f'   STDOUT differs ({len(r1.stdout)} vs {len(r2.stdout)})')
            print(f'   ref: {r1.stdout[:200]!r}')
            print(f'   sut: {r2.stdout[:200]!r}')
        if r1.stderr != r2.stderr:
            print(f'   STDERR differs')
            print(f'   ref: {r1.stderr[:200]!r}')
            print(f'   sut: {r2.stderr[:200]!r}')
        if r1.returncode != r2.returncode:
            print(f'   EXIT differs: ref={r1.returncode}, sut={r2.returncode}')

print()
print(f'STATISTICAL TOP-UP: {pass_n} passed, {fail_n} failed (out of {pass_n + fail_n})')
sys.exit(0 if fail_n == 0 else 1)
