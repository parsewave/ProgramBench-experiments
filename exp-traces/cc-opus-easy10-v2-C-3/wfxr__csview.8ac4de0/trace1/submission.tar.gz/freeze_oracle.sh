#!/usr/bin/env bash
# Freeze a set of golden tests against the reference binary.
# Each test is a directory under goldens/ with:
#   - args.txt:   command-line args (one per line, but we tr to a single line)
#   - stdin.bin:  stdin content (raw bytes)
#   - expected_stdout.bin: captured stdout
#   - expected_stderr.bin: captured stderr
#   - expected_exit.txt: exit code

set -u

REF=${REF_BIN:-/workspace/executable}
GOLDENS_DIR=${1:-/work/work/goldens}

run_test() {
  local name="$1"; shift
  local stdin_content="$1"; shift
  # Remaining args are CLI args
  local dir="$GOLDENS_DIR/$name"
  mkdir -p "$dir"
  printf '%s\n' "$@" > "$dir/args.txt"
  printf '%s' "$stdin_content" > "$dir/stdin.bin"
  set +e
  printf '%s' "$stdin_content" | timeout 5 "$REF" "$@" > "$dir/expected_stdout.bin" 2> "$dir/expected_stderr.bin"
  local exit_code=$?
  set -e
  echo "$exit_code" > "$dir/expected_exit.txt"
}

run_test_file() {
  local name="$1"; shift
  local file="$1"; shift
  local dir="$GOLDENS_DIR/$name"
  mkdir -p "$dir"
  printf '%s\n' "$@" "$file" > "$dir/args.txt"
  cp "$file" "$dir/input.csv"
  set +e
  timeout 5 "$REF" "$@" "$file" > "$dir/expected_stdout.bin" 2> "$dir/expected_stderr.bin"
  local exit_code=$?
  set -e
  echo "$exit_code" > "$dir/expected_exit.txt"
}

# Help/version
run_test help "" --help
run_test help_short "" -h
run_test version "" --version
run_test version_short "" -V
run_test bogus_arg "" --bogus
run_test conflict_tsv_delim "" -t -d ','
run_test conflict_delim_tsv "" -d ',' -t
run_test bad_padding "" -p notanumber
run_test bad_style "" -s notastyle
run_test bad_sniff "" --sniff abc
run_test missing_style_value "" -s
run_test bad_delim_empty "" -d ''
run_test bad_delim_2chars "" -d 'xx'

# Empty / minimal
run_test empty_stdin ""
run_test just_lf $'\n'
run_test just_lfs $'\n\n\n'
run_test header_only_no_lf "a,b,c"
run_test header_only_lf $'a,b,c\n'
run_test simple_2cols $'a,b\n1,2\n'
run_test simple_3rows $'a,b,c\n1,2,3\n4,5,6\n'
run_test single_column $'a\n1\n2\n'

# Various flags
run_test no_headers $'a,b,c\n1,2,3\n4,5,6\n' -H
run_test no_headers_n $'a,b,c\n1,2,3\n4,5,6\n' -H -n
run_test number $'a,b,c\n1,2,3\n4,5,6\n' -n
run_test tsv $'a\tb\tc\n1\t2\t3\n' -t
run_test delim_semi $'a;b;c\n1;2;3\n' -d ';'
run_test delim_pipe $'a|b|c\n1|2|3\n' -d '|'

# Style variants
for style in none ascii ascii2 sharp rounded reinforced markdown grid; do
  run_test "style_${style}_3rows" $'a,b,c\n1,2,3\n4,5,6\n' -s "$style"
  run_test "style_${style}_header_only" $'a,b,c\n' -s "$style"
  run_test "style_${style}_no_headers" $'a,b,c\n1,2,3\n4,5,6\n' -H -s "$style"
  run_test "style_${style}_single_col" $'a\n1\n2\n' -s "$style"
done

# Padding
for p in 0 1 2 3; do
  run_test "padding_${p}" $'a,b\n1,2\n' -p "$p"
  run_test "padding_${p}_none" $'a,b\n1,2\n' -p "$p" -s none
  run_test "padding_${p}_ascii2" $'a,b\n1,2\n' -p "$p" -s ascii2
done

# Indent
for i in 0 1 4 8; do
  run_test "indent_${i}" $'a,b\n1,2\n' -i "$i"
done

# Alignments
for h in left center right; do
  for b in left center right; do
    run_test "align_h${h}_b${b}" $'abcdef,b\n1,222\nshort,3\n' --header-align "$h" --body-align "$b"
  done
done

# CJK / Emoji
run_test cjk_hello $'a,b,c\n你好,世界,!\n'
run_test cjk_mixed $'name,age\n龙,25\nAlice,30\n'
run_test emoji_simple $'a,b\n🌟,2\n'
run_test emoji_zwj_family $'a,b\n👨‍👩‍👧,2\n'
run_test emoji_flag $'a,b\n🇺🇸,2\n'
run_test snowman_vs16 $'a,b\n☃️,2\n'
run_test combining $'a,b\nA\xcc\x81,2\n'
run_test fullwidth $'a,b\nＡＢＣ,2\n'

# Quoting
run_test quoted_simple $'a,b,c\n"hello, world",2,3\n'
run_test quoted_double_quote $'a,b,c\n"a""b",2,3\n'
run_test quoted_multiline $'a,b,c\n"hello\nworld",2,3\n'
run_test quoted_trailing_data $'a,b\n"x"y,2\n'
run_test quoted_with_spaces $'a,b\n"hello"   ,2\n'

# Sniff
run_test sniff_0 $'a,b\n1,222\n2222,3\n' --sniff 0
run_test sniff_1 $'a,b\n1,222\n2222,3\n' --sniff 1
run_test sniff_2 $'a,b\n1,222\n2222,3\n' --sniff 2
run_test sniff_1_cjk $'ab,b\n1,2\n中文测试,3\n' --sniff 1
run_test sniff_truncate_5 $'abcde,b\n1,2\n中文测试,3\n' --sniff 1
run_test sniff_truncate_no_overflow $'abcdef,b\n1,2\n中文测试,3\n' --sniff 1

# Edge cases
run_test bom_stripped $'\xef\xbb\xbfa,b,c\n1,2,3\n'
run_test bom_mid $'a\xef\xbb\xbfb,c\n1,2\n'
run_test crlf $'a,b,c\r\n1,2,3\r\n'
run_test cr_only $'a,b,c\r1,2,3\r'
run_test mismatched_fields $'a,b\n1,2,3\n'
run_test invalid_utf8 $'a,b\n\xff\xfe,2\n'

# Trailing empties
run_test trailing_empty_col $'a,b,\n1,2,\n'
run_test all_empty_row $'a,b,c\n,,\n,,\n'
run_test spaces_preserved $'a,b,c\n  ,  ,  \n'

# Mixed real-world-ish
run_test realistic_csv $'Name,Age,City\nAlice,30,New York\nBob,25,San Francisco\nCharlie,35,Tokyo\n'

# Stress: many cols
run_test many_cols $'a,b,c,d,e,f,g,h,i,j\n1,2,3,4,5,6,7,8,9,10\n'

# File-based test
echo $'name,value\nfoo,1\nbar,2\n' > /tmp/test_file.csv
run_test_file file_arg /tmp/test_file.csv
run_test_file file_arg_n /tmp/test_file.csv -n
run_test_file nonexistent_file /tmp/nonexistent_file.csv

echo "Total goldens: $(ls -1 "$GOLDENS_DIR" | wc -l)"
