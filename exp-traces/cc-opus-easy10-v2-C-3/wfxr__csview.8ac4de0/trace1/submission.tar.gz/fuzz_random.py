#!/usr/bin/env python3
"""Random fuzz comparison of reference vs SUT."""
import os
import random
import subprocess
import sys

REF = os.environ.get('REF_BIN', '/workspace/executable')
SUT = os.environ.get('SUT', '/work/work/executable')
SEED = int(os.environ.get('SEED', '1'))
N = int(os.environ.get('N', '200'))

random.seed(SEED)

def gen_field():
    n = random.randint(0, 12)
    chars = []
    pool = "abcdefghijklmnopqrstuvwxyz0123456789 .-_/!@#"
    extras = ["你", "好", "龙", "🌟", "😀", "❤️", "☃️", "👨‍👩‍👧", "Ａ", "ñ", "Á"]
    for _ in range(n):
        if random.random() < 0.15:
            chars.append(random.choice(extras))
        else:
            chars.append(random.choice(pool))
    f = ''.join(chars)
    if random.random() < 0.2:
        f = '"' + f.replace('"', '""') + '"'
    return f

def gen_csv():
    ncols = random.randint(1, 6)
    nrows = random.randint(0, 8)
    rows = []
    for r in range(nrows + 1):
        fields = [gen_field() for _ in range(ncols)]
        rows.append(','.join(fields))
    return ('\n'.join(rows) + '\n').encode('utf-8')

styles = ['none', 'ascii', 'ascii2', 'sharp', 'rounded', 'reinforced', 'markdown', 'grid']
aligns = ['left', 'center', 'right']

pass_n = 0
fail_n = 0
failures = []

for i in range(N):
    csv = gen_csv()
    args = []
    if random.random() < 0.4:
        args += ['-s', random.choice(styles)]
    if random.random() < 0.3:
        args += ['-p', str(random.randint(0, 4))]
    if random.random() < 0.2:
        args += ['-i', str(random.randint(0, 8))]
    if random.random() < 0.3:
        args += ['-H']
    if random.random() < 0.3:
        args += ['-n']
    if random.random() < 0.3:
        args += ['--header-align', random.choice(aligns)]
    if random.random() < 0.3:
        args += ['--body-align', random.choice(aligns)]
    if random.random() < 0.2:
        args += ['--sniff', str(random.randint(0, 5))]

    try:
        r1 = subprocess.run([REF] + args, input=csv, capture_output=True, timeout=5)
        r2 = subprocess.run([SUT] + args, input=csv, capture_output=True, timeout=5)
    except Exception as e:
        fail_n += 1
        failures.append(f'exception: {e}')
        continue
    if r1.stdout == r2.stdout and r1.stderr == r2.stderr and r1.returncode == r2.returncode:
        pass_n += 1
    else:
        fail_n += 1
        if len(failures) < 5:
            failures.append({
                'args': args,
                'input': csv[:200],
                'ref_exit': r1.returncode, 'sut_exit': r2.returncode,
                'ref_out': r1.stdout[:500], 'sut_out': r2.stdout[:500],
                'ref_err': r1.stderr[:200], 'sut_err': r2.stderr[:200],
            })

print(f'PASS: {pass_n}')
print(f'FAIL: {fail_n}')
for f in failures[:5]:
    if isinstance(f, dict):
        print(f"-- args={f['args']}")
        print(f"   input={f['input']!r}")
        print(f"   ref_exit={f['ref_exit']} sut_exit={f['sut_exit']}")
        print(f"   ref_out={f['ref_out']!r}")
        print(f"   sut_out={f['sut_out']!r}")
        if f['ref_err'] or f['sut_err']:
            print(f"   ref_err={f['ref_err']!r}")
            print(f"   sut_err={f['sut_err']!r}")
    else:
        print(f, file=sys.stderr)
