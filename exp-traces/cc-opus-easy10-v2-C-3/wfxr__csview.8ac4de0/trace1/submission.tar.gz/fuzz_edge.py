#!/usr/bin/env python3
"""Edge-case fuzz."""
import os
import random
import subprocess
import sys

REF = os.environ.get('REF_BIN', '/workspace/executable')
SUT = os.environ.get('SUT', '/work/work/executable')

pass_n = 0
fail_n = 0
failures = []

def run_pair(input_bytes, args, label=""):
    global pass_n, fail_n, failures
    try:
        r1 = subprocess.run([REF] + args, input=input_bytes, capture_output=True, timeout=5)
        r2 = subprocess.run([SUT] + args, input=input_bytes, capture_output=True, timeout=5)
    except Exception as e:
        fail_n += 1
        failures.append(f'exception: {e}')
        return
    if r1.stdout == r2.stdout and r1.stderr == r2.stderr and r1.returncode == r2.returncode:
        pass_n += 1
    else:
        fail_n += 1
        if len(failures) < 20:
            failures.append({
                'label': label,
                'args': args,
                'input': input_bytes[:300],
                'ref_exit': r1.returncode, 'sut_exit': r2.returncode,
                'ref_out': r1.stdout[:500], 'sut_out': r2.stdout[:500],
                'ref_err': r1.stderr[:200], 'sut_err': r2.stderr[:200],
            })

# Test 1: Multiline cells in various scenarios
multiline_inputs = [
    b'a,b,c\n"line1\nline2",2,3\n',
    b'a,b\n"first\nsecond\nthird",col2\n',
    b'a,b\nshort,2\n"long\nmultiline",4\n',
    b'"h1\nh2",col2\n1,2\n3,4\n',
    b'a,b\n"x\ny",2\n"a\nb\nc",3\n',
]
for inp in multiline_inputs:
    for style in ['none', 'ascii', 'sharp', 'markdown', 'grid', 'rounded', 'reinforced', 'ascii2']:
        for align in ['left', 'center', 'right']:
            for sniff in ['0', '1', '2']:
                run_pair(inp, ['-s', style, '--body-align', align, '--sniff', sniff], 'multiline')

# Test 2: BOM, CRLF, CR
bom_inputs = [
    b'\xef\xbb\xbfa,b,c\n1,2,3\n',
    b'\xef\xbb\xbf',
    b'a,b\r\n1,2\r\n',
    b'a,b\r1,2\r',
    b'\xef\xbb\xbfa,b\r\n1,2\r\n',
]
for inp in bom_inputs:
    for style in ['sharp', 'markdown', 'ascii']:
        run_pair(inp, ['-s', style], 'bom_crlf')

# Test 3: All styles with no records
empty_inputs = [b'', b'\n', b'\n\n']
for inp in empty_inputs:
    for style in ['none', 'ascii', 'ascii2', 'sharp', 'rounded', 'reinforced', 'markdown', 'grid']:
        for h in [False, True]:
            for n in [False, True]:
                args = ['-s', style]
                if h: args.append('-H')
                if n: args.append('-n')
                run_pair(inp, args, 'empty')

# Test 4: Number column with various data row counts (around boundaries)
for n_rows in [0, 1, 8, 9, 10, 99, 100, 999, 1000, 1001]:
    csv = b'a,b\n' + b'1,2\n' * n_rows
    for h in [False, True]:
        args = ['-n']
        if h: args.append('-H')
        # Skip extremely slow tests
        if n_rows < 100:
            run_pair(csv, args, f'n_rows_{n_rows}')

# Test 5: Sniff with various overflow scenarios
for sniff in ['0', '1', '2', '3', '5', '10']:
    csv = b'a,b\n' + b'1,2\n' * 5 + b'longer text here,3\n'
    run_pair(csv, ['--sniff', sniff], f'sniff_overflow_{sniff}')
    # With error after sniff
    csv2 = b'a,b\n' + b'1,2\n' * 5 + b'bad,row,here\n'
    run_pair(csv2, ['--sniff', sniff], f'sniff_then_error_{sniff}')

# Test 6: Padding & indent extremes
for p in ['0', '1', '5', '10']:
    for i in ['0', '1', '5', '10']:
        for style in ['none', 'ascii', 'ascii2', 'sharp', 'markdown', 'grid']:
            run_pair(b'a,b\n1,2\n3,4\n', ['-p', p, '-i', i, '-s', style], 'p_i')

# Test 7: Help / version & errors
run_pair(b'', ['--help'])
run_pair(b'', ['-h'])
run_pair(b'', ['--version'])
run_pair(b'', ['-V'])
run_pair(b'', ['--bogus'])
run_pair(b'', ['-d', ''])
run_pair(b'', ['-d', 'xx'])
run_pair(b'', ['-d', 'ñ'])
run_pair(b'', ['-d', '你'])
run_pair(b'', ['-s', 'bad'])
run_pair(b'', ['-s'])
run_pair(b'', ['-p', 'abc'])
run_pair(b'', ['-p', '-1'])
run_pair(b'', ['-i', 'abc'])
run_pair(b'', ['--sniff', 'abc'])
run_pair(b'', ['--sniff', '-1'])
run_pair(b'a,b\n1,2\n', ['-t', '-d', ','])
run_pair(b'a,b\n1,2\n', ['-d', ',', '-t'])
run_pair(b'', ['unknown_positional', 'extra'])

# Test 8: With file
import tempfile
with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
    f.write('name,age\nAlice,30\nBob,25\n')
    file_path = f.name
run_pair(b'', [file_path])
run_pair(b'', ['-n', file_path])
run_pair(b'', ['-H', file_path])
os.unlink(file_path)
run_pair(b'', ['/nonexistent_xyz.csv'])
run_pair(b'', ['/tmp/'])

# Test 9: Various delimiters
delims_inputs = [
    (b'a;b;c\n1;2;3\n', ['-d', ';']),
    (b'a|b\n1|2\n', ['-d', '|']),
    (b'a:b\n1:2\n', ['-d', ':']),
    (b'a\tb\n1\t2\n', ['-t']),
    (b'a\tb\n1\t2\n', ['-d', '\t']),  # same as -t
    (b'aXb\n1X2\n', ['-d', 'X']),
]
for inp, args in delims_inputs:
    run_pair(inp, args, 'delims')

# Test 10: Quoted edge cases
quoted_inputs = [
    b'a,b\n"hello, world",2\n',
    b'a,b\n"a""b",2\n',
    b'a,b\n"hello"  ,2\n',
    b'a,b\n"x"y,2\n',
    b'a,b\n"",2\n',
    b'a,b\n" leading space",2\n',
    b'a,b\n"trailing space ",2\n',
    b'a,b\n"with""multiple""quotes",2\n',
]
for inp in quoted_inputs:
    run_pair(inp, [], 'quoted')

# Test 11: Wide CJK + alignment + sniff
cjk_inputs = [
    b'name,age\n\xe4\xbd\xa0\xe5\xa5\xbd,25\n\xe4\xb8\x96\xe7\x95\x8c,30\n',
]
for inp in cjk_inputs:
    for ha in ['left', 'center', 'right']:
        for ba in ['left', 'center', 'right']:
            for sniff in ['0', '1']:
                run_pair(inp, ['--header-align', ha, '--body-align', ba, '--sniff', sniff], 'cjk')

print(f'PASS: {pass_n}')
print(f'FAIL: {fail_n}')
for f in failures[:10]:
    if isinstance(f, dict):
        print(f"-- label={f.get('label')} args={f['args']}")
        print(f"   input={f['input']!r}")
        print(f"   ref_exit={f['ref_exit']} sut_exit={f['sut_exit']}")
        if f['ref_out'] != f['sut_out']:
            print(f"   ref_out={f['ref_out']!r}")
            print(f"   sut_out={f['sut_out']!r}")
        if f['ref_err'] != f['sut_err']:
            print(f"   ref_err={f['ref_err']!r}")
            print(f"   sut_err={f['sut_err']!r}")
    else:
        print(f, file=sys.stderr)
