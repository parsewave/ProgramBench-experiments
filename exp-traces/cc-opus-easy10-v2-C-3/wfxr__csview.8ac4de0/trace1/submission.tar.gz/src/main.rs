use std::fs::File;
use std::io::{self, Read, Write, BufReader, BufWriter};
use std::path::PathBuf;
use std::process::ExitCode;

use clap::{Parser, ValueEnum};
use unicode_segmentation::UnicodeSegmentation;
use unicode_width::{UnicodeWidthChar, UnicodeWidthStr};

#[derive(Copy, Clone, PartialEq, Eq, ValueEnum, Debug)]
#[clap(rename_all = "lowercase")]
enum Style {
    None,
    Ascii,
    Ascii2,
    Sharp,
    Rounded,
    Reinforced,
    Markdown,
    Grid,
}

#[derive(Copy, Clone, PartialEq, Eq, ValueEnum, Debug)]
#[clap(rename_all = "lowercase")]
enum Align {
    Left,
    Center,
    Right,
}

#[derive(Parser, Debug)]
#[command(
    name = "csview",
    version,
    about = "A high performance csv viewer with cjk/emoji support.",
    disable_help_flag = true,
    disable_version_flag = true,
    next_line_help = true,
    term_width(100),
)]
struct Cli {
    /// Specify that the input has no header row
    #[arg(short = 'H', long = "no-headers")]
    no_headers: bool,

    /// Prepend a column of line numbers to the table
    #[arg(short = 'n', long = "number")]
    number: bool,

    /// Use '\t' as delimiter for tsv
    #[arg(short = 't', long = "tsv", conflicts_with = "delimiter")]
    tsv: bool,

    /// Specify the field delimiter
    #[arg(short = 'd', long = "delimiter", default_value = ",", value_parser = parse_delim)]
    delimiter: char,

    /// Specify the border style
    #[arg(short = 's', long = "style", value_enum, default_value_t = Style::Sharp)]
    style: Style,

    /// Specify padding for table cell
    #[arg(short = 'p', long = "padding", default_value_t = 1)]
    padding: usize,

    /// Specify global indent for table
    #[arg(short = 'i', long = "indent", default_value_t = 0)]
    indent: usize,

    /// Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
    #[arg(long = "sniff", value_name = "LIMIT", default_value_t = 1000)]
    sniff: usize,

    /// Specify the alignment of the table header
    #[arg(long = "header-align", value_enum, default_value_t = Align::Center)]
    header_align: Align,

    /// Specify the alignment of the table body
    #[arg(long = "body-align", value_enum, default_value_t = Align::Left)]
    body_align: Align,

    /// Disable pager
    #[arg(short = 'P', long = "disable-pager")]
    disable_pager: bool,

    /// Print help
    #[arg(short = 'h', long = "help", action = clap::ArgAction::Help)]
    help: Option<bool>,

    /// Print version
    #[arg(short = 'V', long = "version", action = clap::ArgAction::Version)]
    version: Option<bool>,

    /// File to view
    file: Option<PathBuf>,
}

fn parse_delim(s: &str) -> Result<char, String> {
    let mut iter = s.chars();
    let c = match iter.next() {
        Some(c) => c,
        None => return Err("cannot parse char from empty string".to_string()),
    };
    if iter.next().is_some() {
        return Err("too many characters in string".to_string());
    }
    Ok(c)
}

fn grapheme_width(g: &str) -> usize {
    let mut chars = g.chars();
    let first = chars.next();
    let second = chars.next();
    if let (Some(c), None) = (first, second) {
        if UnicodeWidthChar::width(c).is_none() {
            return 1;
        }
    }
    UnicodeWidthStr::width(g)
}

fn str_width(s: &str) -> usize {
    s.graphemes(true).map(grapheme_width).sum()
}

fn digit_count(n: usize) -> usize {
    if n == 0 { 1 } else {
        let mut x = n;
        let mut c = 0;
        while x > 0 {
            x /= 10;
            c += 1;
        }
        c
    }
}

fn truncate_to_width(s: &str, max_w: usize) -> (String, usize) {
    if str_width(s) <= max_w {
        let w = str_width(s);
        return (s.to_string(), w);
    }
    let mut out = String::new();
    let mut w = 0;
    for g in s.graphemes(true) {
        let gw = grapheme_width(g);
        if w + gw > max_w {
            break;
        }
        out.push_str(g);
        w += gw;
    }
    (out, w)
}

fn pad_to(content: &str, content_w: usize, target_w: usize, align: Align) -> String {
    if content_w >= target_w {
        return content.to_string();
    }
    let diff = target_w - content_w;
    match align {
        Align::Left => format!("{}{}", content, " ".repeat(diff)),
        Align::Right => format!("{}{}", " ".repeat(diff), content),
        Align::Center => {
            let left = diff / 2;
            let right = diff - left;
            format!("{}{}{}", " ".repeat(left), content, " ".repeat(right))
        }
    }
}

struct StyleDef {
    top: Option<(&'static str, &'static str, &'static str, &'static str)>,
    bottom: Option<(&'static str, &'static str, &'static str, &'static str)>,
    sep: Option<(&'static str, &'static str, &'static str, &'static str)>,
    body_sep: Option<(&'static str, &'static str, &'static str, &'static str)>,
    row: (&'static str, &'static str, &'static str),
    outer_pad: usize,
}

fn style_def(s: Style) -> StyleDef {
    match s {
        Style::Sharp => StyleDef {
            top: Some(("┌", "─", "┬", "┐")),
            bottom: Some(("└", "─", "┴", "┘")),
            sep: Some(("├", "─", "┼", "┤")),
            body_sep: None,
            row: ("│", "│", "│"),
            outer_pad: 0,
        },
        Style::Rounded => StyleDef {
            top: Some(("╭", "─", "┬", "╮")),
            bottom: Some(("╰", "─", "┴", "╯")),
            sep: Some(("├", "─", "┼", "┤")),
            body_sep: None,
            row: ("│", "│", "│"),
            outer_pad: 0,
        },
        Style::Reinforced => StyleDef {
            top: Some(("┏", "─", "┬", "┓")),
            bottom: Some(("┗", "─", "┴", "┛")),
            sep: Some(("├", "─", "┼", "┤")),
            body_sep: None,
            row: ("│", "│", "│"),
            outer_pad: 0,
        },
        Style::Grid => StyleDef {
            top: Some(("┌", "─", "┬", "┐")),
            bottom: Some(("└", "─", "┴", "┘")),
            sep: Some(("├", "─", "┼", "┤")),
            body_sep: Some(("├", "─", "┼", "┤")),
            row: ("│", "│", "│"),
            outer_pad: 0,
        },
        Style::Markdown => StyleDef {
            top: None,
            bottom: None,
            sep: Some(("|", "-", "|", "|")),
            body_sep: None,
            row: ("|", "|", "|"),
            outer_pad: 0,
        },
        Style::Ascii => StyleDef {
            top: Some(("+", "-", "+", "+")),
            bottom: Some(("+", "-", "+", "+")),
            sep: Some(("+", "-", "+", "+")),
            body_sep: None,
            row: ("|", "|", "|"),
            outer_pad: 0,
        },
        Style::Ascii2 => StyleDef {
            top: None,
            bottom: None,
            sep: Some(("", "-", "+", "")),
            body_sep: None,
            row: ("", "|", ""),
            outer_pad: 1,
        },
        Style::None => StyleDef {
            top: None,
            bottom: None,
            sep: None,
            body_sep: None,
            row: ("", "", ""),
            outer_pad: 0,
        },
    }
}

fn format_border<W: Write>(
    out: &mut W,
    indent: usize,
    style_parts: (&str, &str, &str, &str),
    col_widths: &[usize],
    padding: usize,
    outer_pad: usize,
) -> io::Result<()> {
    let (left, fill, middle, right) = style_parts;
    if indent > 0 {
        write!(out, "{}", " ".repeat(indent))?;
    }
    if outer_pad > 0 {
        write!(out, "{}", " ".repeat(outer_pad))?;
    }
    write!(out, "{}", left)?;
    for (i, &w) in col_widths.iter().enumerate() {
        let total = w + 2 * padding;
        for _ in 0..total {
            write!(out, "{}", fill)?;
        }
        if i + 1 < col_widths.len() {
            write!(out, "{}", middle)?;
        }
    }
    write!(out, "{}", right)?;
    if outer_pad > 0 {
        write!(out, "{}", " ".repeat(outer_pad))?;
    }
    writeln!(out)?;
    Ok(())
}

fn format_row<W: Write>(
    out: &mut W,
    indent: usize,
    style: &StyleDef,
    cells: &[String],
    col_widths: &[usize],
    padding: usize,
    align: Align,
) -> io::Result<()> {
    let (left, middle, right) = style.row;
    if indent > 0 {
        write!(out, "{}", " ".repeat(indent))?;
    }
    if style.outer_pad > 0 {
        write!(out, "{}", " ".repeat(style.outer_pad))?;
    }
    write!(out, "{}", left)?;
    let pad = " ".repeat(padding);
    let num_cells = cells.len();
    let num_cols = col_widths.len();
    for i in 0..num_cols {
        let cell = if i < num_cells { cells[i].as_str() } else { "" };
        let w = col_widths[i];
        let (truncated, tw) = truncate_to_width(cell, w);
        let padded = pad_to(&truncated, tw, w, align);
        write!(out, "{}{}{}", pad, padded, pad)?;
        if i + 1 < num_cols {
            write!(out, "{}", middle)?;
        }
    }
    write!(out, "{}", right)?;
    if style.outer_pad > 0 {
        write!(out, "{}", " ".repeat(style.outer_pad))?;
    }
    writeln!(out)?;
    Ok(())
}

fn padding_unused(cli: &Cli) -> usize { cli.padding }

fn render_empty_table<W: Write>(out: &mut W, cli: &Cli) -> io::Result<()> {
    let style = style_def(cli.style);
    let col_widths: &[usize] = &[];
    if let Some(top) = style.top {
        format_border(out, cli.indent, top, col_widths, cli.padding, style.outer_pad)?;
    }
    let (left, _, right) = style.row;
    if cli.indent > 0 {
        write!(out, "{}", " ".repeat(cli.indent))?;
    }
    if style.outer_pad > 0 {
        write!(out, "{}", " ".repeat(style.outer_pad))?;
    }
    write!(out, "{}", left)?;
    write!(out, "{}", right)?;
    if style.outer_pad > 0 {
        write!(out, "{}", " ".repeat(style.outer_pad))?;
    }
    writeln!(out)?;
    if let Some(bot) = style.bottom {
        format_border(out, cli.indent, bot, col_widths, cli.padding, style.outer_pad)?;
    }
    Ok(())
}

fn read_all<R: Read>(mut r: R) -> io::Result<Vec<u8>> {
    let mut buf = Vec::new();
    r.read_to_end(&mut buf)?;
    Ok(buf)
}

fn run() -> ExitCode {
    let cli = Cli::parse();
    let _ = cli.disable_pager;

    let delim: u8 = if cli.tsv { b'\t' } else { (cli.delimiter as u32) as u8 };

    // Read input
    let input_bytes: Vec<u8> = if let Some(ref path) = cli.file {
        match File::open(path) {
            Ok(f) => match read_all(BufReader::new(f)) {
                Ok(b) => b,
                Err(e) => {
                    eprintln!("csview: {}", e);
                    return ExitCode::from(1);
                }
            },
            Err(e) => {
                eprintln!("csview: {}", e);
                return ExitCode::from(1);
            }
        }
    } else {
        let stdin = io::stdin().lock();
        match read_all(stdin) {
            Ok(b) => b,
            Err(e) => {
                eprintln!("csview: {}", e);
                return ExitCode::from(1);
            }
        }
    };

    let input_bytes: Vec<u8> = if input_bytes.starts_with(b"\xef\xbb\xbf") {
        input_bytes[3..].to_vec()
    } else {
        input_bytes
    };

    let has_header = !cli.no_headers;
    let style = style_def(cli.style);

    let mut reader = csv::ReaderBuilder::new()
        .has_headers(false)
        .delimiter(delim)
        .flexible(false)
        .trim(csv::Trim::None)
        .from_reader(&input_bytes[..]);

    let stdout = io::stdout();
    let mut out = BufWriter::new(stdout.lock());

    // Phase 1: read header (if any) + sniff data rows
    let mut iter = reader.records();
    let mut header: Option<Vec<String>> = None;
    let mut sniffed: Vec<Vec<String>> = Vec::new();
    let sniff_target = if cli.sniff == 0 { usize::MAX } else { cli.sniff };

    if has_header {
        if let Some(result) = iter.next() {
            match result {
                Ok(rec) => {
                    header = Some(rec.iter().map(|s| s.to_string()).collect());
                }
                Err(e) => {
                    eprintln!("csview: {}", e);
                    return ExitCode::from(1);
                }
            }
        }
    }

    while sniffed.len() < sniff_target {
        match iter.next() {
            Some(Ok(rec)) => {
                sniffed.push(rec.iter().map(|s| s.to_string()).collect());
            }
            Some(Err(e)) => {
                eprintln!("csview: {}", e);
                return ExitCode::from(1);
            }
            None => break,
        }
    }

    let has_records = header.is_some() || !sniffed.is_empty();
    let sniff_count = sniffed.len();

    // Build header_row. If has_header is set, we always have a header_row (possibly empty).
    let mut header_row: Option<Vec<String>> = if has_header {
        Some(header.clone().unwrap_or_else(Vec::new))
    } else {
        None
    };

    if cli.number {
        if let Some(h) = header_row.as_mut() {
            h.insert(0, "#".to_string());
        }
        for (i, rec) in sniffed.iter_mut().enumerate() {
            let label = (i + 1).to_string();
            rec.insert(0, label);
        }
    }

    // Determine num_cols
    let num_cols = if let Some(h) = &header_row {
        h.len()
    } else if let Some(r) = sniffed.first() {
        r.len()
    } else if cli.number {
        1
    } else {
        0
    };

    if num_cols == 0 && !has_records && !cli.number {
        // Truly empty input, no records, no -n: special "empty table" representation
        let col_widths: &[usize] = &[];
        if let Some(top) = style.top {
            let _ = format_border(&mut out, cli.indent, top, col_widths, padding_unused(&cli), style.outer_pad);
        }
        if has_header {
            // Print empty row `││`
            let _ = format_row(&mut out, cli.indent, &style, &[], col_widths, cli.padding, cli.header_align);
        }
        if let Some(bot) = style.bottom {
            let _ = format_border(&mut out, cli.indent, bot, col_widths, padding_unused(&cli), style.outer_pad);
        }
        let _ = out.flush();
        return ExitCode::from(0);
    }

    let mut col_widths = vec![0usize; num_cols];

    if cli.number {
        let w = digit_count(sniff_count + 1);
        col_widths[0] = w;
    }

    if let Some(h) = &header_row {
        for (i, cell) in h.iter().enumerate() {
            if i < num_cols {
                col_widths[i] = col_widths[i].max(str_width(cell));
            }
        }
    }
    for rec in &sniffed {
        for (i, cell) in rec.iter().enumerate() {
            if i < num_cols {
                col_widths[i] = col_widths[i].max(str_width(cell));
            }
        }
    }

    let padding = cli.padding;

    // Render top border
    if let Some(top) = style.top {
        if let Err(e) = format_border(&mut out, cli.indent, top, &col_widths, padding, style.outer_pad) {
            if e.kind() == io::ErrorKind::BrokenPipe { let _ = out.flush(); return ExitCode::from(0); }
            eprintln!("csview: {}", e);
            return ExitCode::from(1);
        }
    }

    // Render header
    if let Some(h) = &header_row {
        if let Err(e) = format_row(&mut out, cli.indent, &style, h, &col_widths, padding, cli.header_align) {
            if e.kind() == io::ErrorKind::BrokenPipe { let _ = out.flush(); return ExitCode::from(0); }
            eprintln!("csview: {}", e);
            return ExitCode::from(1);
        }
    }

    // Determine if we'll have body output
    let has_body = !sniffed.is_empty();

    // Header/body separator
    if has_header && has_body {
        if let Some(sep) = style.sep {
            if let Err(e) = format_border(&mut out, cli.indent, sep, &col_widths, padding, style.outer_pad) {
                if e.kind() == io::ErrorKind::BrokenPipe { let _ = out.flush(); return ExitCode::from(0); }
                eprintln!("csview: {}", e);
                return ExitCode::from(1);
            }
        }
    }

    // Render sniffed body rows
    let sniffed_len = sniffed.len();
    for (i, rec) in sniffed.iter().enumerate() {
        if let Err(e) = format_row(&mut out, cli.indent, &style, rec, &col_widths, padding, cli.body_align) {
            if e.kind() == io::ErrorKind::BrokenPipe { let _ = out.flush(); return ExitCode::from(0); }
            eprintln!("csview: {}", e);
            return ExitCode::from(1);
        }
        if i + 1 < sniffed_len {
            if let Some(bs) = style.body_sep {
                if let Err(e) = format_border(&mut out, cli.indent, bs, &col_widths, padding, style.outer_pad) {
                    if e.kind() == io::ErrorKind::BrokenPipe { let _ = out.flush(); return ExitCode::from(0); }
                    eprintln!("csview: {}", e);
                    return ExitCode::from(1);
                }
            }
        }
    }

    // Stream phase: read remaining records, render each immediately.
    // Note: body_sep is printed BEFORE both successful rows AND errors (matching reference).
    let mut row_idx = sniff_count;
    loop {
        match iter.next() {
            Some(Ok(rec)) => {
                let mut row: Vec<String> = rec.iter().map(|s| s.to_string()).collect();
                if cli.number {
                    row.insert(0, (row_idx + 1).to_string());
                }
                row_idx += 1;
                if let Some(bs) = style.body_sep {
                    if let Err(e) = format_border(&mut out, cli.indent, bs, &col_widths, padding, style.outer_pad) {
                        if e.kind() == io::ErrorKind::BrokenPipe { let _ = out.flush(); return ExitCode::from(0); }
                        eprintln!("csview: {}", e);
                        return ExitCode::from(1);
                    }
                }
                if let Err(e) = format_row(&mut out, cli.indent, &style, &row, &col_widths, padding, cli.body_align) {
                    if e.kind() == io::ErrorKind::BrokenPipe { let _ = out.flush(); return ExitCode::from(0); }
                    eprintln!("csview: {}", e);
                    return ExitCode::from(1);
                }
            }
            Some(Err(e)) => {
                if let Some(bs) = style.body_sep {
                    let _ = format_border(&mut out, cli.indent, bs, &col_widths, padding, style.outer_pad);
                }
                let _ = out.flush();
                eprintln!("csview: {}", e);
                return ExitCode::from(1);
            }
            None => break,
        }
    }

    // Bottom border
    if let Some(bot) = style.bottom {
        if let Err(e) = format_border(&mut out, cli.indent, bot, &col_widths, padding, style.outer_pad) {
            if e.kind() == io::ErrorKind::BrokenPipe { let _ = out.flush(); return ExitCode::from(0); }
            eprintln!("csview: {}", e);
            return ExitCode::from(1);
        }
    }
    let _ = out.flush();
    ExitCode::from(0)
}

fn main() -> ExitCode {
    run()
}
