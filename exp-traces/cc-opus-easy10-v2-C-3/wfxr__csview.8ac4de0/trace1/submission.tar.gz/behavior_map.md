# csview 1.3.4 behavior map

## CLI / Help

`--help` and `-h` produce IDENTICAL output (39 lines, "next_line_help" clap format):

```
A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version
```

`--version` / `-V`: prints `csview 1.3.4\n` (binary name in version is "csview", NOT executable).

## Argument parsing

clap-derived. Notable behaviors:
- File `-` is NOT special; treated as filename.
- `--tsv` and `--delimiter` conflict.
- Delimiter must be exactly 1 UTF-8 char.
- Negative values like `-1` → "unexpected argument" (clap parses as flag).
- Repeated options like `-p 2 -p 3` → "cannot be used multiple times".

## CSV parsing
- `csv` crate behavior:
  - Quoted fields, embedded `""` escape, embedded delimiter, embedded newlines.
  - Trailing content after closing quote concatenates: `"x"y` → `xy`.
  - Quote in middle of unquoted = literal.
  - Line terminators: LF, CRLF (normalized to LF), and CR alone all work.
  - BOM at start is stripped; BOM in middle is preserved as text.
  - Empty/blank lines between records are skipped.
  - Mismatched field count → error.
  - Invalid UTF-8 → error.

## Error messages (exact format)

- File not found: `csview: No such file or directory (os error 2)\n` (exit 1)
- Directory: `csview: Is a directory (os error 21)\n`
- Permission denied: `csview: Permission denied (os error 13)\n`
- Field count mismatch: `csview: CSV error: record <N> (line: <L>, byte: <B>): found record with <X> fields, but the previous record has <Y> fields\n`
  - `<N>` = data record index (0-based, excluding header line if -H not set)
  - `<L>` = line number (1-based, counting all lines including header)
  - `<B>` = byte offset where the differing field count was detected
- Invalid UTF-8: `csview: CSV parse error: record <N> (line <L>, field: <F>, byte: <B>): invalid utf-8: invalid UTF-8 in field <F> near byte index <I>\n`
- All clap errors go to stderr with `error:` prefix and structure:
  ```
  error: <message>

  [tip: ...]
  Usage: <usage>

  For more information, try '--help'.
  ```

## Width calculation (per cell)

Use grapheme cluster segmentation. Per grapheme `g`:
- If g is 1 char AND `UnicodeWidthChar::width(c)` is None (control char): width = 1
- Else: width = `UnicodeWidthStr::width(g)` (in unicode-width 0.2.0, this handles ZWJ-emoji, VS-16/15 promotion, etc.)

Notable cases verified:
- `\n`, `\r`, `\t`, `\x00`, `\x01` (controls): width 1 each
- `你`, `好`, `龙` (CJK): 2
- 😀 (single emoji): 2
- 👨‍👩‍👧 (ZWJ family): 2 (collapsed by unicode-width 0.2.0)
- 🇺🇸 (flag = 2 RIs): 2
- ☃ alone: 1; ☃️ (with VS-16): 2
- ✂ alone: 1; ✂️: 2; ❤: 1; ❤️: 2
- ñ, Á (precomposed): 1
- A\u{0301} (A + combining): 1 (combining is 0)
- VS-16 alone: 0; combining mark alone: 0; ZWJ alone: 0
- Halfwidth ﾑ: 1; Fullwidth Ａ: 2

Cell width = sum of grapheme widths (including embedded \n as width 1).

## Column width

For each column:
- `col_content_width = max(header_width, body_widths[i] for i in 0..sniff_limit)` (sniff=0 means no limit)
- Note: header is ALWAYS included in width calc.
- For rows beyond sniff limit: cell is TRUNCATED to fit `col_content_width` (chars taken until they no longer fit visually).

## Sniff truncation

Cell value `v` in col with content width `w`:
- If `width(v) <= w`: no truncation (the cell value is used as-is, padded with spaces per alignment)
- If `width(v) > w`: take graphemes from start until adding the next grapheme would exceed `w`. The remaining content is dropped. Pad to `w` per alignment.

## Cell rendering

Cell content within content width `w`:
- left-align: `content` + spaces to fill
- right-align: spaces + `content` 
- center-align: `floor((w - cw) / 2)` spaces + content + `ceil((w - cw) / 2)` spaces
  Where `cw = width(content)` (after truncation)

Then padded with `p` spaces on each side: `{pad}{aligned}{pad}`

Default alignments:
- Header: center
- Body: left

## Multiline cells (cells with embedded \n)

csview is NAIVE about multiline cells:
- The cell content is output as-is including embedded `\n`.
- Width = width-with-\n-counted-as-1.
- So a cell "hello\nworld" has width 11, and prints as:
  ```
  │ hello
  world │ ...
  ```
- Alignment doesn't really work for multiline (the body-align is computed on the whole string, but the rendering uses the embedded newlines).

## Styles

Each style defines border characters and which separators appear.

### Sharp (default)
```
┌─...─┬─...─┐    (top)
│ h1  │ h2  │    (header)
├─...─┼─...─┤    (separator between header and body)
│ b1  │ b2  │    (body row)
└─...─┴─...─┘    (bottom)
```

### Rounded
Like sharp but corners are: ╭ ╮ ╰ ╯ (top-left, top-right, bottom-left, bottom-right).

### Reinforced
Like sharp but corners are: ┏ ┓ ┗ ┛.

### Grid
Like sharp BUT also has separator between EACH body row (uses same chars as header/body separator).

### Markdown
```
| h1 | h2 |       (header)
|----|----|       (separator: `-` chars + `|`)
| b1 | b2 |       (body)
```
No top/bottom borders.

### Ascii
```
+----+----+       (top)
| h1 | h2 |       (header)
+----+----+       (separator)
| b1 | b2 |       (body)
+----+----+       (bottom)
```

### Ascii2
```
  h1 | h2         (header, with leading and trailing space)
 ----+----        (separator, with leading and trailing space)
  b1 | b2         (body, with leading and trailing space)
```
- Always 1 outer space on each side (independent of padding).
- No top/bottom borders.
- Vertical: `|` between cells; cross/junction: `+`; horizontal: `-`.

### None
No borders, no separators. Just cells padded + concatenated with no separator chars between, plus indent.

## Separator rules

| Style       | Top | Header/Body sep | Body/Body sep | Bottom |
|-------------|-----|-----------------|---------------|--------|
| sharp       | yes | yes             | no            | yes    |
| rounded     | yes | yes             | no            | yes    |
| reinforced  | yes | yes             | no            | yes    |
| grid        | yes | yes             | yes           | yes    |
| markdown    | no  | yes             | no            | no     |
| ascii       | yes | yes             | no            | yes    |
| ascii2      | no  | yes             | no            | no     |
| none        | no  | no              | no            | no     |

When `-H` (no-headers): the header/body separator is NOT emitted (rows are all data).
- Exception: grid style still emits separator between every row.

When there's no body (only header): no header/body separator is emitted.

## -n (number column)

Prepend a column labeled `#` (header) with row numbers 1, 2, ..., N.
- With -H, `#` is just a regular header for the first row.
- The `#` column is the first column.

## Padding (-p, default 1)

Spaces on each side of cell content. Column total width = content_width + 2*padding.

For style "ascii2", padding affects cell width but there's an ADDITIONAL 1-space outer margin.

## Indent (-i, default 0)

Each output line is prefixed with `indent` spaces.

## File / stdin

If `FILE` is given, read from that file. Otherwise read from stdin.
- File `-` is a literal filename (errors).
- Multiple positional args → clap error.

## Determinism

Output is deterministic for a given input.

## --disable-pager (-P)

No observable effect when piped (pager only matters for TTY). Safe to ignore.
