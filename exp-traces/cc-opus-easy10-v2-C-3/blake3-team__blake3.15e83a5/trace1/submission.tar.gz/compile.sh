#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Prefer the cargo-installed rustc if present
if [ -x /usr/local/cargo/bin/rustc ]; then
    RUSTC=/usr/local/cargo/bin/rustc
else
    RUSTC=rustc
fi

"$RUSTC" -O --edition 2021 src/main.rs -o executable
