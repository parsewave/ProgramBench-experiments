mod blake3;

use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::path::Path;
use std::process::ExitCode;

use blake3::{Hasher, KEY_LEN};

// Ignore SIGPIPE so broken pipe causes Err(EPIPE) instead of process kill.
// Without libc, we declare the signal() libc function directly.
extern "C" {
    fn signal(sig: i32, handler: usize) -> usize;
}
const SIGPIPE: i32 = 13;
const SIG_IGN: usize = 1;

fn setup_signals() {
    // Ignore SIGPIPE — broken-pipe writes return EPIPE instead of killing the
    // process. The reference binary ignores all write errors silently, so we
    // do the same via the say!/say_raw! macros.
    unsafe {
        signal(SIGPIPE, SIG_IGN);
    }
}

// `say!` writes a line to stdout, ignoring any write error (so broken pipe
// won't panic). Returns nothing.
macro_rules! say {
    ($($arg:tt)*) => {{
        let stdout = io::stdout();
        let mut out = stdout.lock();
        let _ = writeln!(out, $($arg)*);
    }};
}

macro_rules! say_raw {
    ($buf:expr) => {{
        let stdout = io::stdout();
        let mut out = stdout.lock();
        let _ = out.write_all($buf);
    }};
}

// ============================================================================
// Argument parsing — mimics clap derive layout used by b3sum 1.8.4
// ============================================================================

#[derive(Default)]
struct Args {
    keyed: bool,
    derive_key: Option<String>,
    length: Option<u64>,
    seek: Option<u64>,
    num_threads: Option<u64>,
    no_mmap: bool,
    no_names: bool,
    raw: bool,
    tag: bool,
    check: bool,
    quiet: bool,
    files: Vec<String>,
    // Track what was provided on the CLI, in order — for Usage lines.
    provided_flags: Vec<&'static str>,
    // Pre-scan: true if argv contains any token that would become a
    // positional (used to format `<FILE>...` vs `[FILE]...` in usage
    // lines for conflict/required errors).
    any_positional_in_argv: bool,
}

const FLAG_KEYED: &str = "--keyed";
const FLAG_DERIVE_KEY: &str = "--derive-key <CONTEXT>";
const FLAG_LENGTH: &str = "--length <LEN>";
const FLAG_SEEK: &str = "--seek <SEEK>";
const FLAG_NUM_THREADS: &str = "--num-threads <NUM>";
const FLAG_NO_MMAP: &str = "--no-mmap";
const FLAG_NO_NAMES: &str = "--no-names";
const FLAG_RAW: &str = "--raw";
const FLAG_TAG: &str = "--tag";
const FLAG_CHECK: &str = "--check";
const FLAG_QUIET: &str = "--quiet";

fn flag_short_name(flag: &str) -> &str {
    // Strip the placeholder part for the short representation used in some lines.
    // E.g. "--length <LEN>" -> "--length" when shown in error tip context.
    // But the canonical conflict-message form keeps the placeholder.
    flag.split_whitespace().next().unwrap_or(flag)
}

// Jaro-Winkler similarity, matches clap's "did you mean" heuristic.
fn jaro(s1: &[char], s2: &[char]) -> f64 {
    if s1.is_empty() && s2.is_empty() {
        return 1.0;
    }
    if s1.is_empty() || s2.is_empty() {
        return 0.0;
    }
    let max_len = std::cmp::max(s1.len(), s2.len());
    let match_dist = if max_len <= 1 { 0 } else { max_len / 2 - 1 };

    let mut s1_matches = vec![false; s1.len()];
    let mut s2_matches = vec![false; s2.len()];
    let mut matches: usize = 0;

    for i in 0..s1.len() {
        let start = i.saturating_sub(match_dist);
        let end = std::cmp::min(i + match_dist + 1, s2.len());
        for j in start..end {
            if s2_matches[j] {
                continue;
            }
            if s1[i] != s2[j] {
                continue;
            }
            s1_matches[i] = true;
            s2_matches[j] = true;
            matches += 1;
            break;
        }
    }

    if matches == 0 {
        return 0.0;
    }

    let mut transpositions: usize = 0;
    let mut k: usize = 0;
    for i in 0..s1.len() {
        if !s1_matches[i] {
            continue;
        }
        while !s2_matches[k] {
            k += 1;
        }
        if s1[i] != s2[k] {
            transpositions += 1;
        }
        k += 1;
    }

    let m = matches as f64;
    let s1_len = s1.len() as f64;
    let s2_len = s2.len() as f64;
    (m / s1_len + m / s2_len + (m - transpositions as f64 / 2.0) / m) / 3.0
}

fn jaro_winkler(s1: &str, s2: &str) -> f64 {
    let c1: Vec<char> = s1.chars().collect();
    let c2: Vec<char> = s2.chars().collect();
    let j = jaro(&c1, &c2);
    let prefix_len = c1
        .iter()
        .zip(c2.iter())
        .take(4)
        .take_while(|(a, b)| a == b)
        .count();
    j + prefix_len as f64 * 0.1 * (1.0 - j)
}

fn suggest_long(unknown: &str) -> Option<&'static str> {
    let candidates: &[&'static str] = &[
        "--keyed",
        "--derive-key",
        "--length",
        "--seek",
        "--num-threads",
        "--no-mmap",
        "--no-names",
        "--raw",
        "--tag",
        "--check",
        "--quiet",
        "--help",
        "--version",
    ];
    // Strip the `--` prefix in similarity calculation to match clap.
    let unk_bare = unknown.trim_start_matches('-');
    let mut best: (f64, &'static str) = (0.0, "");
    for c in candidates {
        let c_bare = c.trim_start_matches('-');
        let score = jaro_winkler(unk_bare, c_bare);
        if score > best.0 {
            best = (score, c);
        }
    }
    if best.0 >= 0.7 {
        Some(best.1)
    } else {
        None
    }
}

// For a known long flag name, return the value placeholder form for Usage.
fn flag_usage_form(name: &str) -> Option<&'static str> {
    match name {
        "--keyed" => Some("--keyed"),
        "--derive-key" => Some("--derive-key <CONTEXT>"),
        "--length" => Some("--length <LEN>"),
        "--seek" => Some("--seek <SEEK>"),
        "--num-threads" => Some("--num-threads <NUM>"),
        "--no-mmap" => Some("--no-mmap"),
        "--no-names" => Some("--no-names"),
        "--raw" => Some("--raw"),
        "--tag" => Some("--tag"),
        "--check" => Some("--check"),
        "--quiet" => Some("--quiet"),
        "--help" => Some("--help"),
        "--version" => Some("--version"),
        _ => None,
    }
}

fn parse_u64(s: &str, flag: &str) -> Result<u64, ClapError> {
    match s.parse::<u64>() {
        Ok(n) => Ok(n),
        Err(e) => {
            let msg = match e.kind() {
                std::num::IntErrorKind::PosOverflow | std::num::IntErrorKind::NegOverflow => {
                    "number too large to fit in target type"
                }
                std::num::IntErrorKind::Empty => "cannot parse integer from empty string",
                _ => "invalid digit found in string",
            };
            Err(ClapError::InvalidValue {
                value: s.to_string(),
                flag: flag.to_string(),
                reason: msg.to_string(),
            })
        }
    }
}

enum ClapError {
    Unknown {
        arg: String,
    },
    NeedValue {
        flag: &'static str,
    },
    InvalidValue {
        value: String,
        flag: String,
        reason: String,
    },
    Conflict {
        first: &'static str,
        second: &'static str,
    },
    ConflictMulti {
        first: &'static str,
        others: Vec<&'static str>,
    },
    RequiredMissing {
        missing: Vec<&'static str>,
    },
}

// The Usage line shows program name (basename), then optional flags + FILE marker.
fn prog_name() -> String {
    let arg0 = env::args().next().unwrap_or_else(|| "b3sum".to_string());
    let p = Path::new(&arg0);
    p.file_name()
        .map(|f| f.to_string_lossy().to_string())
        .unwrap_or(arg0)
}

fn write_usage_line(stderr: &mut dyn Write, flags: &[&str], file_required: bool) {
    let mut s = String::new();
    s.push_str(&prog_name());
    if flags.is_empty() {
        s.push_str(" [OPTIONS]");
    } else {
        for f in flags {
            s.push(' ');
            s.push_str(f);
        }
    }
    if file_required {
        s.push_str(" <FILE>...");
    } else {
        s.push_str(" [FILE]...");
    }
    let _ = writeln!(stderr, "Usage: {}", s);
}

fn emit_clap_error(err: ClapError, args: &Args) {
    let mut stderr = io::stderr().lock();
    match err {
        ClapError::Unknown { arg } => {
            let _ = writeln!(stderr, "error: unexpected argument '{}' found", arg);
            let _ = writeln!(stderr);
            // Check for "did you mean" suggestion (long flags only).
            let suggestion = if arg.starts_with("--") {
                suggest_long(&arg)
            } else {
                None
            };
            // For unknown-arg errors, FILE is required iff a positional
            // already appeared before the error point.
            let file_required = !args.files.is_empty();
            if let Some(s) = suggestion {
                let _ = writeln!(stderr, "  tip: a similar argument exists: '{}'", s);
                let _ = writeln!(stderr);
                let usage_form = flag_usage_form(s).unwrap_or(s);
                let mut shown: Vec<&str> = Vec::new();
                shown.push(usage_form);
                for f in &args.provided_flags {
                    if flag_short_name(f) != s {
                        shown.push(f);
                    }
                }
                write_usage_line(&mut stderr, &shown, file_required);
            } else {
                let _ = writeln!(
                    stderr,
                    "  tip: to pass '{}' as a value, use '-- {}'",
                    arg, arg
                );
                let _ = writeln!(stderr);
                if args.provided_flags.is_empty() {
                    write_usage_line(&mut stderr, &args.provided_flags, file_required);
                } else {
                    write_usage_line(&mut stderr, &args.provided_flags, file_required);
                }
            }
            let _ = writeln!(stderr);
            let _ = writeln!(stderr, "For more information, try '--help'.");
        }
        ClapError::NeedValue { flag } => {
            let _ = writeln!(
                stderr,
                "error: a value is required for '{}' but none was supplied",
                flag
            );
            let _ = writeln!(stderr);
            let _ = writeln!(stderr, "For more information, try '--help'.");
        }
        ClapError::InvalidValue {
            value,
            flag,
            reason,
        } => {
            let _ = writeln!(
                stderr,
                "error: invalid value '{}' for '{}': {}",
                value, flag, reason
            );
            let _ = writeln!(stderr);
            let _ = writeln!(stderr, "For more information, try '--help'.");
        }
        ClapError::Conflict { first, second } => {
            let _ = writeln!(
                stderr,
                "error: the argument '{}' cannot be used with '{}'",
                first, second
            );
            let _ = writeln!(stderr);
            let first_short = flag_short_name(first);
            let f_conflicts = conflicts_for(first_short);
            let mut shown: Vec<&str> = vec![first];
            for f in &args.provided_flags {
                if *f == first {
                    continue;
                }
                let other_short = flag_short_name(f);
                if !f_conflicts.contains(&other_short) {
                    shown.push(f);
                }
            }
            let file_required = shown.iter().any(|s| flag_short_name(s) == "--keyed")
                || !args.files.is_empty();
            write_usage_line(&mut stderr, &shown, file_required);
            let _ = writeln!(stderr);
            let _ = writeln!(stderr, "For more information, try '--help'.");
        }
        ClapError::ConflictMulti { first, others } => {
            let _ = writeln!(
                stderr,
                "error: the argument '{}' cannot be used with:",
                first
            );
            for o in &others {
                let _ = writeln!(stderr, "  {}", o);
            }
            let _ = writeln!(stderr);
            let first_short = flag_short_name(first);
            let f_conflicts = conflicts_for(first_short);
            let mut shown: Vec<&str> = vec![first];
            for f in &args.provided_flags {
                if *f == first {
                    continue;
                }
                let other_short = flag_short_name(f);
                if !f_conflicts.contains(&other_short) {
                    shown.push(f);
                }
            }
            let file_required = shown.iter().any(|s| flag_short_name(s) == "--keyed")
                || !args.files.is_empty();
            write_usage_line(&mut stderr, &shown, file_required);
            let _ = writeln!(stderr);
            let _ = writeln!(stderr, "For more information, try '--help'.");
        }
        ClapError::RequiredMissing { missing } => {
            let _ = writeln!(
                stderr,
                "error: the following required arguments were not provided:"
            );
            for m in &missing {
                let _ = writeln!(stderr, "  {}", m);
            }
            let _ = writeln!(stderr);
            // Usage line: missing flags first (in struct order), then user flags
            let mut flags: Vec<&str> = Vec::new();
            for m in &missing {
                if *m != "<FILE>..." {
                    flags.push(m);
                }
            }
            for f in &args.provided_flags {
                if !flags.contains(f) {
                    flags.push(f);
                }
            }
            let file_required =
                missing.contains(&"<FILE>...") || !args.files.is_empty();
            write_usage_line(&mut stderr, &flags, file_required);
            let _ = writeln!(stderr);
            let _ = writeln!(stderr, "For more information, try '--help'.");
        }
    }
}

fn conflicts_for(short_name: &str) -> &'static [&'static str] {
    match short_name {
        "--check" => &["--keyed", "--derive-key", "--length", "--no-names", "--raw", "--tag"],
        "--keyed" => &["--check", "--derive-key"],
        "--derive-key" => &["--check", "--keyed"],
        "--length" => &["--check"],
        "--no-names" => &["--check"],
        "--raw" => &["--check"],
        "--tag" => &["--check"],
        _ => &[],
    }
}

// After all args are parsed, scan provided_flags in cmdline order to find
// the earliest flag that has at least one conflict among the others.
// Returns the conflict error to emit, if any.
fn find_conflicts(args: &Args) -> Option<ClapError> {
    for (idx, f) in args.provided_flags.iter().enumerate() {
        let short = flag_short_name(f);
        let conflicts = conflicts_for(short);
        if conflicts.is_empty() {
            continue;
        }
        // Find all other provided flags that conflict with this one.
        let mut conflicting: Vec<&'static str> = Vec::new();
        for (jdx, other) in args.provided_flags.iter().enumerate() {
            if jdx == idx {
                continue;
            }
            let other_short = flag_short_name(other);
            if conflicts.contains(&other_short) {
                conflicting.push(other);
            }
        }
        if !conflicting.is_empty() {
            if conflicting.len() == 1 {
                return Some(ClapError::Conflict {
                    first: f,
                    second: conflicting[0],
                });
            } else {
                return Some(ClapError::ConflictMulti {
                    first: f,
                    others: conflicting,
                });
            }
        }
    }
    None
}

fn is_flag_set(args: &Args, short_name: &str) -> bool {
    match short_name {
        "--keyed" => args.keyed,
        "--derive-key" => args.derive_key.is_some(),
        "--length" => args.length.is_some(),
        "--seek" => args.seek.is_some(),
        "--num-threads" => args.num_threads.is_some(),
        "--no-mmap" => args.no_mmap,
        "--no-names" => args.no_names,
        "--raw" => args.raw,
        "--tag" => args.tag,
        "--check" => args.check,
        "--quiet" => args.quiet,
        _ => false,
    }
}

fn find_provided(args: &Args, short_name: &str) -> Option<&'static str> {
    args.provided_flags
        .iter()
        .find(|f| flag_short_name(f) == short_name)
        .copied()
}

fn mark_provided(args: &mut Args, flag: &'static str) {
    if !args.provided_flags.contains(&flag) {
        args.provided_flags.push(flag);
    }
}

// Parse a single long flag with optional inline =VALUE.
// Returns Some(value) if value follows, or None for boolean flags.
fn split_eq(s: &str) -> (&str, Option<&str>) {
    if let Some(idx) = s.find('=') {
        (&s[..idx], Some(&s[idx + 1..]))
    } else {
        (s, None)
    }
}

// Recognize tokens that "look like" a flag (have a known long name or
// known short-flag-cluster prefix). Used to distinguish missing-value
// from unexpected-argument errors when parsing values from next token.
fn looks_like_known_flag(s: &str) -> bool {
    if s == "-" || s == "--" {
        return false;
    }
    if let Some(rest) = s.strip_prefix("--") {
        let name = rest.split('=').next().unwrap_or("");
        matches!(
            name,
            "keyed"
                | "derive-key"
                | "length"
                | "seek"
                | "num-threads"
                | "no-mmap"
                | "no-names"
                | "raw"
                | "tag"
                | "check"
                | "quiet"
                | "help"
                | "version"
        )
    } else if let Some(rest) = s.strip_prefix('-') {
        let first = rest.chars().next().unwrap_or('\0');
        matches!(first, 'l' | 'c' | 'h' | 'V')
    } else {
        false
    }
}

// `-` is a positional. `--` is the terminator. Anything else starting with
// `-` looks like a flag (known or unknown).
fn looks_like_any_flag(s: &str) -> bool {
    s.starts_with('-') && s != "-" && s != "--"
}

enum ValueErr {
    Missing,   // emit "a value is required for FLAG"
    Unexpected(String), // emit "unexpected argument 'X' found"
}

// Take the value for a flag that requires one. `inline_val` is Some when
// `--flag=value` was used (always taken verbatim). Otherwise, the next
// argv token is taken — unless it looks like a flag, in which case we
// return ValueErr::Missing (for known flag prefixes) or
// ValueErr::Unexpected (for unknown flag prefixes).
fn take_flag_value(
    argv: &[String],
    i: &mut usize,
    inline_val: Option<String>,
) -> Result<String, ValueErr> {
    if let Some(v) = inline_val {
        return Ok(v);
    }
    if *i + 1 >= argv.len() {
        return Err(ValueErr::Missing);
    }
    let next = &argv[*i + 1];
    if next == "--" {
        // `--` terminator: original flag is missing its value.
        return Err(ValueErr::Missing);
    }
    if looks_like_any_flag(next) {
        if looks_like_known_flag(next) {
            return Err(ValueErr::Missing);
        } else {
            return Err(ValueErr::Unexpected(next.clone()));
        }
    }
    *i += 1;
    Ok(argv[*i].clone())
}

// Pre-scan argv to determine whether ANY token would become a positional.
// Skips over value-taking flags' immediate next-token. Used to decide whether
// the Usage line shows `<FILE>...` or `[FILE]...` in conflict errors.
fn prescan_has_positional(argv: &[String]) -> bool {
    let mut i = 0;
    let mut after_dash_dash = false;
    while i < argv.len() {
        let a = &argv[i];
        if after_dash_dash {
            return true;
        }
        if a == "--" {
            after_dash_dash = true;
            i += 1;
            continue;
        }
        if a == "-" || !a.starts_with('-') {
            return true;
        }
        // It's a flag. If it's a value-taking flag without inline =, skip next token.
        if a.starts_with("--") {
            let name = a.split('=').next().unwrap_or("");
            // value-taking long flags
            let takes_value = matches!(
                name,
                "--derive-key" | "--length" | "--seek" | "--num-threads"
            );
            let has_inline = a.contains('=');
            if takes_value && !has_inline {
                i += 2;
                continue;
            }
        } else {
            // Short flag cluster. -l takes a value (rest-of-cluster or next token).
            let chars: Vec<char> = a[1..].chars().collect();
            let mut has_l_at_end = false;
            for (idx, c) in chars.iter().enumerate() {
                if *c == 'l' {
                    // -l with nothing after consumes next token as value
                    if idx == chars.len() - 1 {
                        has_l_at_end = true;
                    } else {
                        // -lX consumes X as value (already part of this token)
                    }
                    break;
                }
            }
            if has_l_at_end {
                i += 2;
                continue;
            }
        }
        i += 1;
    }
    false
}

fn parse_args() -> Result<Args, (Args, ClapError)> {
    let mut args = Args::default();
    let argv: Vec<String> = env::args().skip(1).collect();
    args.any_positional_in_argv = prescan_has_positional(&argv);
    let mut i = 0;
    let mut positional_only = false;

    macro_rules! err {
        ($e:expr) => {
            return Err((args, $e))
        };
    }

    macro_rules! take_val {
        ($flag:expr, $inline:expr) => {{
            match take_flag_value(&argv, &mut i, $inline) {
                Ok(v) => v,
                Err(ValueErr::Missing) => err!(ClapError::NeedValue { flag: $flag }),
                Err(ValueErr::Unexpected(bad)) => err!(ClapError::Unknown { arg: bad }),
            }
        }};
    }

    while i < argv.len() {
        let a = argv[i].clone();
        if positional_only {
            args.files.push(a);
            i += 1;
            continue;
        }
        if a == "--" {
            positional_only = true;
            i += 1;
            continue;
        }
        if a == "-" || !a.starts_with('-') {
            args.files.push(a);
            i += 1;
            continue;
        }
        if a.starts_with("--") {
            let (name_str, inline_val) = split_eq(&a);
            let name: String = name_str.to_string();
            let inline_val: Option<String> = inline_val.map(|s| s.to_string());
            match name.as_str() {
                "--help" => {
                    print_help_full();
                    std::process::exit(0);
                }
                "--version" => {
                    print_version();
                    std::process::exit(0);
                }
                "--keyed" => {
                    args.keyed = true;
                    mark_provided(&mut args, FLAG_KEYED);
                }
                "--derive-key" => {
                    let val = take_val!(FLAG_DERIVE_KEY, inline_val);
                    args.derive_key = Some(val);
                    mark_provided(&mut args, FLAG_DERIVE_KEY);
                }
                "--length" => {
                    let val = take_val!(FLAG_LENGTH, inline_val);
                    let n = match parse_u64(&val, FLAG_LENGTH) {
                        Ok(n) => n,
                        Err(e) => err!(e),
                    };
                    args.length = Some(n);
                    mark_provided(&mut args, FLAG_LENGTH);
                }
                "--seek" => {
                    let val = take_val!(FLAG_SEEK, inline_val);
                    let n = match parse_u64(&val, FLAG_SEEK) {
                        Ok(n) => n,
                        Err(e) => err!(e),
                    };
                    args.seek = Some(n);
                    mark_provided(&mut args, FLAG_SEEK);
                }
                "--num-threads" => {
                    let val = take_val!(FLAG_NUM_THREADS, inline_val);
                    let n = match parse_u64(&val, FLAG_NUM_THREADS) {
                        Ok(n) => n,
                        Err(e) => err!(e),
                    };
                    args.num_threads = Some(n);
                    mark_provided(&mut args, FLAG_NUM_THREADS);
                }
                "--no-mmap" => {
                    args.no_mmap = true;
                    mark_provided(&mut args, FLAG_NO_MMAP);
                }
                "--no-names" => {
                    args.no_names = true;
                    mark_provided(&mut args, FLAG_NO_NAMES);
                }
                "--raw" => {
                    args.raw = true;
                    mark_provided(&mut args, FLAG_RAW);
                }
                "--tag" => {
                    args.tag = true;
                    mark_provided(&mut args, FLAG_TAG);
                }
                "--check" => {
                    args.check = true;
                    mark_provided(&mut args, FLAG_CHECK);
                }
                "--quiet" => {
                    args.quiet = true;
                    mark_provided(&mut args, FLAG_QUIET);
                }
                _ => {
                    err!(ClapError::Unknown { arg: a });
                }
            }
            i += 1;
        } else {
            // Short flag(s): -xyz or -xVALUE
            let chars: Vec<char> = a[1..].chars().collect();
            let mut ci = 0;
            while ci < chars.len() {
                let c = chars[ci];
                match c {
                    'h' => {
                        print_help_short();
                        std::process::exit(0);
                    }
                    'V' => {
                        print_version();
                        std::process::exit(0);
                    }
                    'c' => {
                        args.check = true;
                        mark_provided(&mut args, FLAG_CHECK);
                    }
                    'l' => {
                        let val_str: String = if ci + 1 < chars.len() {
                            // -lVALUE: take rest of cluster as value
                            let v: String = chars[ci + 1..].iter().collect();
                            ci = chars.len();
                            v
                        } else {
                            // -l with value from next token (with heuristics)
                            take_val!(FLAG_LENGTH, None)
                        };
                        let n = match parse_u64(&val_str, FLAG_LENGTH) {
                            Ok(n) => n,
                            Err(e) => err!(e),
                        };
                        args.length = Some(n);
                        mark_provided(&mut args, FLAG_LENGTH);
                    }
                    _ => {
                        let bad = format!("-{}", c);
                        err!(ClapError::Unknown { arg: bad });
                    }
                }
                ci += 1;
            }
            i += 1;
        }
    }

    // Post-parse: detect conflicts among the set flags (in cmdline order).
    if let Some(e) = find_conflicts(&args) {
        err!(e);
    }

    // --quiet requires --check, UNLESS one of the flags that conflict with --check is set
    let quiet_satisfied = args.check
        || args.keyed
        || args.derive_key.is_some()
        || args.length.is_some()
        || args.no_names
        || args.raw
        || args.tag;
    if args.quiet && !quiet_satisfied {
        let mut missing: Vec<&'static str> = Vec::new();
        missing.push(FLAG_CHECK);
        if args.keyed && args.files.is_empty() {
            missing.push("<FILE>...");
        }
        err!(ClapError::RequiredMissing { missing });
    }
    // --keyed requires <FILE>...
    if args.keyed && args.files.is_empty() {
        let mut missing: Vec<&'static str> = Vec::new();
        missing.push("<FILE>...");
        err!(ClapError::RequiredMissing { missing });
    }
    // Empty arg `""` is rejected as empty positional value
    if args.files.iter().any(|f| f.is_empty()) {
        let mut stderr = io::stderr().lock();
        let _ = writeln!(
            stderr,
            "error: a value is required for '[FILE]...' but none was supplied"
        );
        let _ = writeln!(stderr);
        let _ = writeln!(stderr, "For more information, try '--help'.");
        std::process::exit(2);
    }

    Ok(args)
}

// ============================================================================
// Help text
// ============================================================================

fn print_version() {
    say!("b3sum 1.8.4");
}

fn print_help_short() {
    let p = prog_name();
    say!("Usage: {} [OPTIONS] [FILE]...", p);
    say!();
    say!("Arguments:");
    say!("  [FILE]...  Files to hash, or checkfiles to check");
    say!();
    say!("Options:");
    say!("      --keyed                 Use the keyed mode, reading the 32-byte key from stdin");
    say!("      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string");
    say!("  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]");
    say!("      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]");
    say!("      --num-threads <NUM>     The maximum number of threads to use");
    say!("      --no-mmap               Disable memory mapping");
    say!("      --no-names              Omit filenames in the output");
    say!("      --raw                   Write raw output bytes to stdout, rather than hex");
    say!("      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]");
    say!("  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them");
    say!("      --quiet                 Skip printing OK for each checked file");
    say!("  -h, --help                  Print help (see more with '--help')");
    say!("  -V, --version               Print version");
}

fn print_help_full() {
    let p = prog_name();
    say!("Usage: {} [OPTIONS] [FILE]...", p);
    say!();
    say!("Arguments:");
    say!("  [FILE]...");
    say!("          Files to hash, or checkfiles to check");
    say!("          ");
    say!("          When no file is given, or when - is given, read standard input.");
    say!();
    say!("Options:");
    say!("      --keyed");
    say!("          Use the keyed mode, reading the 32-byte key from stdin");
    say!();
    say!("      --derive-key <CONTEXT>");
    say!("          Use the key derivation mode, with the given context string");
    say!("          ");
    say!("          Cannot be used with --keyed.");
    say!();
    say!("  -l, --length <LEN>");
    say!("          The number of output bytes, before hex encoding");
    say!("          ");
    say!("          [default: 32]");
    say!();
    say!("      --seek <SEEK>");
    say!("          The starting output byte offset, before hex encoding");
    say!("          ");
    say!("          [default: 0]");
    say!();
    say!("      --num-threads <NUM>");
    say!("          The maximum number of threads to use");
    say!("          ");
    say!("          By default, this is the number of logical cores. If this flag is omitted, or if its value");
    say!("          is 0, RAYON_NUM_THREADS is also respected.");
    say!();
    say!("      --no-mmap");
    say!("          Disable memory mapping");
    say!("          ");
    say!("          Currently this also disables multithreading.");
    say!();
    say!("      --no-names");
    say!("          Omit filenames in the output");
    say!();
    say!("      --raw");
    say!("          Write raw output bytes to stdout, rather than hex");
    say!("          ");
    say!("          --no-names is implied. In this case, only a single input is allowed.");
    say!();
    say!("      --tag");
    say!("          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]");
    say!();
    say!("  -c, --check");
    say!("          Read BLAKE3 sums from the [FILE]s and check them");
    say!();
    say!("      --quiet");
    say!("          Skip printing OK for each checked file");
    say!("          ");
    say!("          Must be used with --check.");
    say!();
    say!("  -h, --help");
    say!("          Print help (see a summary with '-h')");
    say!();
    say!("  -V, --version");
    say!("          Print version");
}

// ============================================================================
// Hashing helpers
// ============================================================================

fn hex_encode(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push_str(&format!("{:02x}", b));
    }
    s
}

fn new_hasher(args: &Args, key: Option<[u8; KEY_LEN]>) -> Hasher {
    if let Some(k) = key {
        Hasher::new_keyed(&k)
    } else if let Some(ctx) = &args.derive_key {
        Hasher::new_derive_key(ctx)
    } else {
        Hasher::new()
    }
}

fn hash_reader<R: Read>(reader: &mut R, hasher: &mut Hasher) -> io::Result<()> {
    let mut buf = [0u8; 65536];
    loop {
        let n = reader.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }
    Ok(())
}

fn read_key_from_stdin() -> Result<[u8; KEY_LEN], String> {
    let mut buf = Vec::with_capacity(33);
    let mut stdin = io::stdin().lock();
    // Read up to KEY_LEN + 1 bytes
    let mut tmp = [0u8; 256];
    loop {
        let n = stdin.read(&mut tmp).map_err(|e| e.to_string())?;
        if n == 0 {
            break;
        }
        buf.extend_from_slice(&tmp[..n]);
        if buf.len() > KEY_LEN {
            return Err(format!("read more than 32 key bytes from stdin"));
        }
    }
    if buf.len() != KEY_LEN {
        return Err(format!(
            "expected 32 key bytes from stdin, found {}",
            buf.len()
        ));
    }
    let mut k = [0u8; KEY_LEN];
    k.copy_from_slice(&buf);
    Ok(k)
}

// Filename encoding for output (Coreutils-style).
// Returns (escaped_filename, needs_prefix).
fn escape_filename(name: &str) -> (String, bool) {
    let mut out = String::with_capacity(name.len());
    let mut needs = false;
    for c in name.chars() {
        match c {
            '\\' => {
                out.push_str("\\\\");
                needs = true;
            }
            '\n' => {
                out.push_str("\\n");
                needs = true;
            }
            _ => out.push(c),
        }
    }
    (out, needs)
}

fn write_hash_line(args: &Args, name: &str, hex: &str) {
    let stdout = io::stdout();
    let mut out = stdout.lock();
    if args.no_names {
        let _ = writeln!(out, "{}", hex);
    } else if args.tag {
        let (esc, needs) = escape_filename(name);
        if needs {
            let _ = writeln!(out, "\\BLAKE3 ({}) = {}", esc, hex);
        } else {
            let _ = writeln!(out, "BLAKE3 ({}) = {}", esc, hex);
        }
    } else {
        let (esc, needs) = escape_filename(name);
        if needs {
            let _ = writeln!(out, "\\{}  {}", hex, esc);
        } else {
            // Hmm, actually escape prefix is BEFORE the hash, not the name
            // Re-do properly below.
            let _ = writeln!(out, "{}  {}", hex, esc);
        }
    }
}

// ============================================================================
// Main hash flow
// ============================================================================

fn hash_file_to_bytes(args: &Args, path: &str, key: Option<[u8; KEY_LEN]>) -> io::Result<Vec<u8>> {
    let length = args.length.unwrap_or(32) as usize;
    let seek = args.seek.unwrap_or(0);
    let mut hasher = new_hasher(args, key);
    if path == "-" {
        let stdin = io::stdin();
        let mut lock = stdin.lock();
        hash_reader(&mut lock, &mut hasher)?;
    } else {
        let mut f = File::open(path)?;
        hash_reader(&mut f, &mut hasher)?;
    }
    let mut out = vec![0u8; length];
    if length > 0 {
        hasher.finalize_xof(&mut out, seek);
    }
    Ok(out)
}

fn print_hash_for(args: &Args, name: &str, bytes: &[u8]) {
    let hex = hex_encode(bytes);
    let stdout = io::stdout();
    let mut out = stdout.lock();
    if args.no_names {
        let _ = writeln!(out, "{}", hex);
    } else if args.tag {
        let (esc, needs) = escape_filename(name);
        if needs {
            let _ = writeln!(out, "\\BLAKE3 ({}) = {}", esc, hex);
        } else {
            let _ = writeln!(out, "BLAKE3 ({}) = {}", esc, hex);
        }
    } else {
        let (esc, needs) = escape_filename(name);
        if needs {
            let _ = writeln!(out, "\\{}  {}", hex, esc);
        } else {
            let _ = writeln!(out, "{}  {}", hex, esc);
        }
    }
}

fn do_hash(args: &Args) -> ExitCode {
    // --raw enforcement
    if args.raw {
        if args.files.len() > 1 {
            eprintln!("Error: Only one filename can be provided when using --raw");
            return ExitCode::from(1);
        }
    }

    // Read key if --keyed (always read first, so key-length errors come
    // before file-open errors).
    let key: Option<[u8; KEY_LEN]> = if args.keyed {
        match read_key_from_stdin() {
            Ok(k) => Some(k),
            Err(e) => {
                eprintln!("Error: {}", e);
                return ExitCode::from(1);
            }
        }
    } else {
        None
    };

    let files: Vec<String> = if args.files.is_empty() {
        vec!["-".to_string()]
    } else {
        args.files.clone()
    };

    let mut any_err = false;
    for f in &files {
        // In keyed mode, `-` is forbidden as a file.
        if args.keyed && f == "-" {
            eprintln!("b3sum: -: Cannot open `-` in keyed mode");
            any_err = true;
            continue;
        }
        match hash_file_to_bytes(args, f, key) {
            Ok(out) => {
                if args.raw {
                    let stdout = io::stdout();
                    let _ = stdout.lock().write_all(&out);
                } else {
                    print_hash_for(args, f, &out);
                }
            }
            Err(e) => {
                let msg = format_io_error(&e);
                eprintln!("b3sum: {}: {}", f, msg);
                any_err = true;
            }
        }
    }
    if any_err {
        ExitCode::from(1)
    } else {
        ExitCode::from(0)
    }
}

fn format_io_error(e: &io::Error) -> String {
    // Match Rust std::io::Error display, which produces "<message> (os error <N>)"
    // We replicate exactly to match Rust formatting.
    format!("{}", e)
}

// ============================================================================
// Check mode
// ============================================================================

struct ParsedLine {
    escaped: bool,           // whether line started with `\` (so filename uses escapes)
    display_name: String,    // name as displayed (escaped form, may include leading `\`)
    actual_path: String,     // de-escaped path (used to open the file)
    expected_hash: [u8; 32], // 32-byte hash
}

enum LineError {
    EmptyLine,
    InvalidFormat,
    InvalidHashLen,
    InvalidHex,
    EmptyPath,
}

fn line_error_msg(e: &LineError) -> &'static str {
    match e {
        LineError::EmptyLine => "Empty line",
        LineError::InvalidFormat => "Invalid check line format",
        LineError::InvalidHashLen => "Invalid hash length",
        LineError::InvalidHex => "Invalid hex",
        LineError::EmptyPath => "empty file path",
    }
}

fn parse_check_line(raw: &[u8]) -> Result<ParsedLine, LineError> {
    // Strip trailing \r (CRLF support)
    let mut bytes = raw;
    if bytes.last() == Some(&b'\r') {
        bytes = &bytes[..bytes.len() - 1];
    }
    if bytes.is_empty() {
        return Err(LineError::EmptyLine);
    }
    // Try as UTF-8 (filenames may not be UTF-8 in general; we treat bytes as latin-1 if needed)
    let line = match std::str::from_utf8(bytes) {
        Ok(s) => s.to_string(),
        Err(_) => {
            // Fallback: use lossy
            String::from_utf8_lossy(bytes).into_owned()
        }
    };

    let (escaped, body) = if let Some(stripped) = line.strip_prefix('\\') {
        (true, stripped)
    } else {
        (false, line.as_str())
    };

    // Try BSD-style: "BLAKE3 (NAME) = HEX"
    if let Some(rest) = body.strip_prefix("BLAKE3 (") {
        if let Some(end_paren) = rest.rfind(") = ") {
            let name_part = &rest[..end_paren];
            let hex_part = &rest[end_paren + 4..];
            return finalize_parse(escaped, name_part, hex_part);
        }
        return Err(LineError::InvalidFormat);
    }

    // Try Coreutils-style: HEX<two_spaces>NAME
    // Find first two-space sequence after hex chars.
    if let Some(idx) = find_double_space(body) {
        let hex_part = &body[..idx];
        let name_part = &body[idx + 2..];
        return finalize_parse(escaped, name_part, hex_part);
    }

    Err(LineError::InvalidFormat)
}

fn find_double_space(s: &str) -> Option<usize> {
    let bytes = s.as_bytes();
    for i in 0..bytes.len().saturating_sub(1) {
        if bytes[i] == b' ' && bytes[i + 1] == b' ' {
            return Some(i);
        }
    }
    None
}

fn finalize_parse(escaped: bool, name_part: &str, hex_part: &str) -> Result<ParsedLine, LineError> {
    if hex_part.len() != 64 {
        return Err(LineError::InvalidHashLen);
    }
    let mut hash = [0u8; 32];
    for i in 0..32 {
        let h = &hex_part[2 * i..2 * i + 2];
        let b1 = decode_hex_lower(h.as_bytes()[0])?;
        let b2 = decode_hex_lower(h.as_bytes()[1])?;
        hash[i] = (b1 << 4) | b2;
    }
    if name_part.is_empty() {
        return Err(LineError::EmptyPath);
    }
    let actual_path = if escaped {
        unescape_filename(name_part)
    } else {
        name_part.to_string()
    };
    let display_name = if escaped {
        format!("\\{}", name_part)
    } else {
        name_part.to_string()
    };
    Ok(ParsedLine {
        escaped,
        display_name,
        actual_path,
        expected_hash: hash,
    })
}

fn decode_hex_lower(b: u8) -> Result<u8, LineError> {
    match b {
        b'0'..=b'9' => Ok(b - b'0'),
        b'a'..=b'f' => Ok(b - b'a' + 10),
        _ => Err(LineError::InvalidHex),
    }
}

fn unescape_filename(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\\' {
            match chars.peek() {
                Some('\\') => {
                    chars.next();
                    out.push('\\');
                }
                Some('n') => {
                    chars.next();
                    out.push('\n');
                }
                _ => out.push(c),
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn do_check(args: &Args) -> ExitCode {
    let files: Vec<String> = if args.files.is_empty() {
        vec!["-".to_string()]
    } else {
        args.files.clone()
    };

    let mut any_failure = false;
    let mut failure_count: u64 = 0;
    let mut io_error: Option<String> = None;

    for cf in &files {
        let reader: Box<dyn BufRead> = if cf == "-" {
            Box::new(BufReader::new(io::stdin()))
        } else {
            match File::open(cf) {
                Ok(f) => Box::new(BufReader::new(f)),
                Err(e) => {
                    // Couldn't open the checkfile itself - fatal Error: ...
                    io_error = Some(format!("{}", e));
                    return print_check_io_error(io_error);
                }
            }
        };

        let mut line_buf: Vec<u8> = Vec::new();
        let mut reader = reader;
        loop {
            line_buf.clear();
            let n = match read_until(&mut reader, b'\n', &mut line_buf) {
                Ok(n) => n,
                Err(e) => {
                    io_error = Some(format!("{}", e));
                    return print_check_io_error(io_error);
                }
            };
            if n == 0 {
                break;
            }
            // Strip trailing \n
            if line_buf.last() == Some(&b'\n') {
                line_buf.pop();
            }
            match parse_check_line(&line_buf) {
                Ok(parsed) => {
                    // Hash the file
                    let mut hasher = match new_hasher_for_check(args) {
                        Ok(h) => h,
                        Err(_) => unreachable!(),
                    };
                    let result: io::Result<Vec<u8>> = if parsed.actual_path == "-" {
                        let mut stdin = io::stdin().lock();
                        let mut buf = [0u8; 65536];
                        let mut total = Vec::new();
                        loop {
                            match stdin.read(&mut buf) {
                                Ok(0) => break,
                                Ok(n) => total.extend_from_slice(&buf[..n]),
                                Err(e) => {
                                    return print_check_io_error(Some(format!("{}", e)));
                                }
                            }
                        }
                        Ok(total)
                    } else {
                        std::fs::read(&parsed.actual_path)
                    };
                    match result {
                        Ok(data) => {
                            hasher.update(&data);
                            let mut hash = [0u8; 32];
                            hasher.finalize_xof(&mut hash, 0);
                            if hash == parsed.expected_hash {
                                if !args.quiet {
                                    say!("{}: OK", parsed.display_name);
                                }
                            } else {
                                say!("{}: FAILED", parsed.display_name);
                                failure_count += 1;
                                any_failure = true;
                            }
                        }
                        Err(e) => {
                            say!(
                                "{}: FAILED ({})",
                                parsed.display_name,
                                format_io_error(&e)
                            );
                            failure_count += 1;
                            any_failure = true;
                        }
                    }
                }
                Err(le) => {
                    eprintln!("b3sum: {}", line_error_msg(&le));
                    failure_count += 1;
                    any_failure = true;
                }
            }
        }
    }

    if any_failure {
        let plural = if failure_count == 1 {
            "checksum"
        } else {
            "checksums"
        };
        eprintln!(
            "b3sum: WARNING: {} computed {} did NOT match",
            failure_count, plural
        );
        ExitCode::from(1)
    } else {
        ExitCode::from(0)
    }
}

fn new_hasher_for_check(args: &Args) -> Result<Hasher, ()> {
    // In check mode, none of --keyed/--derive-key/--length/etc. can be set (clap conflicts).
    // So always use plain hasher. But --seek IS allowed (causes hash mismatch).
    Ok(Hasher::new())
}

fn print_check_io_error(io_error: Option<String>) -> ExitCode {
    if let Some(e) = io_error {
        eprintln!("Error: {}", e);
    }
    ExitCode::from(1)
}

fn read_until<R: BufRead>(reader: &mut R, delim: u8, buf: &mut Vec<u8>) -> io::Result<usize> {
    reader.read_until(delim, buf)
}

// ============================================================================
// Main
// ============================================================================

fn main() -> ExitCode {
    setup_signals();
    let args = match parse_args() {
        Ok(a) => a,
        Err((partial, err)) => {
            emit_clap_error(err, &partial);
            return ExitCode::from(2);
        }
    };
    if args.check {
        do_check(&args)
    } else {
        do_hash(&args)
    }
}
