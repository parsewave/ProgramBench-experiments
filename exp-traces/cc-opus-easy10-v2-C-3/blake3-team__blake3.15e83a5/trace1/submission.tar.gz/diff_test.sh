#!/usr/bin/env bash
# Comprehensive differential testing script

SUT=/work/work/executable
REF=/workspace/executable
PASS=0
FAIL=0
FAILED_TESTS=()

t() {
    local label="$1"
    shift
    local ref_out ref_err ref_ec sut_out sut_err sut_ec
    local stdin_file=""
    if [ "$1" = "--stdin-file" ]; then
        stdin_file="$2"
        shift 2
        ref_out=$($REF "$@" < "$stdin_file" 2>/tmp/ref.err); ref_ec=$?
        sut_out=$($SUT "$@" < "$stdin_file" 2>/tmp/sut.err); sut_ec=$?
    elif [ "$1" = "--stdin" ]; then
        local stdin_data="$2"
        shift 2
        ref_out=$(printf '%s' "$stdin_data" | $REF "$@" 2>/tmp/ref.err); ref_ec=$?
        sut_out=$(printf '%s' "$stdin_data" | $SUT "$@" 2>/tmp/sut.err); sut_ec=$?
    else
        ref_out=$($REF "$@" 2>/tmp/ref.err); ref_ec=$?
        sut_out=$($SUT "$@" 2>/tmp/sut.err); sut_ec=$?
    fi
    ref_err=$(cat /tmp/ref.err)
    sut_err=$(cat /tmp/sut.err)
    local ok=true
    if [ "$ref_out" != "$sut_out" ]; then ok=false; fi
    if [ "$ref_err" != "$sut_err" ]; then ok=false; fi
    if [ "$ref_ec" != "$sut_ec" ]; then ok=false; fi
    if $ok; then
        PASS=$((PASS+1))
        # echo "PASS: $label"
    else
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$label")
        echo "FAIL: $label"
        echo "  REF_EC=$ref_ec SUT_EC=$sut_ec"
        if [ "$ref_out" != "$sut_out" ]; then
            echo "  STDOUT diff (< REF, > SUT):"
            diff <(printf '%s\n' "$ref_out") <(printf '%s\n' "$sut_out") | head -20 | sed 's/^/    /'
        fi
        if [ "$ref_err" != "$sut_err" ]; then
            echo "  STDERR diff:"
            diff <(printf '%s\n' "$ref_err") <(printf '%s\n' "$sut_err") | head -20 | sed 's/^/    /'
        fi
    fi
}

cd /work/work/goldens

# === Basic hashing ===
t "empty stdin" --stdin ""
t "hello stdin" --stdin "hello"
t "empty file" empty.bin
t "hello file" hello.bin
t "abc file" abc.bin
t "tv1023" tv1023.bin
t "tv1024" tv1024.bin
t "tv2048" tv2048.bin
t "tv8192" tv8192.bin
t "tv102400" tv102400.bin
t "multiple files" hello.bin abc.bin
t "tag" --tag hello.bin
t "tag multiple" --tag hello.bin abc.bin
t "no-names" --no-names hello.bin
t "no-names multiple" --no-names hello.bin abc.bin
t "tag + no-names" --tag --no-names hello.bin

# Length / seek
t "length 64" -l 64 hello.bin
t "length 0" -l 0 hello.bin
t "length 1" -l 1 hello.bin
t "length 100" -l 100 hello.bin
t "length 1024" -l 1024 hello.bin
t "seek 16" --seek 16 hello.bin
t "seek 16 len 16" --seek 16 -l 16 hello.bin
t "seek 1000" --seek 1000 -l 4 hello.bin

# Raw
t "raw" --raw hello.bin
t "raw -l 4" --raw -l 4 hello.bin
t "raw -l 0" --raw -l 0 hello.bin
t "raw stdin" --stdin "hello" --raw

# Keyed
t "keyed zero" --stdin-file /work/work/goldens/zerokey.bin --keyed hello.bin
t "keyed elvish empty" --stdin "whats the Elvish word for friend" --keyed empty.bin
t "keyed multiple files" --stdin-file /work/work/goldens/zerokey.bin --keyed hello.bin abc.bin

# Derive-key
t "derive empty" --stdin "" --derive-key "ctx"
t "derive testvec" --stdin "test data" --derive-key "BLAKE3 2019-12-27 16:29:52 test vectors context"
t "derive empty context" --stdin "input" --derive-key ""

# Help / version
t "version" --version
t "version short" -V
t "help" --help
t "help short" -h

# Errors / clap
t "bogus" --bogus
t "raw multi" --raw hello.bin abc.bin
t "raw with --tag" --stdin "hello" --raw --tag
t "quiet alone" --quiet
t "quiet stdin" --stdin "" --quiet
t "keyed no file" --stdin "" --keyed
t "keyed conflict derive" --keyed --derive-key x hello.bin
t "keyed conflict check" --keyed --check hello.bin
t "derive conflict check" --derive-key x --check hello.bin
t "check + tag" --check --tag hello.bin
t "check + raw" --check --raw hello.bin
t "check + no-names" --check --no-names hello.bin
t "check + length" --check --length 16 hello.bin
t "check + keyed" --check --keyed hello.bin
t "check + derive" --check --derive-key x hello.bin
t "tag + check" --tag --check hello.bin
t "raw + check" --raw --check hello.bin
t "neg -1" -l -1 hello.bin
t "invalid length abc" -l abc hello.bin
t "length =abc" --length=abc hello.bin
t "length overflow" -l 18446744073709551616 hello.bin
t "seek abc" --seek abc hello.bin
t "num-threads abc" --num-threads abc hello.bin
t "missing length value" -l
t "missing derive-key value" --derive-key
t "missing num-threads value" --num-threads
t "missing seek value" --seek
t "empty positional" ""
t "nonexistent file" nonexistent_xyz_zzz.bin

# Filename quirks
t "stdin with -" --stdin "hello" -
t "double --" --stdin "" --
t "single - and file" --stdin "extra" - hello.bin
t "two -" --stdin "extra" - -
t "-- then --bogus" --stdin "" -- --bogus

# Check mode
t "check sums.b3sum" --check sums.b3sum
t "check bad" --check bad_sums.b3sum
t "check bad quiet" --check --quiet bad_sums.b3sum

# Keyed edge cases
t "keyed - special" --stdin "12345678901234567890123456789012" --keyed -

echo
echo "=== Summary: PASS=$PASS FAIL=$FAIL ==="

# Check mode edge cases
echo
echo "=== Additional check mode tests ==="
cd /work/work/goldens

# Create various test checkfiles
$REF hello.bin > /tmp/sums_basic.txt
$REF --tag hello.bin > /tmp/sums_tag.txt
printf "deadbeef00000000000000000000000000000000000000000000000000000000  hello.bin\n" > /tmp/sums_wrong.txt
printf "BLAKE3 (hello.bin) = ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f\n" > /tmp/sums_bsd.txt
printf "EA8F163DB38682925E4491C5E58D4BB3506EF8C14EB78A86E908C5624A67200F  hello.bin\n" > /tmp/sums_upper.txt
printf "  ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f  hello.bin\n" > /tmp/sums_leadws.txt
printf "ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f  hello.bin\n\n" > /tmp/sums_emptyline.txt
printf "ea8f163  hello.bin\n" > /tmp/sums_oddlen.txt
printf "garbage line\n" > /tmp/sums_garbage.txt
printf "ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f  \n" > /tmp/sums_emptypath.txt

t "check basic" --check /tmp/sums_basic.txt
t "check tag" --check /tmp/sums_tag.txt
t "check wrong" --check /tmp/sums_wrong.txt
t "check bsd" --check /tmp/sums_bsd.txt
t "check upper hex" --check /tmp/sums_upper.txt
t "check leading ws" --check /tmp/sums_leadws.txt
t "check empty line trail" --check /tmp/sums_emptyline.txt
t "check odd length" --check /tmp/sums_oddlen.txt
t "check garbage" --check /tmp/sums_garbage.txt
t "check empty path" --check /tmp/sums_emptypath.txt
t "check quiet ok" --check --quiet /tmp/sums_basic.txt
t "check quiet bad" --check --quiet /tmp/sums_wrong.txt

# Stdin checks
t "check stdin good" --stdin-file /tmp/sums_basic.txt --check
t "check stdin via -" --stdin-file /tmp/sums_basic.txt --check -

# Multiple checkfiles
t "check multiple" --check /tmp/sums_basic.txt /tmp/sums_wrong.txt

# Missing checkfile
t "check missing file" --check /tmp/nonexistent_checkfile.txt

# CRLF
printf "ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f  hello.bin\r\n" > /tmp/sums_crlf.txt
t "check CRLF" --check /tmp/sums_crlf.txt

# Backslash in name
mkdir -p '/tmp/b3test_bs'
echo -n "back" > '/tmp/b3test_bs/file.txt'
echo -n "back" > '/tmp/b3test_bs/with\backslash.txt' 2>/dev/null
echo -n "back" > "/tmp/b3test_bs/$(printf 'with\nnewline.txt')" 2>/dev/null

(cd /tmp/b3test_bs && $REF 'with\backslash.txt') > /tmp/sums_bs.txt
t "check backslash" --check /tmp/sums_bs.txt
(cd /tmp/b3test_bs && $REF 'with\backslash.txt')
(cd /tmp && $SUT b3test_bs/with\\backslash.txt 2>&1)

# Generate hash for filename with backslash
ls /tmp/b3test_bs/

# Hash file with backslash from current dir
cd /tmp/b3test_bs
t "hash file with backslash" 'with\backslash.txt'
cd /work/work/goldens

echo
echo "=== Summary after extended tests: PASS=$PASS FAIL=$FAIL ==="
