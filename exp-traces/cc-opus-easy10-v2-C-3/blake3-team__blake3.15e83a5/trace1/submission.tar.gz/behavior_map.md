# b3sum behavior map

Reference binary: `/workspace/executable` (b3sum 1.8.4)
Identifying string: `b3sum 1.8.4\n` (program name hardcoded; argv[0] shown in Usage lines)

## CLI options (built on clap derive)

- `--keyed` — read 32-byte key from stdin, then hash the FILE(s) with keyed_hash mode
- `--derive-key <CONTEXT>` — derive_key mode, context string given
- `-l, --length <LEN>` — output length in bytes (default 32); XOF, any u64
- `--seek <SEEK>` — starting output byte offset (default 0); u64
- `--num-threads <NUM>` — max threads (no-op for correctness)
- `--no-mmap` — disable mmap (no-op for correctness)
- `--no-names` — omit filenames in output
- `--raw` — write raw output bytes; implies --no-names; only one FILE allowed
- `--tag` — output BSD-style: `BLAKE3 (NAME) = HASH`
- `-c, --check` — verify checksums from FILE(s)
- `--quiet` — only with --check; skip OK lines
- `-h, --help` / `--help` — print help (different verbosity)
- `-V, --version` — print "b3sum 1.8.4"

## Conflicts (clap-detected, exit 2)

- `--check` ⊥ `--keyed`, `--derive-key`, `--length`, `--no-names`, `--raw`, `--tag`
- `--keyed` ⊥ `--derive-key`
- `--quiet` requires `--check`

NOT in conflict with `--check`: `--seek`, `--no-mmap`, `--num-threads`, `--quiet`.

## Output formats

- Default: `HEX  FILENAME\n` (two spaces) — Coreutils style
- `--tag`: `BLAKE3 (FILENAME) = HEX\n`
- `--no-names`: `HEX\n`
- `--raw`: raw bytes, no newline
- stdin filename: `-`

## Backslash escaping (Coreutils style)

For filenames containing `\` or `\n`:
- Line is prefixed with `\`
- `\` becomes `\\`, newline becomes `\n` (literal backslash-n)
- Applies to both default and tag formats
- When checking, the escape prefix is preserved in OK/FAILED messages (display the parsed form), but the actual filename is de-escaped to open the file.

## --check format

Accepts two formats per line:
1. `HEX  FILENAME` (two spaces between hash and filename)
2. `BLAKE3 (FILENAME) = HEX` (BSD-style)

Lines may be prefixed by `\` indicating filename is escaped.

CRLF line endings are accepted (trailing `\r` stripped from filename).

Output per line:
- Success: `FILENAME: OK` (suppressed by --quiet)
- Hash mismatch: `FILENAME: FAILED`
- File open error: `FILENAME: FAILED (<os error msg>)`
- Parse error: `b3sum: <kind>` to stderr (counts as a failure)

Each parse failure counts towards "did NOT match" total.

Summary on stderr if any failures: `b3sum: WARNING: N computed checksum{s} did NOT match`
- "1 computed checksum" (singular)
- "2 computed checksums" (plural)

Hash length in check MUST be 64 hex chars (32 bytes). Other lengths → "Invalid hash length".
Lowercase hex only. Uppercase → "Invalid hex".

## Parse errors (each printed `b3sum: ...` to stderr)

- `Empty line` — empty line
- `Invalid check line format` — couldn't find " " separator or BLAKE3 prefix
- `Invalid hash length` — hex string not 64 chars
- `Invalid hex` — non-hex characters (uppercase included)
- `empty file path` — no filename after hash

## Exit codes

- 0: success
- 1: hashing error (file open, key read, etc.), or check failure
- 2: clap argument error

## Error message templates

Hashing errors (stderr):
- `b3sum: <filename>: <os error message> (os error <N>)`

Other errors (stderr):
- `Error: <message>` — e.g. "Error: Only one filename can be provided when using --raw"
- `Error: expected 32 key bytes from stdin, found <N>` — short key
- `Error: read more than 32 key bytes from stdin` — long key
- `b3sum: -: Cannot open `-` in keyed mode` — `--keyed -` is forbidden

Clap errors (stderr, exit 2):
- `error: unexpected argument '<X>' found\n\n  tip: to pass '<X>' as a value, use '-- <X>'\n\nUsage: <PROG> [OPTIONS] [FILE]...\n\nFor more information, try '--help'.\n`
- `error: the argument '<X>' cannot be used with '<Y>'\n\nUsage: <PROG> <X> <FILE>...\n\nFor more information, try '--help'.\n`
- `error: the following required arguments were not provided:\n  <X>...\n\nUsage: <PROG> [opts] <X>...\n\nFor more information, try '--help'.\n`
- `error: invalid value '<V>' for '<flag>': invalid digit found in string\n\nFor more information, try '--help'.\n`
- `error: a value is required for '<flag>' but none was supplied\n\nFor more information, try '--help'.\n`

## BLAKE3 algorithm notes

- IV = SHA-256 IV (8 u32 words)
- MSG_PERMUTATION = [2,6,3,10,7,0,4,13,1,11,12,5,9,14,15,8]
- 7 rounds (permute after rounds 1-6)
- Flags: CHUNK_START=1, CHUNK_END=2, PARENT=4, ROOT=8, KEYED_HASH=16, DERIVE_KEY_CONTEXT=32, DERIVE_KEY_MATERIAL=64
- Chunk = 1024 bytes = 16 blocks of 64 bytes
- Counter per chunk (not per block within chunk)
- Merkle binary tree of chunk CVs

## Modes

- Regular: key=IV, flags=0
- Keyed: key=user 32 bytes, flags=KEYED_HASH
- Derive key:
  1. Hash context with key=IV, flags=DERIVE_KEY_CONTEXT → 32-byte key
  2. Hash input with key=derived, flags=DERIVE_KEY_MATERIAL
