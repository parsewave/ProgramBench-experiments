#!/bin/bash
# Capture golden outputs from reference binary
# Usage: ./capture_goldens.sh [output-dir]
set -u
REF=${REF:-/workspace/executable}
OUT=${1:-/work/work/goldens}
mkdir -p "$OUT"
cd "$OUT"

# Helper: run a probe, capture stdout, stderr, exit code
probe() {
    local name="$1"
    shift
    local stdin="${1:-}"
    shift || true
    # Remaining args are passed to the reference binary
    local args=("$@")
    local out_file="${name}.stdout"
    local err_file="${name}.stderr"
    local ec_file="${name}.ec"
    if [[ -n "$stdin" ]]; then
        printf '%s' "$stdin" | timeout 10 "$REF" "${args[@]}" >"$out_file" 2>"$err_file"
    else
        : | timeout 10 "$REF" "${args[@]}" >"$out_file" 2>"$err_file"
    fi
    echo $? >"$ec_file"
}

# === Surface scan ===
probe "help-long" "" --help
probe "help-short" "" -h
probe "version-long" "" --version
probe "version-short" "" -V
probe "empty-args" ""
probe "bogus-flag" "" --bogus
probe "dash" "" -
probe "doubledash" "" --
probe "single-find" "" foo

# === Basic replace ===
probe "basic-replace" "hello world" hello goodbye
probe "regex-digits" "hello world 123" '\d+' NUM
probe "no-match" "abc" xyz QQQ
probe "empty-stdin" "" hello goodbye
probe "empty-find" "abc" "" "X"
probe "empty-replace" "abc" "a" ""
probe "both-empty" "abc" "" ""

# === Capture groups ===
probe "capgroup-numbered" "cargo +nightly watch" '(\w+)\s+\+(\w+)\s+(\w+)' 'cmd: $1, channel: $2, subcmd: $3'
probe "capgroup-named" "123.45" '(?P<dollars>\d+)\.(?P<cents>\d+)' '$dollars dollars and $cents cents'
probe "capgroup-braces" "123.45" '(?P<dollars>\d+)\.(?P<cents>\d+)' '${dollars}_dollars and ${cents}_cents'
probe "capgroup-unclosed" "123.45" '(?P<dollars>\d+)\.(?P<cents>\d+)' '$dollars_dollars and $cents_cents'
probe "dollar-dollar" "foo" "foo" '$$bar'
probe "dollar-1-end" "abc" "a" '$1'

# === Ambiguity ===
probe "ambig-1y" "abc" "a" 'X$1Y'
probe "ambig-2-existing" "abc" "(a)" 'X$2Y'
probe "ambig-0" "abc" "b" 'X$0Y'
probe "ambig-10y" "abc" "a" 'X$10Y'
probe "ambig-underscore" "abc" "a" '$1_'
probe "ambig-comma" "abc" "a" '$1,'
probe "ambig-dash" "abc" "a" '$1-'
probe "ambig-named-no-group" "abc" "a" 'X${name}Y'

# === Fixed-strings ===
probe "fixed-special-chars" 'lots((([]))) of special chars' -F '((([])))' ''
probe "fixed-long" 'lots((([]))) of special chars' --fixed-strings '((([])))' ''
probe "fixed-dollar" 'foo' -F 'foo' '$$bar'
probe "fixed-newline" $'foo\n' -F 'foo' 'a\nb'

# === Escape interpretation in regex mode ===
probe "regex-newline-in-replace" $'foo\n' 'foo' 'a\nb'
probe "regex-tab-in-replace" "foo" 'foo' 'a\tb'

# === Flags ===
probe "flag-i" "Hello WORLD" -f i 'hello' 'goodbye'
probe "flag-w" "hello hello1 hello" -f w 'hello' 'X'
probe "flag-m-anchored" $'abc\nabc' -f m '^abc$' 'X'
probe "flag-s-dot" $'a\nb' -f s 'a.b' 'X'
probe "flag-default-multiline" $'abc\nabc' '^abc$' 'X'
probe "flag-e-disables" $'abc\nabc' -f e '^abc' 'X'
probe "flag-s-disables-m" $'abc\nabc' -f s '^abc' 'X'
probe "flag-w-disables-m" $'abc\nabc' -f w '^abc' 'X'
probe "flag-sm-keeps-m" $'abc\nabc' -f sm '^abc' 'X'
probe "flag-wm-stays-off" $'abc\nabc' -f wm '^abc' 'X'
probe "flag-em-off" $'abc\nabc' -f em '^abc' 'X'
probe "flag-me-off" $'abc\nabc' -f me '^abc' 'X'
probe "flag-ci-last-i" "Hello" -f ci 'hello' 'X'
probe "flag-ic-last-c" "Hello" -f ic 'hello' 'X'
probe "flag-icic" "Hello" -f icic 'hello' 'X'
probe "flag-cici" "Hello" -f cici 'hello' 'X'
probe "flag-empty" "Hello" -f '' 'hello' 'X'
probe "flag-unknown" "test" -f 'q' 'test' 'X'
probe "flag-digit" "test" -f '1' 'test' 'X'
probe "flag-w-no-boundary" "a1b" -f w '1' 'X'
probe "flag-w-with-boundary" "a-b" -f w 'b' 'X'

# === Max replacements ===
probe "n-1" "aaaa" -n 1 a X
probe "n-0" "aaaa" -n 0 a X
probe "n-2" "aaaa" -n 2 a X
probe "n-big" "aaaa" -n 100 a X
probe "n-eq" "aaaa" -n=2 a X
probe "n-attached" "aaaa" -n2 a X
probe "n-neg" "aaaa" --max-replacements=-1 a X
probe "n-non-number" "aaaa" -n abc a X
probe "n-overflow" "aaaa" -n 99999999999999999999 a X

# === Preview / stdin ===
probe "preview-stdin" "hello" -p h X
probe "preview-no-match" "abc" -p xxx X

# === Args parsing ===
probe "F-twice" "abc" -F -F a X
probe "p-twice" "abc" -p -p a X
probe "f-twice" "abc" -f i -f m a X
probe "n-twice" "abc" -n 1 -n 2 a X

# === Regex syntax errors ===
probe "regex-unclosed" "abc" '[' X
probe "regex-look-ahead" "abc" '(?=abc)' X
probe "regex-look-behind" "abc" '(?<=abc)' X
probe "regex-unclosed-paren" "abc" '(abc' X
probe "regex-empty-named" "abc" '(?P<>abc)' X
probe "regex-unknown-flag" "abc" '(?z)abc' X

# === Binary/UTF8 ===
probe "stdin-binary" $'a\x00b\x01c' "b" "X"
probe "stdin-invalid-utf8" $'a\xffb' "b" "X"
probe "stdin-bom" $'\xef\xbb\xbfhello' "hello" "X"
probe "stdin-crlf" $'a\r\nb' "b" "X"
probe "utf8-chars" "naïve café" "a" "X"
probe "utf8-match-pattern" "naïve café" "café" "X"

# === Empty/edge cases ===
probe "empty-find-regex" "abc" "" X
probe "empty-find-fixed" "abc" -F "" X

# === Replacement edge cases ===
probe "ambig-1-no-trail-eof" "abc" "a" '$1'
probe "ambig-1-space-after" "abc" "a" '$1 Y'
probe "ambig-1-bang-after" "abc" "a" '$1!Y'
probe "ambig-1-digit-after" "abc" "a" '$11'

# === Inline flag override ===
probe "inline-m-override-e" $'abc\nabc' -f e '(?m)^abc' X
probe "inline-m-override-s" $'abc\nabc' -f s '(?m)^abc' X
probe "inline-m-override-w" $'abc\nabc' -f w '(?m)^abc' X

# === Even more probes ===
probe "ambig-long-prefix" "abc" "a" 'longprefix-$1-longsuffix'
probe "ambig-2-groups" "abc" "a" '$1abc$2def'

# Replacement escapes
probe "repl-tab" "abc" "a" 'X\tY'
probe "repl-cr" "abc" "a" 'X\rY'
probe "repl-bs" "abc" "a" 'X\\Y'
probe "repl-quote" "abc" "a" 'X\"Y'
probe "repl-hex" "abc" "a" 'X\x41Y'
probe "repl-hex-bad" "abc" "a" 'X\xZZY'
probe "repl-unknown-esc" "abc" "a" 'X\qY'
probe "repl-trailing-bs" "abc" "a" 'X\'
probe "repl-trailing-d" "abc" "a" 'X$'
probe "repl-trailing-brace" "abc" "a" 'X${'
probe "repl-empty-brace" "abc" "a" 'X${}Y'

# Group references
probe "group-numbered-3" "cargo +nightly watch" '(\w+)\s+\+(\w+)\s+(\w+)' '$3-$2-$1'
probe "group-zero" "abc" "(a)b" 'X${0}Y'
probe "group-zero-bare" "abc" "(a)b" 'X$0Y'
probe "group-99" "abc" "(a)" 'X$99Y'

# Regex edge cases
probe "regex-empty-group" "abc" '()' "X"
probe "regex-question" "abc" 'a?bc' "X"
probe "regex-alt-empty" "abc" 'a|' "X"

# Various flag tests
probe "flag-mw-no-match" "abc" -f mw '^abc' "X"
probe "flag-msw-pattern" "abc" -f msw 'abc' "X"
probe "flag-iwm" "abc" -f iwm 'ABC' "X"

# Replacement special cases
probe "repl-only-dollar" "abc" "a" '$'
probe "repl-only-bs" "abc" "a" '\'
probe "repl-double-dollar" "abc" "a" '$$'

# Captures with no match
probe "regex-no-match-with-cap" "xyz" '(a)' '$1Z'

# Various input shapes
probe "input-only-newlines" $'\n\n\n' '\n' "X"
probe "input-trailing-newline" $'abc\n' "abc" "X"
probe "input-leading-newline" $'\nabc' "abc" "X"

# Long replacement
probe "repl-long" "abc" "a" "AAAAAAAAAAAAAAAAAAAAAAAAAAAAA"

echo "Captured $(ls *.ec | wc -l) probes"
