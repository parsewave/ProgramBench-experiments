#!/bin/bash
# Fuzz-style differential testing
set -u
REF=${REF:-/workspace/executable}
SUT=${SUT:-/work/work/executable}
SEED=${SEED:-1}
N=${N:-100}

PASS=0
FAIL=0
FAILS=()

run_diff() {
    local label="$1"
    shift
    local stdin="$1"
    shift
    local ref_out=$(mktemp); local ref_err=$(mktemp)
    local sut_out=$(mktemp); local sut_err=$(mktemp)
    if [ -n "$stdin" ]; then
        printf '%s' "$stdin" | timeout 5 "$REF" "$@" >"$ref_out" 2>"$ref_err"
        local ref_ec=$?
        printf '%s' "$stdin" | timeout 5 "$SUT" "$@" >"$sut_out" 2>"$sut_err"
        local sut_ec=$?
    else
        : | timeout 5 "$REF" "$@" >"$ref_out" 2>"$ref_err"
        local ref_ec=$?
        : | timeout 5 "$SUT" "$@" >"$sut_out" 2>"$sut_err"
        local sut_ec=$?
    fi

    if [ "$ref_ec" != "$sut_ec" ] || ! diff -q "$ref_out" "$sut_out" >/dev/null 2>&1 || ! diff -q "$ref_err" "$sut_err" >/dev/null 2>&1; then
        FAIL=$((FAIL+1))
        if [ ${#FAILS[@]} -lt 5 ]; then
            FAILS+=("$label: args=$* stdin='$stdin' ec=$ref_ec/$sut_ec")
            echo "FAIL: $label"
            echo "  args: $@"
            echo "  stdin: $(printf '%s' "$stdin" | od -c | head -2)"
            [ "$ref_ec" != "$sut_ec" ] && echo "  EC: ref=$ref_ec sut=$sut_ec"
            if ! diff -q "$ref_out" "$sut_out" >/dev/null 2>&1; then
                echo "  Stdout diff:"
                diff "$ref_out" "$sut_out" | head -10 | sed 's/^/    /'
            fi
            if ! diff -q "$ref_err" "$sut_err" >/dev/null 2>&1; then
                echo "  Stderr diff:"
                diff "$ref_err" "$sut_err" | head -10 | sed 's/^/    /'
            fi
        fi
    else
        PASS=$((PASS+1))
    fi
    rm -f "$ref_out" "$ref_err" "$sut_out" "$sut_err"
}

# Generate random fuzz tests via Python
python3 - "$SEED" << 'EOF' > /tmp/fuzz_cases.txt
import random
import json
import sys
random.seed(int(sys.argv[1]))

flags_chars = "miscew"
def random_flags():
    n = random.randint(0, 4)
    return ''.join(random.choices(flags_chars, k=n))

patterns = [
    "a", "abc", "(a)", "(?P<x>a)", "\\d+", "[abc]+",
    "^abc", "abc$", "^abc$", "a.b", "a.*b",
    "(a)(b)", "(a|b)+", "\\w+", "\\s+", "\\b\\w+\\b",
    "", "a*", ".+",
]

replacements = [
    "X", "${1}", "$1", "${x}", "\\n", "Y\\tZ",
    "$$dollar", "before-${1}-after", "X\\\\Y",
    "$1 $2", "${1}_y", "",
]

inputs = [
    "hello world", "abc\ndef\nghi", "aaaa", "naïve café",
    "abc 123 def 456", "Hello World", "", "a",
    "line1\nline2\nline3", "\t\n\r",
]

cases = []
for i in range(100):
    pattern = random.choice(patterns)
    replacement = random.choice(replacements)
    input_str = random.choice(inputs)

    args = []
    if random.random() < 0.3:
        args.append("-p")
    if random.random() < 0.3:
        args.append("-F")
    if random.random() < 0.3:
        args.append("-n")
        args.append(str(random.randint(0, 5)))
    if random.random() < 0.3:
        args.append("-f")
        args.append(random_flags())
    args.append(pattern)
    args.append(replacement)

    cases.append({"args": args, "stdin": input_str})

for c in cases:
    print(json.dumps(c))
EOF

count=0
while IFS= read -r line; do
    args=$(echo "$line" | python3 -c "import sys, json; d = json.loads(sys.stdin.read()); print(' '.join(repr(a) for a in d['args']))")
    stdin=$(echo "$line" | python3 -c "import sys, json; d = json.loads(sys.stdin.read()); sys.stdout.write(d['stdin'])")
    eval "run_diff \"fuzz-$count\" \"\$stdin\" $args"
    count=$((count+1))
done < /tmp/fuzz_cases.txt

echo "=== Pass: $PASS  Fail: $FAIL ==="
