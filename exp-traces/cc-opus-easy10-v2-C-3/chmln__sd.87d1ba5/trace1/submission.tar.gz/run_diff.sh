#!/bin/bash
# Direct A/B comparison helper - compares REF against SUT for arbitrary inputs
# Usage: ./run_diff.sh "name" "stdin_value" args...
# Example: ./run_diff.sh "case 1" "abc" "a" "X"

REF=${REF:-/workspace/executable}
SUT=${SUT:-/work/work/executable}

name="$1"; shift
stdin="$1"; shift

ref_out=$(mktemp); ref_err=$(mktemp)
sut_out=$(mktemp); sut_err=$(mktemp)
trap "rm -f $ref_out $ref_err $sut_out $sut_err" EXIT

if [ -n "$stdin" ]; then
    printf '%s' "$stdin" | timeout 10 "$REF" "$@" >"$ref_out" 2>"$ref_err"
    ref_ec=$?
    printf '%s' "$stdin" | timeout 10 "$SUT" "$@" >"$sut_out" 2>"$sut_err"
    sut_ec=$?
else
    : | timeout 10 "$REF" "$@" >"$ref_out" 2>"$ref_err"
    ref_ec=$?
    : | timeout 10 "$SUT" "$@" >"$sut_out" 2>"$sut_err"
    sut_ec=$?
fi

if [ "$ref_ec" != "$sut_ec" ] || ! diff -q "$ref_out" "$sut_out" >/dev/null 2>&1 || ! diff -q "$ref_err" "$sut_err" >/dev/null 2>&1; then
    echo "FAIL: $name"
    echo "  Args: $@"
    [ "$ref_ec" != "$sut_ec" ] && echo "  EC: ref=$ref_ec sut=$sut_ec"
    if ! diff -q "$ref_out" "$sut_out" >/dev/null 2>&1; then
        echo "  Stdout diff:"
        diff "$ref_out" "$sut_out" | head -20 | sed 's/^/    /'
    fi
    if ! diff -q "$ref_err" "$sut_err" >/dev/null 2>&1; then
        echo "  Stderr diff:"
        diff "$ref_err" "$sut_err" | head -20 | sed 's/^/    /'
    fi
    return 1 2>/dev/null
    exit 1
else
    echo "PASS: $name"
    return 0 2>/dev/null
    exit 0
fi
