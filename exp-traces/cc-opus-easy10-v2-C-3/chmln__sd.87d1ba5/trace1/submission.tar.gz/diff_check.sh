#!/bin/bash
# Run capture_goldens.sh against SUT and compare against goldens
set -u

GOLDENS_DIR=${GOLDENS_DIR:-/work/work/goldens}
SUT=${SUT:-/work/work/executable}

# Capture SUT outputs in temp dir
SUT_DIR=$(mktemp -d)
trap "rm -rf $SUT_DIR" EXIT

REF="$SUT" /work/work/capture_goldens.sh "$SUT_DIR" >/dev/null

PASS=0
FAIL=0
FAILED_NAMES=()

for ec_file in "$GOLDENS_DIR"/*.ec; do
    name=$(basename "$ec_file" .ec)
    expected_ec=$(cat "$ec_file")
    if [ ! -f "$SUT_DIR/$name.ec" ]; then
        actual_ec="MISSING"
    else
        actual_ec=$(cat "$SUT_DIR/$name.ec")
    fi

    ok=true
    if [ "$actual_ec" != "$expected_ec" ]; then ok=false; fi
    if ! diff -q "$GOLDENS_DIR/$name.stdout" "$SUT_DIR/$name.stdout" >/dev/null 2>&1; then ok=false; fi
    if ! diff -q "$GOLDENS_DIR/$name.stderr" "$SUT_DIR/$name.stderr" >/dev/null 2>&1; then ok=false; fi

    if $ok; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILED_NAMES+=("$name")
        if [ "${VERBOSE:-0}" = "1" ]; then
            echo "FAIL: $name"
            echo "  Expected EC: $expected_ec  Actual: $actual_ec"
            echo "  stdout diff:"
            diff "$GOLDENS_DIR/$name.stdout" "$SUT_DIR/$name.stdout" | head -10 | sed 's/^/    /'
            echo "  stderr diff:"
            diff "$GOLDENS_DIR/$name.stderr" "$SUT_DIR/$name.stderr" | head -10 | sed 's/^/    /'
        fi
    fi
done

echo "=== Pass: $PASS  Fail: $FAIL ==="
if [ $FAIL -gt 0 ]; then
    printf "Failed: "
    for f in "${FAILED_NAMES[@]}"; do printf "%s " "$f"; done
    echo
fi
