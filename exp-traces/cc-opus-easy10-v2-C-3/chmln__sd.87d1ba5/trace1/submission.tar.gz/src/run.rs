use std::io::{Read, Write};
use std::path::PathBuf;

use crate::replacer;

pub struct Options {
    pub preview: bool,
    pub fixed_strings: bool,
    pub max_replacements: u64,
    pub flags: Option<String>,
    pub find: String,
    pub replace_with: String,
    pub files: Vec<PathBuf>,
}

pub fn run(opts: Options) -> Result<(), u8> {
    // 1. Ambiguity check (regex mode only)
    if !opts.fixed_strings {
        if let Err(amb) = replacer::check_ambiguous(&opts.replace_with) {
            eprint!("{}", amb.render());
            return Err(1);
        }
    }

    // 2. Build the regex
    let re = match replacer::build_regex(&opts.find, opts.flags.as_deref(), opts.fixed_strings) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("error: {}", e);
            return Err(1);
        }
    };

    if opts.files.is_empty() {
        // stdin -> stdout
        let mut buf = Vec::new();
        if std::io::stdin().lock().read_to_end(&mut buf).is_err() {
            return Err(1);
        }
        let out = replacer::replace_all(
            &re,
            &buf,
            &opts.replace_with,
            opts.fixed_strings,
            opts.max_replacements,
        );
        let _ = std::io::stdout().lock().write_all(&out);
        return Ok(());
    }

    // Validate all paths exist first
    for path in &opts.files {
        if !path.exists() {
            eprintln!("error: invalid path: {}", path.display());
            return Err(1);
        }
    }

    // Process files (use memmap to match reference error format)
    let multi = opts.files.len() > 1;
    for path in &opts.files {
        let buf = match read_via_mmap(path) {
            Ok(b) => b,
            Err(e) => {
                eprintln!("error: {}", e);
                return Err(1);
            }
        };
        let out = replacer::replace_all(
            &re,
            &buf,
            &opts.replace_with,
            opts.fixed_strings,
            opts.max_replacements,
        );

        if opts.preview {
            let stdout = std::io::stdout();
            let mut h = stdout.lock();
            if multi {
                let _ = write!(h, "----- FILE {} -----\n", path.display());
            }
            let _ = h.write_all(&out);
        } else {
            // Write back to file
            if let Err(e) = write_file(path, &out) {
                eprintln!("error: {}", e);
                return Err(1);
            }
        }
    }
    Ok(())
}

fn write_file(path: &std::path::Path, content: &[u8]) -> std::io::Result<()> {
    let parent = path.parent().unwrap_or_else(|| std::path::Path::new("."));
    let mut tmp = tempfile::NamedTempFile::new_in(parent)?;
    tmp.write_all(content)?;
    tmp.persist(path).map_err(|e| e.error)?;
    Ok(())
}

fn read_via_mmap(path: &std::path::Path) -> std::io::Result<Vec<u8>> {
    let file = std::fs::File::open(path)?;
    let metadata = file.metadata()?;
    if metadata.is_file() && metadata.len() == 0 {
        return Ok(Vec::new());
    }
    let mmap = unsafe { memmap2::Mmap::map(&file)? };
    Ok(mmap.to_vec())
}
