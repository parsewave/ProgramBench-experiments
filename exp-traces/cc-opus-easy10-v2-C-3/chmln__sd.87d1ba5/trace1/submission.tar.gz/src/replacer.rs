use regex::bytes::{Captures, Regex, RegexBuilder};

use crate::flags::{parse_flags, FlagSet};

pub struct AmbiguousReplacement {
    pub digits: String,
    pub trail: String,
    pub pos_chars: usize,
    pub length_chars: usize,
    pub replacement: String,
}

impl AmbiguousReplacement {
    pub fn render(&self) -> String {
        let mut s = String::new();
        s.push_str(&format!(
            "error: The numbered capture group `${}` in the replacement text is ambiguous.\n",
            self.digits
        ));
        s.push_str(&format!(
            "hint: Use curly braces to disambiguate it `${{{}}}{}`.\n",
            self.digits, self.trail
        ));
        s.push_str(&self.replacement);
        s.push('\n');
        for _ in 0..self.pos_chars {
            s.push(' ');
        }
        for _ in 0..self.length_chars {
            s.push('^');
        }
        s.push('\n');
        s
    }
}

fn is_word_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

pub fn check_ambiguous(replacement: &str) -> Result<(), AmbiguousReplacement> {
    let chars: Vec<char> = replacement.chars().collect();
    let n = chars.len();
    let mut i = 0;
    while i < n {
        let c = chars[i];
        if c == '$' {
            if i + 1 < n && chars[i + 1] == '$' {
                i += 2;
                continue;
            }
            if i + 1 < n && chars[i + 1] == '{' {
                let mut j = i + 2;
                while j < n && chars[j] != '}' {
                    j += 1;
                }
                if j < n {
                    i = j + 1;
                } else {
                    i += 1;
                }
                continue;
            }
            // Parse digits greedily
            let mut j = i + 1;
            while j < n && chars[j].is_ascii_digit() {
                j += 1;
            }
            if j > i + 1 {
                // $NUMBER
                if j < n && is_word_char(chars[j]) {
                    let mut k = j;
                    while k < n && is_word_char(chars[k]) {
                        k += 1;
                    }
                    let digits: String = chars[i + 1..j].iter().collect();
                    let trail: String = chars[j..k].iter().collect();
                    return Err(AmbiguousReplacement {
                        digits,
                        trail,
                        pos_chars: i + 1,
                        length_chars: k - (i + 1),
                        replacement: replacement.to_string(),
                    });
                }
                i = j;
            } else {
                let mut j = i + 1;
                while j < n && is_word_char(chars[j]) {
                    j += 1;
                }
                if j > i + 1 {
                    i = j;
                } else {
                    i += 1;
                }
            }
        } else {
            i += 1;
        }
    }
    Ok(())
}

pub fn expand(replacement: &str, caps: &Captures) -> Vec<u8> {
    let chars: Vec<char> = replacement.chars().collect();
    let n = chars.len();
    let mut out: Vec<u8> = Vec::with_capacity(replacement.len());
    let mut buf = [0u8; 4];
    let mut i = 0;
    while i < n {
        let c = chars[i];
        if c == '\\' && i + 1 < n {
            let next = chars[i + 1];
            match next {
                'n' => {
                    out.push(b'\n');
                    i += 2;
                }
                'r' => {
                    out.push(b'\r');
                    i += 2;
                }
                't' => {
                    out.push(b'\t');
                    i += 2;
                }
                '\\' => {
                    out.push(b'\\');
                    i += 2;
                }
                '"' => {
                    out.push(b'"');
                    i += 2;
                }
                '\'' => {
                    out.push(b'\'');
                    i += 2;
                }
                'x' if i + 3 < n
                    && chars[i + 2].is_ascii_hexdigit()
                    && chars[i + 3].is_ascii_hexdigit() =>
                {
                    let h1 = chars[i + 2].to_digit(16).unwrap();
                    let h2 = chars[i + 3].to_digit(16).unwrap();
                    let value = (h1 << 4) | h2;
                    let ch = char::from_u32(value).unwrap_or('\u{FFFD}');
                    let encoded = ch.encode_utf8(&mut buf);
                    out.extend_from_slice(encoded.as_bytes());
                    i += 4;
                    // Discard one more char if present
                    if i < n {
                        i += 1;
                    }
                }
                _ => {
                    let encoded = c.encode_utf8(&mut buf);
                    out.extend_from_slice(encoded.as_bytes());
                    i += 1;
                }
            }
        } else if c == '$' {
            if i + 1 < n && chars[i + 1] == '$' {
                out.push(b'$');
                i += 2;
                continue;
            }
            if i + 1 < n && chars[i + 1] == '{' {
                let mut j = i + 2;
                while j < n && chars[j] != '}' {
                    j += 1;
                }
                if j < n {
                    let name: String = chars[i + 2..j].iter().collect();
                    if let Ok(num) = name.parse::<usize>() {
                        if let Some(m) = caps.get(num) {
                            out.extend_from_slice(m.as_bytes());
                        }
                    } else if !name.is_empty() {
                        if let Some(m) = caps.name(&name) {
                            out.extend_from_slice(m.as_bytes());
                        }
                    }
                    i = j + 1;
                    continue;
                } else {
                    out.push(b'$');
                    i += 1;
                    continue;
                }
            }
            // Parse digits greedily
            let mut j = i + 1;
            while j < n && chars[j].is_ascii_digit() {
                j += 1;
            }
            if j > i + 1 {
                let digits: String = chars[i + 1..j].iter().collect();
                if let Ok(num) = digits.parse::<usize>() {
                    if let Some(m) = caps.get(num) {
                        out.extend_from_slice(m.as_bytes());
                    }
                }
                i = j;
            } else {
                let mut j = i + 1;
                while j < n && is_word_char(chars[j]) {
                    j += 1;
                }
                if j > i + 1 {
                    let name: String = chars[i + 1..j].iter().collect();
                    if let Some(m) = caps.name(&name) {
                        out.extend_from_slice(m.as_bytes());
                    }
                    i = j;
                } else {
                    out.push(b'$');
                    i += 1;
                }
            }
        } else {
            let encoded = c.encode_utf8(&mut buf);
            out.extend_from_slice(encoded.as_bytes());
            i += 1;
        }
    }
    out
}

pub fn build_regex(
    find: &str,
    flags: Option<&str>,
    fixed_strings: bool,
) -> Result<Regex, String> {
    let fs: FlagSet = parse_flags(flags);

    let pattern = if fixed_strings {
        regex::escape(find)
    } else {
        find.to_string()
    };

    let pattern = if fs.word_bounded {
        format!(r"\b{}\b", pattern)
    } else {
        pattern
    };

    let mut builder = RegexBuilder::new(&pattern);
    builder.multi_line(fs.multi_line);
    builder.case_insensitive(fs.case_insensitive);
    builder.dot_matches_new_line(fs.dot_all);
    builder.unicode(true);
    builder.build().map_err(|e| {
        format!("invalid regex {}", e)
    })
}

pub fn replace_all(
    re: &Regex,
    haystack: &[u8],
    replacement: &str,
    fixed_strings: bool,
    max_replacements: u64,
) -> Vec<u8> {
    let mut out = Vec::with_capacity(haystack.len());
    let mut last_end = 0;
    let mut count: u64 = 0;
    let unlimited = max_replacements == 0;
    let repl_bytes = if fixed_strings {
        Some(replacement.as_bytes().to_vec())
    } else {
        None
    };

    for caps in re.captures_iter(haystack) {
        if !unlimited && count >= max_replacements {
            break;
        }
        let m = caps.get(0).unwrap();
        out.extend_from_slice(&haystack[last_end..m.start()]);
        if let Some(rb) = &repl_bytes {
            out.extend_from_slice(rb);
        } else {
            let expanded = expand(replacement, &caps);
            out.extend_from_slice(&expanded);
        }
        last_end = m.end();
        count += 1;
    }
    out.extend_from_slice(&haystack[last_end..]);
    out
}
