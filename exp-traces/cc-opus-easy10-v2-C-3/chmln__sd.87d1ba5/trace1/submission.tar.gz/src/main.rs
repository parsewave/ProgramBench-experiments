use std::path::PathBuf;
use std::process::ExitCode;

use clap::{Arg, ArgAction, Command};

mod flags;
mod replacer;
mod run;

fn build_cli() -> Command {
    Command::new("sd")
        .version("1.0.0")
        .about("An intuitive find & replace CLI")
        .help_template(
            "sd v{version}\n{about}\n\n{usage-heading} {usage}\n\n{all-args}",
        )
        .arg(
            Arg::new("preview")
                .short('p')
                .long("preview")
                .action(ArgAction::SetTrue)
                .help(
                    "Display changes in a human reviewable format (the specifics of the format are likely to change in the future)",
                ),
        )
        .arg(
            Arg::new("fixed-strings")
                .short('F')
                .long("fixed-strings")
                .action(ArgAction::SetTrue)
                .help("Treat FIND and REPLACE_WITH args as literal strings"),
        )
        .arg(
            Arg::new("max-replacements")
                .short('n')
                .long("max-replacements")
                .value_name("LIMIT")
                .default_value("0")
                .value_parser(clap::value_parser!(u64))
                .help(
                    "Limit the number of replacements that can occur per file. 0 indicates unlimited replacements",
                ),
        )
        .arg(
            Arg::new("flags")
                .short('f')
                .long("flags")
                .value_name("FLAGS")
                .help("Regex flags. May be combined (like `-f mc`).")
                .long_help(
                    "Regex flags. May be combined (like `-f mc`).\n\n\
                     c - case-sensitive\n\n\
                     e - disable multi-line matching\n\n\
                     i - case-insensitive\n\n\
                     m - multi-line matching\n\n\
                     s - make `.` match newlines\n\n\
                     w - match full words only",
                ),
        )
        .arg(
            Arg::new("find")
                .value_name("FIND")
                .required(true)
                .help("The regexp or string (if using `-F`) to search for"),
        )
        .arg(
            Arg::new("replace_with")
                .value_name("REPLACE_WITH")
                .required(true)
                .help(
                    "What to replace each match with. Unless in string mode, you may use captured values like $1, $2, etc",
                ),
        )
        .arg(
            Arg::new("files")
                .value_name("FILES")
                .num_args(0..)
                .value_parser(clap::value_parser!(PathBuf))
                .help("The path to file(s). This is optional - sd can also read from STDIN")
                .long_help(
                    "The path to file(s). This is optional - sd can also read from STDIN.\n\n\
                     Note: sd modifies files in-place by default. See documentation for examples.",
                ),
        )
}

fn main() -> ExitCode {
    let cmd = build_cli();
    let matches = match cmd.try_get_matches() {
        Ok(m) => m,
        Err(e) => {
            // clap handles printing for both errors and help/version
            e.print().unwrap();
            return ExitCode::from(if e.use_stderr() { 2 } else { 0 });
        }
    };

    let opts = run::Options {
        preview: matches.get_flag("preview"),
        fixed_strings: matches.get_flag("fixed-strings"),
        max_replacements: *matches.get_one::<u64>("max-replacements").unwrap(),
        flags: matches.get_one::<String>("flags").cloned(),
        find: matches.get_one::<String>("find").unwrap().clone(),
        replace_with: matches.get_one::<String>("replace_with").unwrap().clone(),
        files: matches
            .get_many::<PathBuf>("files")
            .map(|vals| vals.cloned().collect())
            .unwrap_or_default(),
    };

    match run::run(opts) {
        Ok(()) => ExitCode::from(0),
        Err(code) => ExitCode::from(code),
    }
}
