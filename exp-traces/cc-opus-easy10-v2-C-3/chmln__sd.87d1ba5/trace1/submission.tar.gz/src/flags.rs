pub struct FlagSet {
    pub multi_line: bool,
    pub case_insensitive: bool,
    pub dot_all: bool,
    pub word_bounded: bool,
}

pub fn parse_flags(input: Option<&str>) -> FlagSet {
    let mut case_insensitive = false;
    let mut dot_all = false;
    let mut word_bounded = false;

    let multi_line = match input {
        None => true,
        Some(s) => {
            let mut has_m = false;
            let mut has_e = false;
            let mut has_s = false;
            let mut has_w = false;

            for c in s.chars() {
                match c {
                    'i' => case_insensitive = true,
                    'c' => case_insensitive = false,
                    'm' => has_m = true,
                    'e' => has_e = true,
                    's' => {
                        has_s = true;
                        dot_all = true;
                    }
                    'w' => {
                        has_w = true;
                        word_bounded = true;
                        // 'w' resets accumulated case-insensitive and dot-all state.
                        case_insensitive = false;
                        dot_all = false;
                    }
                    _ => {}
                }
            }

            if has_w || has_e {
                false
            } else if has_s && !has_m {
                false
            } else {
                true
            }
        }
    };

    FlagSet {
        multi_line,
        case_insensitive,
        dot_all,
        word_bounded,
    }
}
