#!/bin/bash
# Build script: produces ./executable in this directory
set -eu
export PATH="/usr/local/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin:$PATH"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Build release binary
cargo build --release --offline --quiet

# Copy to expected location
cp target/release/sd executable
chmod +x executable
