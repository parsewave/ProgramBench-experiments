# sd v1.0.0 Behavior Map (derived from observation)

## Identity
- Reports as "sd v1.0.0" in help, "sd 1.0.0\n" for --version
- Help line "Usage: <argv[0]> [OPTIONS] <FIND> <REPLACE_WITH> [FILES]..."
- Built on clap 4.x (Rust) + regex 1.10.x crate

## CLI
- Positional: <FIND> <REPLACE_WITH> [FILES...]
- Options:
  - `-p, --preview` (flag; multi-occur = error 2)
  - `-F, --fixed-strings` (flag; multi-occur = error 2)
  - `-n, --max-replacements <LIMIT>` (u64; default 0 = unlimited; multi-occur = error 2)
  - `-f, --flags <FLAGS>` (string of letters; multi-occur = error 2)
  - `-h, --help` (prints help to stdout, exit 0)
  - `-V, --version` (prints "sd 1.0.0\n" to stdout, exit 0)

### Parsing details
- `-n=N`, `-nN`, `-n N`, `--max-replacements=N`, `--max-replacements N` all work
- `--` ends flag parsing
- Files starting with `-` not in flag list are treated as paths (clap auto-detects)
- `-` is NOT stdin; treated as filename and errors as "invalid path: -"

### Errors (exit code 2; to stderr)
- Missing required args:
```
error: the following required arguments were not provided:
  <FIND>
  <REPLACE_WITH>

Usage: <argv0> <FIND> <REPLACE_WITH> [FILES]...

For more information, try '--help'.
```
(only missing args listed)

- Unknown flag:
```
error: unexpected argument '--bogus' found

  tip: to pass '--bogus' as a value, use '-- --bogus'

Usage: <argv0> [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

For more information, try '--help'.
```

- Repeated flag:
```
error: the argument '--preview' cannot be used multiple times

Usage: <argv0> [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

For more information, try '--help'.
```

- Bad number:
```
error: invalid value '<v>' for '--max-replacements <LIMIT>': invalid digit found in string

For more information, try '--help'.
```

- Number out of range:
```
error: invalid value '<v>' for '--max-replacements <LIMIT>': number too large to fit in target type

For more information, try '--help'.
```

- Invalid UTF-8 in arg:
```
error: invalid UTF-8 was detected in one or more arguments

Usage: <argv0> [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

For more information, try '--help'.
```

## Process model
- One-shot: reads stdin/files, writes output, exits
- No streaming; consumes whole input
- No interactive blocking unless stdin is unconnected

## Sources
- If FILES given: process each file in order, in-place modify (unless -p)
  - First invalid file aborts: `error: invalid path: <path>` exit 1
  - File must exist and be readable
- If no FILES: read stdin, write stdout
- If both stdin and FILES: only FILES processed; stdin ignored

## Replacement (regex mode)
- Find pattern is a Rust regex
- Default flags: `(?m)` multi-line is ON
- Replacement string supports `$1`, `$2`, ..., `$name`, `${1}`, `${name}`
- `$$` = literal `$`
- `\n`, `\t`, etc. = escape sequences interpreted

### Ambiguous capture group rule
When `$N` (N=digits) is followed by a word character (`[A-Za-z0-9_]`), error:
```
error: The numbered capture group `$N` in the replacement text is ambiguous.
hint: Use curly braces to disambiguate it `${N}TRAIL`.
<replacement-text>
<spaces><^N+TRAIL>
```
- spaces = position of N in replacement (right after $)
- carets cover digits + trailing word chars
- Exit code 1, output stderr
- Only first ambiguity reported

Word characters AFTER `$N` that don't cause ambiguity:
- `,`, `-`, ` `, `!`, `;`, `?`, etc. (non-word)
- EOF (end of string)

Word characters that DO cause ambiguity:
- letters (a-z, A-Z)
- digits (0-9)
- underscore (_)

`$x` where x is not a defined named group: replaced with empty
`${1}` always works (numbered, braces, unambiguous)
`${name}` works for named groups
`$10` at end of string: no ambiguity, treated as group 10
`${` not followed by `}`: literal text

## Regex flags `-f <FLAGS>` (string of letters)
- Each char is processed independently:
  - `m`: enable multi-line (default ON)
  - `e`: disable multi-line (overrides m)
  - `i`: enable case-insensitive
  - `c`: disable case-insensitive (overrides i if appears later, last-wins for i/c)
  - `s`: enable dot-all (`.` matches newlines)
  - `w`: wrap pattern in `\b...\b`
- Unknown chars (digits, dash, anything else): silently ignored
- Multi-line behavior:
  - Default (no -f): ON
  - With -f: ON, BUT disabled when ANY of {e, s without m, w} present
  - 'e' disables multi-line regardless of m
  - 'w' disables multi-line, even if m present
  - 's' disables multi-line, UNLESS m is also present
- Case behavior: i/c are toggleable, last wins
- Word wrap: `\b...\b` around the entire pattern

## Fixed strings `-F`
- FIND treated as literal string (no regex)
- REPLACE_WITH treated as literal (no $N substitution, no escapes)
- All other flags applied normally except regex flags

## Empty FIND
- Regex mode: empty pattern matches at every position (including end-of-input)
- Fixed mode: empty pattern matches at every position

## Output behavior
- Reading stdin, no files: write result to stdout
- Reading files, no `-p`: modify each file in-place
- Reading files, with `-p`:
  - Single file: print result to stdout (no header)
  - Multiple files: print `----- FILE <path> -----\n<content>` for each
- Stdin with `-p` is identical to stdin without `-p`

## Encoding
- Input: byte-oriented (uses regex::bytes::RegexBuilder presumably)
- Invalid UTF-8 in input passes through
- BOM, CRLF, NUL bytes pass through
- Args must be valid UTF-8 (clap requirement)

## File errors
- Non-existent file: `error: invalid path: <path>` exit 1
- Directory: `error: No such device (os error 19)` exit 1 (mmap failure)

## Exit codes
- 0: success
- 1: runtime error (bad regex, invalid path, etc.)
- 2: clap parse error
- 101: panic (not encountered in normal usage)
