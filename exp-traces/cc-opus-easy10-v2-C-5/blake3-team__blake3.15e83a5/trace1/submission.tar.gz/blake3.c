/* Pure-C BLAKE3 implementation.
 *
 * Built as a shared library used by b3sum.py via ctypes.
 * Implements: regular hash, keyed hash, derive-key; XOF output with seek.
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define BLOCK_LEN 64
#define CHUNK_LEN 1024
#define MAX_DEPTH 54   /* enough for 2^54 chunks ≈ 2^64 bytes */

#define CHUNK_START         (1u << 0)
#define CHUNK_END           (1u << 1)
#define PARENT              (1u << 2)
#define ROOT                (1u << 3)
#define KEYED_HASH          (1u << 4)
#define DERIVE_KEY_CONTEXT  (1u << 5)
#define DERIVE_KEY_MATERIAL (1u << 6)

static const uint32_t IV[8] = {
    0x6A09E667UL, 0xBB67AE85UL, 0x3C6EF372UL, 0xA54FF53AUL,
    0x510E527FUL, 0x9B05688CUL, 0x1F83D9ABUL, 0x5BE0CD19UL,
};

static const uint8_t MSG_PERMUTATION[16] = {
    2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8,
};

typedef struct {
    uint32_t cv[8];
    uint64_t chunk_counter;
    uint8_t block[BLOCK_LEN];
    uint8_t block_len;
    uint8_t blocks_compressed;
    uint32_t flags;
} chunk_state;

typedef struct {
    chunk_state cs;
    uint32_t key_words[8];
    uint32_t base_flags;
    uint32_t cv_stack_len;
    uint8_t cv_stack[MAX_DEPTH * 32];
} blake3_hasher;

static inline uint32_t rotr32(uint32_t x, int n) {
    return (x >> n) | (x << (32 - n));
}

static inline uint32_t load_u32_le(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static inline void store_u32_le(uint8_t *p, uint32_t v) {
    p[0] = v & 0xff;
    p[1] = (v >> 8) & 0xff;
    p[2] = (v >> 16) & 0xff;
    p[3] = (v >> 24) & 0xff;
}

static inline void g_mix(uint32_t s[16], int a, int b, int c, int d,
                         uint32_t mx, uint32_t my) {
    s[a] = s[a] + s[b] + mx;
    s[d] = rotr32(s[d] ^ s[a], 16);
    s[c] = s[c] + s[d];
    s[b] = rotr32(s[b] ^ s[c], 12);
    s[a] = s[a] + s[b] + my;
    s[d] = rotr32(s[d] ^ s[a], 8);
    s[c] = s[c] + s[d];
    s[b] = rotr32(s[b] ^ s[c], 7);
}

static void round_fn(uint32_t state[16], const uint32_t m[16]) {
    g_mix(state, 0, 4, 8, 12, m[0], m[1]);
    g_mix(state, 1, 5, 9, 13, m[2], m[3]);
    g_mix(state, 2, 6, 10, 14, m[4], m[5]);
    g_mix(state, 3, 7, 11, 15, m[6], m[7]);
    g_mix(state, 0, 5, 10, 15, m[8], m[9]);
    g_mix(state, 1, 6, 11, 12, m[10], m[11]);
    g_mix(state, 2, 7, 8, 13, m[12], m[13]);
    g_mix(state, 3, 4, 9, 14, m[14], m[15]);
}

static void permute_block(uint32_t m[16]) {
    uint32_t p[16];
    for (int i = 0; i < 16; i++) p[i] = m[MSG_PERMUTATION[i]];
    memcpy(m, p, sizeof(p));
}

/* Compress 64-byte block. Result is 16 u32 words. */
static void compress(const uint32_t cv[8], const uint32_t block_words_in[16],
                     uint64_t counter, uint32_t block_len, uint32_t flags,
                     uint32_t out[16]) {
    uint32_t state[16];
    uint32_t block[16];

    for (int i = 0; i < 8; i++) state[i] = cv[i];
    state[8] = IV[0]; state[9] = IV[1]; state[10] = IV[2]; state[11] = IV[3];
    state[12] = (uint32_t)(counter & 0xFFFFFFFFu);
    state[13] = (uint32_t)((counter >> 32) & 0xFFFFFFFFu);
    state[14] = block_len;
    state[15] = flags;

    memcpy(block, block_words_in, sizeof(block));

    for (int r = 0; r < 6; r++) {
        round_fn(state, block);
        permute_block(block);
    }
    round_fn(state, block);

    for (int i = 0; i < 8; i++) {
        out[i] = state[i] ^ state[i + 8];
        out[i + 8] = state[i + 8] ^ cv[i];
    }
}

static void words_from_block(const uint8_t bytes_in[BLOCK_LEN], uint32_t out[16]) {
    for (int i = 0; i < 16; i++) out[i] = load_u32_le(bytes_in + i * 4);
}

static void chunk_state_init(chunk_state *cs, const uint32_t key[8],
                             uint64_t chunk_counter, uint32_t flags) {
    memcpy(cs->cv, key, 32);
    cs->chunk_counter = chunk_counter;
    memset(cs->block, 0, BLOCK_LEN);
    cs->block_len = 0;
    cs->blocks_compressed = 0;
    cs->flags = flags;
}

static size_t chunk_state_len(const chunk_state *cs) {
    return (size_t)BLOCK_LEN * cs->blocks_compressed + cs->block_len;
}

static uint32_t chunk_state_start_flag(const chunk_state *cs) {
    return cs->blocks_compressed == 0 ? CHUNK_START : 0u;
}

static void chunk_state_update(chunk_state *cs, const uint8_t *data, size_t len) {
    while (len > 0) {
        if (cs->block_len == BLOCK_LEN) {
            uint32_t block_words[16];
            uint32_t out[16];
            words_from_block(cs->block, block_words);
            compress(cs->cv, block_words, cs->chunk_counter, BLOCK_LEN,
                     cs->flags | chunk_state_start_flag(cs), out);
            memcpy(cs->cv, out, 32);
            cs->blocks_compressed += 1;
            memset(cs->block, 0, BLOCK_LEN);
            cs->block_len = 0;
        }
        size_t want = BLOCK_LEN - cs->block_len;
        size_t take = len < want ? len : want;
        memcpy(cs->block + cs->block_len, data, take);
        cs->block_len += (uint8_t)take;
        data += take;
        len -= take;
    }
}

/* Output for finalization: holds the inputs to one final compression. */
typedef struct {
    uint32_t input_cv[8];
    uint32_t block_words[16];
    uint64_t counter;
    uint32_t block_len;
    uint32_t flags;
} output_t;

static void chunk_state_output(const chunk_state *cs, output_t *o) {
    memcpy(o->input_cv, cs->cv, 32);
    uint8_t padded[BLOCK_LEN];
    memcpy(padded, cs->block, BLOCK_LEN);
    words_from_block(padded, o->block_words);
    o->counter = cs->chunk_counter;
    o->block_len = cs->block_len;
    o->flags = cs->flags | chunk_state_start_flag(cs) | CHUNK_END;
}

static void output_chaining_value(const output_t *o, uint32_t cv_out[8]) {
    uint32_t state[16];
    compress(o->input_cv, o->block_words, o->counter, o->block_len, o->flags, state);
    memcpy(cv_out, state, 32);
}

static void parent_output(const uint32_t left[8], const uint32_t right[8],
                          const uint32_t key[8], uint32_t flags, output_t *o) {
    memcpy(o->input_cv, key, 32);
    memcpy(o->block_words, left, 32);
    memcpy(o->block_words + 8, right, 32);
    o->counter = 0;
    o->block_len = BLOCK_LEN;
    o->flags = flags | PARENT;
}

static void parent_cv(const uint32_t left[8], const uint32_t right[8],
                      const uint32_t key[8], uint32_t flags,
                      uint32_t cv_out[8]) {
    output_t o;
    parent_output(left, right, key, flags, &o);
    output_chaining_value(&o, cv_out);
}

/* ---- Public hasher API ---- */

void b3_init(blake3_hasher *h) {
    memcpy(h->key_words, IV, 32);
    h->base_flags = 0;
    h->cv_stack_len = 0;
    chunk_state_init(&h->cs, h->key_words, 0, 0);
}

void b3_init_keyed(blake3_hasher *h, const uint8_t key[32]) {
    for (int i = 0; i < 8; i++) h->key_words[i] = load_u32_le(key + i * 4);
    h->base_flags = KEYED_HASH;
    h->cv_stack_len = 0;
    chunk_state_init(&h->cs, h->key_words, 0, KEYED_HASH);
}

/* Forward decl for derive-key. */
void b3_update(blake3_hasher *h, const uint8_t *data, size_t len);
void b3_finalize(const blake3_hasher *h, uint8_t *out, size_t out_len, uint64_t seek);

void b3_init_derive_key(blake3_hasher *h, const uint8_t *ctx, size_t ctx_len) {
    blake3_hasher ctx_h;
    memcpy(ctx_h.key_words, IV, 32);
    ctx_h.base_flags = DERIVE_KEY_CONTEXT;
    ctx_h.cv_stack_len = 0;
    chunk_state_init(&ctx_h.cs, ctx_h.key_words, 0, DERIVE_KEY_CONTEXT);
    b3_update(&ctx_h, ctx, ctx_len);
    uint8_t ctx_key_bytes[32];
    b3_finalize(&ctx_h, ctx_key_bytes, 32, 0);

    for (int i = 0; i < 8; i++) h->key_words[i] = load_u32_le(ctx_key_bytes + i * 4);
    h->base_flags = DERIVE_KEY_MATERIAL;
    h->cv_stack_len = 0;
    chunk_state_init(&h->cs, h->key_words, 0, DERIVE_KEY_MATERIAL);
}

static void push_cv(blake3_hasher *h, const uint32_t new_cv[8], uint64_t total_chunks) {
    uint32_t cv[8];
    memcpy(cv, new_cv, 32);
    while ((total_chunks & 1) == 0) {
        uint8_t *top = h->cv_stack + (h->cv_stack_len - 1) * 32;
        uint32_t left[8];
        for (int i = 0; i < 8; i++) left[i] = load_u32_le(top + i * 4);
        uint32_t merged[8];
        parent_cv(left, cv, h->key_words, h->base_flags, merged);
        memcpy(cv, merged, 32);
        h->cv_stack_len -= 1;
        total_chunks >>= 1;
    }
    uint8_t *dst = h->cv_stack + h->cv_stack_len * 32;
    for (int i = 0; i < 8; i++) store_u32_le(dst + i * 4, cv[i]);
    h->cv_stack_len += 1;
}

void b3_update(blake3_hasher *h, const uint8_t *data, size_t len) {
    while (len > 0) {
        if (chunk_state_len(&h->cs) == CHUNK_LEN) {
            output_t o;
            chunk_state_output(&h->cs, &o);
            uint32_t chunk_cv[8];
            output_chaining_value(&o, chunk_cv);
            uint64_t total = h->cs.chunk_counter + 1;
            push_cv(h, chunk_cv, total);
            chunk_state_init(&h->cs, h->key_words, total, h->base_flags);
        }
        size_t want = CHUNK_LEN - chunk_state_len(&h->cs);
        size_t take = len < want ? len : want;
        chunk_state_update(&h->cs, data, take);
        data += take;
        len -= take;
    }
}

void b3_finalize(const blake3_hasher *h, uint8_t *out, size_t out_len, uint64_t seek) {
    output_t output;
    chunk_state_output(&h->cs, &output);
    uint32_t remaining = h->cv_stack_len;
    while (remaining > 0) {
        remaining -= 1;
        uint32_t parent_cv_words[8];
        output_chaining_value(&output, parent_cv_words);
        const uint8_t *left_bytes = h->cv_stack + remaining * 32;
        uint32_t left[8];
        for (int i = 0; i < 8; i++) left[i] = load_u32_le(left_bytes + i * 4);
        parent_output(left, parent_cv_words, h->key_words, h->base_flags, &output);
    }

    /* XOF output with optional seek. */
    uint64_t block_idx = seek / 64;
    size_t offset = (size_t)(seek % 64);
    size_t produced = 0;
    while (produced < out_len) {
        uint32_t state[16];
        compress(output.input_cv, output.block_words, block_idx,
                 output.block_len, output.flags | ROOT, state);
        uint8_t buf[64];
        for (int i = 0; i < 16; i++) store_u32_le(buf + i * 4, state[i]);
        size_t take = 64 - offset;
        if (produced + take > out_len) take = out_len - produced;
        memcpy(out + produced, buf + offset, take);
        produced += take;
        offset = 0;
        block_idx += 1;
    }
}

size_t b3_hasher_size(void) { return sizeof(blake3_hasher); }
