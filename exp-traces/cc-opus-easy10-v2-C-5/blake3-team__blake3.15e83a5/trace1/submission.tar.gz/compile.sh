#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"

gcc -O3 -fPIC -shared -o libblake3.so blake3.c

cat > executable <<'EOF'
#!/usr/bin/env python3
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b3sum import main
main()
EOF
chmod +x executable
