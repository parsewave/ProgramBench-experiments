"""Pure-Python BLAKE3 implementation.

Implements the BLAKE3 algorithm per the public specification.
Used by b3sum.py to provide the hashing primitive.
"""

import struct

IV = [0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
      0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19]

BLOCK_LEN = 64
CHUNK_LEN = 1024
MSG_PERMUTATION = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8]

CHUNK_START = 1 << 0
CHUNK_END = 1 << 1
PARENT = 1 << 2
ROOT = 1 << 3
KEYED_HASH = 1 << 4
DERIVE_KEY_CONTEXT = 1 << 5
DERIVE_KEY_MATERIAL = 1 << 6

MASK = 0xFFFFFFFF


def _rotr(x, n):
    x &= MASK
    return ((x >> n) | (x << (32 - n))) & MASK


def _g(state, a, b, c, d, mx, my):
    state[a] = (state[a] + state[b] + mx) & MASK
    state[d] = _rotr(state[d] ^ state[a], 16)
    state[c] = (state[c] + state[d]) & MASK
    state[b] = _rotr(state[b] ^ state[c], 12)
    state[a] = (state[a] + state[b] + my) & MASK
    state[d] = _rotr(state[d] ^ state[a], 8)
    state[c] = (state[c] + state[d]) & MASK
    state[b] = _rotr(state[b] ^ state[c], 7)


def _round(state, m):
    # Columns
    _g(state, 0, 4, 8, 12, m[0], m[1])
    _g(state, 1, 5, 9, 13, m[2], m[3])
    _g(state, 2, 6, 10, 14, m[4], m[5])
    _g(state, 3, 7, 11, 15, m[6], m[7])
    # Diagonals
    _g(state, 0, 5, 10, 15, m[8], m[9])
    _g(state, 1, 6, 11, 12, m[10], m[11])
    _g(state, 2, 7, 8, 13, m[12], m[13])
    _g(state, 3, 4, 9, 14, m[14], m[15])


def _permute(m):
    return [m[MSG_PERMUTATION[i]] for i in range(16)]


def compress(cv, block_words, counter, block_len, flags):
    state = [
        cv[0], cv[1], cv[2], cv[3], cv[4], cv[5], cv[6], cv[7],
        IV[0], IV[1], IV[2], IV[3],
        counter & MASK, (counter >> 32) & MASK,
        block_len & MASK, flags & MASK,
    ]
    block = list(block_words)
    for _ in range(6):
        _round(state, block)
        block = _permute(block)
    _round(state, block)  # 7th round, no permute after
    for i in range(8):
        state[i] ^= state[i + 8]
        state[i + 8] ^= cv[i]
    return state


def _words_from_block(b):
    if len(b) < BLOCK_LEN:
        b = b + b'\x00' * (BLOCK_LEN - len(b))
    return list(struct.unpack('<16I', b[:BLOCK_LEN]))


class Output:
    __slots__ = ('input_cv', 'block_words', 'counter', 'block_len', 'flags')

    def __init__(self, input_cv, block_words, counter, block_len, flags):
        self.input_cv = input_cv
        self.block_words = block_words
        self.counter = counter
        self.block_len = block_len
        self.flags = flags

    def chaining_value(self):
        return compress(self.input_cv, self.block_words, self.counter,
                        self.block_len, self.flags)[:8]

    def root_output_bytes(self, length, seek=0):
        # XOF: each "output block" is one compression with counter = block index,
        # flags include ROOT. Each compression yields 64 bytes.
        result = bytearray()
        start_block = seek // 64
        offset = seek % 64
        block_idx = start_block
        while len(result) < length:
            words = compress(self.input_cv, self.block_words, block_idx,
                             self.block_len, self.flags | ROOT)
            out_bytes = struct.pack('<16I', *words)
            chunk = out_bytes[offset:]
            offset = 0
            need = length - len(result)
            result += chunk[:need]
            block_idx += 1
        return bytes(result)


class ChunkState:
    __slots__ = ('chaining_value', 'chunk_counter', 'block', 'blocks_compressed', 'flags')

    def __init__(self, key_words, chunk_counter, flags):
        self.chaining_value = list(key_words)
        self.chunk_counter = chunk_counter
        self.block = bytearray()
        self.blocks_compressed = 0
        self.flags = flags

    def len(self):
        return BLOCK_LEN * self.blocks_compressed + len(self.block)

    def start_flag(self):
        return CHUNK_START if self.blocks_compressed == 0 else 0

    def update(self, data):
        i = 0
        n = len(data)
        while i < n:
            if len(self.block) == BLOCK_LEN:
                bw = list(struct.unpack('<16I', bytes(self.block)))
                self.chaining_value = compress(
                    self.chaining_value, bw, self.chunk_counter, BLOCK_LEN,
                    self.flags | self.start_flag()
                )[:8]
                self.blocks_compressed += 1
                self.block = bytearray()
            want = BLOCK_LEN - len(self.block)
            take = min(want, n - i)
            self.block += data[i:i + take]
            i += take

    def output(self):
        bw = _words_from_block(bytes(self.block))
        return Output(self.chaining_value, bw, self.chunk_counter,
                      len(self.block),
                      self.flags | self.start_flag() | CHUNK_END)


def _parent_output(left_cv, right_cv, key_words, flags):
    bw = list(left_cv) + list(right_cv)
    return Output(list(key_words), bw, 0, BLOCK_LEN, flags | PARENT)


def _parent_cv(left, right, key_words, flags):
    return _parent_output(left, right, key_words, flags).chaining_value()


class Hasher:
    def __init__(self, key=None, derive_key_context=None):
        if derive_key_context is not None:
            if isinstance(derive_key_context, str):
                derive_key_context = derive_key_context.encode('utf-8')
            ctx = Hasher.__new__(Hasher)
            ctx.key_words = list(IV)
            ctx.base_flags = DERIVE_KEY_CONTEXT
            ctx.chunk_state = ChunkState(IV, 0, DERIVE_KEY_CONTEXT)
            ctx.cv_stack = []
            ctx.update(derive_key_context)
            ctx_key_bytes = ctx.finalize(32)
            self.key_words = list(struct.unpack('<8I', ctx_key_bytes))
            self.base_flags = DERIVE_KEY_MATERIAL
        elif key is not None:
            if len(key) != 32:
                raise ValueError("key must be 32 bytes")
            self.key_words = list(struct.unpack('<8I', bytes(key)))
            self.base_flags = KEYED_HASH
        else:
            self.key_words = list(IV)
            self.base_flags = 0
        self.chunk_state = ChunkState(self.key_words, 0, self.base_flags)
        self.cv_stack = []

    def _push_chunk_cv(self, new_cv, total_chunks):
        # Merge while the lowest bit of total is 0 (every time we complete a
        # power-of-two boundary).
        while (total_chunks & 1) == 0:
            left = self.cv_stack.pop()
            new_cv = _parent_cv(left, new_cv, self.key_words, self.base_flags)
            total_chunks >>= 1
        self.cv_stack.append(new_cv)

    def update(self, data):
        if isinstance(data, str):
            data = data.encode('utf-8')
        i = 0
        n = len(data)
        while i < n:
            if self.chunk_state.len() == CHUNK_LEN:
                chunk_cv = self.chunk_state.output().chaining_value()
                total = self.chunk_state.chunk_counter + 1
                self._push_chunk_cv(chunk_cv, total)
                self.chunk_state = ChunkState(self.key_words, total, self.base_flags)
            want = CHUNK_LEN - self.chunk_state.len()
            take = min(want, n - i)
            self.chunk_state.update(data[i:i + take])
            i += take

    def _root_output(self):
        output = self.chunk_state.output()
        remaining = len(self.cv_stack)
        while remaining > 0:
            remaining -= 1
            output = _parent_output(
                self.cv_stack[remaining], output.chaining_value(),
                self.key_words, self.base_flags)
        return output

    def finalize(self, length=32, seek=0):
        return self._root_output().root_output_bytes(length, seek)


def hash_oneshot(data, length=32, seek=0):
    h = Hasher()
    h.update(data)
    return h.finalize(length, seek)
