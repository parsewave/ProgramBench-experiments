# b3sum 1.8.4 behavior map

## Invocation patterns
- `b3sum` → reads stdin (no '-' arg implies stdin), labels output with `-`
- `b3sum -` → reads stdin, labels with `-`
- `b3sum --` → same as no args (reads stdin)
- `b3sum FILE...` → hashes each file
- `b3sum -- FILE...` → after `--`, args treated as files even if leading `-`
- `b3sum --bogus` → unknown flag, exit 2, clap-style error

## Output formats
Default: `<hex>  <filename>\n` (two spaces between hash and name)
`--tag`: `BLAKE3 (<filename>) = <hex>\n`
`--no-names`: `<hex>\n` (overrides tag)
`--raw`: raw output bytes, only one file allowed, error otherwise

When filename contains backslash or newline:
- Line is prefixed with literal `\`
- Backslash → `\\`
- Newline → `\n`
- Format with --tag: `\BLAKE3 (escaped) = HASH\n`

## Length / Seek
- `-l, --length N` (default 32) → N bytes of XOF output, hex encoded
- `--seek N` (default 0) → start at byte offset N in XOF stream
- length 0: empty hash field, format becomes `  filename\n` or `BLAKE3 (filename) = \n`
- length is u64 (negative values rejected by clap as unknown flag '-1')

## Modes (mutually exclusive)
- Default: hash mode
- `--keyed`: 32-byte key from stdin, REQUIRES file arg (cannot use `-` for input)
  - key < 32 bytes: `Error: expected 32 key bytes from stdin, found N` exit 1
  - key > 32 bytes: `Error: read more than 32 key bytes from stdin` exit 1
  - `--keyed -`: `b3sum: -: Cannot open `-` in keyed mode` exit 1
- `--derive-key CTX`: derive_key mode with ctx string; input from file or stdin
- `--keyed` + `--derive-key`: clap error "the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'" exit 2

## Check mode (-c, --check)
- Reads check file(s); for each line, hash named file and compare
- Format auto-detected per line:
  - `<64hex>  <filename>` (exactly 2 spaces)
  - `BLAKE3 (<filename>) = <64hex>`
- Lines starting with `\`: filename has escapes (`\\` → `\`, `\n` → newline)
- Output: `<filename>: OK` or `<filename>: FAILED`
- Missing file: `<filename>: FAILED (No such file or directory (os error 2))`
- `--quiet`: suppress OK lines; only FAILED + warnings
- Summary on stderr: `b3sum: WARNING: N computed checksum(s) did NOT match` (plural form `checksums` when N > 1)
- Exit code: 0 if all pass, 1 if any fail
- Error variants on stderr (per bad line, counted in summary):
  - Empty line: `b3sum: Empty line`
  - Malformed: `b3sum: Invalid check line format`
  - Wrong hash length (not 64 hex chars / 32 bytes): `b3sum: Invalid hash length`
  - Bad backslash escape: `b3sum: Invalid backslash escape`
- Only 32-byte hashes (64 hex chars) accepted in check mode
- `--check` + `--keyed`/`--derive-key`: clap conflict error exit 2
- `--quiet` without `--check`: clap "required arguments not provided: --check" exit 2

## File error messages (during hashing)
- Missing: `b3sum: <name>: No such file or directory (os error 2)` exit 1
- Permission denied: `b3sum: <name>: Permission denied (os error 13)` exit 1
- Directory: `b3sum: <name>: Is a directory (os error 21)` exit 1
- Multiple files: errors don't abort, continue with rest; exit 1 if any failed

## Misc flags
- `--num-threads N`: u64. Invalid value: clap-style error
- `--no-mmap`: no behavioral change visible to us
- `-V`/`--version`: `b3sum 1.8.4\n` exit 0
- `-h`/`--help`: short help; `--help` = long help

## Help text (exact bytes important)
See goldens/help_long.txt and goldens/help_short.txt.

## Known BLAKE3 test vectors (hex)
- empty: `af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262`
- "abc": `6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85`
- "hello world": `d74981efa70a0c880b8d8c1985d075dbcbf679b99a5f9914e5aaf96b831a9e24`
- "hello world\n": `dc5a4edb8240b018124052c330270696f96771a63b45250a5c17d3000e823355`
