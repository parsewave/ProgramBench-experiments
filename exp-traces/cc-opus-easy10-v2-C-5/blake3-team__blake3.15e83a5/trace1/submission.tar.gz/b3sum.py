#!/usr/bin/env python3
"""b3sum 1.8.4 reimplementation - CLI driver.

Calls into libblake3.so for the hashing primitive; this module only handles
argument parsing, file/stdin reading, output formatting, and --check mode.
"""

import ctypes
import os
import sys

PROG_NAME_FOR_HELP = None  # filled in main() from argv[0] basename

# ---------------------------------------------------------------------------
# BLAKE3 C library binding
# ---------------------------------------------------------------------------

_LIB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'libblake3.so')
_lib = ctypes.CDLL(_LIB_PATH)

_lib.b3_hasher_size.restype = ctypes.c_size_t
_lib.b3_init.argtypes = [ctypes.c_void_p]
_lib.b3_init.restype = None
_lib.b3_init_keyed.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
_lib.b3_init_keyed.restype = None
_lib.b3_init_derive_key.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
_lib.b3_init_derive_key.restype = None
_lib.b3_update.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
_lib.b3_update.restype = None
_lib.b3_finalize.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint64]
_lib.b3_finalize.restype = None

_HASHER_SIZE = _lib.b3_hasher_size()


class Hasher:
    __slots__ = ('_buf',)

    def __init__(self, key=None, derive_key_context=None):
        self._buf = (ctypes.c_ubyte * _HASHER_SIZE)()
        if key is not None:
            if len(key) != 32:
                raise ValueError("key must be 32 bytes")
            _lib.b3_init_keyed(self._buf, bytes(key))
        elif derive_key_context is not None:
            ctx = derive_key_context
            if isinstance(ctx, str):
                ctx = ctx.encode('utf-8')
            _lib.b3_init_derive_key(self._buf, ctx, len(ctx))
        else:
            _lib.b3_init(self._buf)

    def update(self, data):
        if len(data) > 0:
            _lib.b3_update(self._buf, bytes(data), len(data))

    def finalize(self, length=32, seek=0):
        out = (ctypes.c_ubyte * length)()
        _lib.b3_finalize(self._buf, out, length, ctypes.c_uint64(seek))
        return bytes(out)


# ---------------------------------------------------------------------------
# Helpers: argv[0] handling, stdout/stderr writes
# ---------------------------------------------------------------------------

def _stdout_write(data):
    sys.stdout.buffer.write(data)


def _stderr_write(data):
    sys.stderr.buffer.write(data)


# ---------------------------------------------------------------------------
# Argument parser (clap-compatible error messages)
# ---------------------------------------------------------------------------

# Each flag: (long_name, short_name_or_None, takes_value, value_placeholder)
# Order matters for help text but here we just need the table.
FLAG_TABLE = [
    ('keyed',       None, False, None),
    ('derive-key',  None, True,  '<CONTEXT>'),
    ('length',      'l',  True,  '<LEN>'),
    ('seek',        None, True,  '<SEEK>'),
    ('num-threads', None, True,  '<NUM>'),
    ('no-mmap',     None, False, None),
    ('no-names',    None, False, None),
    ('raw',         None, False, None),
    ('tag',         None, False, None),
    ('check',       'c',  False, None),
    ('quiet',       None, False, None),
    ('help',        'h',  False, None),
    ('version',     'V',  False, None),
]
LONG_BY_NAME = {f[0]: f for f in FLAG_TABLE}
SHORT_BY_NAME = {f[1]: f for f in FLAG_TABLE if f[1]}

# Flags that conflict with --check.
CHECK_CONFLICTS = ('keyed', 'derive-key', 'length', 'no-names', 'raw', 'tag')
# Flags that conflict pairwise outside of --check.
KEY_CONFLICTS = ('keyed', 'derive-key')


def flag_display(name):
    """Return clap-style display string for a flag, e.g. '--length <LEN>'."""
    f = LONG_BY_NAME[name]
    if f[2]:
        return f"--{name} {f[3]}"
    return f"--{name}"


def usage_line(seen, missing=None, use_required=True):
    """Construct Usage line.
    seen: list of flag names seen so far.
    missing: list of missing required tokens, e.g. ['check', '<FILE>...']. Order preserved.
    use_required: if False, force [FILE]... regardless of --keyed presence.
    """
    missing = missing or []
    # Filter help/version out of seen
    seen = [s for s in seen if s not in ('help', 'version')]
    if not seen and not missing:
        return f"{PROG_NAME_FOR_HELP} [OPTIONS] [FILE]..."
    parts = [PROG_NAME_FOR_HELP]
    # Missing flag-type required come first (in order)
    for m in missing:
        if m == '<FILE>...':
            continue
        parts.append(flag_display(m))
    # Then seen flags in order
    for s in seen:
        parts.append(flag_display(s))
    # File token
    keyed_active = ('keyed' in seen) or ('keyed' in missing)
    if use_required and keyed_active:
        parts.append('<FILE>...')
    else:
        parts.append('[FILE]...')
    return ' '.join(parts)


class ParsedArgs:
    def __init__(self):
        self.keyed = False
        self.derive_key = None
        self.length = 32
        self.seek = 0
        self.num_threads = None
        self.no_mmap = False
        self.no_names = False
        self.raw = False
        self.tag = False
        self.check = False
        self.quiet = False
        self.help = False
        self.version = False
        self.files = []
        self.flags_used = []  # ordered list of flag names as encountered

    def set_flag(self, name, value=None):
        if name not in self.flags_used:
            self.flags_used.append(name)
        attr = name.replace('-', '_')
        if value is None:
            setattr(self, attr, True)
        else:
            setattr(self, attr, value)


def clap_error_with_usage(message, seen, missing=None, use_required=True, exit_code=2):
    out = bytearray()
    out += f"error: {message}\n\n".encode()
    out += f"Usage: {usage_line(seen, missing=missing, use_required=use_required)}\n\n".encode()
    out += b"For more information, try '--help'.\n"
    _stderr_write(bytes(out))
    sys.exit(exit_code)


def clap_error_no_usage(message, exit_code=2):
    out = bytearray()
    out += f"error: {message}\n\n".encode()
    out += b"For more information, try '--help'.\n"
    _stderr_write(bytes(out))
    sys.exit(exit_code)


def parse_u64(value_str, flag_disp):
    """Parse u64 with Rust-like error messages."""
    if value_str == '':
        clap_error_no_usage(
            f"invalid value '' for '{flag_disp}': cannot parse integer from empty string"
        )
    # Rust's u64.parse: allows optional + prefix, digits 0-9 only, no whitespace.
    s = value_str
    sign_offset = 0
    if s.startswith('+'):
        sign_offset = 1
    # Check all remaining chars are digits
    body = s[sign_offset:]
    if not body or not all(c.isdigit() and c.isascii() for c in body):
        clap_error_no_usage(
            f"invalid value '{value_str}' for '{flag_disp}': invalid digit found in string"
        )
    try:
        n = int(body)
    except ValueError:
        clap_error_no_usage(
            f"invalid value '{value_str}' for '{flag_disp}': invalid digit found in string"
        )
    if n >= (1 << 64):
        clap_error_no_usage(
            f"invalid value '{value_str}' for '{flag_disp}': number too large to fit in target type"
        )
    return n


def check_conflicts(state, new_name):
    """When setting new_name, check it doesn't conflict with already-set flags.
    On conflict: error mentions PREVIOUS-SEEN flag first, then new flag.
    Also detects repeated flag usage."""
    # Repeat detection (help/version don't count)
    if new_name in state.flags_used and new_name not in ('help', 'version'):
        clap_error_with_usage(
            f"the argument '{flag_display(new_name)}' cannot be used multiple times",
            seen=[],
            use_required=False,
        )
    # Find prior flag that conflicts with new_name.
    prior = None
    if new_name == 'check':
        for p in state.flags_used:
            if p in CHECK_CONFLICTS:
                prior = p
                break
    elif new_name in CHECK_CONFLICTS:
        if 'check' in state.flags_used:
            prior = 'check'
    if new_name == 'keyed' and 'derive-key' in state.flags_used:
        prior = 'derive-key'
    elif new_name == 'derive-key' and 'keyed' in state.flags_used:
        prior = 'keyed'
    if prior is not None:
        # Error: '<prior>' cannot be used with '<new>'
        clap_error_with_usage(
            f"the argument '{flag_display(prior)}' cannot be used with '{flag_display(new_name)}'",
            seen=list(state.flags_used),
        )


def parse_argv(argv):
    state = ParsedArgs()
    i = 0
    n = len(argv)
    end_of_opts = False

    def is_known_flag_arg(arg):
        if arg.startswith('--'):
            eq = arg.find('=')
            name = arg[2:eq] if eq >= 0 else arg[2:]
            return name in LONG_BY_NAME
        if arg.startswith('-') and len(arg) > 1:
            return arg[1] in SHORT_BY_NAME
        return False

    def try_consume_value(pos, flag_name_long):
        """Returns (value, was_consumed). value=None means: don't commit this flag,
        continue parsing — next arg looks like a (probably unknown) flag and
        should error on its own."""
        if pos >= n:
            clap_error_no_usage(
                f"a value is required for '{flag_display(flag_name_long)}' but none was supplied"
            )
        val = argv[pos]
        if val.startswith('-') and len(val) > 1 and val != '--':
            if is_known_flag_arg(val):
                clap_error_no_usage(
                    f"a value is required for '{flag_display(flag_name_long)}' but none was supplied"
                )
            return None, False
        return val, True

    while i < n:
        arg = argv[i]
        if end_of_opts:
            state.files.append(arg)
            i += 1
            continue

        if arg == '--':
            end_of_opts = True
            i += 1
            continue

        if arg.startswith('--') and len(arg) > 2:
            # Long option
            eq_idx = arg.find('=')
            if eq_idx >= 0:
                name = arg[2:eq_idx]
                inline_value = arg[eq_idx + 1:]
                have_inline = True
            else:
                name = arg[2:]
                inline_value = None
                have_inline = False

            if name not in LONG_BY_NAME:
                clap_error_with_usage(
                    f"unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'",
                    seen=list(state.flags_used),
                    use_required=False,
                )

            entry = LONG_BY_NAME[name]
            takes_value = entry[2]
            if takes_value:
                if have_inline:
                    value = inline_value
                else:
                    value, was_consumed = try_consume_value(i + 1, name)
                    if value is None:
                        # Skip this flag; next iteration processes the hyphen arg.
                        i += 1
                        continue
                    if was_consumed:
                        i += 1
                check_conflicts(state, name)
                if name == 'length':
                    state.set_flag('length', parse_u64(value, flag_display('length')))
                elif name == 'seek':
                    state.set_flag('seek', parse_u64(value, flag_display('seek')))
                elif name == 'num-threads':
                    state.set_flag('num-threads', parse_u64(value, flag_display('num-threads')))
                elif name == 'derive-key':
                    state.set_flag('derive-key', value)
            else:
                if have_inline:
                    # Unexpected inline value for boolean flag — clap rejects with specific error
                    clap_error_no_usage(
                        f"unexpected value '{inline_value}' for '--{name}' found; no more were expected"
                    )
                check_conflicts(state, name)
                if name == 'help':
                    print_long_help()
                    sys.exit(0)
                elif name == 'version':
                    _stdout_write(b"b3sum 1.8.4\n")
                    sys.exit(0)
                state.set_flag(name)
            i += 1
            continue

        if arg.startswith('-') and len(arg) > 1 and arg != '-':
            # Short option (potentially grouped or with inline value)
            # arg = '-<chars...>'. Try to consume each char.
            chars = arg[1:]
            j = 0
            while j < len(chars):
                ch = chars[j]
                if ch == '=' and j > 0:
                    # Stop; treat rest as value for previous flag (handled below)
                    j += 1
                    break
                if ch not in SHORT_BY_NAME:
                    # Unknown short flag. Unlike unknown long flag, reverts to default Usage.
                    bad = '-' + ch
                    clap_error_with_usage(
                        f"unexpected argument '{bad}' found\n\n  tip: to pass '{bad}' as a value, use '-- {bad}'",
                        seen=[],
                        use_required=False,
                    )
                entry = SHORT_BY_NAME[ch]
                long_name = entry[0]
                takes_value = entry[2]
                if takes_value:
                    rest = chars[j + 1:]
                    if rest.startswith('='):
                        rest = rest[1:]
                    if rest:
                        value = rest
                        j = len(chars)
                    else:
                        value, was_consumed = try_consume_value(i + 1, long_name)
                        if value is None:
                            # Skip; next iteration handles the hyphen arg.
                            i += 1
                            j = len(chars)
                            break
                        if was_consumed:
                            i += 1
                        j = len(chars)
                    check_conflicts(state, long_name)
                    if long_name == 'length':
                        state.set_flag('length', parse_u64(value, flag_display('length')))
                    elif long_name == 'seek':
                        state.set_flag('seek', parse_u64(value, flag_display('seek')))
                    elif long_name == 'num-threads':
                        state.set_flag('num-threads', parse_u64(value, flag_display('num-threads')))
                    elif long_name == 'derive-key':
                        state.set_flag('derive-key', value)
                    break
                else:
                    check_conflicts(state, long_name)
                    if long_name == 'help':
                        print_short_help()
                        sys.exit(0)
                    elif long_name == 'version':
                        _stdout_write(b"b3sum 1.8.4\n")
                        sys.exit(0)
                    state.set_flag(long_name)
                    j += 1
            i += 1
            continue

        # Positional (file path or '-')
        state.files.append(arg)
        i += 1

    # Post-parse validation
    missing_tokens = []  # tokens for the error list and Usage
    if state.quiet and not state.check:
        missing_tokens.append('check')
    if state.keyed and not state.files:
        missing_tokens.append('<FILE>...')
    if missing_tokens:
        lines = ["error: the following required arguments were not provided:"]
        for m in missing_tokens:
            if m == '<FILE>...':
                lines.append(f"  {m}")
            else:
                lines.append(f"  {flag_display(m)}")
        msg = "\n".join(lines)
        out = bytearray()
        out += msg.encode() + b"\n\n"
        out += f"Usage: {usage_line(state.flags_used, missing=missing_tokens)}\n\n".encode()
        out += b"For more information, try '--help'.\n"
        _stderr_write(bytes(out))
        sys.exit(2)

    return state


# ---------------------------------------------------------------------------
# Help / version text
# ---------------------------------------------------------------------------

SHORT_HELP_TEMPLATE = (
    "Usage: {prog} [OPTIONS] [FILE]...\n"
    "\n"
    "Arguments:\n"
    "  [FILE]...  Files to hash, or checkfiles to check\n"
    "\n"
    "Options:\n"
    "      --keyed                 Use the keyed mode, reading the 32-byte key from stdin\n"
    "      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string\n"
    "  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]\n"
    "      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]\n"
    "      --num-threads <NUM>     The maximum number of threads to use\n"
    "      --no-mmap               Disable memory mapping\n"
    "      --no-names              Omit filenames in the output\n"
    "      --raw                   Write raw output bytes to stdout, rather than hex\n"
    "      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n"
    "  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them\n"
    "      --quiet                 Skip printing OK for each checked file\n"
    "  -h, --help                  Print help (see more with '--help')\n"
    "  -V, --version               Print version\n"
)

# Long help has "blank" paragraph separators that contain 10 spaces (clap convention).
_SP10 = "          "
LONG_HELP_TEMPLATE = (
    "Usage: {prog} [OPTIONS] [FILE]...\n"
    "\n"
    "Arguments:\n"
    "  [FILE]...\n"
    f"{_SP10}Files to hash, or checkfiles to check\n"
    f"{_SP10}\n"
    f"{_SP10}When no file is given, or when - is given, read standard input.\n"
    "\n"
    "Options:\n"
    "      --keyed\n"
    f"{_SP10}Use the keyed mode, reading the 32-byte key from stdin\n"
    "\n"
    "      --derive-key <CONTEXT>\n"
    f"{_SP10}Use the key derivation mode, with the given context string\n"
    f"{_SP10}\n"
    f"{_SP10}Cannot be used with --keyed.\n"
    "\n"
    "  -l, --length <LEN>\n"
    f"{_SP10}The number of output bytes, before hex encoding\n"
    f"{_SP10}\n"
    f"{_SP10}[default: 32]\n"
    "\n"
    "      --seek <SEEK>\n"
    f"{_SP10}The starting output byte offset, before hex encoding\n"
    f"{_SP10}\n"
    f"{_SP10}[default: 0]\n"
    "\n"
    "      --num-threads <NUM>\n"
    f"{_SP10}The maximum number of threads to use\n"
    f"{_SP10}\n"
    f"{_SP10}By default, this is the number of logical cores. If this flag is omitted, or if its value\n"
    f"{_SP10}is 0, RAYON_NUM_THREADS is also respected.\n"
    "\n"
    "      --no-mmap\n"
    f"{_SP10}Disable memory mapping\n"
    f"{_SP10}\n"
    f"{_SP10}Currently this also disables multithreading.\n"
    "\n"
    "      --no-names\n"
    f"{_SP10}Omit filenames in the output\n"
    "\n"
    "      --raw\n"
    f"{_SP10}Write raw output bytes to stdout, rather than hex\n"
    f"{_SP10}\n"
    f"{_SP10}--no-names is implied. In this case, only a single input is allowed.\n"
    "\n"
    "      --tag\n"
    f"{_SP10}Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n"
    "\n"
    "  -c, --check\n"
    f"{_SP10}Read BLAKE3 sums from the [FILE]s and check them\n"
    "\n"
    "      --quiet\n"
    f"{_SP10}Skip printing OK for each checked file\n"
    f"{_SP10}\n"
    f"{_SP10}Must be used with --check.\n"
    "\n"
    "  -h, --help\n"
    f"{_SP10}Print help (see a summary with '-h')\n"
    "\n"
    "  -V, --version\n"
    f"{_SP10}Print version\n"
)


def print_short_help():
    _stdout_write(SHORT_HELP_TEMPLATE.format(prog=PROG_NAME_FOR_HELP).encode())


def print_long_help():
    _stdout_write(LONG_HELP_TEMPLATE.format(prog=PROG_NAME_FOR_HELP).encode())


# ---------------------------------------------------------------------------
# Filename escape for output
# ---------------------------------------------------------------------------

def needs_escape(name_bytes):
    return b'\\' in name_bytes or b'\n' in name_bytes


def escape_filename(name_bytes):
    out = bytearray()
    for b in name_bytes:
        if b == ord('\\'):
            out += b'\\\\'
        elif b == ord('\n'):
            out += b'\\n'
        else:
            out.append(b)
    return bytes(out)


# ---------------------------------------------------------------------------
# Hashing wrappers
# ---------------------------------------------------------------------------

def make_hasher(state, key_bytes=None):
    if state.keyed:
        return Hasher(key=key_bytes)
    elif state.derive_key is not None:
        return Hasher(derive_key_context=state.derive_key)
    else:
        return Hasher()


def read_key_from_stdin():
    """Read exactly 32 bytes from stdin. Errors with reference-matching message."""
    data = bytearray()
    while len(data) < 33:
        chunk = sys.stdin.buffer.read(33 - len(data))
        if not chunk:
            break
        data.extend(chunk)
    if len(data) > 32:
        _stderr_write(b"Error: read more than 32 key bytes from stdin\n")
        sys.exit(1)
    if len(data) < 32:
        _stderr_write(f"Error: expected 32 key bytes from stdin, found {len(data)}\n".encode())
        sys.exit(1)
    return bytes(data)


CHUNK_READ = 1 << 16  # 64 KB


def hash_path(state, path_bytes, key_bytes=None):
    """Hash a file (or '-' = stdin). Returns hex-encoded result string (bytes), or None on error.
    Errors are reported to stderr and we return None to signal continuation."""
    h = make_hasher(state, key_bytes=key_bytes)
    if path_bytes == b'-':
        if state.keyed:
            _stderr_write(b"b3sum: -: Cannot open `-` in keyed mode\n")
            return None
        f = sys.stdin.buffer
        try:
            while True:
                chunk = f.read(CHUNK_READ)
                if not chunk:
                    break
                h.update(chunk)
        except OSError as e:
            _stderr_write(format_file_error(path_bytes, e))
            return None
    else:
        try:
            f = open(path_bytes, 'rb')
        except IsADirectoryError as e:
            _stderr_write(format_file_error(path_bytes, e))
            return None
        except FileNotFoundError as e:
            _stderr_write(format_file_error(path_bytes, e))
            return None
        except PermissionError as e:
            _stderr_write(format_file_error(path_bytes, e))
            return None
        except OSError as e:
            _stderr_write(format_file_error(path_bytes, e))
            return None
        try:
            while True:
                try:
                    chunk = f.read(CHUNK_READ)
                except IsADirectoryError as e:
                    _stderr_write(format_file_error(path_bytes, e))
                    return None
                except OSError as e:
                    _stderr_write(format_file_error(path_bytes, e))
                    return None
                if not chunk:
                    break
                h.update(chunk)
        finally:
            f.close()
    return h.finalize(state.length, state.seek)


def format_file_error(path_bytes, exc):
    """Match reference: 'b3sum: <name>: <os description> (os error <errno>)\n'."""
    errno = getattr(exc, 'errno', None)
    if isinstance(exc, FileNotFoundError):
        desc = "No such file or directory"
    elif isinstance(exc, IsADirectoryError):
        desc = "Is a directory"
    elif isinstance(exc, PermissionError):
        desc = "Permission denied"
    elif isinstance(exc, NotADirectoryError):
        desc = "Not a directory"
    else:
        desc = os.strerror(errno) if errno else (exc.strerror or str(exc))
    if errno is None:
        # Fallback
        return b"b3sum: " + path_bytes + b": " + desc.encode() + b"\n"
    return b"b3sum: " + path_bytes + b": " + desc.encode() + f" (os error {errno})\n".encode()


def open_for_error_message(path_bytes):
    """Like trying to open the file; return None on success, else writes error & returns string."""
    pass


# ---------------------------------------------------------------------------
# Output formatting (default / tag / raw / no-names)
# ---------------------------------------------------------------------------

def emit_hash(state, hash_bytes, path_bytes):
    """Write one output line for a hashed file."""
    if state.raw:
        _stdout_write(hash_bytes)
        return
    hex_hash = hash_bytes.hex().encode('ascii')
    if state.no_names:
        _stdout_write(hex_hash + b"\n")
        return
    if state.tag:
        line = bytearray()
        if needs_escape(path_bytes):
            line += b'\\'
            line += b'BLAKE3 ('
            line += escape_filename(path_bytes)
            line += b') = '
            line += hex_hash
        else:
            line += b'BLAKE3 ('
            line += path_bytes
            line += b') = '
            line += hex_hash
        line += b"\n"
        _stdout_write(bytes(line))
        return
    # Default format
    if needs_escape(path_bytes):
        out = b'\\' + hex_hash + b'  ' + escape_filename(path_bytes) + b"\n"
    else:
        out = hex_hash + b'  ' + path_bytes + b"\n"
    _stdout_write(out)


# ---------------------------------------------------------------------------
# Check mode
# ---------------------------------------------------------------------------

def parse_check_line(line_bytes):
    """Parse one line of a check file. Returns (filename_bytes, hash_hex_bytes, error_or_None).
    On error, returns (None, None, error_string)."""
    if line_bytes == b'':
        return None, None, "Empty line"
    # Detect escape prefix
    escaped = False
    body = line_bytes
    if body.startswith(b'\\'):
        escaped = True
        body = body[1:]
    # BSD format: "BLAKE3 (NAME) = HASH"
    if body.startswith(b"BLAKE3 ("):
        sep = body.rfind(b") = ")
        if sep < 0:
            return None, None, "Invalid check line format"
        name = body[len(b"BLAKE3 ("):sep]
        hash_str = body[sep + len(b") = "):]
        if escaped:
            try:
                name = unescape_filename(name)
            except ValueError:
                return None, None, "Invalid backslash escape"
        if not name:
            return None, None, "empty file path"
        return name, hash_str, None
    # Default format: "HASH  NAME" with exactly two spaces.
    sep = body.find(b"  ")
    if sep < 0:
        return None, None, "Invalid check line format"
    hash_str = body[:sep]
    name = body[sep + 2:]
    if not hash_str:
        return None, None, "Invalid check line format"
    if not name:
        return None, None, "empty file path"
    if escaped:
        try:
            name = unescape_filename(name)
        except ValueError:
            return None, None, "Invalid backslash escape"
    return name, hash_str, None


def unescape_filename(name_bytes):
    """Reverse \\ escaping: \\\\ → \\, \\n → newline. Raise ValueError on bad escape."""
    out = bytearray()
    i = 0
    while i < len(name_bytes):
        c = name_bytes[i]
        if c == ord('\\'):
            if i + 1 >= len(name_bytes):
                raise ValueError("trailing backslash")
            nxt = name_bytes[i + 1]
            if nxt == ord('\\'):
                out.append(ord('\\'))
            elif nxt == ord('n'):
                out.append(ord('\n'))
            else:
                raise ValueError("unknown escape")
            i += 2
        else:
            out.append(c)
            i += 1
    return bytes(out)


def hash_str_status(hash_str_bytes):
    """Return one of: 'ok', 'bad_length', 'bad_hex'. Reference accepts only 64
    lowercase-hex characters."""
    if len(hash_str_bytes) != 64:
        return 'bad_length'
    for b in hash_str_bytes:
        if not (
            (ord('0') <= b <= ord('9')) or
            (ord('a') <= b <= ord('f'))
        ):
            return 'bad_hex'
    return 'ok'


def do_check(state, check_files, key_bytes=None):
    """Process check files; return number of failures."""
    failed_count = 0
    any_targets = False

    def process_lines(file_iter, source_label):
        nonlocal failed_count, any_targets
        for raw_line in file_iter:
            any_targets = True
            # Reference reads as UTF-8 text; any non-UTF-8 line aborts the
            # entire check with this error, regardless of prior failures.
            try:
                raw_line.decode('utf-8')
            except UnicodeDecodeError:
                _stderr_write(b"Error: stream did not contain valid UTF-8\n")
                sys.exit(1)
            # Strip trailing newline (LF), allow trailing CR before LF
            line = raw_line
            if line.endswith(b'\n'):
                line = line[:-1]
            if line.endswith(b'\r'):
                line = line[:-1]
            name, hash_str, err = parse_check_line(line)
            if err is not None:
                _stderr_write(f"b3sum: {err}\n".encode())
                failed_count += 1
                continue
            status = hash_str_status(hash_str)
            if status == 'bad_length':
                _stderr_write(b"b3sum: Invalid hash length\n")
                failed_count += 1
                continue
            if status == 'bad_hex':
                _stderr_write(b"b3sum: Invalid hex\n")
                failed_count += 1
                continue
            # Hash the named file and compare
            try:
                f = open(name, 'rb')
            except (FileNotFoundError, PermissionError, IsADirectoryError, NotADirectoryError, OSError) as e:
                # Emit "<name>: FAILED (<error description>)" to STDOUT (per reference)
                # plus increment failed_count
                if state.quiet:
                    # Still print FAILED line even in quiet
                    pass
                desc = format_file_error_inline(e)
                # Print to stdout
                if needs_escape(name):
                    _stdout_write(b'\\' + escape_filename(name) + b": FAILED (" + desc.encode() + b")\n")
                else:
                    _stdout_write(name + b": FAILED (" + desc.encode() + b")\n")
                failed_count += 1
                continue
            try:
                h = make_hasher(state, key_bytes=key_bytes)
                while True:
                    try:
                        chunk = f.read(CHUNK_READ)
                    except (IsADirectoryError, OSError) as e:
                        desc = format_file_error_inline(e)
                        if needs_escape(name):
                            _stdout_write(b'\\' + escape_filename(name) + b": FAILED (" + desc.encode() + b")\n")
                        else:
                            _stdout_write(name + b": FAILED (" + desc.encode() + b")\n")
                        failed_count += 1
                        chunk = None
                        break
                    if not chunk:
                        break
                    h.update(chunk)
                if chunk is None:
                    continue
            finally:
                f.close()
            actual_hex = h.finalize(32, state.seek).hex().encode('ascii')
            expected = hash_str.lower()
            if actual_hex == expected:
                if not state.quiet:
                    if needs_escape(name):
                        _stdout_write(b'\\' + escape_filename(name) + b": OK\n")
                    else:
                        _stdout_write(name + b": OK\n")
            else:
                if needs_escape(name):
                    _stdout_write(b'\\' + escape_filename(name) + b": FAILED\n")
                else:
                    _stdout_write(name + b": FAILED\n")
                failed_count += 1

    if not check_files:
        # Read from stdin
        process_lines(iter_lines_binary(sys.stdin.buffer), b'-')
    else:
        for cf in check_files:
            if cf == b'-':
                process_lines(iter_lines_binary(sys.stdin.buffer), cf)
            else:
                try:
                    fh = open(cf, 'rb')
                except (FileNotFoundError, PermissionError, IsADirectoryError,
                        NotADirectoryError, OSError) as e:
                    # Reference: fatal "Error:" message, no b3sum prefix or
                    # filename, exit 1 without further processing.
                    _stderr_write(b"Error: " + _short_err_desc(e).encode() + b"\n")
                    sys.exit(1)
                try:
                    process_lines(iter_lines_binary(fh), cf)
                finally:
                    fh.close()

    if failed_count > 0:
        if failed_count == 1:
            _stderr_write(b"b3sum: WARNING: 1 computed checksum did NOT match\n")
        else:
            _stderr_write(f"b3sum: WARNING: {failed_count} computed checksums did NOT match\n".encode())
        return 1
    return 0


def _short_err_desc(exc):
    errno = getattr(exc, 'errno', None)
    if isinstance(exc, FileNotFoundError):
        desc = "No such file or directory"
    elif isinstance(exc, IsADirectoryError):
        desc = "Is a directory"
    elif isinstance(exc, PermissionError):
        desc = "Permission denied"
    elif isinstance(exc, NotADirectoryError):
        desc = "Not a directory"
    else:
        desc = os.strerror(errno) if errno else (exc.strerror or str(exc))
    if errno is not None:
        return f"{desc} (os error {errno})"
    return desc


def format_file_error_inline(exc):
    """Format for inline 'FAILED (...)' messages."""
    errno = getattr(exc, 'errno', None)
    if isinstance(exc, FileNotFoundError):
        desc = "No such file or directory"
    elif isinstance(exc, IsADirectoryError):
        desc = "Is a directory"
    elif isinstance(exc, PermissionError):
        desc = "Permission denied"
    elif isinstance(exc, NotADirectoryError):
        desc = "Not a directory"
    else:
        desc = os.strerror(errno) if errno else (exc.strerror or str(exc))
    if errno is not None:
        return f"{desc} (os error {errno})"
    return desc


def iter_lines_binary(f):
    """Iterate lines of a binary file, yielding bytes including trailing \\n."""
    buf = bytearray()
    while True:
        chunk = f.read(8192)
        if not chunk:
            if buf:
                yield bytes(buf)
                buf.clear()
            return
        buf.extend(chunk)
        while True:
            idx = buf.find(b'\n')
            if idx < 0:
                break
            yield bytes(buf[:idx + 1])
            del buf[:idx + 1]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    global PROG_NAME_FOR_HELP
    PROG_NAME_FOR_HELP = os.path.basename(sys.argv[0]) if sys.argv else 'executable'
    # Use raw argv as strings (using filesystem encoding); for clap-style errors,
    # we mostly compare/display as text. For file paths we'll use os.fsencode below.
    argv = sys.argv[1:]
    state = parse_argv(argv)

    # Validate keyed: read key
    key_bytes = None
    if state.keyed:
        key_bytes = read_key_from_stdin()

    # Check mode
    if state.check:
        file_paths = [os.fsencode(p) for p in state.files]
        rc = do_check(state, file_paths, key_bytes=key_bytes)
        sys.exit(rc)

    # Otherwise hash mode
    file_paths = [os.fsencode(p) for p in state.files]
    if not file_paths:
        file_paths = [b'-']

    # --raw requires single file
    if state.raw and len(file_paths) > 1:
        _stderr_write(b"Error: Only one filename can be provided when using --raw\n")
        sys.exit(1)

    exit_code = 0
    for path_bytes in file_paths:
        hash_bytes = hash_path(state, path_bytes, key_bytes=key_bytes)
        if hash_bytes is None:
            exit_code = 1
            continue
        emit_hash(state, hash_bytes, path_bytes)
    sys.exit(exit_code)


if __name__ == '__main__':
    try:
        main()
    except BrokenPipeError:
        # Match Rust behavior: silent exit on SIGPIPE (or write to /dev/null)
        try:
            sys.stdout.flush()
        except Exception:
            pass
        os._exit(0)
