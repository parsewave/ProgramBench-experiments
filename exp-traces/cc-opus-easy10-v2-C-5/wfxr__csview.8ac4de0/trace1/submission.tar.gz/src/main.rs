use std::io::{self, IsTerminal, Read, Write};
use std::num::ParseIntError;
use std::path::PathBuf;
use std::process::ExitCode;
use std::str::FromStr;

use clap::{ArgAction, Parser, ValueEnum};

mod render;
mod style;

use render::render_table;
use style::Style;

#[derive(Copy, Clone, Debug, PartialEq, Eq, ValueEnum)]
#[clap(rename_all = "lowercase")]
pub enum Align {
    Left,
    Center,
    Right,
}

#[derive(Parser, Debug)]
#[command(
    name = "csview",
    bin_name = "executable",
    version = "1.3.4",
    about = "A high performance csv viewer with cjk/emoji support.",
    disable_help_flag = true,
    disable_version_flag = false,
    next_line_help = true,
    term_width = 100,
    max_term_width = 100,
)]
pub struct App {
    /// File to view
    #[arg(value_name = "FILE")]
    pub file: Option<PathBuf>,

    /// Specify that the input has no header row
    #[arg(short = 'H', long, action = ArgAction::SetTrue, conflicts_with = "no_headers")]
    pub no_headers: bool,

    /// Prepend a column of line numbers to the table
    #[arg(short = 'n', long = "number", action = ArgAction::SetTrue, conflicts_with = "number")]
    pub number: bool,

    /// Use '\t' as delimiter for tsv
    #[arg(short = 't', long, action = ArgAction::SetTrue, conflicts_with_all = ["tsv", "delimiter"])]
    pub tsv: bool,

    /// Specify the field delimiter
    #[arg(short = 'd', long, default_value = ",", value_name = "DELIMITER", conflicts_with_all = ["delimiter", "tsv"])]
    pub delimiter: char,

    /// Specify the border style
    #[arg(short = 's', long, default_value = "sharp", value_name = "STYLE", conflicts_with = "style")]
    pub style: Style,

    /// Specify padding for table cell
    #[arg(short = 'p', long, default_value = "1", value_name = "PADDING", value_parser = parse_u32, conflicts_with = "padding")]
    pub padding: u32,

    /// Specify global indent for table
    #[arg(short = 'i', long, default_value = "0", value_name = "INDENT", value_parser = parse_u32, conflicts_with = "indent")]
    pub indent: u32,

    /// Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
    #[arg(long, default_value = "1000", value_name = "LIMIT", value_parser = parse_u32, conflicts_with = "sniff")]
    pub sniff: u32,

    /// Specify the alignment of the table header
    #[arg(long = "header-align", default_value = "center", value_name = "HEADER_ALIGN", conflicts_with = "header_align")]
    pub header_align: Align,

    /// Specify the alignment of the table body
    #[arg(long = "body-align", default_value = "left", value_name = "BODY_ALIGN", conflicts_with = "body_align")]
    pub body_align: Align,

    /// Disable pager
    #[arg(short = 'P', long, action = ArgAction::SetTrue, conflicts_with = "disable_pager")]
    pub disable_pager: bool,

    /// Print help
    #[arg(short = 'h', long = "help", action = ArgAction::Help)]
    pub help: Option<bool>,
}

fn parse_u32(s: &str) -> Result<u32, ParseIntError> {
    u32::from_str(s)
}

fn run(app: App) -> io::Result<()> {
    let delimiter_byte: u8 = if app.tsv {
        b'\t'
    } else {
        let mut buf = [0u8; 4];
        let bytes = app.delimiter.encode_utf8(&mut buf).as_bytes();
        bytes[0]
    };

    let input_data: Vec<u8> = if let Some(path) = &app.file {
        match std::fs::File::open(path) {
            Ok(mut f) => {
                let mut buf = Vec::new();
                if let Err(e) = f.read_to_end(&mut buf) {
                    eprintln!("csview: {}", e);
                    std::process::exit(1);
                }
                buf
            }
            Err(e) => {
                eprintln!("csview: {}", e);
                std::process::exit(1);
            }
        }
    } else {
        let mut buf = Vec::new();
        io::stdin().read_to_end(&mut buf)?;
        buf
    };

    let data = if input_data.starts_with(&[0xEF, 0xBB, 0xBF]) {
        &input_data[3..]
    } else {
        &input_data[..]
    };

    let mut rdr = csv::ReaderBuilder::new()
        .delimiter(delimiter_byte)
        .has_headers(false)
        .flexible(false)
        .from_reader(data);

    let mut records: Vec<Vec<String>> = Vec::new();
    for result in rdr.records() {
        match result {
            Ok(rec) => {
                let row: Vec<String> = rec.iter().map(|s| s.to_string()).collect();
                records.push(row);
            }
            Err(e) => {
                eprintln!("csview: {}", e);
                std::process::exit(1);
            }
        }
    }

    let stdout = io::stdout();
    let mut out = stdout.lock();
    render_table(&mut out, &records, &app)?;
    Ok(())
}

fn main() -> ExitCode {
    let app = App::parse();
    let _ = io::stdout().is_terminal();
    match run(app) {
        Ok(_) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("csview: {}", e);
            ExitCode::from(1)
        }
    }
}

pub fn col_width(s: &str) -> usize {
    use unicode_width::UnicodeWidthStr;
    s.width_cjk()
}

pub fn render_width(s: &str) -> usize {
    use unicode_width::UnicodeWidthStr;
    s.width()
}
