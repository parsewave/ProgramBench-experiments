use std::io::{self, Write};

use crate::style::BorderChars;
use crate::{col_width, render_width, Align, App};

pub fn render_table<W: Write>(out: &mut W, records: &[Vec<String>], app: &App) -> io::Result<()> {
    let style = app.style;
    let pad = app.padding as usize;
    let indent = app.indent as usize;
    let chars = style.chars();

    // Separate header and body
    let (header, body): (Option<&Vec<String>>, &[Vec<String>]) = if app.no_headers {
        (None, records)
    } else if records.is_empty() {
        (None, &[])
    } else {
        (Some(&records[0]), &records[1..])
    };

    // Determine total columns considering -n option
    let user_ncols = if let Some(h) = header {
        h.len()
    } else if let Some(first) = body.first() {
        first.len()
    } else {
        0
    };

    let total_cols = if app.number { user_ncols + 1 } else { user_ncols };
    let header_present = !app.no_headers;

    if total_cols == 0 {
        emit_empty_table(out, &chars, indent, header_present)?;
        return Ok(());
    }

    // Compute column widths
    let mut widths = vec![0usize; total_cols];
    let data_offset = if app.number { 1 } else { 0 };

    // Header always included if present
    if let Some(h) = header {
        for (i, cell) in h.iter().enumerate() {
            if i + data_offset < widths.len() {
                widths[i + data_offset] = widths[i + data_offset].max(col_width(cell));
            }
        }
    }

    // Body rows up to sniff limit
    let sniff = app.sniff as usize;
    let body_limit = if sniff == 0 { body.len() } else { sniff.min(body.len()) };

    for row in body.iter().take(body_limit) {
        for (i, cell) in row.iter().enumerate() {
            if i + data_offset < widths.len() {
                widths[i + data_offset] = widths[i + data_offset].max(col_width(cell));
            }
        }
    }

    if app.number {
        // Sniff limit applies to # column too: width based on body_limit + 1
        let num_width = (body_limit + 1).to_string().len();
        widths[0] = widths[0].max(num_width).max(1);
    }

    // Render
    if chars.has_top {
        write_horizontal(out, &chars, &widths, pad, indent, BorderRow::Top)?;
    }

    if let Some(h) = header {
        let header_row = build_header_row(h, app, total_cols);
        write_row(out, &chars, &widths, pad, indent, &header_row, app.header_align)?;

        if !body.is_empty() && chars.has_sep {
            write_horizontal(out, &chars, &widths, pad, indent, BorderRow::Sep)?;
        }
    } else if header_present && app.number {
        // Empty input but -n set: synthesize the # header
        let row: Vec<String> = (0..total_cols).map(|i| if i == 0 { "#".to_string() } else { String::new() }).collect();
        write_row(out, &chars, &widths, pad, indent, &row, app.header_align)?;
        if !body.is_empty() && chars.has_sep {
            write_horizontal(out, &chars, &widths, pad, indent, BorderRow::Sep)?;
        }
    }

    for (idx, row) in body.iter().enumerate() {
        let body_row = build_body_row(row, idx + 1, app, total_cols);
        write_row(out, &chars, &widths, pad, indent, &body_row, app.body_align)?;
        if chars.has_row_sep && idx + 1 < body.len() {
            write_horizontal(out, &chars, &widths, pad, indent, BorderRow::Sep)?;
        }
    }

    if chars.has_bottom {
        write_horizontal(out, &chars, &widths, pad, indent, BorderRow::Bottom)?;
    }

    Ok(())
}

#[derive(Copy, Clone)]
enum BorderRow {
    Top,
    Sep,
    Bottom,
}

fn build_header_row(header: &[String], app: &App, total_cols: usize) -> Vec<String> {
    let mut row: Vec<String> = Vec::with_capacity(total_cols);
    if app.number {
        row.push("#".to_string());
    }
    for cell in header {
        row.push(cell.clone());
    }
    while row.len() < total_cols {
        row.push(String::new());
    }
    row
}

fn build_body_row(row: &[String], num: usize, app: &App, total_cols: usize) -> Vec<String> {
    let mut out: Vec<String> = Vec::with_capacity(total_cols);
    if app.number {
        out.push(num.to_string());
    }
    for cell in row {
        out.push(cell.clone());
    }
    while out.len() < total_cols {
        out.push(String::new());
    }
    out
}

fn emit_empty_table<W: Write>(
    out: &mut W,
    chars: &BorderChars,
    indent: usize,
    has_header_row: bool,
) -> io::Result<()> {
    let ind = " ".repeat(indent);
    if chars.has_top {
        writeln!(out, "{}{}{}", ind, chars.top_left, chars.top_right)?;
    }
    if has_header_row {
        writeln!(out, "{}{}{}", ind, chars.outer_vert, chars.outer_vert)?;
    }
    if chars.has_bottom {
        writeln!(out, "{}{}{}", ind, chars.bottom_left, chars.bottom_right)?;
    }
    Ok(())
}

fn write_horizontal<W: Write>(
    out: &mut W,
    chars: &BorderChars,
    widths: &[usize],
    pad: usize,
    indent: usize,
    kind: BorderRow,
) -> io::Result<()> {
    let (left, right, t_join, h) = match kind {
        BorderRow::Top => (chars.top_left, chars.top_right, chars.top_t, chars.top_h),
        BorderRow::Bottom => (chars.bottom_left, chars.bottom_right, chars.bottom_t, chars.bottom_h),
        BorderRow::Sep => (chars.sep_left, chars.sep_right, chars.sep_cross, chars.sep_h),
    };

    write!(out, "{}", " ".repeat(indent))?;
    write!(out, "{}", left)?;
    for (i, w) in widths.iter().enumerate() {
        let cell_width = w + 2 * pad;
        for _ in 0..cell_width {
            write!(out, "{}", h)?;
        }
        if i + 1 < widths.len() {
            write!(out, "{}", t_join)?;
        }
    }
    writeln!(out, "{}", right)?;
    Ok(())
}

fn write_row<W: Write>(
    out: &mut W,
    chars: &BorderChars,
    widths: &[usize],
    pad: usize,
    indent: usize,
    row: &[String],
    align: Align,
) -> io::Result<()> {
    write!(out, "{}", " ".repeat(indent))?;
    write!(out, "{}", chars.outer_vert)?;
    for (i, cell) in row.iter().enumerate() {
        let w = widths[i];
        let truncated = truncate_to_width(cell, w);
        let cw = render_width(&truncated);
        let pad_spaces = " ".repeat(pad);
        let extra = w.saturating_sub(cw);
        let content = match align {
            Align::Left => format!("{}{}", truncated, " ".repeat(extra)),
            Align::Right => format!("{}{}", " ".repeat(extra), truncated),
            Align::Center => {
                let left = extra / 2;
                let right = extra - left;
                format!("{}{}{}", " ".repeat(left), truncated, " ".repeat(right))
            }
        };
        write!(out, "{}{}{}", pad_spaces, content, pad_spaces)?;
        if i + 1 < row.len() {
            write!(out, "{}", chars.inner_vert)?;
        }
    }
    write!(out, "{}", chars.outer_vert)?;
    writeln!(out)?;
    Ok(())
}

fn truncate_to_width(s: &str, max_width: usize) -> String {
    if render_width(s) <= max_width {
        return s.to_string();
    }
    use unicode_truncate::UnicodeTruncateStr;
    let (truncated, _) = s.unicode_truncate(max_width);
    truncated.to_string()
}
