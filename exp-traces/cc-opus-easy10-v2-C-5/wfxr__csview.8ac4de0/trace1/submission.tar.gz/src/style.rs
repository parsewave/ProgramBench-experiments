use clap::ValueEnum;

#[derive(Copy, Clone, Debug, PartialEq, Eq, ValueEnum)]
#[clap(rename_all = "lowercase")]
pub enum Style {
    None,
    Ascii,
    Ascii2,
    Sharp,
    Rounded,
    Reinforced,
    Markdown,
    Grid,
}

pub struct BorderChars {
    // Top border characters
    pub top_left: &'static str,
    pub top_right: &'static str,
    pub top_t: &'static str,
    pub top_h: &'static str,
    // Bottom border characters
    pub bottom_left: &'static str,
    pub bottom_right: &'static str,
    pub bottom_t: &'static str,
    pub bottom_h: &'static str,
    // Header/body separator characters
    pub sep_left: &'static str,
    pub sep_right: &'static str,
    pub sep_cross: &'static str,
    pub sep_h: &'static str,
    // Row vertical separator (outer and inner)
    pub outer_vert: &'static str,
    pub inner_vert: &'static str,
    // Layout flags
    pub has_top: bool,
    pub has_bottom: bool,
    pub has_sep: bool,
    pub has_row_sep: bool,
}

impl Style {
    pub fn chars(self) -> BorderChars {
        match self {
            Style::None => BorderChars {
                top_left: "", top_right: "", top_t: "", top_h: "",
                bottom_left: "", bottom_right: "", bottom_t: "", bottom_h: "",
                sep_left: "", sep_right: "", sep_cross: "", sep_h: "",
                outer_vert: "", inner_vert: "",
                has_top: false, has_bottom: false, has_sep: false, has_row_sep: false,
            },
            Style::Ascii => BorderChars {
                top_left: "+", top_right: "+", top_t: "+", top_h: "-",
                bottom_left: "+", bottom_right: "+", bottom_t: "+", bottom_h: "-",
                sep_left: "+", sep_right: "+", sep_cross: "+", sep_h: "-",
                outer_vert: "|", inner_vert: "|",
                has_top: true, has_bottom: true, has_sep: true, has_row_sep: false,
            },
            Style::Ascii2 => BorderChars {
                top_left: "", top_right: "", top_t: "", top_h: "",
                bottom_left: "", bottom_right: "", bottom_t: "", bottom_h: "",
                sep_left: " ", sep_right: " ", sep_cross: "+", sep_h: "-",
                outer_vert: " ", inner_vert: "|",
                has_top: false, has_bottom: false, has_sep: true, has_row_sep: false,
            },
            Style::Sharp => BorderChars {
                top_left: "┌", top_right: "┐", top_t: "┬", top_h: "─",
                bottom_left: "└", bottom_right: "┘", bottom_t: "┴", bottom_h: "─",
                sep_left: "├", sep_right: "┤", sep_cross: "┼", sep_h: "─",
                outer_vert: "│", inner_vert: "│",
                has_top: true, has_bottom: true, has_sep: true, has_row_sep: false,
            },
            Style::Rounded => BorderChars {
                top_left: "╭", top_right: "╮", top_t: "┬", top_h: "─",
                bottom_left: "╰", bottom_right: "╯", bottom_t: "┴", bottom_h: "─",
                sep_left: "├", sep_right: "┤", sep_cross: "┼", sep_h: "─",
                outer_vert: "│", inner_vert: "│",
                has_top: true, has_bottom: true, has_sep: true, has_row_sep: false,
            },
            Style::Reinforced => BorderChars {
                top_left: "┏", top_right: "┓", top_t: "┬", top_h: "─",
                bottom_left: "┗", bottom_right: "┛", bottom_t: "┴", bottom_h: "─",
                sep_left: "├", sep_right: "┤", sep_cross: "┼", sep_h: "─",
                outer_vert: "│", inner_vert: "│",
                has_top: true, has_bottom: true, has_sep: true, has_row_sep: false,
            },
            Style::Markdown => BorderChars {
                top_left: "", top_right: "", top_t: "", top_h: "",
                bottom_left: "", bottom_right: "", bottom_t: "", bottom_h: "",
                sep_left: "|", sep_right: "|", sep_cross: "|", sep_h: "-",
                outer_vert: "|", inner_vert: "|",
                has_top: false, has_bottom: false, has_sep: true, has_row_sep: false,
            },
            Style::Grid => BorderChars {
                top_left: "┌", top_right: "┐", top_t: "┬", top_h: "─",
                bottom_left: "└", bottom_right: "┘", bottom_t: "┴", bottom_h: "─",
                sep_left: "├", sep_right: "┤", sep_cross: "┼", sep_h: "─",
                outer_vert: "│", inner_vert: "│",
                has_top: true, has_bottom: true, has_sep: true, has_row_sep: true,
            },
        }
    }
}
