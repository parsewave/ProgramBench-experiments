#!/usr/bin/env bash
# Statistical top-up: 10 fresh random probes
set -u
REF=/workspace/executable
SUT=/work/work/executable
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

mkdir -p "$TMPDIR/probes"

cat > "$TMPDIR/probes/p1.csv" <<'EOF'
name,age,city
Alice,30,NYC
Bob,25,Tokyo
Carol,35,Beijing
EOF

printf 'col1\tcol2\tcol3\n1\t2\t3\n4\t5\t6\n' > "$TMPDIR/probes/p2.tsv"

cat > "$TMPDIR/probes/p3.csv" <<'EOF'
项目,数量,价格
苹果,5,1.50
香蕉,3,0.75
猕猴桃,2,2.00
EOF

{ echo "id,description,status,date"
  for i in $(seq 1 15); do
    echo "$i,Item description for entry $i,active,2026-01-$i"
  done
} > "$TMPDIR/probes/p4.csv"

cat > "$TMPDIR/probes/p5.csv" <<'EOF'
name,address,note
"Smith, John","123 Main St, Apt 5","prefers Tuesday meetings"
"Doe, Jane","456 Elm St","on vacation"
EOF

cat > "$TMPDIR/probes/p6.csv" <<'EOF'
a,b,c
,2,3
1,,3
1,2,
EOF

cat > "$TMPDIR/probes/p7.csv" <<'EOF'
a,b
"hello
world",test
EOF

cat > "$TMPDIR/probes/p8.csv" <<'EOF'
a,b,c
EOF

cat > "$TMPDIR/probes/p9.csv" <<'EOF'
n,sqr,cube
1,1,1
2,4,8
3,9,27
4,16,64
5,25,125
EOF

cat > "$TMPDIR/probes/p10.csv" <<'EOF'
item,status,priority
🌍 Earth,active,high
🌙 Moon,inactive,low
🚀 Rocket,pending,high
EOF

declare -A probe_args=(
    [p1]=""
    [p2]="-t -s grid"
    [p3]="--sniff 2 --header-align right"
    [p4]="-n -p 0"
    [p5]="-s markdown"
    [p6]="-s ascii --body-align center"
    [p7]="-s rounded -i 2"
    [p8]="-n -s ascii2"
    [p9]="-n --body-align right -p 2"
    [p10]="-s reinforced --header-align left"
)

total=0
fail=0
for p in p1 p2 p3 p4 p5 p6 p7 p8 p9 p10; do
    total=$((total+1))
    args=${probe_args[$p]}
    f="$TMPDIR/probes/${p}.csv"
    [[ ! -f "$f" ]] && f="$TMPDIR/probes/${p}.tsv"

    "$REF" $args "$f" > "$TMPDIR/ref.out" 2> "$TMPDIR/ref.err"
    ref_exit=$?
    "$SUT" $args "$f" > "$TMPDIR/sut.out" 2> "$TMPDIR/sut.err"
    sut_exit=$?

    if ! cmp -s "$TMPDIR/ref.out" "$TMPDIR/sut.out" || \
       ! cmp -s "$TMPDIR/ref.err" "$TMPDIR/sut.err" || \
       [[ "$ref_exit" != "$sut_exit" ]]; then
        fail=$((fail+1))
        echo "FAIL: $p (args: $args, file: $f)"
        if [[ "$ref_exit" != "$sut_exit" ]]; then
            echo "  Exit: ref=$ref_exit sut=$sut_exit"
        fi
        diff "$TMPDIR/ref.out" "$TMPDIR/sut.out" 2>&1 | head -20 | sed 's/^/  /'
    else
        echo "PASS: $p (args: $args)"
    fi
done

echo "==================="
echo "Top-up: $total tested, $fail failed"
