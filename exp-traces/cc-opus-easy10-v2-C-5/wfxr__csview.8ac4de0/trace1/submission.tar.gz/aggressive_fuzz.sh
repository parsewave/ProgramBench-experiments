#!/usr/bin/env bash
# Aggressive random-input fuzzer
REF=/workspace/executable
SUT=/work/work/executable
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

total=0
fail=0

styles=("none" "ascii" "ascii2" "sharp" "rounded" "reinforced" "markdown" "grid")
aligns=("left" "center" "right")
yn=("" "-H" "-n" "-H -n")

# Generate "weird" content variants
gen_weird() {
    local out=$1
    local kind=$2
    case $kind in
        ascii_long)
            { echo "a,b,c"
              for i in 1 2 3 4 5; do
                echo "$(head -c $((RANDOM % 20 + 1)) /dev/urandom | tr -dc 'a-zA-Z0-9_'),$(head -c $((RANDOM % 20 + 1)) /dev/urandom | tr -dc 'a-zA-Z0-9_'),$(head -c $((RANDOM % 20 + 1)) /dev/urandom | tr -dc 'a-zA-Z0-9_')"
              done } > $out
            ;;
        unicode_mix)
            { echo "name,value,note"
              echo "中文,数字,描述"
              echo "World,42,description"
              echo "🌍 emoji,😀 happy,description with emoji 🎉"
              echo "fr,Très bonne,élégant"
              echo "math,²³¼½,2+2=4"
              echo "stars,★☆,rated"
            } > $out
            ;;
        many_rows)
            { echo "id,name,value"
              for i in $(seq 1 25); do
                echo "$i,item$i,value$i"
              done } > $out
            ;;
        unicode_widths)
            { echo "char,width,name"
              echo "a,1,latin"
              echo "世,2,cjk"
              echo "🌍,2,emoji"
              echo "é,1,latin_accent"
              echo "±,?,ambiguous"
              echo "°C,?,temp"
              echo "★,?,star"
            } > $out
            ;;
        leading_trailing_space)
            { echo "a,b,c"
              echo " spaces, more spaces , end"
              echo "no  spaces,'quoted',normal"
              echo "tabs,here\\tthere,plain"
            } > $out
            ;;
    esac
}

run_diff() {
    local label="$1"
    shift
    total=$((total+1))
    local ref_out="$TMPDIR/ref_out"
    local ref_err="$TMPDIR/ref_err"
    local sut_out="$TMPDIR/sut_out"
    local sut_err="$TMPDIR/sut_err"

    "$REF" "$@" > "$ref_out" 2> "$ref_err"; local ref_exit=$?
    "$SUT" "$@" > "$sut_out" 2> "$sut_err"; local sut_exit=$?

    if ! cmp -s "$ref_out" "$sut_out" || ! cmp -s "$ref_err" "$sut_err" || [[ "$ref_exit" != "$sut_exit" ]]; then
        fail=$((fail+1))
        if [[ $fail -le 5 ]]; then
            echo "FAIL: $label (args: $*)"
            diff "$ref_out" "$sut_out" 2>&1 | head -10 | sed 's/^/  out: /'
            diff "$ref_err" "$sut_err" 2>&1 | head -3 | sed 's/^/  err: /'
        fi
    fi
}

for kind in ascii_long unicode_mix many_rows unicode_widths leading_trailing_space; do
    for iter in 1 2 3; do
        f="$TMPDIR/${kind}_${iter}.csv"
        gen_weird "$f" "$kind"
        for header in "${yn[@]}"; do
            for s in "${styles[@]}"; do
                for p in 0 1 3; do
                    for ha in "${aligns[@]}"; do
                        for ba in "${aligns[@]}"; do
                            run_diff "$kind/$iter $header -s $s -p $p" $header -s $s -p $p --header-align $ha --body-align $ba "$f"
                        done
                    done
                done
            done
            for sn in 0 1 3 100; do
                run_diff "$kind/$iter $header --sniff $sn" $header --sniff $sn "$f"
            done
            for i in 0 1 4; do
                run_diff "$kind/$iter $header -i $i" $header -i $i "$f"
            done
        done
    done
done

echo "==================="
echo "Total: $total, Failed: $fail"
