#!/usr/bin/env bash
# Fuzz-style testing using random inputs and flag combinations
REF=/workspace/executable
SUT=/work/work/executable
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

total=0
fail=0
declare -a failures

run_diff() {
    local label="$1"
    shift
    local input_file="$1"
    shift
    total=$((total+1))

    local ref_out="$TMPDIR/ref_out"
    local ref_err="$TMPDIR/ref_err"
    local sut_out="$TMPDIR/sut_out"
    local sut_err="$TMPDIR/sut_err"

    "$REF" "$@" "$input_file" > "$ref_out" 2> "$ref_err"
    local ref_exit=$?
    "$SUT" "$@" "$input_file" > "$sut_out" 2> "$sut_err"
    local sut_exit=$?

    if ! cmp -s "$ref_out" "$sut_out" || ! cmp -s "$ref_err" "$sut_err" || [[ "$ref_exit" != "$sut_exit" ]]; then
        fail=$((fail+1))
        failures+=("$label")
        if [[ $fail -le 5 ]]; then
            echo "FAIL ($label): args=$@ file=$input_file"
            if [[ "$ref_exit" != "$sut_exit" ]]; then
                echo "  Exit: ref=$ref_exit sut=$sut_exit"
            fi
            diff "$ref_out" "$sut_out" 2>&1 | head -10 | sed 's/^/  out: /'
            diff "$ref_err" "$sut_err" 2>&1 | head -5 | sed 's/^/  err: /'
        fi
    fi
}

# Generate random CSV files
gen_random() {
    local file="$1"
    local rows=$2
    local cols=$3
    local pattern="$4"

    rm -f "$file"
    case "$pattern" in
        simple)
            for r in $(seq 1 $rows); do
                row=""
                for c in $(seq 1 $cols); do
                    [[ -n "$row" ]] && row="$row,"
                    row="${row}v${r}_${c}"
                done
                echo "$row" >> "$file"
            done
            ;;
        wide)
            for r in $(seq 1 $rows); do
                row=""
                for c in $(seq 1 $cols); do
                    [[ -n "$row" ]] && row="$row,"
                    # Generate value of variable length
                    len=$((($r + $c) % 20 + 1))
                    val=$(head -c $len /dev/urandom | tr -dc 'a-z0-9' | head -c $len)
                    [[ -z "$val" ]] && val="x"
                    row="${row}${val}"
                done
                echo "$row" >> "$file"
            done
            ;;
        unicode)
            chars=("a" "世" "界" "中" "文" "测" "试" "🌍" "😀" "abc" "日本" "한국")
            for r in $(seq 1 $rows); do
                row=""
                for c in $(seq 1 $cols); do
                    [[ -n "$row" ]] && row="$row,"
                    idx=$(((r * c + r + c) % ${#chars[@]}))
                    row="${row}${chars[$idx]}"
                done
                echo "$row" >> "$file"
            done
            ;;
        quoted)
            for r in $(seq 1 $rows); do
                row=""
                for c in $(seq 1 $cols); do
                    [[ -n "$row" ]] && row="$row,"
                    if (( (r + c) % 3 == 0 )); then
                        row="${row}\"v,${r}\"${c}\""
                    elif (( (r + c) % 3 == 1 )); then
                        row="${row}\"v${r}_${c}\""
                    else
                        row="${row}v${r}_${c}"
                    fi
                done
                echo "$row" >> "$file"
            done
            ;;
        ambiguous)
            chars=("°" "€" "£" "★" "①" "½" "§" "®" "±" "¿" "✓" "⚠" "♠" "♥" "♣")
            for r in $(seq 1 $rows); do
                row=""
                for c in $(seq 1 $cols); do
                    [[ -n "$row" ]] && row="$row,"
                    idx=$(((r * c + r + c) % ${#chars[@]}))
                    row="${row}${chars[$idx]}${chars[$((($idx + 1) % ${#chars[@]}))]}"
                done
                echo "$row" >> "$file"
            done
            ;;
    esac
}

# Generate test files
for pattern in simple wide unicode quoted ambiguous; do
    for size in "3 2" "5 5" "10 4" "1 1" "20 8"; do
        rows=${size% *}
        cols=${size#* }
        f="$TMPDIR/${pattern}_${rows}x${cols}.csv"
        gen_random "$f" $rows $cols $pattern
    done
done

# Run tests with diverse flag combos
styles=("none" "ascii" "ascii2" "sharp" "rounded" "reinforced" "markdown" "grid")
aligns=("left" "center" "right")

for f in "$TMPDIR"/*.csv; do
    name=$(basename "$f" .csv)
    # Base test
    run_diff "$name base" "$f"
    run_diff "$name -H" "$f" -H
    run_diff "$name -n" "$f" -n
    run_diff "$name -H -n" "$f" -H -n
    for s in "${styles[@]}"; do
        run_diff "$name -s $s" "$f" -s "$s"
    done
    for p in 0 1 2 3 5; do
        run_diff "$name -p $p" "$f" -p $p
    done
    for i in 0 1 4; do
        run_diff "$name -i $i" "$f" -i $i
    done
    for ha in "${aligns[@]}"; do
        for ba in "${aligns[@]}"; do
            run_diff "$name --header-align $ha --body-align $ba" "$f" --header-align $ha --body-align $ba
        done
    done
    for sn in 0 1 2 5 100; do
        run_diff "$name --sniff $sn" "$f" --sniff $sn
    done
done

echo "==================="
echo "Total: $total, Failed: $fail"
