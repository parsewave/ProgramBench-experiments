#!/usr/bin/env bash
# Edge case testing
REF=/workspace/executable
SUT=/work/work/executable
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

total=0
fail=0

run_diff() {
    local label="$1"
    shift
    total=$((total+1))
    local stdin_file=""
    if [[ "$1" == "--stdin" ]]; then
        stdin_file="$2"; shift 2
    fi

    local ref_out="$TMPDIR/ref_out"
    local ref_err="$TMPDIR/ref_err"
    local sut_out="$TMPDIR/sut_out"
    local sut_err="$TMPDIR/sut_err"

    if [[ -n "$stdin_file" ]]; then
        "$REF" "$@" < "$stdin_file" > "$ref_out" 2> "$ref_err"; local ref_exit=$?
        "$SUT" "$@" < "$stdin_file" > "$sut_out" 2> "$sut_err"; local sut_exit=$?
    else
        "$REF" "$@" > "$ref_out" 2> "$ref_err"; local ref_exit=$?
        "$SUT" "$@" > "$sut_out" 2> "$sut_err"; local sut_exit=$?
    fi

    if ! cmp -s "$ref_out" "$sut_out" || ! cmp -s "$ref_err" "$sut_err" || [[ "$ref_exit" != "$sut_exit" ]]; then
        fail=$((fail+1))
        echo "FAIL: $label (args: $*)"
        if [[ "$ref_exit" != "$sut_exit" ]]; then
            echo "  Exit: ref=$ref_exit sut=$sut_exit"
        fi
        diff "$ref_out" "$sut_out" 2>&1 | head -10 | sed 's/^/  out: /'
        diff "$ref_err" "$sut_err" 2>&1 | head -5 | sed 's/^/  err: /'
    fi
}

# Various edge cases
# Empty stdin
run_diff "empty stdin" --stdin /dev/null
run_diff "empty stdin -H" --stdin /dev/null -H
run_diff "empty stdin -n" --stdin /dev/null -n
run_diff "empty stdin -H -n" --stdin /dev/null -H -n
for s in none ascii ascii2 sharp rounded reinforced markdown grid; do
    run_diff "empty stdin -s $s" --stdin /dev/null -s "$s"
    run_diff "empty stdin -H -s $s" --stdin /dev/null -H -s "$s"
    run_diff "empty stdin -n -s $s" --stdin /dev/null -n -s "$s"
done

# Single char inputs
printf "" > $TMPDIR/empty.csv
printf "\n" > $TMPDIR/nl.csv
printf "\r" > $TMPDIR/cr.csv
printf "\r\n" > $TMPDIR/crlf.csv
printf "," > $TMPDIR/comma.csv
printf ",," > $TMPDIR/comma2.csv
printf "a" > $TMPDIR/a.csv
printf "a\n" > $TMPDIR/a_nl.csv
printf "\xef\xbb\xbf" > $TMPDIR/bom.csv
printf "\xef\xbb\xbf\n" > $TMPDIR/bomnl.csv

for f in "$TMPDIR"/*.csv; do
    n=$(basename "$f")
    run_diff "$n" "$f"
    run_diff "$n -H" -H "$f"
    run_diff "$n -n" -n "$f"
done

# Quoted edge cases
printf 'a,b\n"x","y"\n' > $TMPDIR/q1.csv
printf 'a,b\n"x\ny","p"\n' > $TMPDIR/q_ml.csv
printf 'a,b\n"x""y","z"\n' > $TMPDIR/q_esc.csv
printf '"a"\n"hello"\n' > $TMPDIR/q_only.csv

for f in $TMPDIR/q*.csv; do
    n=$(basename "$f")
    for s in sharp markdown grid; do
        run_diff "$n -s $s" -s "$s" "$f"
    done
done

# Special cells
printf 'a,b\n,empty\nempty,\n' > $TMPDIR/empty_cells.csv
printf 'a,b\n"\n","x"\n' > $TMPDIR/just_nl.csv

# Test many cell counts
for cols in 1 2 5 10 20; do
    printf "" > $TMPDIR/cols.csv
    h=""; for c in $(seq 1 $cols); do [[ -n "$h" ]] && h="$h,"; h="${h}h$c"; done
    echo "$h" >> $TMPDIR/cols.csv
    r=""; for c in $(seq 1 $cols); do [[ -n "$r" ]] && r="$r,"; r="${r}v$c"; done
    echo "$r" >> $TMPDIR/cols.csv
    run_diff "cols=$cols" "$TMPDIR/cols.csv"
    run_diff "cols=$cols -n" -n "$TMPDIR/cols.csv"
done

# Numeric edge cases
run_diff "padding=4294967295" --padding 4294967295 "$TMPDIR/empty.csv" 2>/dev/null
run_diff "sniff=4294967295" --sniff 4294967295 "$TMPDIR/empty.csv"
run_diff "indent=4294967295" --indent 4294967295 "$TMPDIR/empty.csv" 2>/dev/null

# Many tests
echo "==================="
echo "Total: $total, Failed: $fail"
