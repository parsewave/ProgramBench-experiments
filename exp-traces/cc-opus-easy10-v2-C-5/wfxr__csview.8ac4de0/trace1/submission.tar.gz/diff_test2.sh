#!/usr/bin/env bash
# Differential testing using file comparison (handles NUL bytes)
REF=/workspace/executable
SUT=/work/work/executable
PROBE_DIR=/work/work/probes
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

total=0
fail=0

run_diff() {
    local description="$1"
    shift
    total=$((total+1))
    local stdin_file=""
    if [[ "$1" == "--stdin" ]]; then
        stdin_file="$2"
        shift 2
    fi

    local ref_out="$TMPDIR/ref_out"
    local ref_err="$TMPDIR/ref_err"
    local sut_out="$TMPDIR/sut_out"
    local sut_err="$TMPDIR/sut_err"

    if [[ -n "$stdin_file" ]]; then
        "$REF" "$@" < "$stdin_file" > "$ref_out" 2> "$ref_err"
        local ref_exit=$?
        "$SUT" "$@" < "$stdin_file" > "$sut_out" 2> "$sut_err"
        local sut_exit=$?
    else
        "$REF" "$@" > "$ref_out" 2> "$ref_err"
        local ref_exit=$?
        "$SUT" "$@" > "$sut_out" 2> "$sut_err"
        local sut_exit=$?
    fi

    local stdout_diff=0
    local stderr_diff=0
    cmp -s "$ref_out" "$sut_out" || stdout_diff=1
    cmp -s "$ref_err" "$sut_err" || stderr_diff=1

    if [[ "$ref_exit" != "$sut_exit" || $stdout_diff -ne 0 || $stderr_diff -ne 0 ]]; then
        fail=$((fail+1))
        echo "FAIL: $description (args: $*)"
        if [[ "$ref_exit" != "$sut_exit" ]]; then
            echo "  Exit: ref=$ref_exit sut=$sut_exit"
        fi
        if [[ $stdout_diff -ne 0 ]]; then
            echo "  Stdout diff:"
            diff "$ref_out" "$sut_out" 2>&1 | head -20 | sed 's/^/    /'
        fi
        if [[ $stderr_diff -ne 0 ]]; then
            echo "  Stderr diff:"
            diff "$ref_err" "$sut_err" 2>&1 | head -10 | sed 's/^/    /'
        fi
    fi
}

# Tests with various combinations
for f in "$PROBE_DIR"/*.csv; do
    name=$(basename "$f")
    # Basic
    run_diff "$name" "$f"
    run_diff "$name -H" -H "$f"
    run_diff "$name -n" -n "$f"
    run_diff "$name -H -n" -H -n "$f"
    # Styles
    for st in none ascii ascii2 sharp rounded reinforced markdown grid; do
        run_diff "$name -s $st" -s "$st" "$f"
        run_diff "$name -H -s $st" -H -s "$st" "$f"
        run_diff "$name -n -s $st" -n -s "$st" "$f"
    done
    # Padding/indent
    for p in 0 2 3; do
        run_diff "$name -p $p" -p "$p" "$f"
    done
    for i in 0 1 4 10; do
        run_diff "$name -i $i" -i "$i" "$f"
    done
    # Alignments
    for al in left center right; do
        run_diff "$name --header-align $al" --header-align "$al" "$f"
        run_diff "$name --body-align $al" --body-align "$al" "$f"
    done
    # Sniff
    for sn in 0 1 2 5 10 100; do
        run_diff "$name --sniff $sn" --sniff "$sn" "$f"
    done
done

# Errors and CLI
run_diff "--help" --help
run_diff "-h" -h
run_diff "--version" --version
run_diff "-V" -V
run_diff "missing file" /nonexistent.csv
run_diff "directory" /tmp
run_diff "bad style" -s bad "$PROBE_DIR/simple.csv"
run_diff "bad header-align" --header-align foo "$PROBE_DIR/simple.csv"
run_diff "negative padding" --padding=-1 "$PROBE_DIR/simple.csv"
run_diff "negative indent" --indent=-1 "$PROBE_DIR/simple.csv"
run_diff "negative sniff" --sniff=-1 "$PROBE_DIR/simple.csv"
run_diff "empty delim" --delimiter "" "$PROBE_DIR/simple.csv"
run_diff "multichar delim" -d "ab" "$PROBE_DIR/simple.csv"
run_diff "tsv and delim" -t -d "," "$PROBE_DIR/simple.csv"
run_diff "double H" -H -H "$PROBE_DIR/simple.csv"
run_diff "double t" -t -t "$PROBE_DIR/simple.csv"
run_diff "extra arg" --foo "$PROBE_DIR/simple.csv"
run_diff "extra positional" "$PROBE_DIR/simple.csv" extra
run_diff "stdin empty" --stdin /dev/null
run_diff "stdin simple" --stdin "$PROBE_DIR/simple.csv"
run_diff "-- only" --
run_diff "-- file" -- "$PROBE_DIR/simple.csv"

# Various delimiters
run_diff "tsv mode" -t "$PROBE_DIR/tsv.csv"
run_diff "tsv via -d" -d "	" "$PROBE_DIR/tsv.csv"
run_diff "pipe delim" -d "|" "$PROBE_DIR/simple.csv"
run_diff "non-ascii delim" -d "世" "$PROBE_DIR/simple.csv"

# Combined options
run_diff "all flags 1" -H -n -s grid -p 2 -i 4 --header-align left --body-align right "$PROBE_DIR/simple.csv"
run_diff "all flags 2" -n -s ascii --sniff 1 -p 0 "$PROBE_DIR/wide.csv"

echo "==================="
echo "Total: $total, Failed: $fail"
