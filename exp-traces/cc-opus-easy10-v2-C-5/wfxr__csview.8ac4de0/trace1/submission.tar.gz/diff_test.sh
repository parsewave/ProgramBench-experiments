#!/usr/bin/env bash
# Differential testing script
REF=/workspace/executable
SUT=/work/work/executable
PROBE_DIR=/work/work/probes

total=0
fail=0

run_diff() {
    local description="$1"
    shift
    total=$((total+1))
    local stdin_file=""
    if [[ "$1" == "--stdin" ]]; then
        stdin_file="$2"
        shift 2
    fi

    local ref_out ref_err ref_exit
    local sut_out sut_err sut_exit

    if [[ -n "$stdin_file" ]]; then
        ref_out=$("$REF" "$@" < "$stdin_file" 2>/tmp/ref_err)
        ref_exit=$?
        sut_out=$("$SUT" "$@" < "$stdin_file" 2>/tmp/sut_err)
        sut_exit=$?
    else
        ref_out=$("$REF" "$@" 2>/tmp/ref_err)
        ref_exit=$?
        sut_out=$("$SUT" "$@" 2>/tmp/sut_err)
        sut_exit=$?
    fi

    ref_err=$(cat /tmp/ref_err)
    sut_err=$(cat /tmp/sut_err)

    if [[ "$ref_out" != "$sut_out" || "$ref_err" != "$sut_err" || "$ref_exit" != "$sut_exit" ]]; then
        fail=$((fail+1))
        echo "FAIL: $description (args: $*)"
        if [[ "$ref_exit" != "$sut_exit" ]]; then
            echo "  Exit: ref=$ref_exit sut=$sut_exit"
        fi
        if [[ "$ref_out" != "$sut_out" ]]; then
            echo "  Stdout diff:"
            diff <(echo "$ref_out") <(echo "$sut_out") | head -20 | sed 's/^/    /'
        fi
        if [[ "$ref_err" != "$sut_err" ]]; then
            echo "  Stderr diff:"
            diff <(echo "$ref_err") <(echo "$sut_err") | head -10 | sed 's/^/    /'
        fi
    fi
}

# Iterate probe files with various option combinations
for f in "$PROBE_DIR"/*.csv; do
    name=$(basename "$f")
    run_diff "$name" "$f"
    run_diff "$name -H" -H "$f"
    run_diff "$name -n" -n "$f"
    run_diff "$name -s grid" -s grid "$f"
    run_diff "$name -s markdown" -s markdown "$f"
    run_diff "$name -s none" -s none "$f"
    run_diff "$name -p 0" -p 0 "$f"
    run_diff "$name -p 3" -p 3 "$f"
    run_diff "$name -i 4" -i 4 "$f"
done

echo "==================="
echo "Total: $total, Failed: $fail"
