#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

export PATH="/usr/local/cargo/bin:$PATH"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"

# Use offline cargo since registry is pre-populated; fallback to online if needed
if cargo build --release --offline 2>/dev/null; then
    :
else
    cargo build --release
fi

cp target/release/executable ./executable
chmod +x ./executable
