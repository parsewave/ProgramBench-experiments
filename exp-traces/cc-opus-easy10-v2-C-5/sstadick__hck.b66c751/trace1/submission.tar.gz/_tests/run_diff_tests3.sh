#!/bin/bash
# Realistic test runner using actual files (with proper newlines)
REF=/workspace/executable
SUT=/work/work/executable
TESTS=/tmp/hck_test_data
rm -rf $TESTS && mkdir -p $TESTS

PASS=0
FAIL=0
QUIET=${QUIET:-0}

# Create some test data files
cat > $TESTS/csv.csv <<EOF
name,age,city
Alice,30,NYC
Bob,25,LA
Charlie,35,SF
Diana,28,DC
EOF

cat > $TESTS/tsv.tsv <<EOF
col1	col2	col3	col4
v1	v2	v3	v4
x1	x2	x3	x4
EOF

cat > $TESTS/space.txt <<EOF
foo bar baz
qux quux quuz
hello world
EOF

cat > $TESTS/numbers.txt <<EOF
1 2 3 4 5 6 7 8 9 10
11 12 13 14 15 16 17 18 19 20
EOF

cat > $TESTS/empty.txt <<EOF
EOF

cat > $TESTS/blank_lines.txt <<EOF
a b c

x y z


EOF

cat > $TESTS/mixed_cols.txt <<EOF
a b c d e
x y z
m n o p
EOF

cat > $TESTS/single_col.txt <<EOF
foo
bar
baz
EOF

cat > $TESTS/special_chars.txt <<EOF
abc def!@#
hello\tworld
EOF

cat > $TESTS/utf8.txt <<EOF
café résumé naïve
日本語 中文 한국어
EOF

run_test() {
    local name="$1"
    shift
    local args=("$@")

    local ref_stdout sut_stdout
    local ref_exit sut_exit
    ref_stdout=$(timeout 5 "$REF" "${args[@]}" 2>/tmp/ref.err)
    ref_exit=$?
    sut_stdout=$(timeout 5 "$SUT" "${args[@]}" 2>/tmp/sut.err)
    sut_exit=$?

    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
        [ "$QUIET" = "0" ] && echo "PASS: $name"
    else
        FAIL=$((FAIL+1))
        echo "FAIL: $name (args: ${args[*]})"
        echo "  REF exit=$ref_exit, SUT exit=$sut_exit"
        echo "  REF stdout:"
        printf '%s' "$ref_stdout" | head -3 | sed 's/^/    /'
        echo "  SUT stdout:"
        printf '%s' "$sut_stdout" | head -3 | sed 's/^/    /'
    fi
}

# CSV tests
run_test "csv basic" -L -d , $TESTS/csv.csv
run_test "csv -f 2" -L -d , -f 2 $TESTS/csv.csv
run_test "csv -f 1,3" -L -d , -f 1,3 $TESTS/csv.csv
run_test "csv -F city" -L -d , -F city $TESTS/csv.csv
run_test "csv -F city -F name" -L -d , -F city -F name $TESTS/csv.csv
run_test "csv -F regex" -L -d , -r -F '^(name|city)$' $TESTS/csv.csv
run_test "csv -E age" -L -d , -E age $TESTS/csv.csv
run_test "csv -e 2" -L -d , -e 2 $TESTS/csv.csv
run_test "csv reorder" -L -d , -f 3,1,2 $TESTS/csv.csv

# TSV tests
run_test "tsv basic" -L -d $'\t' $TESTS/tsv.tsv
run_test "tsv -f 2-3" -L -d $'\t' -f 2-3 $TESTS/tsv.tsv
run_test "tsv -D ," -L -d $'\t' -D , $TESTS/tsv.tsv
run_test "tsv -F" -L -d $'\t' -F col1 -F col3 $TESTS/tsv.tsv

# Space-separated
run_test "space default" $TESTS/space.txt
run_test "space -f 2" -f 2 $TESTS/space.txt
run_test "space -f 1-2" -f 1-2 $TESTS/space.txt
run_test "space -d ' '" -d ' ' -L $TESTS/space.txt

# Number data
run_test "numbers -f 5" -f 5 $TESTS/numbers.txt
run_test "numbers -f 1,3,5,7,9" -f 1,3,5,7,9 $TESTS/numbers.txt
run_test "numbers -f 5-10" -f 5-10 $TESTS/numbers.txt
run_test "numbers -e 5-7" -e 5-7 $TESTS/numbers.txt

# Edge cases
run_test "empty file" $TESTS/empty.txt
run_test "blank lines" $TESTS/blank_lines.txt
run_test "mixed cols -f 3" -f 3 $TESTS/mixed_cols.txt
run_test "mixed cols -f 1" -f 1 $TESTS/mixed_cols.txt
run_test "single col" $TESTS/single_col.txt
run_test "single col -f 1" -f 1 $TESTS/single_col.txt
run_test "single col -f 2" -f 2 $TESTS/single_col.txt
run_test "utf8" $TESTS/utf8.txt
run_test "utf8 -f 2" -f 2 $TESTS/utf8.txt

# Range orderings
run_test "complex range 1" -f "1-5,1-3,3-5" $TESTS/numbers.txt
run_test "complex range 2" -f "1-10,1,5,10" $TESTS/numbers.txt
run_test "complex range 3" -f "10,5,1" $TESTS/numbers.txt

# Multi-file
run_test "two files" $TESTS/csv.csv $TESTS/single_col.txt
run_test "two files with -f" -f 1 $TESTS/csv.csv $TESTS/single_col.txt

# - for stdin
run_test "dash stdin" "-" < $TESTS/space.txt

# Compression
gzip -k $TESTS/csv.csv  # creates csv.csv.gz
run_test "gz decompress" -z $TESTS/csv.csv.gz
run_test "gz decompress with -F" -z -d , -L -F city $TESTS/csv.csv.gz
gzip -k $TESTS/numbers.txt
run_test "gz numbers" -z $TESTS/numbers.txt.gz
run_test "gz no -z reads raw" $TESTS/numbers.txt.gz

# CRLF
printf 'a b c\r\nx y z\r\n' > $TESTS/crlf.txt
run_test "crlf with --crlf" --crlf $TESTS/crlf.txt
run_test "crlf without --crlf" $TESTS/crlf.txt
run_test "crlf with -f" --crlf -f 2 $TESTS/crlf.txt

echo ""
echo "==============================="
echo "PASSED: $PASS, FAILED: $FAIL"
echo "==============================="
exit $((FAIL > 0 ? 1 : 0))
