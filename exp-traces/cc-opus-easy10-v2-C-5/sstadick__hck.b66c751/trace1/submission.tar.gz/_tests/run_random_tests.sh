#!/bin/bash
# Random testing
exec python3 /work/work/random_test_runner.py
