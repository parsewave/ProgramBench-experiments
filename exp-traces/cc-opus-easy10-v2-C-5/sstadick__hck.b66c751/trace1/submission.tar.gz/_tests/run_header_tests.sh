#!/bin/bash
# Comprehensive header tests
REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0

run() {
    local name="$1"
    local data="$2"
    shift 2

    local ref_stdout ref_exit sut_stdout sut_exit
    ref_stdout=$(printf '%s' "$data" | timeout 5 "$REF" "$@" 2>/tmp/ref.err)
    ref_exit=$?
    sut_stdout=$(printf '%s' "$data" | timeout 5 "$SUT" "$@" 2>/tmp/sut.err)
    sut_exit=$?

    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        echo "FAIL: $name"
        echo "  args: $*"
        echo "  REF exit=$ref_exit, SUT exit=$sut_exit"
        echo "  REF: $(printf '%s' "$ref_stdout" | od -c | head -3 | sed 's/^/    /')"
        echo "  SUT: $(printf '%s' "$sut_stdout" | od -c | head -3 | sed 's/^/    /')"
    fi
}

# Standard CSV with headers
DATA=$'name,age,city\nAlice,30,NYC\nBob,25,LA\n'

run "csv -F name" "$DATA" -d , -L -F name
run "csv -F city" "$DATA" -d , -L -F city
run "csv -F name -F city" "$DATA" -d , -L -F name -F city
run "csv -F city -F name" "$DATA" -d , -L -F city -F name
run "csv -F all" "$DATA" -d , -L -F name -F age -F city
run "csv -E age" "$DATA" -d , -L -E age
run "csv -E name -E city" "$DATA" -d , -L -E name -E city
run "csv -F name -E name" "$DATA" -d , -L -F name -E name
run "csv -F name -F age -E age" "$DATA" -d , -L -F name -F age -E age

# -r regex modes
run "csv -r -F .*" "$DATA" -d , -L -r -F '.*'
run "csv -r -F ^c" "$DATA" -d , -L -r -F '^c'
run "csv -r -F ^a" "$DATA" -d , -L -r -F '^a'
run "csv -r -F name|city" "$DATA" -d , -L -r -F 'name|city'
run "csv -r -F nope" "$DATA" -d , -L -r -F 'nope'
run "csv -F nope" "$DATA" -d , -L -F nope
run "csv -F name -F nope" "$DATA" -d , -L -F name -F nope

# Mix -f and -F
run "csv -F name -f 3" "$DATA" -d , -L -F name -f 3
run "csv -f 1-3 -E age" "$DATA" -d , -L -f 1-3 -E age
run "csv -F name -F city -e 1" "$DATA" -d , -L -F name -F city -e 1
run "csv -F name -F city -e 1-" "$DATA" -d , -L -F name -F city -e 1-
run "csv -F name -F city -E name -E city" "$DATA" -d , -L -F name -F city -E name -E city

# Empty headers
run "empty data" "" -d , -L -F name
run "header only" "$(printf 'name,age,city\n')" -d , -L -F name
run "header no nl" "name,age,city" -d , -L -F name

# Edge cases
DATA2=$'h1\th2\th3\nv1\tv2\tv3\n'
run "tab -F" "$DATA2" -d $'\t' -L -F h1
run "tab -F regex" "$DATA2" -d $'\t' -L -r -F '^h'

# Case sensitivity
DATA3=$'Name\nAlice\n'
run "case sens" "$DATA3" -F name
run "case sens lit" "$DATA3" -F Name
run "case ins regex" "$DATA3" -r -F '(?i)name'

# Identical headers
DATA4=$'name\tname\nv1\tv2\n'
run "dup headers" "$DATA4" -d $'\t' -L -F name

echo "PASSED: $PASS, FAILED: $FAIL"
