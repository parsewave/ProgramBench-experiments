#!/usr/bin/env python3
"""Random differential testing for hck reimplementation."""
import random
import subprocess
import os
import sys

REF = "/workspace/executable"
SUT = "/work/work/executable"

random.seed(42)

field_specs = [
    "1", "2", "5", "10",
    "1-3", "1-5", "2-4", "3-",
    "-3", "1,3,5", "2,4",
    "1-3,5", "1-3,4-6",
    "5,1,3", "1,1,1",
    "1-5,1-2,4-5",
    "1-,2-",
    "3-5,1-2",
]

delim_configs = [
    [],
    ["-d", ","],
    ["-d", "|"],
    ["-L", "-d", ","],
    ["-L", "-d", "|"],
    ["-L", "-d", "::"],
    ["-d", "[,;]"],
    ["-d", "\\s+"],
    ["-L", "-d", " "],
]


def gen_data(n_cols, n_rows, delim=" "):
    rows = []
    for _ in range(n_rows):
        cols = [str(random.randint(1, 1000)) for _ in range(n_cols)]
        rows.append(delim.join(cols))
    return ("\n".join(rows) + "\n").encode("utf-8")


data_pool = [
    gen_data(5, 3, " "),
    gen_data(10, 5, " "),
    gen_data(8, 2, ","),
    gen_data(3, 10, ","),
    gen_data(6, 4, "\t"),
    b"a b c\nx y z\n",
    b"alpha bravo charlie delta\n",
    b"1,2,3,4,5\nA,B,C,D,E\n",
    b"single\nrow\nonly\n",
    b"col1\tcol2\tcol3\nv1\tv2\tv3\n",
]


passes = 0
fails = 0
fail_details = []

NCASES = int(os.environ.get('NCASES', 200))

for i in range(NCASES):
    data = random.choice(data_pool)
    args = list(random.choice(delim_configs))
    if random.random() < 0.5:
        args.extend(["-f", random.choice(field_specs)])
    if random.random() < 0.2:
        args.extend(["-e", random.choice(field_specs)])
    if random.random() < 0.2:
        args.extend(["-D", random.choice([",", "|", "/", "\t"])])

    try:
        ref = subprocess.run([REF] + args, input=data, capture_output=True, timeout=5)
        sut = subprocess.run([SUT] + args, input=data, capture_output=True, timeout=5)
    except subprocess.TimeoutExpired:
        print(f"TIMEOUT case {i}: args={args}", file=sys.stderr)
        fails += 1
        continue

    if ref.stdout == sut.stdout and ref.returncode == sut.returncode:
        passes += 1
    else:
        fails += 1
        if len(fail_details) < 10:
            fail_details.append((i, args, data[:100], ref.returncode, sut.returncode, ref.stdout[:200], sut.stdout[:200]))

print(f"PASSED: {passes}, FAILED: {fails}")
for det in fail_details:
    i, args, data, refc, sutc, refout, sutout = det
    print(f"\nCASE {i}: args={args}")
    print(f"  data (first 100 bytes): {data!r}")
    print(f"  REF exit={refc}, SUT exit={sutc}")
    if refout != sutout:
        print(f"  REF: {refout!r}")
        print(f"  SUT: {sutout!r}")
