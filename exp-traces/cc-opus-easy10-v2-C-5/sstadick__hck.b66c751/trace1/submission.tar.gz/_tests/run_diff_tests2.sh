#!/bin/bash
# Extended differential testing
REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAILED_TESTS=()
QUIET=${QUIET:-0}

run_full_case() {
    # name, stdin_data, expect_byte_exact_stderr, args...
    local name="$1"
    local stdin_data="$2"
    shift 2
    local args=("$@")

    local ref_stdout ref_exit
    local sut_stdout sut_exit

    ref_stdout=$(printf '%s' "$stdin_data" | timeout 5 "$REF" "${args[@]}" 2>/tmp/ref.err)
    ref_exit=$?
    sut_stdout=$(printf '%s' "$stdin_data" | timeout 5 "$SUT" "${args[@]}" 2>/tmp/sut.err)
    sut_exit=$?

    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
        [ "$QUIET" = "0" ] && echo "PASS: $name"
    else
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$name")
        echo "FAIL: $name"
        echo "  args: ${args[*]}"
        echo "  REF exit=$ref_exit, SUT exit=$sut_exit"
        if [ "$ref_stdout" != "$sut_stdout" ]; then
            echo "  REF stdout:"
            printf '%s' "$ref_stdout" | od -c | head -15 | sed 's/^/    /'
            echo "  SUT stdout:"
            printf '%s' "$sut_stdout" | od -c | head -15 | sed 's/^/    /'
        fi
    fi
}

# Random/diverse tests
# Multiline with various delim configs
run_full_case "csv default field 2" "$(printf 'a,b,c\n1,2,3\nx,y,z\n')" -d , -L -f 2
run_full_case "csv field 1,3" "$(printf 'a,b,c\n1,2,3\nx,y,z\n')" -d , -L -f 1,3
run_full_case "csv reorder" "$(printf 'name,age,city\nAlice,30,NYC\n')" -d , -L -F city -F name
run_full_case "tab data" "$(printf 'col1\tcol2\tcol3\nA\tB\tC\n')" -d $'\t' -L -F col1
run_full_case "tab data range" "$(printf 'col1\tcol2\tcol3\nA\tB\tC\n')" -d $'\t' -L -f 2-

# Edge case lines
run_full_case "single column" "$(printf 'hello\nworld\n')"
run_full_case "empty fields" "$(printf 'a,,b\n,,\n')" -d , -L
run_full_case "trailing delim" "$(printf 'a,b,\nx,y,\n')" -d , -L
run_full_case "leading delim multi-char" "$(printf 'XXaXXb\n')" -L -d XX

# Multiple -F regex behavior
run_full_case "F regex group order" "$(printf 'alpha\tbeta\tgamma\tcat\tdog\nA\tB\tC\tD\tE\n')" -d $'\t' -L -r -F '^c' -F '^a'
run_full_case "F single regex multi match" "$(printf 'alpha\tbeta\tgamma\tcat\tdog\nA\tB\tC\tD\tE\n')" -d $'\t' -L -r -F 'a$'

# Mixed -f and -F
run_full_case "F+f combined" "$(printf 'name\tage\tcity\nA\t30\tNYC\n')" -d $'\t' -L -F name -f 3
run_full_case "F+e index" "$(printf 'name\tage\tcity\nA\t30\tNYC\n')" -d $'\t' -L -F name -F city -e 1

# Various data types
run_full_case "numeric data" "$(printf '1 2 3\n4 5 6\n7 8 9\n')" -f 2
run_full_case "special chars in data" "$(printf 'a*b c d\n')" -f 1
run_full_case "long line" "$(python3 -c "print(' '.join(str(i) for i in range(100)))")" -f 50
run_full_case "very long line" "$(python3 -c "print(' '.join(str(i) for i in range(1000)))")" -f 999,500

# Regex edge cases
run_full_case "regex char class" "$(printf 'a1b2c3d\n')" -d '[0-9]'
run_full_case "regex backslash" "$(printf 'a\\b\\c\n')" -d '\\\\' -L
run_full_case "regex dot literal" "$(printf 'a.b.c\n')" -L -d '.'
run_full_case "regex dot regex" "$(printf 'a.b.c\n')" -d '\.'

# Output formatting
run_full_case "output delim newline" "$(printf 'a b c\n')" -D $'\n'
run_full_case "output delim multi" "$(printf 'a b c\n')" -D '<>'

# Multi-line + ranges
run_full_case "multi line range" "$(printf 'a b c d e\n1 2 3 4 5\nx y z\n')" -f 2-4

# Special delim
run_full_case "regex with anchor" "$(printf 'abc\n')" -d '^'

# --crlf with various inputs
run_full_case "crlf inline" "$(printf 'a b c\r\nx y z\r\n')" --crlf
run_full_case "crlf with explicit cr" "$(printf 'a b c\r\nx y z\r\n')" --crlf -f 2

# -I
run_full_case "-I no -L" "a,b,c" -d , -I -L
run_full_case "-I overridden" "a,b,c" -d , -L -I -D '|'

# Empty/whitespace input
run_full_case "tab spaces" "$(printf '\t  \t  \n')"
run_full_case "blanks" "$(printf '\n\n\n')"

# File-like things
echo "hello world" > /tmp/inp.txt
run_full_case "from file" "" -- /tmp/inp.txt
run_full_case "from stdin" "hello world"

# -z compression
echo "compressed data" | gzip > /tmp/inp.gz
run_full_case "decompress gz" "" -z -- /tmp/inp.gz

# Compression output - tested via decompression
test_gzip_output() {
    local name="$1"
    local input="$2"
    shift 2
    local args=("$@")

    local ref_dec sut_dec
    ref_dec=$(printf '%s' "$input" | timeout 5 "$REF" "${args[@]}" -Z 2>/dev/null | gunzip 2>/dev/null)
    sut_dec=$(printf '%s' "$input" | timeout 5 "$SUT" "${args[@]}" -Z 2>/dev/null | gunzip 2>/dev/null)
    if [ "$ref_dec" = "$sut_dec" ]; then
        PASS=$((PASS+1))
        [ "$QUIET" = "0" ] && echo "PASS: $name"
    else
        FAIL=$((FAIL+1))
        echo "FAIL: $name (gzip output diff)"
        echo "  REF dec: $(echo "$ref_dec" | head -3)"
        echo "  SUT dec: $(echo "$sut_dec" | head -3)"
    fi
}
test_gzip_output "Z basic" "$(printf 'a b c\n')"
test_gzip_output "Z multi" "$(printf 'a b c\n1 2 3\nx y z\n')" -f 2

echo ""
echo "==============================="
echo "PASSED: $PASS, FAILED: $FAIL"
echo "==============================="
exit $((FAIL > 0 ? 1 : 0))
