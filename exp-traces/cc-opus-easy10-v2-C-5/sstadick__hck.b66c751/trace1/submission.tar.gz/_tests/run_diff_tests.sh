#!/bin/bash
# Differential testing harness
REF=/workspace/executable
SUT=/work/work/executable

PASS=0
FAIL=0
FAILED_TESTS=()
QUIET=${QUIET:-0}

run_case() {
    local name="$1"
    local stdin_data="$2"
    shift 2
    local args=("$@")

    local ref_stdout ref_stderr ref_exit
    local sut_stdout sut_stderr sut_exit

    ref_stdout=$(printf '%s' "$stdin_data" | timeout 5 "$REF" "${args[@]}" 2>/tmp/ref.err)
    ref_exit=$?
    ref_stderr=$(cat /tmp/ref.err)

    sut_stdout=$(printf '%s' "$stdin_data" | timeout 5 "$SUT" "${args[@]}" 2>/tmp/sut.err)
    sut_exit=$?
    sut_stderr=$(cat /tmp/sut.err)

    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
        [ "$QUIET" = "0" ] && echo "PASS: $name"
    else
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$name")
        echo "FAIL: $name"
        echo "  args: ${args[*]}"
        echo "  stdin: $(printf '%s' "$stdin_data" | od -c | head -2)"
        echo "  REF exit=$ref_exit, SUT exit=$sut_exit"
        if [ "$ref_stdout" != "$sut_stdout" ]; then
            echo "  REF stdout:"
            printf '%s' "$ref_stdout" | od -c | head -10 | sed 's/^/    /'
            echo "  SUT stdout:"
            printf '%s' "$sut_stdout" | od -c | head -10 | sed 's/^/    /'
        fi
    fi
}

# Add newline tests use printf '%s\n' style
run_case_nl() {
    local name="$1"
    local stdin_data="$2"
    shift 2
    local args=("$@")

    local ref_stdout ref_stderr ref_exit
    local sut_stdout sut_stderr sut_exit

    ref_stdout=$(printf '%s\n' "$stdin_data" | timeout 5 "$REF" "${args[@]}" 2>/tmp/ref.err)
    ref_exit=$?
    sut_stdout=$(printf '%s\n' "$stdin_data" | timeout 5 "$SUT" "${args[@]}" 2>/tmp/sut.err)
    sut_exit=$?

    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_exit" = "$sut_exit" ]; then
        PASS=$((PASS+1))
        [ "$QUIET" = "0" ] && echo "PASS: $name"
    else
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$name")
        echo "FAIL: $name"
        echo "  args: ${args[*]}"
        echo "  REF exit=$ref_exit, SUT exit=$sut_exit"
        if [ "$ref_stdout" != "$sut_stdout" ]; then
            echo "  REF stdout:"
            printf '%s\n' "$ref_stdout" | od -c | head -10 | sed 's/^/    /'
            echo "  SUT stdout:"
            printf '%s\n' "$sut_stdout" | od -c | head -10 | sed 's/^/    /'
        fi
    fi
}

# Basic tests (with newline)
run_case_nl "basic" "a b c d e"
run_case_nl "field 1" "a b c d e" -f 1
run_case_nl "field 3" "a b c d e" -f 3
run_case_nl "field 5" "a b c d e" -f 5
run_case_nl "range 1-3" "a b c d e" -f 1-3
run_case_nl "range 3-" "a b c d e" -f 3-
run_case_nl "range -3" "a b c d e" -f -3
run_case_nl "multi 1,3,5" "a b c d e" -f 1,3,5
run_case_nl "rev 3,1" "a b c d e" -f 3,1
run_case_nl "dup 1,1" "a b c d e" -f 1,1

# Specific complex orderings
run_case_nl "1-3,1-2" "a b c d e" -f "1-3,1-2"
run_case_nl "1-7,1,1-2" "a b c d e f g" -f "1-7,1,1-2"
run_case_nl "1-7,1-2,1" "a b c d e f g" -f "1-7,1-2,1"
run_case_nl "1-7,1-3,5-7" "a b c d e f g" -f "1-7,1-3,5-7"
run_case_nl "1-5,1-3,3-5" "a b c d e" -f "1-5,1-3,3-5"
run_case_nl "3-5,1-2" "a b c d e" -f "3-5,1-2"
run_case_nl "3-5,1-2,3" "a b c d e" -f "3-5,1-2,3"
run_case_nl "1-5,1" "a b c d e" -f "1-5,1"
run_case_nl "1-5,5" "a b c d e" -f "1-5,5"
run_case_nl "1-5,1,5" "a b c d e" -f "1-5,1,5"
run_case_nl "1-5,5,1" "a b c d e" -f "1-5,5,1"
run_case_nl "1,1,1,1" "a b c d e" -f "1,1,1,1"
run_case_nl "1-3,1,2-3" "a b c d e" -f "1-3,1,2-3"
run_case_nl "1-3,2-3,1" "a b c d e" -f "1-3,2-3,1"
run_case_nl "1-3,1,3" "a b c d e" -f "1-3,1,3"
run_case_nl "1-3,2" "a b c d e" -f "1-3,2"
run_case_nl "1-3,4" "a b c d e" -f "1-3,4"
run_case_nl "1-3,5" "a b c d e" -f "1-3,5"
run_case_nl "1-9,1-3,4-6,7-9" "a b c d e f g h i" -f "1-9,1-3,4-6,7-9"
run_case_nl "1-9,1,2,3" "a b c d e f g h i" -f "1-9,1,2,3"
run_case_nl "1-9,9,8,7" "a b c d e f g h i" -f "1-9,9,8,7"
run_case_nl "1-5,1-3,1" "a b c d e" -f "1-5,1-3,1"
run_case_nl "1-5,1,1-3" "a b c d e" -f "1-5,1,1-3"
run_case_nl "2-4,3,2,4,1,5" "a b c d e" -f "2-4,3,2,4,1,5"
run_case_nl "1-7,1,4,7" "a b c d e f g" -f "1-7,1,4,7"

# Default delim tests
run_case_nl "default delim multi-space" "a   b  c"
run_case_nl "default delim leading space" "  a b c"
run_case_nl "default delim trailing space" "a b c   "
run_case_nl "default delim tab" "$(printf 'a\tb\tc')"

# Errors
run_case_nl "field 0" "a b c" -f 0
run_case_nl "bad range" "a b c" -f 3-1
run_case_nl "non-numeric field" "a b c" -f foo
run_case_nl "empty field" "a b c" -f ""

# Delimiter variants
run_case_nl "literal colon" "a:b:c" -L -d ":"
run_case_nl "literal multi-char" "aXXbXXc" -L -d "XX"
run_case_nl "regex colon" "a:b:c" -d ":"
run_case_nl "trailing colon" "a:b:c:" -L -d ":"
run_case_nl "consecutive" "a::b" -L -d ":"
run_case_nl "regex digit" "a1b2c3d" -d "[0-9]"
run_case_nl "regex pipe alt" "a|b,c" -d "[|,]"
run_case_nl "regex unicode" "aあb" -L -d "あ"

# Output delim
run_case_nl "-D comma" "a b c" -D ","
run_case_nl "-D multi" "a b c" -D "|||"
run_case_nl "-D empty" "a b c" -D ""
run_case_nl "-I literal" "a:b:c" -L -d ":" -I

# Exclude
run_case_nl "-e 2,4" "a b c d e" -e 2,4
run_case_nl "-e 2-4" "a b c d e" -e 2-4
run_case_nl "-f -e" "a b c d e" -f "1-5" -e 3
run_case_nl "-e all" "a b c d e" -e "1-"
run_case_nl "-e overlapping" "a b c d e" -f "1-5" -e "2-3"

# CRLF
run_case_nl "--crlf simple" "a b c" --crlf
run_case "--crlf with cr no nl" "$(printf 'a b c\r')" --crlf

# Inputs
run_case "empty input" ""
run_case_nl "blank line" ""
run_case_nl "multi line" "$(printf 'a b c\nx y z')"
run_case_nl "varying col count" "$(printf 'a b c d e\nx y\nm n o p')" -f 3

# Header tests
HEADER_TSV="$(printf 'name\tage\tcity\nAlice\t30\tNYC\nBob\t25\tLA')"
run_case_nl "F simple" "$HEADER_TSV" -d $'\t' -L -F name
run_case_nl "F two" "$HEADER_TSV" -d $'\t' -L -F name -F city
run_case_nl "F regex" "$HEADER_TSV" -d $'\t' -L -r -F '^a'
run_case_nl "F regex all" "$HEADER_TSV" -d $'\t' -L -r -F '.*'
run_case_nl "F not found" "$HEADER_TSV" -d $'\t' -L -F nope
run_case_nl "F valid+invalid" "$HEADER_TSV" -d $'\t' -L -F name -F nope
run_case_nl "E header" "$HEADER_TSV" -d $'\t' -L -E age
run_case_nl "E regex" "$HEADER_TSV" -d $'\t' -L -r -E '^a'
run_case_nl "F and E" "$HEADER_TSV" -d $'\t' -L -F name -F age -E age
run_case_nl "F and -f combine" "$HEADER_TSV" -d $'\t' -L -F name -f 3

# Various ranges
run_case_nl "all combined 1-,3-" "a b c d e" -f "1-,3-"
run_case_nl "1-5 vs no -f" "a b c d e"
run_case_nl "out of range field" "a b c" -f 10
run_case_nl "out of range range" "a b c" -f 4-10
run_case_nl "no fields valid" "a b c" -f 4-5

# Empty delim
run_case_nl "empty delim literal" "abc" -L -d ""

# Version + help
run_case "version" "" --version
run_case "version short" "" -V
run_case "help short" "" -h
# Don't compare long help since it's exact text:
# run_case "help long" "" --help

# Print summary
echo ""
echo "==============================="
echo "PASSED: $PASS, FAILED: $FAIL"
echo "==============================="
exit $((FAIL > 0 ? 1 : 0))
