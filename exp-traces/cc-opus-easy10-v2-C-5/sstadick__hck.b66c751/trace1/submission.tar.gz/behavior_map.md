# hck behavior map

## Identity
Version string: `hck git:23bebe8-modified`. Rust implementation.

## CLI structure (from --help, byte sizes: --help=3600 bytes, -h=2496 bytes)

```
Usage: executable [OPTIONS] [INPUT]...

OPTIONS:
  -o, --output OUTPUT          Output file (default: stdout)
  -d, --delimiter DELIM        Default \s+
  -L, --delim-is-literal       Treat -d as literal substring
  -I, --use-input-delim        Output uses input delim (only with -L; -D overrides)
  -D, --output-delimiter SEP   Default "\t"
  -f, --fields FIELDS
  -e, --exclude FIELDS
  -E, --exclude-header PAT     Literal by default; with -r treated as regex
  -F, --header-field PAT       Literal by default; with -r treated as regex
  -r, --header-is-regex
  -z, --try-decompress         Detect by file extension
  -Z, --try-compress           Gzip output
  -t, --compression-threads N  Default 4
  -l, --compression-level N    Default 6
      --no-mmap
      --crlf
  -h, --help
  -V, --version
```

## Input handling
- Stdin if no INPUT files
- `-` means stdin
- `--` ends options
- Multiple files: concat outputs
- Stdin and file together: file wins, stdin ignored
- File with `.gz`, `.gzip`, `.bz2`, `.xz` auto-decompressed when `-z`. Without `-z`, read as raw bytes.
- Stdin with `-z` assumes gzip (decompresses).

## Defaults
- delimiter: `\s+` regex
- output delim: `\t`
- compression threads: 4
- compression level: 6

## Default delim behavior (regex \s+)
- `"a b c"` → 3 fields a,b,c
- `"a  b"` (multi space) → 2 fields a,b (any whitespace run is one delim)
- `"  a b"` (leading) → 4 fields ["", a, b]... wait test shows 4 fields with empty
  - Actually output `\ta\tb\tc\n` from input `"  a b c"`. So leading creates empty first field.
- Trailing whitespace creates trailing empty field
- `"   "` (only whitespace) → 2 empty fields → output `\t\n`
- Empty input → no output, exit 0
- Single field: output as-is

## Output formatting
- Trailing newline ALWAYS added (even for input without trailing newline)
- Blank lines preserved (input "\n" → output "\n")
- Single field: output as-is followed by newline (no delimiter)
- CRLF without `--crlf`: `\r` kept as part of last field
- CRLF with `--crlf`: `\r` stripped

## Field selection (-f)

Range syntax (1-based, inclusive):
- `N`: single field at position N
- `N-M`: range, inclusive
- `N-`: N to end of line
- `-M`: 1 through M (i.e., 1-M)
- `,` separates ranges

Errors (exit 1):
- `0`: "Fields and positions are numbered from 1: 0"
- `3-1`: "High end of range less than low end of range: 3-1"
- empty: "Failed to parse field: "
- non-numeric `foo`: "Failed to parse field: foo"
- negative `-1` alone as arg: clap error "unexpected argument '-1' found"

Out-of-range:
- Field beyond line length: silently skipped, exit 0
- Range fully beyond: empty output

### Range ordering algorithm (CRITICAL — non-obvious)

Each line is processed by computing output positions per-line using the
range list in CLI order:

For each range R[i] in CLI order:
- `start = R[i].start`, `end = R[i].end`
- `list_start = []`, `list_end = []`  (positions trimmed from start/end)
- For each later range R[j] (j > i, CLI order):
  - If `R[j].start <= R[i].start` (covers original start):
    - For each position p in `[start, min(R[j].end, R[i].end)]`:
      - If p in list_start: touch (remove and re-append to end of list_start)
      - Else if p in list_end: move to list_start (remove from end, append to start)
      - Else: append to list_start
    - Update `start = max(start, R[j].end + 1)`
  - If `R[j].end >= R[i].end` (covers original end):
    - For each position p in `[max(R[j].start, R[i].start), end]`:
      - If p in list_end: touch
      - Else if p in list_start: skip (already in start, takes precedence)
      - Else: append to list_end
    - Update `end = min(end, R[j].start - 1)`
- Output for R[i]: 
  - core = positions [start, end] (if start <= end)
  - core in ascending order
- After ALL ranges processed (so subsequent ranges can use positions in core):
  - Each R[i] appends its `list_end` then `list_start` to overall output

Wait, that doesn't quite match. Let me restate from observation:

For each range R[i] in CLI order, output:
  1. core (positions remaining after trim from both sides) in ascending order
  2. After ALL ranges are processed, append each range's pending trim positions
     in CLI order: list_end then list_start (end first), in their respective list orders.

Actually closer to: for each range R[i] in order, output its core, and tracking
"pending trim positions" to output at the END.

Examples:
- `1-7,1-2,1` → core 3-7, then list_start = [2, 1] (touched), no list_end
  → output `3,4,5,6,7,2,1`
- `1-7,1,1-2` → core 3-7, list_start = [1, 2]
  → output `3,4,5,6,7,1,2`
- `1-7,1-3,5-7` → core 4, list_start=[1,2,3], list_end=[5,6,7]
  → output `4,5,6,7,1,2,3` (end first, then start)
- `1-5,1-3,3-5` → core empty, list_start=[1,2,3], list_end=[4,5] (3 went to start)
  → output `4,5,1,2,3`
- `3-5,1-2` → R1 core 3-5 (no trim from {1-2}), then R2 outputs 1, 2
  → output `c,d,e,a,b`
- `3-5,1-2,3` → R1 core 4-5, list_start=[3], R2 outputs 1, 2
  → output `d,e,1,2,then R1.list_start = 3` → `d,e,a,b,c`

So the rule is: after all ranges output their CORES (with later ranges outputting only unused positions), append each range's trim lists.

## Exclude (-e)
- After computing field selection (from -f and/or -F), remove excluded positions.
- Applied to output positions, not selection set.
- T5: `-f 5,4,3,2,1 -e 3` → "5,4,2,1" (3 removed from output, others preserved).

## Header selection (-F, -E)

Requires first line to be parsed as headers.

`-F PAT`:
- Without `-r`: literal exact match against header strings.
- With `-r`: regex search (matches if regex matches substring).
- Multiple `-F`: each pattern produces positions; positions output in CLI order of patterns; within pattern, positions in column order; dedup across patterns.
- Errors:
  - If ALL patterns find zero matches: `No headers matched` (exit 1)
  - If some find matches but at least one literal/regex finds none: `Header not found: <pattern>` (exit 1)

`-E PAT`:
- Like `-F` but for exclude.
- Pattern not matching: silent no-op.
- No "not found" error for `-E`.

Combination with `-f`/`-e`:
- `-F` positions UNION `-f` positions = selection
- `-E` positions UNION `-e` positions = exclusion
- Selection minus exclusion = final output positions

## Delimiter modes

`-L` (literal):
- Single byte: highly optimized but has BUG — panics with exit 101 when first byte of (first?) input matches delim. Panic message: `thread 'main' panicked at /workspace/src/lib/single_byte_delim_parser.rs:84:57: attempted to index slice up to maximum usize`
- Multi-byte: works correctly, doesn't panic.
- Empty (`-d ''`): splits between every char (produces empty fields at start/end).

Regex (default):
- Standard Rust regex syntax.
- Default `\s+`.
- Leading/trailing match creates leading/trailing empty fields.
- Zero-width regex (e.g., `^`) splits at start.
- Invalid regex: anyhow error `Error: regex parse error:\n    [\n    ^\nerror: unclosed character class` (exit 1)

## Error message format (env_logger style)
`[<TIMESTAMP>Z ERROR hck] <message>` where TIMESTAMP is `YYYY-MM-DDTHH:MM:SS`.
Examples:
- `Fields and positions are numbered from 1: 0`
- `High end of range less than low end of range: 3-1`
- `Failed to parse field: foo`
- `No headers matched`
- `Header not found: NAME`
- `No such file or directory (os error 2)`
- `Is a directory (os error 21)`
- `Permission denied (os error 13)`
- `unexpected end of file` (during decompression)

## Error format (anyhow style for output / regex)
```
Error: <message>

Caused by:
    <cause>
```
Used for `-o` failures and invalid regex.

## Error format (clap)
Used for invalid CLI args. Exit 2.
`error: unexpected argument '...' found\n\n  tip: ...\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n`

## Special edge cases
- `--`: end of options
- `-`: stdin
- `-V`/`--version`: prints `hck git:23bebe8-modified\n`
- `-h`: short help (2496 bytes)
- `--help`: long help (3600 bytes)
- `""` (empty positional): clap error "a value is required for '[INPUT]...' but none was supplied"

## Compression
- `-Z` produces gzip output (BGZF format in reference, but any gzip will decompress correctly)
- `-l N` (level 0-9 valid; >9 hangs)
- `-t N` threads (0 = single-threaded)
- `-z` decompresses .gz/.gzip/.bz2/.xz based on file extension; or always for stdin.

## Process model
- One-shot. Reads all input, writes output, exits.
- Stdin: blocks until EOF.
- No interactive mode.
