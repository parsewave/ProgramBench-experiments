#!/bin/bash
set -e
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
cat > "$SRC_DIR/executable" <<EOF
#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hck_main import main
sys.exit(main())
EOF
chmod +x "$SRC_DIR/executable"
