#!/usr/bin/env python3
"""Test multi-file scenarios."""
import os
import subprocess
import tempfile
import shutil
import sys

REF = os.environ.get("REF_BIN", "/workspace/executable")
SUT = "/work/work/executable"

PASS = 0
FAIL = 0
DIFFS = []


def setup_dir(files):
    """Create temp dir with named files."""
    d = tempfile.mkdtemp()
    for name, content in files.items():
        p = os.path.join(d, name)
        os.makedirs(os.path.dirname(p) or d, exist_ok=True)
        with open(p, "wb") as f:
            f.write(content)
    return d


def case(name, file_specs, args_template, extra_setup=None, extra_check=None):
    """Run a multi-file case.

    file_specs: list of (filename, content)
    args_template: list of args (file paths added at end based on file_specs order)
    """
    global PASS, FAIL
    results = []
    for binary in [REF, SUT]:
        d = setup_dir(file_specs)
        if extra_setup:
            extra_setup(d)
        args = list(args_template)
        for name, _ in file_specs.items():
            args.append(os.path.join(d, name))
        try:
            r = subprocess.run([binary] + args, capture_output=True, timeout=10)
            post = {}
            for name in file_specs:
                p = os.path.join(d, name)
                try:
                    with open(p, "rb") as f:
                        post[name] = f.read()
                except FileNotFoundError:
                    post[name] = None
            results.append({
                "exit": r.returncode,
                "stdout": r.stdout.replace(d.encode(), b"<D>"),
                "stderr": r.stderr.replace(d.encode(), b"<D>"),
                "post": post,
            })
        finally:
            shutil.rmtree(d, ignore_errors=True)

    ref, sut = results
    # For random tempfile names in stderr, we may need to normalize
    import re
    ref_stderr_norm = re.sub(rb'\.tmp[A-Za-z0-9]+', b'.tmpXXXXXX', ref["stderr"])
    sut_stderr_norm = re.sub(rb'\.tmp[A-Za-z0-9]+', b'.tmpXXXXXX', sut["stderr"])

    ok = (
        ref["exit"] == sut["exit"]
        and ref["stdout"] == sut["stdout"]
        and ref_stderr_norm == sut_stderr_norm
        and ref["post"] == sut["post"]
    )
    if ok:
        PASS += 1
    else:
        FAIL += 1
        msg = [f"FAIL {name}: args={args_template}"]
        if ref["exit"] != sut["exit"]:
            msg.append(f"  exit: ref={ref['exit']} sut={sut['exit']}")
        if ref["stdout"] != sut["stdout"]:
            msg.append(f"  stdout ref={ref['stdout']!r} sut={sut['stdout']!r}")
        if ref_stderr_norm != sut_stderr_norm:
            msg.append(f"  stderr ref={ref_stderr_norm!r} sut={sut_stderr_norm!r}")
        if ref["post"] != sut["post"]:
            msg.append(f"  post: ref={ref['post']} sut={sut['post']}")
        DIFFS.append("\n".join(msg))


# Single file
case("single", {"a.txt": b"abc"}, ["b", "X"])
case("preview_single", {"a.txt": b"abc"}, ["-p", "b", "X"])
case("multi", {"a.txt": b"abc", "b.txt": b"def"}, ["a", "Z"])
case("preview_multi", {"a.txt": b"abc", "b.txt": b"def"}, ["-p", "a", "Z"])
case("preview_no_match_multi", {"a.txt": b"abc", "b.txt": b"def"}, ["-p", "zz", "Z"])
case("file_binary", {"a.bin": b"\xff\x00abc\xff"}, ["a", "Z"])
case("file_no_match", {"a.txt": b"abc"}, ["xyz", "Z"])
case("file_with_newline", {"a.txt": b"abc\n"}, ["b", "X"])
case("file_no_newline", {"a.txt": b"abc"}, ["b", "X"])
case("file_long", {"a.txt": b"line1\nline2\nline3\nline4\n"}, ["line", "L"])
case("file_unicode", {"a.txt": "héllo".encode()}, ["é", "E"])

# write fail scenarios
def make_ro_dir(d):
    os.chmod(d, 0o555)

# Reset perms before cleanup
def case_ro(name, file_specs, args_template):
    global PASS, FAIL
    results = []
    for binary in [REF, SUT]:
        d = setup_dir(file_specs)
        os.chmod(d, 0o555)
        args = list(args_template)
        for n, _ in file_specs.items():
            args.append(os.path.join(d, n))
        try:
            r = subprocess.run([binary] + args, capture_output=True, timeout=10)
            post = {}
            for n in file_specs:
                p = os.path.join(d, n)
                try:
                    with open(p, "rb") as f:
                        post[n] = f.read()
                except FileNotFoundError:
                    post[n] = None
            results.append({
                "exit": r.returncode,
                "stdout": r.stdout.replace(d.encode(), b"<D>"),
                "stderr": r.stderr.replace(d.encode(), b"<D>"),
                "post": post,
            })
        finally:
            os.chmod(d, 0o755)
            shutil.rmtree(d, ignore_errors=True)
    ref, sut = results
    import re
    ref_stderr_norm = re.sub(rb'\.tmp[A-Za-z0-9]+', b'.tmpXXXXXX', ref["stderr"])
    sut_stderr_norm = re.sub(rb'\.tmp[A-Za-z0-9]+', b'.tmpXXXXXX', sut["stderr"])
    ok = (
        ref["exit"] == sut["exit"]
        and ref["stdout"] == sut["stdout"]
        and ref_stderr_norm == sut_stderr_norm
        and ref["post"] == sut["post"]
    )
    if ok:
        PASS += 1
    else:
        FAIL += 1
        msg = [f"FAIL {name}: args={args_template}"]
        msg.append(f"  exit: ref={ref['exit']} sut={sut['exit']}")
        msg.append(f"  stderr ref={ref_stderr_norm!r}")
        msg.append(f"  stderr sut={sut_stderr_norm!r}")
        msg.append(f"  post ref={ref['post']}")
        msg.append(f"  post sut={sut['post']}")
        DIFFS.append("\n".join(msg))


case_ro("ro_single", {"x.txt": b"abc"}, ["b", "X"])
case_ro("ro_multi", {"a.txt": b"abc", "b.txt": b"def"}, ["a", "Z"])

print(f"PASSED: {PASS}")
print(f"FAILED: {FAIL}")
for d in DIFFS[:30]:
    print()
    print(d)
sys.exit(0 if FAIL == 0 else 1)
