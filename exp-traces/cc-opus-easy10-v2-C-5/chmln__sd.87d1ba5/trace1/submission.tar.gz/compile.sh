#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PATH="/usr/local/cargo/bin:$PATH"
export CARGO_TARGET_DIR="target"
cargo build --release --offline 2>&1
cp -f target/release/executable ./executable
