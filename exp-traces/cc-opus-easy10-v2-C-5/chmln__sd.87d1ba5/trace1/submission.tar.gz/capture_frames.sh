#!/usr/bin/env bash
# Capture a triple (exit, stdout, stderr) per probe to frames.jsonl
# Usage: ./capture_frames.sh REF_BIN > frames.jsonl
set -euo pipefail
BIN=${1:-$REF_BIN}
out=goldens/frames.jsonl
: > "$out"

run_frame() {
  local name=$1
  shift
  local stdin_file=${STDIN_FILE:-/dev/null}
  local stdout_file stderr_file
  stdout_file=$(mktemp)
  stderr_file=$(mktemp)
  set +e
  "$BIN" "$@" < "$stdin_file" > "$stdout_file" 2> "$stderr_file"
  local code=$?
  set -e
  python3 - "$name" "$code" "$stdout_file" "$stderr_file" "$STDIN_INFO" "$@" <<'PY' >> "$out"
import sys, json, base64, pathlib
name, code, stdout_p, stderr_p, stdin_info, *args = sys.argv[1:]
stdout = pathlib.Path(stdout_p).read_bytes()
stderr = pathlib.Path(stderr_p).read_bytes()
frame = {
    "name": name,
    "args": args,
    "stdin": stdin_info,
    "exit": int(code),
    "stdout_b64": base64.b64encode(stdout).decode(),
    "stderr_b64": base64.b64encode(stderr).decode(),
}
print(json.dumps(frame))
PY
  rm -f "$stdout_file" "$stderr_file"
}

with_stdin() {
  local data=$1
  local info=$2
  local tmp=$(mktemp)
  printf '%s' "$data" > "$tmp"
  STDIN_FILE=$tmp STDIN_INFO=$info
}

# Surface frames
STDIN_FILE=/dev/null STDIN_INFO="none"
run_frame "help_long" --help
run_frame "help_short" -h
run_frame "version_long" --version
run_frame "version_short" -V
run_frame "bare"
run_frame "dashdash"  --
run_frame "single_dash" -
run_frame "unknown_long" --bogus
run_frame "unknown_short" -x
run_frame "only_find" find
run_frame "no_args_p" -p
run_frame "two_p" -p -p

# Basic regex on stdin
with_stdin "hello world" "hello world"
run_frame "basic_replace" world earth
run_frame "basic_no_match" xyz Y

with_stdin "" "empty"
run_frame "empty_stdin" x y

with_stdin "hello" "hello"
run_frame "preview_stdin" -p l L

# Multi-line / flags
with_stdin "$(printf 'abc\ndef')" "abc\\ndef"
run_frame "multiline_default" '^d' X
run_frame "multiline_e" -f e '^d' X
run_frame "multiline_m" -f m '^d' X
run_frame "multiline_em" -f em '^d' X
run_frame "multiline_me" -f me '^d' X
run_frame "multiline_mem" -f mem '^d' X

with_stdin "Hello WORLD" "Hello WORLD"
run_frame "flags_i" -f i hello X
run_frame "flags_c" -f c hello X
run_frame "flags_ci" -f ci hello X
run_frame "flags_ic" -f ic hello X
run_frame "flags_cic" -f cic hello X
run_frame "flags_ici" -f ici hello X
run_frame "flags_empty" -f "" hello X
run_frame "flags_unknown" -f q hello X
run_frame "flags_iw" -f iw hello X

with_stdin "abc abcd cabc" "abc abcd cabc"
run_frame "flags_w" -f w abc X

with_stdin "$(printf 'a\nb')" "a\\nb"
run_frame "flags_s" -f s 'a.b' X
run_frame "flags_se" -f se 'a.b' X

# Replacement escapes
with_stdin "abc" "abc"
run_frame "rep_newline" b '\n'
run_frame "rep_tab" b '\t'
run_frame "rep_cr" b '\r'
run_frame "rep_backslash" b '\\'
run_frame "rep_dbl_backslash_n" b '\\n'
run_frame "rep_dollar_dollar" b '$$'
run_frame "rep_hex41" b '\x41'
run_frame "rep_hex_7f" b '\x7f'
run_frame "rep_hex_80" b '\x80'
run_frame "rep_hex_ff" b '\xff'
run_frame "rep_hex_invalid" b '\xZZ'
run_frame "rep_hex_short" b '\xA'
run_frame "rep_trail_back" b 'X\'
run_frame "rep_v" b '\v'
run_frame "rep_a" b '\a'

with_stdin "abc" "abc"
run_frame "rep_capture_group" '(b)' '\$1'

# Capture groups
with_stdin "123.45" "123.45"
run_frame "rep_named" '(?P<dollars>\d+)\.(?P<cents>\d+)' '$dollars dollars and $cents cents'
run_frame "rep_named_brace" '(?P<dollars>\d+)\.(?P<cents>\d+)' '${dollars}_dollars and ${cents}_cents'
run_frame "rep_named_ambig" '(?P<dollars>\d+)\.(?P<cents>\d+)' '$dollars_dollars and $cents_cents'

with_stdin "abc" "abc"
run_frame "rep_missing_group" '(a)' '$2'
run_frame "rep_missing_named" '(a)' '${nothere}'

# Max replacements
with_stdin "aaaa" "aaaa"
run_frame "n_0" -n 0 a X
run_frame "n_1" -n 1 a X
run_frame "n_2" -n 2 a X
run_frame "n_huge" -n 99999999 a X
run_frame "n_too_big" -n 99999999999999999999 a X
run_frame "n_negative" -n -1 a X
run_frame "n_non_numeric" -n abc a X
run_frame "n_float" -n 1.5 a X

# -F mode
with_stdin "a.b" "a.b"
run_frame "F_literal" -F "a.b" X
run_frame "F_no_match" -F "a.b" X

with_stdin 'a$b' 'a$b'
run_frame "F_dollar_find" -F '$' '_'

with_stdin "abc" "abc"
run_frame "F_dollar_rep" -F b '$1'
run_frame "F_backslash_rep" -F b '\n'

# Empty patterns
with_stdin "abc" "abc"
run_frame "empty_find" "" X
run_frame "empty_find_F" -F "" X
run_frame "empty_replace" b ""

# Invalid regex
with_stdin "abc" "abc"
run_frame "regex_invalid_class" "[" X
run_frame "regex_invalid_group" "(abc" X
run_frame "regex_invalid_named" "(?P<>foo)" X

# Lookaround
run_frame "regex_lookahead" '(?=b)' X
run_frame "regex_lookbehind" '(?<=a)' X
run_frame "regex_Z" '\Z' X
run_frame "regex_z" '\z' X

# Zero-width
with_stdin "abc" "abc"
run_frame "zero_a_star" 'a*' X

with_stdin "" "empty"
run_frame "zero_a_star_empty" 'a*' X
run_frame "zero_dot_star_empty" '.*' X

# Greedy/lazy
with_stdin "aabbcc" "aabbcc"
run_frame "greedy" '.+' X
run_frame "lazy" '.+?' X

# Edge: arguments
with_stdin "hello -w" "hello -w"
run_frame "dashdash_arg" -- "-w" X

# Inline flag
with_stdin "Hello WORLD" "Hello WORLD"
run_frame "inline_flag" '(?i)hello' Y

