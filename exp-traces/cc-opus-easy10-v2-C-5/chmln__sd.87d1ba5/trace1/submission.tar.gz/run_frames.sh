#!/usr/bin/env bash
# Runs frames.jsonl against both REF and our binary, reports diffs
set -uo pipefail
REF=${REF:-$REF_BIN}
SUT=${SUT:-/work/work/executable}
python3 - "$REF" "$SUT" <<'PY'
import sys, json, base64, subprocess, pathlib, tempfile

ref, sut = sys.argv[1], sys.argv[2]
frames_path = pathlib.Path("/work/work/goldens/frames.jsonl")

passed = 0
failed = 0
diffs = []
for line in frames_path.read_text().splitlines():
    if not line.strip():
        continue
    frame = json.loads(line)
    name = frame["name"]
    args = frame["args"]
    stdin_info = frame["stdin"]
    expected_exit = frame["exit"]
    expected_stdout = base64.b64decode(frame["stdout_b64"])
    expected_stderr = base64.b64decode(frame["stderr_b64"])

    # Determine stdin contents
    if stdin_info == "none":
        stdin_bytes = b""
    elif stdin_info.startswith("a\\n"):
        stdin_bytes = stdin_info.replace("\\n", "\n").encode()
    elif "\\n" in stdin_info:
        stdin_bytes = stdin_info.replace("\\n", "\n").encode()
    elif stdin_info == "empty":
        stdin_bytes = b""
    else:
        stdin_bytes = stdin_info.encode()

    try:
        result = subprocess.run([sut, *args], input=stdin_bytes, capture_output=True, timeout=10)
        actual_exit = result.returncode
        actual_stdout = result.stdout
        actual_stderr = result.stderr
    except subprocess.TimeoutExpired:
        diffs.append(f"{name}: TIMEOUT")
        failed += 1
        continue

    ok_exit = actual_exit == expected_exit
    ok_stdout = actual_stdout == expected_stdout
    ok_stderr = actual_stderr == expected_stderr

    if ok_exit and ok_stdout and ok_stderr:
        passed += 1
    else:
        failed += 1
        msg = [f"FAIL {name}: args={args}, stdin={stdin_info!r}"]
        if not ok_exit:
            msg.append(f"  exit: expected={expected_exit}, actual={actual_exit}")
        if not ok_stdout:
            msg.append(f"  stdout differ:")
            msg.append(f"    expected: {expected_stdout!r}")
            msg.append(f"    actual:   {actual_stdout!r}")
        if not ok_stderr:
            msg.append(f"  stderr differ:")
            msg.append(f"    expected: {expected_stderr!r}")
            msg.append(f"    actual:   {actual_stderr!r}")
        diffs.append("\n".join(msg))

print(f"PASSED: {passed}")
print(f"FAILED: {failed}")
if diffs:
    print("---")
    for d in diffs[:50]:
        print(d)
        print()
PY
