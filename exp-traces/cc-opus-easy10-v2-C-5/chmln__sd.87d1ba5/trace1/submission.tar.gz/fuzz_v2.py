#!/usr/bin/env python3
"""More aggressive fuzz testing focusing on edge cases."""
import os
import subprocess
import random
import sys

REF = os.environ.get("REF_BIN", "/workspace/executable")
SUT = "/work/work/executable"

random.seed(123)

PASS = 0
FAIL = 0
DIFFS = []


def run_one(binary, args, stdin_bytes=b""):
    try:
        result = subprocess.run(
            [binary] + args,
            input=stdin_bytes,
            capture_output=True,
            timeout=10,
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"


def case(name, args, stdin=b""):
    global PASS, FAIL
    ref_exit, ref_stdout, ref_stderr = run_one(REF, args, stdin)
    sut_exit, sut_stdout, sut_stderr = run_one(SUT, args, stdin)
    if ref_exit == sut_exit and ref_stdout == sut_stdout and ref_stderr == sut_stderr:
        PASS += 1
    else:
        FAIL += 1
        msg = [f"FAIL {name}: args={args}, stdin={stdin!r}"]
        if ref_exit != sut_exit:
            msg.append(f"  exit: ref={ref_exit} sut={sut_exit}")
        if ref_stdout != sut_stdout:
            msg.append(f"  stdout ref={ref_stdout!r} sut={sut_stdout!r}")
        if ref_stderr != sut_stderr:
            msg.append(f"  stderr ref={ref_stderr!r} sut={sut_stderr!r}")
        DIFFS.append("\n".join(msg))


# Patterns more aggressive
PATTERNS = [
    "", "a", ".", "[", "]", "(", ")", "+", "*", "?", "{", "}",
    ".*?", ".+?", "[abc]", "[^abc]", "[a-zA-Z0-9_]+",
    "\\w", "\\W", "\\s", "\\S", "\\d", "\\D", "\\b", "\\B",
    "(?P<x>a)", "(?P<x>a)(?P<y>b)", "(?:a)", "a|b|c",
    "(a)(b)(c)(d)(e)(f)(g)(h)(i)(j)(k)",
    "^", "$", "^a$", "(?:^)", "(?:$)",
    "\\\\", "\\.", "\\(", "\\)", "\\[", "\\]",
    "[\\]a-z]", "\\xff", "\\u{0041}",
    ".{1,5}", ".{0,}", ".{,3}",
    "(?i)abc", "(?-i)abc", "(?s)abc", "(?m)abc",
    "a(?:b|c)*d", "(?P<a>x)(?P<b>y)\\b",
    "\\w*\\s*\\d+",
    # Some patterns the reference might handle differently
    "[\\d-]+", "\\b\\d{3}\\b",
]

REPLACEMENTS = [
    "", "X", " ", "\\n", "\\t", "\\r", "\\\\", "$$",
    "$0", "$1", "$2", "$10", "${1}", "${name}",
    "\\x41", "\\xff", "\\xZZ", "\\x",
    "$1$2$3", "${1}_${2}",
    "[$0]", "<$1>", "\\$1", "\\$",
    "a\\nb\\tc", "$0$0",
    "abc", "$$$0$$",
]

FLAGS = ["", "i", "c", "ci", "ic", "iw", "wi", "s", "e", "m",
         "is", "isw", "iws", "ewsm", "wesi", "wsei", "ws",
         "cc", "ii", "ee", "ww", "qqq", "abc"]

INPUTS = [
    b"", b"a", b"abc", b"ABC", b"hello world",
    b"a\nb", b"a\n\n\nb",
    b"\x00\x01\x02", b"\xff\xfe abc",
    b"line1\nline2\nline3\n", b"  spaces  ",
    b"123 abc 456", b"a" * 50,
    "héllo wörld".encode(), b"\t\ttabs",
]

N = 300
for i in range(N):
    pattern = random.choice(PATTERNS)
    replacement = random.choice(REPLACEMENTS)
    inp = random.choice(INPUTS)
    args = []
    if random.random() < 0.4:
        flag = random.choice(FLAGS)
        args.extend(["-f", flag])
    if random.random() < 0.3:
        n = random.choice([0, 1, 2, 5, 100])
        args.extend(["-n", str(n)])
    if random.random() < 0.15:
        args.append("-F")
    if random.random() < 0.1:
        args.append("-p")
    args.extend([pattern, replacement])
    case(f"fuzz_{i}", args, inp)

print(f"PASSED: {PASS}")
print(f"FAILED: {FAIL}")
for d in DIFFS[:30]:
    print()
    print(d)
sys.exit(0 if FAIL == 0 else 1)
