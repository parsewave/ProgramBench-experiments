#!/usr/bin/env python3
"""Even more aggressive fuzz testing including file operations."""
import os
import subprocess
import random
import sys
import tempfile
import shutil
import re

REF = os.environ.get("REF_BIN", "/workspace/executable")
SUT = "/work/work/executable"

random.seed(999)

PASS = 0
FAIL = 0
DIFFS = []


def normalize_tempnames(b):
    return re.sub(rb'\.tmp[A-Za-z0-9]+', b'.tmpXXXXXX', b)


def case_file(name, file_content, args_template):
    """Run a file-based case."""
    global PASS, FAIL
    results = []
    for binary in [REF, SUT]:
        d = tempfile.mkdtemp()
        p = os.path.join(d, "x.txt")
        with open(p, "wb") as f:
            f.write(file_content)
        args = list(args_template) + [p]
        try:
            r = subprocess.run([binary] + args, capture_output=True, timeout=10)
            try:
                with open(p, "rb") as f:
                    post = f.read()
            except FileNotFoundError:
                post = None
            results.append({
                "exit": r.returncode,
                "stdout": r.stdout.replace(d.encode(), b"<D>"),
                "stderr": normalize_tempnames(r.stderr.replace(d.encode(), b"<D>")),
                "post": post,
            })
        finally:
            shutil.rmtree(d, ignore_errors=True)
    ref, sut = results
    ok = (
        ref["exit"] == sut["exit"]
        and ref["stdout"] == sut["stdout"]
        and ref["stderr"] == sut["stderr"]
        and ref["post"] == sut["post"]
    )
    if ok:
        PASS += 1
    else:
        FAIL += 1
        msg = [f"FAIL {name}: args={args_template}, content={file_content!r}"]
        if ref["exit"] != sut["exit"]:
            msg.append(f"  exit: ref={ref['exit']} sut={sut['exit']}")
        if ref["stdout"] != sut["stdout"]:
            msg.append(f"  stdout ref={ref['stdout']!r} sut={sut['stdout']!r}")
        if ref["stderr"] != sut["stderr"]:
            msg.append(f"  stderr ref={ref['stderr']!r} sut={sut['stderr']!r}")
        if ref["post"] != sut["post"]:
            msg.append(f"  post ref={ref['post']!r} sut={sut['post']!r}")
        DIFFS.append("\n".join(msg))


PATTERNS = [
    "a", "b", "abc", "\\w+", "\\d+", "[a-z]+",
    "(a)(b)", "(?P<x>\\w+)", "(?:abc)?", "(abc)+",
    "[^abc]+", "[a-zA-Z]{2,5}",
    "^", "$", "^abc", "abc$", "\\b\\w+\\b",
    "(?i)abc", "(?-i)ABC",
]

REPLACEMENTS = [
    "", "X", "<$0>", "$1$0", "${1}_${2}",
    "\\n", "\\t", "X\\nY", "\\xff",
    "captured: $0", "[${name}]",
]

FLAGS = ["", "i", "ci", "ic", "iw", "wi", "w", "ws", "wsm", "isw", "wsi"]
INPUTS = [
    b"", b"a", b"abc", b"hello world\nfoo bar\nbaz qux\n",
    b"123 abc 456 def\n", b"A1b2C3", b"\nfirst\nsecond\nthird\n",
]

N = 200
for i in range(N):
    pattern = random.choice(PATTERNS)
    replacement = random.choice(REPLACEMENTS)
    content = random.choice(INPUTS)
    args = []
    if random.random() < 0.4:
        args.extend(["-f", random.choice(FLAGS)])
    if random.random() < 0.3:
        args.extend(["-n", str(random.choice([0, 1, 2, 5]))])
    if random.random() < 0.15:
        args.append("-F")
    if random.random() < 0.2:
        args.append("-p")
    args.extend([pattern, replacement])
    case_file(f"file_fuzz_{i}", content, args)

print(f"PASSED: {PASS}")
print(f"FAILED: {FAIL}")
for d in DIFFS[:30]:
    print()
    print(d)
sys.exit(0 if FAIL == 0 else 1)
