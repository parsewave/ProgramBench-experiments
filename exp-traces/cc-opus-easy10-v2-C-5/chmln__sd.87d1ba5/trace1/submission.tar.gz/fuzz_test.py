#!/usr/bin/env python3
"""Fuzz test sd reimplementation against reference."""

import os
import subprocess
import random
import string
import sys
import tempfile

REF = os.environ.get("REF_BIN", "/workspace/executable")
SUT = "/work/work/executable"

random.seed(42)

PASS = 0
FAIL = 0
DIFFS = []

# Patterns that should work
PATTERNS = [
    "a", "abc", ".", ".+", ".*", ".+?", "[a-z]+", "[0-9]+",
    "\\w+", "\\s+", "\\d+", "\\b", "\\bword\\b",
    "(a)", "(a)(b)", "(?P<x>a)", "(?:abc)",
    "a|b", "a|b|c", "^a", "a$", "^a$",
    "a*", "a?", "a+", "a{2}", "a{2,3}",
    "[abc]", "[^abc]", "(abc)+", "[a-zA-Z]+",
]

REPLACEMENTS = [
    "", "X", "$0", "$1", "${x}", "$1$2",
    "\\n", "\\t", "\\r", "\\\\", "$$",
    "\\x41", "\\x7f", "\\x80", "\\xff",
    "before $1 after", "<$0>", "${1}_${2}",
]

FLAGS = ["", "i", "c", "ci", "ic", "iw", "wi", "s", "e", "m", "is", "isw"]

INPUTS = [
    b"hello world", b"abc abc abc", b"a\nb\nc", b"AAA bbb CCC",
    b"123 abc 456 def", b"", b"x", b"\xff\xfeabc",
    b"a" * 100, b"line1\nline2\nline3\n",
    b"   spaces   ", b"\t\ttabs\t\t",
]


def run_one(binary, args, stdin_bytes=b""):
    try:
        result = subprocess.run(
            [binary] + args,
            input=stdin_bytes,
            capture_output=True,
            timeout=10,
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"


def case(name, args, stdin=b""):
    global PASS, FAIL
    ref_exit, ref_stdout, ref_stderr = run_one(REF, args, stdin)
    sut_exit, sut_stdout, sut_stderr = run_one(SUT, args, stdin)
    if ref_exit == sut_exit and ref_stdout == sut_stdout and ref_stderr == sut_stderr:
        PASS += 1
    else:
        FAIL += 1
        msg = [f"FAIL {name}: args={args}, stdin={stdin!r}"]
        if ref_exit != sut_exit:
            msg.append(f"  exit: ref={ref_exit} sut={sut_exit}")
        if ref_stdout != sut_stdout:
            msg.append(f"  stdout ref={ref_stdout!r} sut={sut_stdout!r}")
        if ref_stderr != sut_stderr:
            msg.append(f"  stderr ref={ref_stderr!r} sut={sut_stderr!r}")
        DIFFS.append("\n".join(msg))


# Run random combinations
N = 200
for i in range(N):
    pattern = random.choice(PATTERNS)
    replacement = random.choice(REPLACEMENTS)
    flag = random.choice(FLAGS)
    inp = random.choice(INPUTS)
    args = []
    if random.random() < 0.3:
        args.extend(["-f", flag] if flag else [])
    if random.random() < 0.2:
        n = random.choice([0, 1, 2, 5])
        args.extend(["-n", str(n)])
    if random.random() < 0.1:
        args.append("-F")
        pattern = pattern.replace("\\", "")  # F mode doesn't accept regex escapes
    if random.random() < 0.1:
        args.append("-p")
    args.extend([pattern, replacement])
    case(f"fuzz_{i}", args, inp)

print(f"PASSED: {PASS}")
print(f"FAILED: {FAIL}")
for d in DIFFS[:30]:
    print()
    print(d)
sys.exit(0 if FAIL == 0 else 1)
