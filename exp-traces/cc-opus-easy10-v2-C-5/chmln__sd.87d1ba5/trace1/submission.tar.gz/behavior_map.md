# behavior map for `sd` reference binary

## tool identity
- Name: `sd` (search & displace), version 1.0.0
- CLI framework: clap v4 (based on error/help text format)
- Regex engine: Rust `regex` crate (based on supported features and error format)
- Probably mmap-based file reading (memmap2)

## CLI surface

```
Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Options:
  -p, --preview                   print to stdout instead of writing files
  -F, --fixed-strings             literal find/replace, no regex / no escape processing
  -n, --max-replacements <LIMIT>  usize, default 0 = unlimited
  -f, --flags <FLAGS>             flag char string
  -h, --help                      print short help
      --help                      print long help (same as long form)
  -V, --version                   "sd 1.0.0\n"
```

- Binary name in help/usage text: `executable` (since argv[0] determines this in clap)
- About line: `An intuitive find & replace CLI`
- Long title (--help): `sd v1.0.0\nAn intuitive find & replace CLI\n\n...`
- Short help (-h): condensed
- Duplicate `-p`, `-n`, or `-f` errors with "the argument 'X' cannot be used multiple times"
- Unknown flag: `error: unexpected argument 'X' found\n\n  tip: ...`
- Argument forms: `--name=value`, `-n=value`, `-nvalue`, `-pn 1`
- `--` works as positional separator
- `-` is NOT special — treated as filename

## flag chars (-f arg)

Default state: `multi_line=true`, `case_sensitive=true`, `dot_matches_newline=false`, `whole_word=false`.

Char | Effect
-----|-------
i    | case_insensitive = true (overrides previous c, last wins)
c    | case_insensitive = false (overrides previous i, last wins)
e    | multi_line = false (sticky — ANY 'e' disables multi_line, m can't re-enable)
m    | NO-OP (default is multi_line=true already; m doesn't actively set anything)
s    | dot_matches_newline = true (additive, no inverse)
w    | wrap pattern as `\b(?:PAT)\b` for whole-word matching (additive)

Unknown chars in `-f` are silently ignored. Empty `-f ""` = defaults.

Implementation note: For `c`/`i`, each char invokes `RegexBuilder::case_insensitive(bool)` 
which overrides prior calls. For `m`/`e`, only `e` invokes `.multi_line(false)`; `m` 
is a no-op. The actual `sd` flag parser likely never calls `.multi_line(true)` based 
on flag chars — it sets the default via builder's default setting (which is false in 
the regex crate by default, but sd's default is true, so multi_line(true) is set once 
upfront).

## replacement-string escapes (regex mode only)

In regex mode (`-F` absent), the replacement string is preprocessed:

Sequence | Replacement
---------|------------
`\n`     | newline (0x0A)
`\r`     | carriage return (0x0D)
`\t`     | tab (0x09)
`\\`     | literal backslash
`\xHH`   | Unicode codepoint U+00HH, encoded as UTF-8 (must be exactly 2 hex digits)
`$N`     | capture group N
`$name`  | named capture (greedy until first non-word char; `$name_x` looks for `name_x`)
`${name}`| named capture with explicit delimiter
`$$`     | literal `$`

Other `\X` sequences (e.g. `\v`, `\f`, `\b`, `\a`, `\0`, `\077`, `\xZ`, `\xA`) 
are passed through as literal backslash + char(s).

Capture refs to missing groups expand to empty string.

`-F` mode: BOTH find and replace are literal — no regex interpretation, no escape 
processing on either side.

## I/O behavior

- No files → read all of stdin, write all to stdout
- ≥1 files → in-place modification of each (read full content, replace, write back)
- File processing strategy: appears to use mmap (memmap2) for read, tempfile + rename for atomic write
  - Preserves file mode/permissions
  - Read-only file mode 444 still successfully modified (rename in writeable dir)
  - Symlinks: writes to target, symlink preserved
- Trailing newline: preserved (or absence preserved)

### Path validation (file mode)

Order:
1. For each FILES arg: check `path.is_file()` or similar → if false, error "invalid path: PATH" exit 1 and stop. Validation is short-circuit on first failure.
2. For each file: process (may fail at this stage with OS errors)

Cases:
- Missing path: `error: invalid path: PATH\n` exit 1
- Path is a directory: passes validation, mmap fails: `error: No such device (os error 19)\n` exit 1
- Path is FIFO: passes validation, mmap fails: `error: No such device (os error 19)\n` exit 1
- /dev/null: `error: No such device (os error 19)\n` exit 1
- Broken symlink: `error: invalid path: PATH\n` exit 1
- Symlink to dir: passes validation, mmap fails: `error: No such device (os error 19)\n` exit 1
- Permission denied (read): `error: Permission denied (os error 13)\n` exit 1
- Multi file with one having permission denied during write: 
  `error: Failed processing some inputs\n    PATH: Permission denied (os error 13) at path "/tmp/.tmpXXXXX"\n` exit 1
  (this format is when the file passes validation but write fails partway through batch — uses thiserror's display)

The "invalid path" check likely uses `Path::is_file()`. For dirs and special files, is_file() returns false in some cases but apparently is_file() is NOT being called — perhaps it's checking exists() instead, since directories pass through to the next stage.

Actually re-examining: `Path::is_file()` returns false for directories. But directories DON'T error with "invalid path" — they error with "No such device". So the check is NOT `is_file()`. It must be `exists()` or similar.

Confirmed: 
- Missing → exists()=false → "invalid path"  
- Directory → exists()=true → goes through, mmap fails

## preview mode (-p)

- Reads from stdin if no files
- Otherwise reads files (file content is NOT modified)
- Output to stdout:
  - 0 or 1 file: just the modified content
  - ≥2 files: each preceded by `----- FILE PATH -----\n` header
- Errors propagate (e.g., missing path → "invalid path")

## regex engine details (rust `regex` crate behavior)

- Default `multi_line` setting in `sd` is **on** (overriding regex crate default of false)
- `^` and `$` match line starts/ends by default
- Lookaround (?=, ?!, ?<=, ?<!) → ERROR
- `\Z` → ERROR (not supported)
- `\z` → end of input (works)
- Named groups: `(?P<name>...)` works; `(?<name>...)` does NOT
- Atomic groups → ERROR
- Inline flags work: `(?i)`, `(?s)`, etc.
- UTF-8 invalid in stdin: passes through unchanged where bytes aren't matched

## error format

Regex parse error format (multi-line):
```
error: invalid regex regex parse error:
    <pattern>
    <caret-pointer>
error: <reason>
```

This is from `regex::Error::Display` wrapped by `sd`'s error type. The "error: invalid regex" prefix is added by `sd`, then `regex`'s own Display is used.

OS/IO errors:
```
error: <std::io::Error display> (os error N)
```

Path-not-found check (sd-specific):
```
error: invalid path: <path>
```

Multi-file partial failure:
```
error: Failed processing some inputs
    <path>: <inner error>
```

## exit codes

- 0: success
- 1: runtime error (regex parse, file processing, invalid path)
- 2: clap arg parse error

## non-features

- No `-i` for in-place toggle (in-place is the default for files)
- No streaming — full read-then-write
- No backup files
- No -r/-R recursive — only files passed
- No --color flag
- No `-`-as-stdin handling
