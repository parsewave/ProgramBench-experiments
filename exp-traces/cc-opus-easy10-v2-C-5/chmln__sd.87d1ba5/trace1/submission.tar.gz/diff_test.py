#!/usr/bin/env python3
"""Comprehensive differential testing of sd reimplementation against reference."""

import os
import subprocess
import tempfile
import sys
import shutil
import pathlib
import random
import string

REF = os.environ.get("REF_BIN", "/workspace/executable")
SUT = "/work/work/executable"

PASS = 0
FAIL = 0
DIFFS = []


def run_one(binary, args, stdin_bytes=b"", file_contents=None):
    """Run binary with args, optionally with stdin or file inputs.

    file_contents: dict path -> bytes. Files are created and passed as args appended.
    Returns: (exit_code, stdout_bytes, stderr_bytes, dict of post-state file contents)
    """
    tmpdir = tempfile.mkdtemp()
    full_args = list(args)
    paths = []
    post = {}
    try:
        if file_contents is not None:
            for name, content in file_contents.items():
                p = os.path.join(tmpdir, name)
                os.makedirs(os.path.dirname(p), exist_ok=True) if os.path.dirname(name) else None
                with open(p, "wb") as f:
                    f.write(content)
                paths.append(p)
                full_args.append(p)
        result = subprocess.run(
            [binary] + full_args,
            input=stdin_bytes,
            capture_output=True,
            timeout=20,
        )
        for name, p in zip(file_contents.keys() if file_contents else [], paths):
            try:
                with open(p, "rb") as f:
                    post[name] = f.read()
            except FileNotFoundError:
                post[name] = None
        # Substitute the temp dir back to make outputs comparable
        stdout = result.stdout.replace(tmpdir.encode(), b"<TMP>")
        stderr = result.stderr.replace(tmpdir.encode(), b"<TMP>")
        return result.returncode, stdout, stderr, post
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def case(name, args, stdin=b"", files=None):
    """Run one test case against both reference and SUT, compare results."""
    global PASS, FAIL
    ref_exit, ref_stdout, ref_stderr, ref_post = run_one(REF, args, stdin, files)
    sut_exit, sut_stdout, sut_stderr, sut_post = run_one(SUT, args, stdin, files)

    ok = (
        ref_exit == sut_exit
        and ref_stdout == sut_stdout
        and ref_stderr == sut_stderr
        and ref_post == sut_post
    )
    if ok:
        PASS += 1
    else:
        FAIL += 1
        msg = [f"FAIL {name}"]
        msg.append(f"  args: {args}")
        msg.append(f"  stdin: {stdin!r}")
        if files:
            for f, c in files.items():
                msg.append(f"  file {f}: {c!r}")
        if ref_exit != sut_exit:
            msg.append(f"  exit: ref={ref_exit} sut={sut_exit}")
        if ref_stdout != sut_stdout:
            msg.append(f"  stdout:")
            msg.append(f"    ref: {ref_stdout!r}")
            msg.append(f"    sut: {sut_stdout!r}")
        if ref_stderr != sut_stderr:
            msg.append(f"  stderr:")
            msg.append(f"    ref: {ref_stderr!r}")
            msg.append(f"    sut: {sut_stderr!r}")
        if ref_post != sut_post:
            msg.append(f"  post-state:")
            msg.append(f"    ref: {ref_post}")
            msg.append(f"    sut: {sut_post}")
        DIFFS.append("\n".join(msg))


# --- Basic stdin tests ---
case("basic_replace", ["b", "X"], b"abc")
case("regex_capture", ["(\\w+)", "[$1]"], b"hello world")
case("named_capture", ["(?P<x>a)", "${x}Z"], b"abc")
case("empty_input", ["a", "X"], b"")
case("no_match", ["xyz", "Y"], b"abc")

# --- Flags ---
case("flag_i", ["-f", "i", "hello", "X"], b"Hello WORLD")
case("flag_c", ["-f", "c", "hello", "X"], b"Hello")
case("flag_ci", ["-f", "ci", "hello", "X"], b"Hello")
case("flag_ic", ["-f", "ic", "hello", "X"], b"Hello")
case("flag_w", ["-f", "w", "abc", "X"], b"abc abcd cabc")
case("flag_iw", ["-f", "iw", "abc", "X"], b"ABC abcd")
case("flag_wi", ["-f", "wi", "abc", "X"], b"ABC abcd")
case("flag_iwc", ["-f", "iwc", "abc", "X"], b"ABC abcd")
case("flag_wic", ["-f", "wic", "hello", "X"], b"Hello")
case("flag_s", ["-f", "s", "a.b", "X"], b"a\nb")
case("flag_e", ["-f", "e", "^d", "X"], b"abc\ndef")
case("flag_m", ["-f", "m", "^d", "X"], b"abc\ndef")
case("flag_em", ["-f", "em", "^d", "X"], b"abc\ndef")
case("flag_me", ["-f", "me", "^d", "X"], b"abc\ndef")
case("flag_empty", ["-f", "", "a", "X"], b"abc")
case("flag_unknown_char", ["-f", "qzy", "a", "X"], b"abc")
case("flag_ws", ["-f", "ws", "a.b", "X"], b"a\nb")
case("flag_sw", ["-f", "sw", "a.b", "X"], b"a\nb")

# --- Max replacements ---
case("n_0", ["-n", "0", "a", "X"], b"aaaa")
case("n_1", ["-n", "1", "a", "X"], b"aaaa")
case("n_2", ["-n", "2", "a", "X"], b"aaaa")
case("n_10", ["-n", "10", "a", "X"], b"aa")
case("n_huge", ["-n", "99999999", "a", "X"], b"aaaa")
case("n_overflow", ["-n", "99999999999999999999", "a", "X"], b"aaaa")
case("n_neg", ["-n", "-1", "a", "X"], b"aaaa")
case("n_text", ["-n", "abc", "a", "X"], b"aaaa")
case("n_eq", ["-n=2", "a", "X"], b"aaaa")

# --- Fixed strings ---
case("F_dot", ["-F", "a.b", "X"], b"a.b axb")
case("F_dollar", ["-F", "$", "_"], b"a$b")
case("F_paren", ["-F", "(a)", "X"], b"(a)b")
case("F_capture_lit", ["-F", "a", "$1"], b"abc")
case("F_newline", ["-F", "\\n", "X"], b"a\nb")

# --- Replacement escapes ---
case("rep_nl", ["b", "\\n"], b"abc")
case("rep_tab", ["b", "\\t"], b"abc")
case("rep_cr", ["b", "\\r"], b"abc")
case("rep_bsl", ["b", "\\\\"], b"abc")
case("rep_bsl_n", ["b", "\\\\n"], b"abc")
case("rep_dollar", ["b", "$$"], b"abc")
case("rep_hex_41", ["b", "\\x41"], b"abc")
case("rep_hex_80", ["b", "\\x80"], b"abc")
case("rep_hex_ff", ["b", "\\xff"], b"abc")
case("rep_hex_bad", ["b", "\\xZZ"], b"abc")
case("rep_hex_short", ["b", "\\xA"], b"abc")
case("rep_trailing_bsl", ["b", "X\\"], b"abc")
case("rep_v", ["b", "\\v"], b"abc")

# --- Named captures ---
case("named_ambig", ["(?P<dollars>\\d+)\\.(?P<cents>\\d+)", "$dollars_dollars and $cents_cents"], b"123.45")
case("named_brace", ["(?P<dollars>\\d+)\\.(?P<cents>\\d+)", "${dollars}_dollars and ${cents}_cents"], b"123.45")
case("missing_grp", ["(a)", "$2"], b"abc")
case("missing_named", ["(a)", "${nothere}"], b"abc")

# --- Errors / CLI parsing ---
case("bare", [])
case("only_find", ["abc"])
case("only_find_p", ["-p", "abc"])
case("unknown_flag", ["--bogus"])
case("unknown_short", ["-x"])
case("double_p", ["-p", "-p", "a", "X"])
case("double_n", ["-n", "1", "-n", "2", "a", "X"])
case("double_f", ["-f", "i", "-f", "c", "a", "X"])
case("invalid_regex", ["[", "X"], b"abc")
case("invalid_regex_grp", ["(abc", "X"], b"abc")
case("invalid_regex_empty_named", ["(?P<>x)", "X"], b"abc")
case("lookahead_err", ["(?=b)", "X"], b"abc")
case("lookbehind_err", ["(?<=a)", "X"], b"abc")
case("Z_anchor_err", ["\\Z", "X"], b"abc")
case("dashdash", ["--"])
case("dashdash_arg", ["--", "-w", "X"], b"hello -w")

# --- File mode ---
case("file_simple", ["b", "X"], files={"x.txt": b"abc"})
case("file_no_trail_nl", ["b", "X"], files={"x.txt": b"abc"})
case("file_with_trail_nl", ["b", "X"], files={"x.txt": b"abc\n"})
case("file_no_match", ["xyz", "X"], files={"x.txt": b"abc"})
case("file_empty", ["b", "X"], files={"x.txt": b""})
case("file_binary", ["a", "Z"], files={"x.dat": b"\xff\x00abc\xff"})
case("file_multi_line", ["b", "X"], files={"x.txt": b"abc\nbbb\nccc"})
case("file_multi", ["b", "X"], files={"a.txt": b"abc", "b.txt": b"bbb"})
case("file_preview", ["-p", "b", "X"], files={"x.txt": b"abc"})
case("file_preview_multi", ["-p", "b", "X"], files={"a.txt": b"abc", "b.txt": b"bbb"})
case("file_preview_no_match", ["-p", "z", "X"], files={"a.txt": b"abc", "b.txt": b"bbb"})

# --- Edge regex ---
case("zero_width", ["a*", "X"], b"abc")
case("zero_width_empty", ["a*", "X"], b"")
case("greedy", [".+", "X"], b"aabbcc")
case("lazy", [".+?", "X"], b"aabbcc")
case("inline_flag", ["(?i)hello", "Y"], b"Hello WORLD")
case("anchor_start", ["^a", "Z"], b"abc\ndef")
case("anchor_end", ["c$", "Z"], b"abc\ndef")
case("char_class", ["[ad]", "X"], b"abcd")

# --- Multi-file mode with errors ---
case("missing_file_only", ["x", "y", "/tmp/nonexistent_X"], b"")
# Note: this works because we don't create the file
print(f"PASSED: {PASS}")
print(f"FAILED: {FAIL}")
for d in DIFFS[:30]:
    print()
    print(d)
sys.exit(0 if FAIL == 0 else 1)
