use crate::utils::Error;
use regex::bytes::{Regex, RegexBuilder};

pub struct Replacer {
    regex: Regex,
    replace_with: Vec<u8>,
    fixed_strings: bool,
    max_replacements: Option<usize>,
}

impl Replacer {
    pub fn new(
        look_for: String,
        replace_with: String,
        is_fixed_strings: bool,
        flags: Option<String>,
        max_replacements: Option<usize>,
    ) -> Result<Self, Error> {
        // Check for ambiguous numbered capture group refs in regex-mode replacement.
        if !is_fixed_strings {
            check_ambiguous_replacement(&replace_with)?;
        }

        let mut pattern = if is_fixed_strings {
            regex::escape(&look_for)
        } else {
            look_for.clone()
        };

        // case_insensitive and dot_matches_new_line are iterative.
        // 'w' wraps pattern (first occurrence) and resets those.
        // multi_line is computed from the flag SET via priority rules.
        let mut case_insensitive: bool = false;
        let mut dot_matches_new_line: bool = false;
        let mut wrapped: bool = false;

        if let Some(flag_str) = &flags {
            for c in flag_str.chars() {
                match c {
                    'c' => case_insensitive = false,
                    'i' => case_insensitive = true,
                    's' => dot_matches_new_line = true,
                    'w' => {
                        if !wrapped {
                            pattern = format!(r"\b{}\b", pattern);
                            wrapped = true;
                        }
                        case_insensitive = false;
                        dot_matches_new_line = false;
                    }
                    'm' | 'e' => {} // multi_line set below from flag set
                    _ => {}
                }
            }
        }

        // multi_line priority: e or w > m > s > default(true)
        let has_m = flags.as_deref().map_or(false, |s| s.contains('m'));
        let has_e = flags.as_deref().map_or(false, |s| s.contains('e'));
        let has_s = flags.as_deref().map_or(false, |s| s.contains('s'));
        let has_w = flags.as_deref().map_or(false, |s| s.contains('w'));
        let multi_line = if has_e || has_w {
            false
        } else if has_m {
            true
        } else if has_s {
            false
        } else {
            true
        };

        let mut builder = RegexBuilder::new(&pattern);
        builder.case_insensitive(case_insensitive);
        builder.multi_line(multi_line);
        builder.dot_matches_new_line(dot_matches_new_line);

        let regex = builder.build()?;

        let processed_replace = if is_fixed_strings {
            replace_with.into_bytes()
        } else {
            process_replacement_escapes(&replace_with)
        };

        Ok(Self {
            regex,
            replace_with: processed_replace,
            fixed_strings: is_fixed_strings,
            max_replacements,
        })
    }

    pub fn replace<'a>(&'a self, content: &'a [u8]) -> std::borrow::Cow<'a, [u8]> {
        if self.fixed_strings {
            self.replace_fixed(content)
        } else {
            // For regex mode, the replacement needs special $N handling via regex crate
            // But we already preprocessed escape sequences, so call replace with our bytes
            // as a Replacer that processes $N
            let limit = self.max_replacements.unwrap_or(0);
            if limit == 0 {
                self.regex.replace_all(content, &self.replace_with[..])
            } else {
                self.regex.replacen(content, limit, &self.replace_with[..])
            }
        }
    }

    fn replace_fixed<'a>(&'a self, content: &'a [u8]) -> std::borrow::Cow<'a, [u8]> {
        // -F mode: literal find, literal replace (no $N expansion)
        let limit = self.max_replacements.unwrap_or(0);
        if limit == 0 {
            self.regex
                .replace_all(content, regex::bytes::NoExpand(&self.replace_with[..]))
        } else {
            self.regex
                .replacen(content, limit, regex::bytes::NoExpand(&self.replace_with[..]))
        }
    }
}

fn check_ambiguous_replacement(rep: &str) -> Result<(), Error> {
    let bytes = rep.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] != b'$' {
            i += 1;
            continue;
        }
        // After $
        let next_pos = i + 1;
        if next_pos >= bytes.len() {
            i += 1;
            continue;
        }
        let next = bytes[next_pos];
        if next == b'$' {
            // $$ escape — skip both
            i += 2;
            continue;
        }
        if next == b'{' {
            // ${name} — skip braced
            i = next_pos + 1;
            while i < bytes.len() && bytes[i] != b'}' {
                i += 1;
            }
            if i < bytes.len() {
                i += 1;
            }
            continue;
        }
        if next.is_ascii_digit() {
            // $<digits>
            let digit_start = next_pos;
            let mut j = next_pos;
            while j < bytes.len() && bytes[j].is_ascii_digit() {
                j += 1;
            }
            let digit_end = j;
            // Check if next char (after digits) is a word char (alpha or underscore)
            if digit_end < bytes.len() && is_name_word(bytes[digit_end]) {
                // Ambiguous!
                let number = std::str::from_utf8(&bytes[digit_start..digit_end])
                    .unwrap()
                    .to_string();
                // Find end of suffix word chars
                let mut k = digit_end;
                while k < bytes.len() && is_name_word(bytes[k]) {
                    k += 1;
                }
                let suffix = std::str::from_utf8(&bytes[digit_end..k]).unwrap().to_string();
                // Pointer: spaces until digit_start, then carets from digit_start to k
                let pointer_len = k - digit_start;
                let leading_spaces = digit_start;
                let mut pointer = " ".repeat(leading_spaces);
                pointer.push_str(&"^".repeat(pointer_len));
                return Err(Error::AmbiguousReplacement {
                    number,
                    suffix,
                    replacement: rep.to_string(),
                    pointer,
                });
            }
            i = digit_end;
            continue;
        }
        if next.is_ascii_alphabetic() || next == b'_' {
            // $name — skip word chars
            let mut j = next_pos;
            while j < bytes.len() && is_name_word(bytes[j]) {
                j += 1;
            }
            i = j;
            continue;
        }
        // Literal $
        i += 1;
    }
    Ok(())
}

fn is_name_word(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'_'
}

fn process_replacement_escapes(s: &str) -> Vec<u8> {
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b == b'\\' && i + 1 < bytes.len() {
            let next = bytes[i + 1];
            match next {
                b'n' => {
                    out.push(b'\n');
                    i += 2;
                }
                b'r' => {
                    out.push(b'\r');
                    i += 2;
                }
                b't' => {
                    out.push(b'\t');
                    i += 2;
                }
                b'\\' => {
                    out.push(b'\\');
                    i += 2;
                }
                b'x' => {
                    // expect exactly 2 hex digits
                    if i + 3 < bytes.len()
                        && is_hex(bytes[i + 2])
                        && is_hex(bytes[i + 3])
                    {
                        let hi = hex_val(bytes[i + 2]);
                        let lo = hex_val(bytes[i + 3]);
                        let codepoint = (hi << 4) | lo;
                        // encode as UTF-8 (codepoint up to 0xFF here)
                        let ch = char::from_u32(codepoint as u32).unwrap();
                        let mut buf = [0u8; 4];
                        let encoded = ch.encode_utf8(&mut buf);
                        out.extend_from_slice(encoded.as_bytes());
                        i += 4;
                    } else {
                        out.push(b);
                        i += 1;
                    }
                }
                _ => {
                    out.push(b);
                    i += 1;
                }
            }
        } else {
            out.push(b);
            i += 1;
        }
    }
    out
}

fn is_hex(b: u8) -> bool {
    matches!(b, b'0'..=b'9' | b'a'..=b'f' | b'A'..=b'F')
}

fn hex_val(b: u8) -> u8 {
    match b {
        b'0'..=b'9' => b - b'0',
        b'a'..=b'f' => b - b'a' + 10,
        b'A'..=b'F' => b - b'A' + 10,
        _ => 0,
    }
}
