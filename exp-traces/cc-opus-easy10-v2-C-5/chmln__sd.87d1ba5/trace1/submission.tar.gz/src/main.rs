use std::path::PathBuf;
use std::process::ExitCode;

use clap::Parser;

mod input;
mod replacer;
mod utils;

const FLAGS_LONG_HELP: &str = "Regex flags. May be combined (like `-f mc`).\n\nc - case-sensitive\n\ne - disable multi-line matching\n\ni - case-insensitive\n\nm - multi-line matching\n\ns - make `.` match newlines\n\nw - match full words only";

const PREVIEW_LONG_HELP: &str = "Display changes in a human reviewable format (the specifics of the format are likely to change in the future)";

const FIXED_LONG_HELP: &str = "Treat FIND and REPLACE_WITH args as literal strings";

const MAX_REPL_LONG_HELP: &str = "Limit the number of replacements that can occur per file. 0 indicates unlimited replacements";

const FIND_LONG_HELP: &str = "The regexp or string (if using `-F`) to search for";

const REPLACE_LONG_HELP: &str = "What to replace each match with. Unless in string mode, you may use captured values like $1, $2, etc";

const FILES_HELP: &str = "The path to file(s). This is optional - sd can also read from STDIN";
const FILES_LONG_HELP: &str = "The path to file(s). This is optional - sd can also read from STDIN.\n\nNote: sd modifies files in-place by default. See documentation for examples.";

#[derive(Parser, Debug)]
#[command(
    name = "sd",
    version = "1.0.0",
    about = "An intuitive find & replace CLI",
    help_template = "{name} v{version}\n{about-with-newline}\n{usage-heading} {usage}\n\n{all-args}{after-help}",
    max_term_width = 100,
)]
struct Args {
    #[arg(
        short = 'p',
        long = "preview",
        help = PREVIEW_LONG_HELP,
        long_help = PREVIEW_LONG_HELP,
    )]
    preview: bool,

    #[arg(
        short = 'F',
        long = "fixed-strings",
        help = FIXED_LONG_HELP,
        long_help = FIXED_LONG_HELP,
    )]
    fixed_strings: bool,

    #[arg(
        short = 'n',
        long = "max-replacements",
        value_name = "LIMIT",
        default_value_t = 0,
        help = MAX_REPL_LONG_HELP,
        long_help = MAX_REPL_LONG_HELP,
    )]
    max_replacements: usize,

    #[arg(
        short = 'f',
        long = "flags",
        value_name = "FLAGS",
        help = "Regex flags. May be combined (like `-f mc`).",
        long_help = FLAGS_LONG_HELP,
    )]
    flags: Option<String>,


    #[arg(help = FIND_LONG_HELP, long_help = FIND_LONG_HELP)]
    find: String,

    #[arg(help = REPLACE_LONG_HELP, long_help = REPLACE_LONG_HELP)]
    replace_with: String,

    #[arg(help = FILES_HELP, long_help = FILES_LONG_HELP)]
    files: Vec<PathBuf>,
}

fn main() -> ExitCode {
    let args = Args::parse();
    match run(args) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {}", e);
            ExitCode::from(1)
        }
    }
}

fn run(args: Args) -> Result<(), utils::Error> {
    let replacer = replacer::Replacer::new(
        args.find,
        args.replace_with,
        args.fixed_strings,
        args.flags,
        if args.max_replacements == 0 { None } else { Some(args.max_replacements) },
    )?;
    let source = input::Source::new(&args.files);
    source.apply(&replacer, args.preview)?;
    Ok(())
}
