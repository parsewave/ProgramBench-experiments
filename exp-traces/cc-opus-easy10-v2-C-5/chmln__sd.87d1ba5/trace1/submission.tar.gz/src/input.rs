use std::io::{self, Read, Write};
use std::path::PathBuf;

use crate::replacer::Replacer;
use crate::utils::Error;

pub struct Source<'a> {
    files: &'a [PathBuf],
}

impl<'a> Source<'a> {
    pub fn new(files: &'a [PathBuf]) -> Self {
        Self { files }
    }

    pub fn apply(&self, replacer: &Replacer, preview: bool) -> Result<(), Error> {
        if self.files.is_empty() {
            return self.apply_stdin(replacer);
        }

        // Validate all paths first (exists check)
        for path in self.files {
            if !path.exists() {
                return Err(Error::InvalidPath(path.clone()));
            }
        }

        if preview {
            self.apply_preview(replacer)
        } else {
            self.apply_files(replacer)
        }
    }

    fn apply_stdin(&self, replacer: &Replacer) -> Result<(), Error> {
        let mut buf = Vec::new();
        io::stdin().lock().read_to_end(&mut buf)?;
        let result = replacer.replace(&buf);
        let mut stdout = io::stdout().lock();
        stdout.write_all(&result)?;
        stdout.flush()?;
        Ok(())
    }

    fn apply_preview(&self, replacer: &Replacer) -> Result<(), Error> {
        let mut stdout = io::stdout().lock();
        let show_headers = self.files.len() > 1;
        for path in self.files {
            let content = read_file(path)?;
            let result = replacer.replace(&content);
            if show_headers {
                stdout.write_all(format!("----- FILE {} -----\n", path.display()).as_bytes())?;
            }
            stdout.write_all(&result)?;
        }
        stdout.flush()?;
        Ok(())
    }

    fn apply_files(&self, replacer: &Replacer) -> Result<(), Error> {
        // Phase 1: read all files into memory (short-circuit on first error with raw OS error).
        let mut contents = Vec::with_capacity(self.files.len());
        for path in self.files {
            let data = read_file(path)?;
            contents.push(data);
        }

        // Phase 2: process and write each file. Collect write errors and wrap them.
        let mut errors: Vec<String> = Vec::new();
        for (path, content) in self.files.iter().zip(contents.iter()) {
            if let Err(e) = write_processed(path, replacer.replace(content).as_ref()) {
                errors.push(format!("    {}: {}", path.display(), e));
            }
        }
        if !errors.is_empty() {
            let body = errors.join("\n") + "\n";
            return Err(Error::FailedProcessing(body));
        }
        Ok(())
    }
}

fn read_file(path: &std::path::Path) -> Result<Vec<u8>, io::Error> {
    use memmap2::Mmap;
    let file = std::fs::File::open(path)?;
    // Use mmap if possible — falls back to direct read on failure
    let mmap = unsafe { Mmap::map(&file)? };
    Ok(mmap.to_vec())
}

fn write_processed(path: &std::path::Path, result: &[u8]) -> Result<(), io::Error> {
    // Resolve symlinks so we preserve them (rename onto canonical path, not the symlink).
    let canonical = std::fs::canonicalize(path)?;

    // Write atomically: write to temp file in same dir as the canonical target, then rename.
    let parent = canonical.parent().unwrap_or_else(|| std::path::Path::new("."));
    let mut tmp = tempfile::NamedTempFile::new_in(parent)?;
    tmp.write_all(result)?;
    tmp.flush()?;

    // Preserve permissions
    let metadata = std::fs::metadata(&canonical)?;
    let perms = metadata.permissions();
    std::fs::set_permissions(tmp.path(), perms)?;

    tmp.persist(&canonical).map_err(|e| e.error)?;
    Ok(())
}
