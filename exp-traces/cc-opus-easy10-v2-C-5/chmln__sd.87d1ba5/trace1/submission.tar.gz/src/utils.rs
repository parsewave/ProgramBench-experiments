use std::path::PathBuf;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum Error {
    #[error("invalid regex {0}")]
    InvalidRegex(#[from] regex::Error),
    #[error("invalid path: {0}")]
    InvalidPath(PathBuf),
    #[error("{0}")]
    Io(#[from] std::io::Error),
    #[error("Failed processing some inputs\n{0}")]
    FailedProcessing(String),
    #[error("The numbered capture group `${number}` in the replacement text is ambiguous.\nhint: Use curly braces to disambiguate it `${{{number}}}{suffix}`.\n{replacement}\n{pointer}")]
    AmbiguousReplacement {
        number: String,
        suffix: String,
        replacement: String,
        pointer: String,
    },
}
