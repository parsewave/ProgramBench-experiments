#!/usr/bin/env python3
"""Markov-chain style top-up: random combinations representative of usage."""
import os
import subprocess
import random
import sys
import tempfile
import shutil
import re

REF = os.environ.get("REF_BIN", "/workspace/executable")
SUT = "/work/work/executable"

random.seed()  # truly random

PASS = 0
FAIL = 0
DIFFS = []


def normalize(b):
    return re.sub(rb'\.tmp[A-Za-z0-9]+', b'.tmpXXXXXX', b)


def run_one(binary, args, stdin_bytes=b""):
    try:
        result = subprocess.run([binary] + args, input=stdin_bytes, capture_output=True, timeout=10)
        return result.returncode, result.stdout, normalize(result.stderr)
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"


def case(name, args, stdin=b""):
    global PASS, FAIL
    re_exit, re_out, re_err = run_one(REF, args, stdin)
    su_exit, su_out, su_err = run_one(SUT, args, stdin)
    if re_exit == su_exit and re_out == su_out and re_err == su_err:
        PASS += 1
    else:
        FAIL += 1
        msg = [f"FAIL {name}: args={args}, stdin={stdin!r}"]
        if re_exit != su_exit:
            msg.append(f"  exit: ref={re_exit} sut={su_exit}")
        if re_out != su_out:
            msg.append(f"  stdout ref={re_out!r}\n          sut={su_out!r}")
        if re_err != su_err:
            msg.append(f"  stderr ref={re_err!r}\n          sut={su_err!r}")
        DIFFS.append("\n".join(msg))


# Mode probabilities (probes Markov-chain-like sampling)
def gen_pattern():
    choices = [
        "abc", "world", "hello", "\\w+", "\\d+", "\\s+", "[a-z]+",
        "(\\w+)", "(?P<x>\\d+)", "(\\w+)\\s(\\w+)", ".",
        "foo|bar", "a*", ".+?", "^", "$",
        "\\b\\w{3}\\b", "[abc]{2,3}",
        "(?i)abc",
    ]
    return random.choice(choices)


def gen_replacement():
    choices = [
        "X", "", "Y", "<$0>", "[$1]", "$1$2",
        "${name}", "\\n", "\\t", "$0_$0",
        "before $0 after", "$$ $1 $$",
    ]
    return random.choice(choices)


def gen_flags():
    if random.random() < 0.7:
        return None
    base = random.choice(["", "i", "c", "s", "e", "w", "ci", "ic", "iw", "wi", "is", "ws"])
    return base


def gen_n():
    if random.random() < 0.7:
        return None
    return str(random.choice([0, 1, 2, 3, 10, 100]))


def gen_input():
    samples = [
        b"", b"hello world", b"abc abc abc",
        b"line one\nline two\nline three\n",
        b"123 abc 456 def", b"AaBbCc",
        b"foo bar baz\n", b"   spaces   ",
        b"\xff\xfe utf8", b"\nstart\nmiddle\nend",
    ]
    return random.choice(samples)


def gen_args():
    args = []
    f = gen_flags()
    if f is not None:
        args.extend(["-f", f])
    n = gen_n()
    if n is not None:
        args.extend(["-n", n])
    if random.random() < 0.1:
        args.append("-F")
    if random.random() < 0.1:
        args.append("-p")
    args.append(gen_pattern())
    args.append(gen_replacement())
    return args


N = 100
for i in range(N):
    args = gen_args()
    stdin = gen_input()
    case(f"markov_{i}", args, stdin)

print(f"PASSED: {PASS}")
print(f"FAILED: {FAIL}")
for d in DIFFS[:20]:
    print()
    print(d)
sys.exit(0 if FAIL == 0 else 1)
