#!/usr/bin/env python3
"""Large fuzz test exercising flags exhaustively."""
import os
import subprocess
import random
import re
import sys

REF = os.environ.get("REF_BIN", "/workspace/executable")
SUT = "/work/work/executable"

PASS = 0
FAIL = 0
DIFFS = []


def normalize(b):
    return re.sub(rb'\.tmp[A-Za-z0-9]+', b'.tmpXXXXXX', b)


def run_one(binary, args, stdin_bytes=b""):
    try:
        result = subprocess.run([binary] + args, input=stdin_bytes, capture_output=True, timeout=10)
        return result.returncode, result.stdout, normalize(result.stderr)
    except subprocess.TimeoutExpired:
        return -1, b"", b"TIMEOUT"


def case(name, args, stdin=b""):
    global PASS, FAIL
    re_exit, re_out, re_err = run_one(REF, args, stdin)
    su_exit, su_out, su_err = run_one(SUT, args, stdin)
    if re_exit == su_exit and re_out == su_out and re_err == su_err:
        PASS += 1
    else:
        FAIL += 1
        msg = [f"FAIL {name}: args={args}, stdin={stdin!r}"]
        if re_exit != su_exit:
            msg.append(f"  exit: ref={re_exit} sut={su_exit}")
        if re_out != su_out:
            msg.append(f"  stdout ref={re_out!r}\n          sut={su_out!r}")
        if re_err != su_err:
            msg.append(f"  stderr ref={re_err!r}\n          sut={su_err!r}")
        DIFFS.append("\n".join(msg))


# Exhaustive 4-char flag combos from {c,i,m,e,s,w,q}
import itertools

FLAG_CHARS = ['c', 'i', 'm', 'e', 's', 'w', 'q']
TEST_INPUTS = [
    (b"hello\nworld\nfoo", "^w"),
    (b"abc\ndef", "^d"),
    (b"Hello WORLD", "hello"),
    (b"a\nb", "a.b"),
    (b"abc abcd cabc", "abc"),
]

for flags_len in range(1, 4):
    for combo in itertools.product(FLAG_CHARS, repeat=flags_len):
        flags = "".join(combo)
        for stdin, pattern in TEST_INPUTS:
            case(f"flags_{flags}_{pattern}", ["-f", flags, pattern, "X"], stdin)
            if PASS + FAIL >= 5000:
                break
        if PASS + FAIL >= 5000:
            break
    if PASS + FAIL >= 5000:
        break

print(f"PASSED: {PASS}")
print(f"FAILED: {FAIL}")
for d in DIFFS[:30]:
    print()
    print(d)
sys.exit(0 if FAIL == 0 else 1)
