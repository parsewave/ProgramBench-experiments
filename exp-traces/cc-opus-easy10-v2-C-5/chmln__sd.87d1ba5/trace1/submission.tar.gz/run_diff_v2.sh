#!/usr/bin/env bash
# Comprehensive differential testing with file mode
set -uo pipefail
REF=${REF:-$REF_BIN}
SUT=${SUT:-/work/work/executable}

mkdir -p /tmp/sdtest_ref /tmp/sdtest_sut
TESTDIR_REF=/tmp/sdtest_ref
TESTDIR_SUT=/tmp/sdtest_sut

setup_files() {
    rm -rf $TESTDIR_REF $TESTDIR_SUT
    mkdir -p $TESTDIR_REF $TESTDIR_SUT
}

# Test 1: file mode - reference vs sut produce identical file contents
PASS=0
FAIL=0
DIFFS=()

run_file_test() {
    local name=$1
    local content=$2
    local args_str=$3  # without files
    setup_files
    printf '%s' "$content" > "$TESTDIR_REF/x.txt"
    printf '%s' "$content" > "$TESTDIR_SUT/x.txt"
    local ref_stderr ref_stdout ref_exit
    local sut_stderr sut_stdout sut_exit
    ref_stdout=$(eval "$REF $args_str $TESTDIR_REF/x.txt" 2>"$TESTDIR_REF/stderr")
    ref_exit=$?
    ref_stderr=$(cat "$TESTDIR_REF/stderr" 2>/dev/null)
    sut_stdout=$(eval "$SUT $args_str $TESTDIR_SUT/x.txt" 2>"$TESTDIR_SUT/stderr")
    sut_exit=$?
    sut_stderr=$(cat "$TESTDIR_SUT/stderr" 2>/dev/null)
    local ref_content sut_content
    ref_content=$(cat "$TESTDIR_REF/x.txt" 2>/dev/null)
    sut_content=$(cat "$TESTDIR_SUT/x.txt" 2>/dev/null)
    if [ "$ref_stdout" = "$sut_stdout" ] && [ "$ref_stderr" = "$sut_stderr" ] && [ "$ref_exit" = "$sut_exit" ] && [ "$ref_content" = "$sut_content" ]; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        DIFFS+=("$name: exit ref=$ref_exit sut=$sut_exit; stdout ref=${ref_stdout:0:80} sut=${sut_stdout:0:80}; stderr ref=${ref_stderr:0:80} sut=${sut_stderr:0:80}; content ref=${ref_content:0:80} sut=${sut_content:0:80}")
    fi
}

run_file_test "simple" "abc abc" "b X"
run_file_test "trailing_nl" $'abc\n' "b X"
run_file_test "no_trailing_nl" "abc" "b X"
run_file_test "with_preview" "abc" "-p b X"
run_file_test "with_n" "aaaa" "-n 2 a X"
run_file_test "empty_content" "" "b X"
run_file_test "multi_line" $'aaa\nbbb\nccc' "a X"
run_file_test "fixed" "a.b" "-F a.b X"
run_file_test "no_match" "xxx" "b X"
run_file_test "with_F_caret" "ab^c" "-F ^ Z"
run_file_test "flags_iw" "Hello hi" "-f iw hi X"
run_file_test "named" "abc" '(?P<x>a) ${x}Z'

echo "PASSED: $PASS"
echo "FAILED: $FAIL"
for d in "${DIFFS[@]}"; do
    echo "$d"
done
