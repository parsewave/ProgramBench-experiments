#!/bin/bash
# Differential test driver: runs many probes against both REF and SUT,
# reports any divergence, and updates a summary.

REF=/workspace/executable
SUT=/work/work/executable
mkdir -p /work/work/goldens

normalize() {
  sed -E 's/thread '"'"'main'"'"' \([0-9]+\)/thread main (PID)/g'
}

pass=0
fail=0
failed_descs=()

check() {
  local desc="$1"; shift
  local input="$1"; shift
  local ref_out ref_exit
  ref_out=$(printf "%s" "$input" | timeout 5 $REF "$@" 2>&1 | normalize)
  ref_exit=${PIPESTATUS[1]}
  local sut_out sut_exit
  sut_out=$(printf "%s" "$input" | timeout 5 $SUT "$@" 2>&1 | normalize)
  sut_exit=${PIPESTATUS[1]}

  if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
    pass=$((pass+1))
  else
    fail=$((fail+1))
    failed_descs+=("$desc")
    if [ "$VERBOSE" = "1" ]; then
      echo "DIFF: $desc"
      echo "  ARGS: $@"
      echo "  REF (exit $ref_exit):"
      printf "%s\n" "$ref_out" | sed 's/^/    /'
      echo "  SUT (exit $sut_exit):"
      printf "%s\n" "$sut_out" | sed 's/^/    /'
      echo "---"
    fi
  fi
}

# Core selectors
check "default html" "<html><body><h1>Hello</h1></body></html>"
check "select h1" "<html><body><h1>Hello</h1></body></html>" "h1"
check "select body" "<html><body><h1>Hello</h1></body></html>" "body"
check "select multi" "<html><body><h1>A</h1><h2>B</h2></body></html>" "h1, h2"
check "no match" "<html><body><h1>A</h1></body></html>" "h2"
check "by id" "<html><body><div id='a'>X</div></body></html>" "#a"
check "by class" "<html><body><div class='a'>X</div></body></html>" ".a"
check "multi class" "<html><body><div class='a b c'>X</div></body></html>" ".a.b.c"
check "type and class" "<html><body><div class='a'>X</div></body></html>" "div.a"
check "child" "<html><body><div><p>A</p></div></body></html>" "div > p"
check "descendant" "<html><body><div><span><p>A</p></span></div></body></html>" "div p"
check "adjacent" "<html><body><div>A</div><p>X</p></body></html>" "div + p"
check "general sibling" "<html><body><div>A</div><span>S</span><p>X</p></body></html>" "div ~ p"
check "universal" "<html><body><a>A</a><b>B</b></body></html>" "body > *"

# Pseudo classes
check "first-child" "<html><body><p>A</p><p>B</p></body></html>" "p:first-child"
check "last-child" "<html><body><p>A</p><p>B</p></body></html>" "p:last-child"
check "only-child" "<html><body><div><p>A</p></div></body></html>" "p:only-child"
check "first-of-type" "<html><body><p>A</p><div>X</div><p>B</p></body></html>" "p:first-of-type"
check "last-of-type" "<html><body><p>A</p><div>X</div><p>B</p></body></html>" "p:last-of-type"
check "only-of-type" "<html><body><div><p>A</p></div></body></html>" "p:only-of-type"
check "nth-child(1)" "<html><body><p>A</p><p>B</p><p>C</p></body></html>" "p:nth-child(1)"
check "nth-child(2)" "<html><body><p>A</p><p>B</p><p>C</p></body></html>" "p:nth-child(2)"
check "nth-child(odd)" "<html><body><p>A</p><p>B</p><p>C</p></body></html>" "p:nth-child(odd)"
check "nth-child(even)" "<html><body><p>A</p><p>B</p><p>C</p></body></html>" "p:nth-child(even)"
check "nth-child(2n)" "<html><body><p>A</p><p>B</p><p>C</p><p>D</p></body></html>" "p:nth-child(2n)"
check "nth-child(2n+1)" "<html><body><p>A</p><p>B</p><p>C</p><p>D</p></body></html>" "p:nth-child(2n+1)"
check ":not class" "<html><body><div class='a'>A</div><div class='b'>B</div></body></html>" "div:not(.a)"
check ":empty" "<html><body><div></div><div>X</div></body></html>" "div:empty"

# Attribute selectors
check "[attr]" "<html><body><a href='x'>A</a><a>B</a></body></html>" "a[href]"
check "[attr=val]" "<html><body><a href='x'>A</a><a href='y'>B</a></body></html>" "a[href=x]"
check "[attr=\"val\"]" '<html><body><a href="x">A</a></body></html>' 'a[href="x"]'
check "[attr~=word]" '<html><body><div class="a b c">X</div></body></html>' 'div[class~=b]'
check "[attr|=val]" '<html><body><div data-x="a-b">X</div></body></html>' 'div[data-x|=a]'
check "[attr^=prefix]" '<html><body><a href="foo">X</a></body></html>' 'a[href^=foo]'
check "[attr$=suffix]" '<html><body><a href="foo.html">X</a></body></html>' 'a[href$=html]'
check "[attr*=part]" '<html><body><a href="foo">X</a></body></html>' 'a[href*=oo]'

# Modes
check "text mode" "<html><body><div>Hello</div></body></html>" "-t" "div"
check "text nested" "<html><body><div>A<span>B</span>C</div></body></html>" "-t" "div"
check "text multiple" "<html><body><p>A</p><p>B</p></body></html>" "-t" "p"
check "text empty" "<html><body><div></div></body></html>" "-t" "div"
check "text ws" "<html><body><div>   </div></body></html>" "-t" "div"
check "text -w" "<html><body><div>A<span>B</span></div></body></html>" "-tw" "div"
check "text -w ws" "<html><body><div>   </div></body></html>" "-tw" "div"

# Attribute mode
check "attr href" "<html><body><a href='x'>A</a></body></html>" "-a" "href" "a"
check "attr missing" "<html><body><a>A</a></body></html>" "-a" "href" "a"
check "attr multi" "<html><body><a href='x'>A</a><a href='y'>B</a></body></html>" "-a" "href" "a"

# Pretty mode
check "pretty simple" "<html><body><div>Hello</div></body></html>" "-p" "div"
check "pretty nested" "<html><body><div><p>A</p></div></body></html>" "-p" "div"
check "pretty 2p" "<html><body><div><p>A</p><p>B</p></div></body></html>" "-p" "div"
check "pretty inline" "<html><body><span>X</span></body></html>" "-p" "span"
check "pretty html" "<html><body><div><p>X</p></div></body></html>" "-p"

# Base URL
check "base on a" '<html><body><a href="/x">X</a></body></html>' "--base" "https://example.com" "a"
check "base attr" '<html><body><a href="/x">X</a></body></html>' "--base" "https://example.com" "-a" "href" "a"
check "base on img" '<html><body><img src="/x"></body></html>' "--base" "https://example.com" "img"
check "base invalid" '<html><body><a href="/x">X</a></body></html>' "--base" "not-url" "a"
check "detect-base" '<html><head><base href="https://b.com/"></head><body><a href="/x">X</a></body></html>' "-B" "-a" "href" "a"

# Errors
check "bogus flag" "" "--bogus"
check "invalid selector" "<html></html>" "@@@"
check "missing file" "" "-f" "/nonexistent/file"

# Help/version
check "version" "" "--version"
check "version -V" "" "-V"
check "help" "" "--help"
check "help -h" "" "-h"

# Edge cases
check "doctype" '<!DOCTYPE html><html><body>X</body></html>' "html"
check "comment" '<html><!--c--><body>X</body></html>' "html"
check "void elem" '<html><body><br><img></body></html>' "body"
check "empty input" "" "html"
check "no html" "Hello" "body"
check "attr order" '<html><body><a id="x" class="y">A</a></body></html>' "a"

# -r remove
check "remove sibling" '<html><body><div>A</div><span>B</span></body></html>' "-r" "span" "--" "body"
check "remove descendant" '<html><body><div><span>X</span></div></body></html>' "-r" "span" "--" "div"
check "remove ancestor" '<html><body><div><span>X</span></div></body></html>' "-r" "div" "--" "span"
check "remove self" '<html><body><div>A</div></body></html>' "-r" "div" "--" "div"

echo ""
echo "Total: $((pass+fail))  Pass: $pass  Fail: $fail"
if [ $fail -gt 0 ]; then
  echo "Failed tests:"
  for d in "${failed_descs[@]}"; do
    echo "  - $d"
  done
fi
