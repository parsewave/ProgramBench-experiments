#!/bin/bash
# Heavy differential test suite
REF=/workspace/executable
SUT=/work/work/executable

normalize() {
  sed -E 's/thread '"'"'main'"'"' \([0-9]+\)/thread main (PID)/g'
}

pass=0
fail=0
failed_descs=()

check() {
  local desc="$1"; shift
  local input="$1"; shift
  local ref_out ref_exit
  ref_out=$(printf "%s" "$input" | timeout 5 $REF "$@" 2>&1 | normalize)
  ref_exit=${PIPESTATUS[1]}
  local sut_out sut_exit
  sut_out=$(printf "%s" "$input" | timeout 5 $SUT "$@" 2>&1 | normalize)
  sut_exit=${PIPESTATUS[1]}

  if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
    pass=$((pass+1))
  else
    fail=$((fail+1))
    failed_descs+=("$desc")
    if [ "$VERBOSE" = "1" ]; then
      echo "DIFF: $desc"
      echo "  ARGS: $@"
      printf "  REF (exit %s):\n" "$ref_exit"
      printf "%s\n" "$ref_out" | head -10 | sed 's/^/    /'
      printf "  SUT (exit %s):\n" "$sut_exit"
      printf "%s\n" "$sut_out" | head -10 | sed 's/^/    /'
      echo "---"
    fi
  fi
}

# Comprehensive HTML5 parsing
check "doctype only" '<!DOCTYPE html>' html
check "html lang" '<html lang="en"><body>X</body></html>' html
check "head with multiple" '<html><head><title>T</title><meta charset="utf-8"></head><body>X</body></html>' head
check "stray script" '<html><body><script>var x=1;</script></body></html>' script
check "stray style" '<html><body><style>a{color:red}</style></body></html>' style
check "noscript" '<html><body><noscript>fallback</noscript></body></html>' noscript

# Comments
check "comment before doctype" '<!--before--><!DOCTYPE html><html><body>X</body></html>' html
check "comment in body" '<html><body><!--c-->X</body></html>' body
check "comment between elements" '<html><body><div>A</div><!--c--><div>B</div></body></html>' body

# Tables
check "tr without table" '<html><body><tr><td>X</td></tr></body></html>' tr
check "table thead" '<html><body><table><thead><tr><th>A</th></tr></thead></table></body></html>' thead
check "table tbody explicit" '<html><body><table><tbody><tr><td>A</td></tr></tbody></table></body></html>' table
check "table mixed" '<html><body><table><thead><tr><th>H</th></tr></thead><tbody><tr><td>D</td></tr></tbody></table></body></html>' table
check "td direct" '<html><body><table><tr><td colspan="2">A</td></tr></table></body></html>' td

# Forms
check "form input" '<html><body><form><input name="x" value="y"></form></body></html>' input
check "form select" '<html><body><form><select><option>A</option><option>B</option></select></form></body></html>' select
check "form textarea" '<html><body><form><textarea>x</textarea></form></body></html>' textarea
check "form button" '<html><body><form><button type="submit">Go</button></form></body></html>' button

# Lists
check "ul li" '<html><body><ul><li>A</li><li>B</li></ul></body></html>' ul
check "li implicit close" '<html><body><ul><li>A<li>B</ul></body></html>' ul
check "dl dt dd" '<html><body><dl><dt>A</dt><dd>1</dd><dt>B</dt><dd>2</dd></dl></body></html>' dl
check "ol li" '<html><body><ol><li>A</li><li>B</li></ol></body></html>' ol

# CSS selectors - complex
check "deep nest" '<html><body><div><div><div><span>X</span></div></div></div></body></html>' 'div > div > span'
check "class chain" '<html><body><div class="a b c">X</div></body></html>' '.a.b.c'
check "id + class" '<html><body><div id="x" class="y">X</div></body></html>' '#x.y'
check "type chain" '<html><body><div><p>A</p><span>B</span></div></body></html>' 'div > p'
check "nth-of-type" '<html><body><p>A</p><p>B</p><p>C</p></body></html>' 'p:nth-of-type(2)'
check "nth-last-child" '<html><body><p>A</p><p>B</p><p>C</p></body></html>' 'p:nth-last-child(1)'
check "first-of-type complex" '<html><body><div><p>A</p><span>X</span><p>B</p></div></body></html>' 'p:first-of-type'
check "only-of-type" '<html><body><div><p>A</p><span>X</span></div></body></html>' 'p:only-of-type'

# Attribute selectors
check "attr presence" '<html><body><a href="x">A</a><a>B</a></body></html>' '[href]'
check "attr equal quoted" '<html><body><a href="x">A</a></body></html>' '[href="x"]'
check "attr starts" '<html><body><a href="https://example.com">A</a></body></html>' '[href^=https]'
check "attr ends" '<html><body><a href="page.html">A</a></body></html>' '[href$=html]'
check "attr contains" '<html><body><a href="example.com/page">A</a></body></html>' '[href*=example]'
check "attr word" '<html><body><div class="alpha beta">A</div></body></html>' '[class~=beta]'

# Combinations
check ":not + :has" '<html><body><div>A</div><div class="x">X</div></body></html>' 'div:not(.x)'
check "child not first" '<html><body><div><p>A</p><p>B</p></div></body></html>' 'p:not(:first-child)'

# Text mode
check "text no children" '<html><body><br></body></html>' -t body
check "text deeply nested" '<html><body><div>A<span>B<i>C</i>D</span>E</div></body></html>' -t div
check "text with entity" '<html><body><div>A&amp;B</div></body></html>' -t div
check "text with newlines" "$(printf '<html><body>line1\nline2</body></html>')" -t body
check "text -w only ws" '<html><body><div> 	 </div></body></html>' -tw div

# Attribute mode
check "attr -t href" '<html><body><a href="/x">X</a></body></html>' -a href -t a
check "attr no value" '<html><body><a href>X</a></body></html>' -a href a
check "attr decoded" '<html><body><a href="a&amp;b">X</a></body></html>' -a href a

# Pretty edge cases
check "pretty single text" '<html><body>HELLO</body></html>' -p body
check "pretty single elem" '<html><body><div>X</div></body></html>' -p body
check "pretty inline w text" '<html><body><span>X</span>text</body></html>' -p body
check "pretty inline+block" '<html><body><span>A</span><div>B</div></body></html>' -p body
check "pretty nested div" '<html><body><div><div><div>X</div></div></div></body></html>' -p body
check "pretty empty" '<html><body><div></div></body></html>' -p body
check "pretty void series" '<html><body><br><br></body></html>' -p body
check "pretty mixed void" '<html><body>before<br>after</body></html>' -p body

# Base URL edge cases
check "base port" '<html><body><a href="/x">A</a></body></html>' --base 'https://example.com:8080' a
check "base path" '<html><body><a href="x">A</a></body></html>' --base 'https://example.com/path/' a
check "base no path" '<html><body><a href="x">A</a></body></html>' --base 'https://example.com' a
check "base double slash" '<html><body><a href="//other.com/y">A</a></body></html>' --base 'https://example.com' a
check "base query" '<html><body><a href="?q=1">A</a></body></html>' --base 'https://example.com/path' a
check "base hash" '<html><body><a href="#x">A</a></body></html>' --base 'https://example.com/path' a

# Remove + various
check "remove no descendant" '<html><body><div>A</div></body></html>' -r script -- body
check "remove and pretty" '<html><body><div>K</div><script>X</script></body></html>' -p -r script -- body
check "remove and text" '<html><body><div>HELLO<script>X</script></div></body></html>' -t -r script -- div
check "remove and attr" '<html><body><a href="x" data-rm="y">X</a></body></html>' -a href -r '[data-rm]' -- a

# Mixed options
check "all flags" '<html><body><div><p>X</p></div></body></html>' -p -t -w -B div
check "long flags" '<html><body><div>X</div></body></html>' --pretty --text div

# Output file
check "-o creates file" '<html><body><div>X</div></body></html>' -o /tmp/htest_$$.html div
rm -f /tmp/htest_$$.html
check "-f reads file" '' -f /etc/hostname 2>&1 # Should not panic since file exists
echo "" > /tmp/empty_$$.html
check "-f empty file" '' -f /tmp/empty_$$.html
rm -f /tmp/empty_$$.html

# Errors
check "invalid utf-8 in stdin" "$(printf '<html><body>\xff\xfe</body></html>')" body
check "missing arg -a" '' -a
check "missing arg -b" '' -b
check "missing arg -f" '' -f
check "missing arg -o" '' -o
check "missing arg -r" '' -r
check "double dash" '<html><body>X</body></html>' --

# Selectors that should panic
check "invalid CSS" '<html></html>' '###bad'
check "empty selector" '<html></html>' ''

# Various charset
check "high unicode" '<html><body>𝕊</body></html>' body
check "rtl text" '<html><body>שלום</body></html>' body

# Various selectors
check "type only" '<html><body><h1>A</h1></body></html>' h1
check "wildcard" '<html><body><a>A</a><b>B</b></body></html>' '*'
check "implicit child" '<html><body><div><p>A</p></div></body></html>' 'div p'
check "complex selector group" '<html><body><h1>H</h1><div class="a">A</div><p>P</p></body></html>' 'h1, .a, p'

# HTML5 oddity
check "form in p" '<html><body><p>X<form><input></form></p></body></html>' p

# Empty/whitespace
check "all whitespace" '   ' body
check "tab only" "$(printf '\t')" body

# Long attributes
check "many attrs" '<html><body><div a="1" b="2" c="3" d="4" e="5" f="6">X</div></body></html>' div

echo ""
echo "Total: $((pass+fail))  Pass: $pass  Fail: $fail"
if [ $fail -gt 0 ]; then
  echo "Failed:"
  for d in "${failed_descs[@]}"; do
    echo "  - $d"
  done
fi
