#!/bin/bash
# Fuzz tests with random/unusual inputs
REF=/workspace/executable
SUT=/work/work/executable

normalize() {
  sed -E 's/thread '"'"'main'"'"' \([0-9]+\)/thread main (PID)/g'
}

pass=0
fail=0
failed_descs=()

check() {
  local desc="$1"; shift
  local input="$1"; shift
  local ref_out ref_exit
  ref_out=$(printf "%s" "$input" | timeout 5 $REF "$@" 2>&1 | normalize)
  ref_exit=${PIPESTATUS[1]}
  local sut_out sut_exit
  sut_out=$(printf "%s" "$input" | timeout 5 $SUT "$@" 2>&1 | normalize)
  sut_exit=${PIPESTATUS[1]}

  if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
    pass=$((pass+1))
  else
    fail=$((fail+1))
    failed_descs+=("$desc")
    if [ "$VERBOSE" = "1" ]; then
      echo "DIFF: $desc"
      echo "  ARGS: $@"
      printf "  REF (exit %s):\n" "$ref_exit"
      printf "%s\n" "$ref_out" | head -10 | sed 's/^/    /'
      printf "  SUT (exit %s):\n" "$sut_exit"
      printf "%s\n" "$sut_out" | head -10 | sed 's/^/    /'
      echo "---"
    fi
  fi
}

# Markov-like sampling from discovered modes
# (a) selector parsing
# (b) html parsing edge cases
# (c) pretty mode quirks
# (d) text mode + ignore-whitespace
# (e) -r interaction
# (f) base URL handling

# Mode A: selector parsing
check "fuzz_a01" '<html><body><div class="big-text"><p>Hi</p></div></body></html>' 'div.big-text p'
check "fuzz_a02" '<html><body><a data-id="123" href="/foo">X</a></body></html>' 'a[data-id="123"]'
check "fuzz_a03" '<html><body><div></div></body></html>' ':not(:empty)'
check "fuzz_a04" '<html><body><ul><li>a</li><li>b</li><li>c</li><li>d</li></ul></body></html>' 'li:nth-child(2n+1)'
check "fuzz_a05" '<html><body><div><h1>A</h1><p>B</p><h2>C</h2><p>D</p></div></body></html>' 'h1 + p'

# Mode B: HTML parsing edge cases
check "fuzz_b01" '<html><body><p>A<b>B</b>C<i>D</i>E</p></body></html>' 'p'
check "fuzz_b02" '<html><body><div>1<div>2<div>3</div>4</div>5</div></body></html>' 'div'
check "fuzz_b03" '<html><body><span>a<div>b</div>c</span></body></html>' 'body'
check "fuzz_b04" '<html><body>Text <!-- comment --> More</body></html>' 'body'
check "fuzz_b05" '<html><body><svg><circle r="5"></circle></svg></body></html>' 'svg'

# Mode C: pretty mode
check "fuzz_c01" '<html><body><table><tr><td>1</td><td>2</td></tr><tr><td>3</td><td>4</td></tr></table></body></html>' -p table
check "fuzz_c02" '<html><body><ul><li>A</li><li>B</li></ul></body></html>' -p ul
check "fuzz_c03" '<html><body><dl><dt>K1</dt><dd>V1</dd><dt>K2</dt><dd>V2</dd></dl></body></html>' -p dl
check "fuzz_c04" '<html><body><form><label>X<input></label></form></body></html>' -p form
check "fuzz_c05" '<html><body><div><span><a><b>Deep</b></a></span></div></body></html>' -p div

# Mode D: text mode
check "fuzz_d01" '<html><body><p>Para 1</p><p>Para 2</p></body></html>' -t body
check "fuzz_d02" '<html><body><div>A<span>B<i>C</i></span>D</div></body></html>' -tw div
check "fuzz_d03" "$(printf '<html><body>\n  Line 1\n  Line 2\n</body></html>')" -t body
check "fuzz_d04" '<html><body><pre>  pre   text  </pre></body></html>' -t pre
check "fuzz_d05" "$(printf '<html><body><div>\n  <span>A</span>\n  <span>B</span>\n</div></body></html>')" -tw div

# Mode E: -r interaction
check "fuzz_e01" '<html><body><div>K</div><span>R</span></body></html>' -r 'span' -- 'body'
check "fuzz_e02" '<html><body><div class="rm">X</div><div>K</div></body></html>' -r '.rm' -- 'body'
check "fuzz_e03" '<html><body><script>x</script><div>K</div></body></html>' -r 'script' 'div'
check "fuzz_e04" '<html><body><div><p>K</p><script>X</script></div></body></html>' -r 'script' -- 'div'
check "fuzz_e05" '<html><body><a class="active">A</a><a>B</a></body></html>' -r '.active' -- 'a'

# Mode F: base URL
check "fuzz_f01" '<html><body><a href="/abs">A</a></body></html>' --base 'https://example.com/' a
check "fuzz_f02" '<html><body><a href="rel">A</a></body></html>' --base 'https://example.com/path/' a
check "fuzz_f03" '<html><body><a href="?q=1">A</a></body></html>' --base 'https://example.com/' a
check "fuzz_f04" '<html><body><a href="//other.com">A</a></body></html>' --base 'https://example.com/' a
check "fuzz_f05" '<html><body><a href="https://abs.com/p">A</a></body></html>' --base 'https://example.com/' a

# Random combinations
check "fuzz_r01" '<html><body><div>A</div><div>B</div></body></html>' -p -t div
check "fuzz_r02" '<html><body><a href="/x">L</a></body></html>' -p --base 'https://e.com' a
check "fuzz_r03" '<html><body><div>X</div><br><span>Y</span></body></html>' -p body
check "fuzz_r04" '<html><body><h1>H1</h1><h2>H2</h2></body></html>' 'h1, h2'
check "fuzz_r05" '<html><body><div><p><b>X</b></p></div></body></html>' 'b'

# Test for -V output exactly
check "fuzz_v01" '' -V
check "fuzz_v02" '' --version
check "fuzz_h01" '' --help

# Common idiomatic uses
check "idiom01" '<html><body><a href="https://example.com/page.html">Link</a></body></html>' -a href a
check "idiom02" '<html><body><meta name="description" content="Test"></body></html>' -a content 'meta[name=description]'
check "idiom03" '<html><body><img src="/img.png" alt="Alt"></body></html>' -a alt img
check "idiom04" '<html><body><h1>Title</h1></body></html>' -t h1
check "idiom05" '<html><body><p class="article">Hi</p></body></html>' '.article'

echo ""
echo "Total: $((pass+fail))  Pass: $pass  Fail: $fail"
if [ $fail -gt 0 ]; then
  echo "Failed:"
  for d in "${failed_descs[@]}"; do
    echo "  - $d"
  done
fi
