#!/bin/bash
# Final sweep with adversarial test cases
REF=/workspace/executable
SUT=/work/work/executable

normalize() {
  sed -E 's/thread '"'"'main'"'"' \([0-9]+\)/thread main (PID)/g'
}

pass=0
fail=0
failed_descs=()

check() {
  local desc="$1"; shift
  local input="$1"; shift
  local ref_out ref_exit
  ref_out=$(printf "%s" "$input" | timeout 5 $REF "$@" 2>&1 | normalize)
  ref_exit=${PIPESTATUS[1]}
  local sut_out sut_exit
  sut_out=$(printf "%s" "$input" | timeout 5 $SUT "$@" 2>&1 | normalize)
  sut_exit=${PIPESTATUS[1]}

  if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
    pass=$((pass+1))
  else
    fail=$((fail+1))
    failed_descs+=("$desc")
    if [ "$VERBOSE" = "1" ]; then
      echo "DIFF: $desc"
      echo "  ARGS: $@"
      printf "  REF (exit %s):\n" "$ref_exit"
      printf "%s\n" "$ref_out" | head -10 | sed 's/^/    /'
      printf "  SUT (exit %s):\n" "$sut_exit"
      printf "%s\n" "$sut_out" | head -10 | sed 's/^/    /'
      echo "---"
    fi
  fi
}

# Real-world HTML
check "real page" '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Test Page</title>
</head>
<body>
<header>
<h1>Welcome</h1>
<nav><a href="/home">Home</a> | <a href="/about">About</a></nav>
</header>
<main>
<article>
<h2>Article Title</h2>
<p>This is some <em>emphasized</em> text.</p>
</article>
</main>
<footer>
<p>&copy; 2024</p>
</footer>
</body>
</html>' "h2"

check "real page links" '<!DOCTYPE html><html><body><nav><a href="/home">Home</a><a href="/about">About</a></nav></body></html>' -a href "nav a"

check "real page text" '<!DOCTYPE html><html><body><article><h1>Title</h1><p>Hello world.</p></article></body></html>' -t article

check "real page pretty" '<!DOCTYPE html><html><body><main><section><h2>Section</h2><p>Content.</p></section></main></body></html>' -p main

# Tricky inputs
check "script with selectors" '<html><body><script>var x = "<div>"</script><div>X</div></body></html>' div
check "nested script" '<html><body><div><script>x=1</script>after</div></body></html>' div
check "style content" '<html><body><style>div { color: red; }</style><div>X</div></body></html>' style

# CDATA-like content
check "html entities" '<html><body>&lt;script&gt;alert(1)&lt;/script&gt;</body></html>' body
check "numeric entities" '<html><body>&#65;&#66;&#67;</body></html>' body
check "hex entities" '<html><body>&#x41;&#x42;</body></html>' body

# Various URL bases
check "data URL base" '<html><body><a href="/x">A</a></body></html>' --base 'data:text/html,test' a
check "file URL" '<html><body><a href="/x">A</a></body></html>' --base 'file:///tmp/test' a
check "no scheme" '<html><body><a href="/x">A</a></body></html>' --base '//example.com/path' a

# Multiple combined selectors
check "many siblings" '<html><body><p>1</p><p>2</p><p>3</p><p>4</p><p>5</p></body></html>' "p:nth-child(2n)"
check "compound type+class" '<html><body><div class="x">A</div><span class="x">B</span></body></html>' "div.x"

# Document structure edge
check "deeply nested" "$(printf '<html><body>%s%s</body></html>' "$(for i in {1..10}; do printf '<div>'; done)" "X$(for i in {1..10}; do printf '</div>'; done)")" "body"

# Special characters in attrs
check "newline in attr" "$(printf '<html><body><a title=\"line1\nline2\">x</a></body></html>')" "a"
check "tab in attr" "$(printf '<html><body><a title=\"x\ty\">x</a></body></html>')" "a"

# Pretty mode edge cases
check "pretty li" '<html><body><ul><li>A</li><li>B</li></ul></body></html>' -p ul
check "pretty mixed nest" '<html><body><div><p>A<i>B</i>C</p></div></body></html>' -p div
check "pretty pre" '<html><body><pre>  formatted  text  </pre></body></html>' -p pre

# Complex -r
check "remove with pretty" '<html><body><div>K</div><script>X</script></body></html>' -p -r script -- body
check "remove cascading" '<html><body><div><span><i>X</i></span></div></body></html>' -r 'i' -- 'div'

# Tag name case sensitivity
check "uppercase tags" '<HTML><BODY><DIV>X</DIV></BODY></HTML>' div
check "mixed case" '<html><Body><Div>X</Div></Body></html>' Body
check "selector case" '<html><body><div>X</div></body></html>' "DIV"

# Multiple stages
check "html then -B" '<html><head><base href="https://b.com/p/"></head><body><a href="x">A</a></body></html>' -B -a href a
check "no base no -B" '<html><body><a href="/x">A</a></body></html>' a

# Conformance
check "br with attrs" '<html><body><br id="x"></body></html>' br
check "img with multi attrs" '<html><body><img src="x.png" alt="x" width="10"></body></html>' img

# Selectors with whitespace
check "spaces in selector" '<html><body><div><p>A</p></div></body></html>' "div   p"
check "tabs in selector" "$(printf '<html><body><div><p>A</p></div></body></html>')" "div	p"

# CSS attribute with special chars
check "attr with hyphen" '<html><body><div data-x-y="z">A</div></body></html>' '[data-x-y="z"]'
check "attr quotes mix" '<html><body><div title="a">A</div></body></html>' "div[title='a']"

# Special selectors
check "asterisk attr" '<html><body><a href="foo">A</a><b>B</b></body></html>' '*[href]'
check "type-then-class" '<html><body><span class="a">S</span><div class="a">D</div></body></html>' 'div.a'

# nth-of-type complex
check "nth-of-type 2n" '<html><body><p>A</p><div>X</div><p>B</p><div>Y</div><p>C</p></body></html>' 'p:nth-of-type(2n)'
check "nth-of-type odd" '<html><body><p>A</p><p>B</p><p>C</p></body></html>' 'p:nth-of-type(odd)'

# Multiple -r with various
check "multi -r" '<html><body><script>1</script><style>2</style><div>X</div></body></html>' -r script -r style -- body
check "many -r same" '<html><body><div>K</div><span class="x">A</span><span class="y">B</span></body></html>' -r '.x' -r '.y' -- body

# Selector edge cases that may break
check "complex selector" '<html><body><div><p class="a"><span>X</span></p></div></body></html>' 'div > p.a > span'
check "selector group multi" '<html><body><h1>1</h1><h2>2</h2><h3>3</h3></body></html>' 'h1, h2, h3'

# Empty descendants
check "select empty body" '<html><body></body></html>' body
check "select empty body -p" '<html><body></body></html>' -p body
check "select empty body -t" '<html><body></body></html>' -t body

# Whitespace handling
check "ws between tags" "$(printf '<html><body><div>A</div>\n\n<div>B</div></body></html>')" body
check "many newlines" "$(printf '<html>\n\n\n<body>\n\n<div>X</div>\n\n</body>\n\n</html>')" div

# Unicode in selector
check "unicode class" '<html><body><div class="café">A</div></body></html>' '.café'

echo ""
echo "Total: $((pass+fail))  Pass: $pass  Fail: $fail"
if [ $fail -gt 0 ]; then
  echo "Failed:"
  for d in "${failed_descs[@]}"; do
    echo "  - $d"
  done
fi
