#!/bin/sh
# Build script - we use Python so just create a wrapper executable
set -e
cd "$(dirname "$0")"
cat > executable <<'EOF'
#!/usr/bin/env python3
EOF
cat htmlq.py >> executable
chmod +x executable
