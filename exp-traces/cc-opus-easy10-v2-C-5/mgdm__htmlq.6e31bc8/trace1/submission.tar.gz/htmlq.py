import sys
import os
import re
import html as html_module
from urllib.parse import urljoin, urlparse


VERSION = "htmlq 0.4.0"

HELP_TEXT = """htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]"""


# ===========================================================================
# HTML5 parser — produces a tree
# ===========================================================================

VOID_ELEMENTS = {
    'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
    'keygen', 'link', 'meta', 'param', 'source', 'track', 'wbr',
    'basefont', 'bgsound', 'frame'
}

RAWTEXT_ELEMENTS = {'script', 'style', 'xmp', 'iframe', 'noembed', 'noframes', 'noscript', 'plaintext'}
ESCAPABLE_RAWTEXT = {'textarea', 'title'}

# Elements that, when seen, implicitly close a <p>
P_CLOSING = {
    'address', 'article', 'aside', 'blockquote', 'details', 'div', 'dl', 'fieldset',
    'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'header', 'hr', 'main', 'menu', 'nav', 'ol', 'p', 'pre', 'section', 'table', 'ul',
    'center', 'dir', 'listing', 'plaintext', 'summary', 'xmp'
}

# Elements considered "block" for pretty serialization (have explicit newlines and indent)
PRETTY_BLOCK_ELEMENTS = {
    'address', 'article', 'aside', 'blockquote', 'body', 'br', 'button', 'canvas',
    'caption', 'col', 'colgroup', 'dd', 'div', 'dl', 'dt', 'embed', 'fieldset',
    'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'head', 'header', 'hgroup', 'hr', 'html', 'iframe', 'img', 'input', 'li',
    'link', 'main', 'meta', 'nav', 'noscript', 'object', 'ol', 'optgroup',
    'option', 'p', 'param', 'pre', 'progress', 'section', 'select', 'source',
    'style', 'table', 'tbody', 'td', 'textarea', 'tfoot', 'th', 'thead', 'title',
    'tr', 'track', 'ul', 'video', 'wbr', 'script'
}


class Node:
    __slots__ = ('kind', 'name', 'attrs', 'children', 'parent', 'data', 'detached')

    def __init__(self, kind, name=None, attrs=None, data=None):
        self.kind = kind  # 'doc', 'element', 'text', 'comment'
        self.name = name
        self.attrs = attrs if attrs is not None else []  # list of (name, value) tuples preserving order
        self.children = []
        self.parent = None
        self.data = data  # text or comment data
        self.detached = False

    def append(self, child):
        if child.parent is not None:
            child.parent.children.remove(child)
        child.parent = self
        self.children.append(child)

    def detach(self):
        if self.parent is not None:
            self.parent.children.remove(self)
            self.parent = None
        self.detached = True

    def get_attr(self, name):
        for k, v in self.attrs:
            if k == name:
                return v
        return None

    def has_attr(self, name):
        return any(k == name for k, _ in self.attrs)


# HTML5 tokenizer (simplified)
class HTML5Tokenizer:
    def __init__(self, source):
        self.src = source
        self.pos = 0
        self.tokens = []

    def parse(self):
        src = self.src
        i = 0
        n = len(src)
        text_buf = []

        def flush_text():
            if text_buf:
                self.tokens.append(('text', ''.join(text_buf)))
                text_buf.clear()

        while i < n:
            c = src[i]
            if c == '<':
                # Check for comment, doctype, tag
                if src.startswith('<!--', i):
                    flush_text()
                    end = src.find('-->', i + 4)
                    if end == -1:
                        self.tokens.append(('comment', src[i+4:]))
                        i = n
                    else:
                        self.tokens.append(('comment', src[i+4:end]))
                        i = end + 3
                elif src.startswith('<!', i) or src.startswith('<!doctype', i.lower() if False else i) or src[i:i+9].lower() == '<!doctype':
                    flush_text()
                    end = src.find('>', i)
                    if end == -1:
                        i = n
                    else:
                        decl = src[i+2:end]
                        if decl.lower().startswith('doctype'):
                            self.tokens.append(('doctype', decl[7:].strip()))
                        else:
                            # Unknown declaration; ignore
                            pass
                        i = end + 1
                elif src.startswith('</', i):
                    # End tag
                    flush_text()
                    end = src.find('>', i + 2)
                    if end == -1:
                        end = n
                    name = src[i+2:end].strip().lower()
                    # Extract just tag name (no attrs in end tag, but handle)
                    name = re.match(r'^([a-zA-Z][a-zA-Z0-9]*)', name)
                    name = name.group(1).lower() if name else ''
                    self.tokens.append(('end_tag', name))
                    i = end + 1
                elif i + 1 < n and (src[i+1].isalpha() or src[i+1] == '!'):
                    # Start tag (or processing instruction-ish handled above)
                    flush_text()
                    # Find end of tag
                    j = i + 1
                    # Get tag name
                    m = re.match(r'[a-zA-Z][a-zA-Z0-9]*', src[j:])
                    if not m:
                        text_buf.append(c)
                        i += 1
                        continue
                    tag_name = m.group(0).lower()
                    j += m.end()
                    # Parse attributes
                    attrs = []
                    self_closing = False
                    while j < n:
                        # Skip whitespace
                        while j < n and src[j] in ' \t\n\r\f':
                            j += 1
                        if j >= n:
                            break
                        if src[j] == '>':
                            j += 1
                            break
                        if src[j] == '/' and j + 1 < n and src[j+1] == '>':
                            self_closing = True
                            j += 2
                            break
                        if src[j] == '/':
                            j += 1
                            continue
                        # Parse attribute name
                        am = re.match(r'[^\s/>=]+', src[j:])
                        if not am:
                            j += 1
                            continue
                        aname = am.group(0).lower()
                        j += am.end()
                        # Skip whitespace
                        while j < n and src[j] in ' \t\n\r\f':
                            j += 1
                        if j < n and src[j] == '=':
                            j += 1
                            # Skip whitespace
                            while j < n and src[j] in ' \t\n\r\f':
                                j += 1
                            if j < n and src[j] == '"':
                                # Double-quoted value
                                end_q = src.find('"', j + 1)
                                if end_q == -1:
                                    avalue = src[j+1:]
                                    j = n
                                else:
                                    avalue = src[j+1:end_q]
                                    j = end_q + 1
                            elif j < n and src[j] == "'":
                                # Single-quoted value
                                end_q = src.find("'", j + 1)
                                if end_q == -1:
                                    avalue = src[j+1:]
                                    j = n
                                else:
                                    avalue = src[j+1:end_q]
                                    j = end_q + 1
                            else:
                                # Unquoted
                                vm = re.match(r'[^\s>]*', src[j:])
                                avalue = vm.group(0) if vm else ''
                                j += len(avalue)
                        else:
                            avalue = ''
                        # Decode entities in value
                        avalue = decode_entities(avalue)
                        # Add attribute (don't duplicate)
                        if not any(k == aname for k, v in attrs):
                            attrs.append((aname, avalue))
                    self.tokens.append(('start_tag', tag_name, attrs, self_closing))
                    i = j
                    # If this is a rawtext element, consume until end tag
                    if tag_name in RAWTEXT_ELEMENTS or tag_name in ESCAPABLE_RAWTEXT:
                        end_tag = '</' + tag_name
                        # Case-insensitive search
                        lower_src = src.lower()
                        end_pos = lower_src.find(end_tag, i)
                        if end_pos == -1:
                            content = src[i:]
                            i = n
                        else:
                            content = src[i:end_pos]
                            i = end_pos
                        if tag_name in ESCAPABLE_RAWTEXT:
                            content = decode_entities(content)
                        self.tokens.append(('text', content))
                        # Now consume the end tag
                        if i < n:
                            end = src.find('>', i)
                            if end == -1:
                                end = n
                            self.tokens.append(('end_tag', tag_name))
                            i = end + 1
                else:
                    text_buf.append(c)
                    i += 1
            elif c == '&':
                # Entity reference in text
                end_amp, decoded = decode_entity_at(src, i)
                text_buf.append(decoded)
                i = end_amp
            else:
                text_buf.append(c)
                i += 1
        flush_text()
        return self.tokens


# Named entity table (subset)
NAMED_ENTITIES = {
    'amp': '&', 'lt': '<', 'gt': '>', 'quot': '"', 'apos': "'",
    'nbsp': '\xa0', 'copy': '\xa9', 'reg': '\xae', 'trade': '™',
    'hellip': '…', 'mdash': '—', 'ndash': '–',
    'lsquo': '‘', 'rsquo': '’', 'ldquo': '“', 'rdquo': '”',
}


def decode_entity_at(src, i):
    """Decode one entity reference at src[i], return (next_pos, decoded_str)."""
    # Use html.unescape — but we need to be careful with semicolon-terminated only
    # Quick approach: find max-length entity and try html.unescape
    if i + 1 >= len(src):
        return i + 1, '&'
    end = i + 1
    n = len(src)
    if src[end] == '#':
        # Numeric entity
        end += 1
        if end < n and src[end] in 'xX':
            end += 1
            while end < n and src[end] in '0123456789abcdefABCDEF':
                end += 1
        else:
            while end < n and src[end] in '0123456789':
                end += 1
        # Optional semicolon
        if end < n and src[end] == ';':
            end += 1
        ref = src[i:end]
    else:
        # Named entity
        m = re.match(r'[a-zA-Z][a-zA-Z0-9]*;?', src[end:])
        if not m:
            return i + 1, '&'
        ref_part = m.group(0)
        end = i + 1 + len(ref_part)
        ref = src[i:end]
    # Use html.unescape with the slice
    decoded = html_module.unescape(ref)
    if decoded == ref:
        # Not a valid entity
        return i + 1, '&'
    return end, decoded


def decode_entities(s):
    """Decode HTML entities in a string."""
    return html_module.unescape(s)


class HTML5Parser:
    """Simplified HTML5 tree construction."""

    def __init__(self):
        self.doc = Node('doc')
        self.stack = []  # element stack
        self.head = None
        self.body = None

    def parse(self, source):
        tokens = HTML5Tokenizer(source).parse()
        # Set up structure: doc > html > head, body
        html_node = Node('element', 'html')
        self.doc.append(html_node)
        self.stack.append(html_node)

        # Pre-create head and body so we can fill them
        head = Node('element', 'head')
        body = Node('element', 'body')
        self.head = head
        self.body = body
        # Don't attach yet; will attach when seen or implicitly

        head_inserted = False
        body_inserted = False
        in_head = False
        seen_real_html = False
        seen_real_head = False
        seen_real_body = False

        # We'll do a simple state machine.
        # State: 'initial' -> 'before-html' -> 'before-head' -> 'in-head' -> 'after-head' -> 'in-body' -> 'after-body'
        state = 'before-html'

        # Holder for tracking "seen html" and "after html" — mutable dict to share across closures
        nonlocal_holder = {'seen_html': False, 'after_html': False}

        # Track the current insertion point
        def current():
            return self.stack[-1] if self.stack else self.doc

        def ensure_html():
            nonlocal state
            nonlocal_holder['seen_html'] = True
            if state == 'before-html':
                # html already pushed
                state = 'before-head'

        def ensure_head():
            nonlocal state, head_inserted
            ensure_html()
            if state in ('before-head', 'before-html'):
                if not head_inserted:
                    html_node.append(head)
                    head_inserted = True
                self.stack.append(head)
                state = 'in-head'

        def close_head():
            nonlocal state
            if state == 'in-head':
                # Pop head from stack
                if self.stack and self.stack[-1].name == 'head':
                    self.stack.pop()
                state = 'after-head'

        def ensure_body():
            nonlocal state, body_inserted, head_inserted
            if state == 'in-head':
                close_head()
            ensure_html()
            if state in ('before-head', 'after-head', 'before-html'):
                if not head_inserted:
                    html_node.append(head)
                    head_inserted = True
                if not body_inserted:
                    html_node.append(body)
                    body_inserted = True
                self.stack.append(body)
                state = 'in-body'

        HEAD_ELEMENTS = {'base', 'basefont', 'bgsound', 'link', 'meta', 'noscript', 'script', 'style', 'template', 'title'}

        def insert_element(name, attrs, self_closing):
            nonlocal state, head_inserted, body_inserted
            if name == 'html':
                nonlocal_holder['seen_html'] = True
                # Merge attributes onto the existing html node
                for an, av in attrs:
                    if not html_node.has_attr(an):
                        html_node.attrs.append((an, av))
                ensure_html()
                return None
            if name == 'head':
                if not head_inserted:
                    html_node.append(head)
                    head_inserted = True
                # Merge attrs
                for an, av in attrs:
                    if not head.has_attr(an):
                        head.attrs.append((an, av))
                if state in ('before-head', 'before-html'):
                    self.stack.append(head)
                    state = 'in-head'
                return None
            if name == 'body':
                if state == 'in-head':
                    close_head()
                if not head_inserted:
                    html_node.append(head)
                    head_inserted = True
                if not body_inserted:
                    html_node.append(body)
                    body_inserted = True
                # Merge attrs onto body
                for an, av in attrs:
                    if not body.has_attr(an):
                        body.attrs.append((an, av))
                if state != 'in-body':
                    self.stack.append(body)
                    state = 'in-body'
                return None

            # Auto-insert head/body
            if state in ('before-html', 'before-head'):
                if name in HEAD_ELEMENTS:
                    ensure_head()
                else:
                    ensure_body()
            elif state == 'in-head':
                if name not in HEAD_ELEMENTS:
                    close_head()
                    ensure_body()
            elif state == 'after-head':
                ensure_body()

            # HTML5 spec: tr/td/th/thead/tbody/tfoot/col/colgroup/caption outside table are dropped
            TABLE_CHILD_ELEMENTS = {'tr', 'td', 'th', 'thead', 'tbody', 'tfoot', 'col', 'colgroup', 'caption'}
            if name in TABLE_CHILD_ELEMENTS:
                in_table = any(el.kind == 'element' and el.name in ('table', 'thead', 'tbody', 'tfoot', 'tr')
                               for el in self.stack)
                if not in_table:
                    # Don't insert; ignore
                    return None

            # Implicit close handling
            if name == 'li':
                self._close_to('li')
            if name in ('dt', 'dd'):
                self._close_to_set({'dt', 'dd'})
            if name in P_CLOSING:
                self._close_to('p')

            # Implicit tbody for tr inside table
            if name == 'tr':
                cur = current()
                if cur.kind == 'element' and cur.name == 'table':
                    tbody = Node('element', 'tbody')
                    cur.append(tbody)
                    self.stack.append(tbody)
            # In table context, td/th must be inside tr; create implicit tbody+tr
            if name in ('td', 'th'):
                cur = current()
                if cur.kind == 'element' and cur.name == 'table':
                    tbody = Node('element', 'tbody')
                    cur.append(tbody)
                    self.stack.append(tbody)
                    tr = Node('element', 'tr')
                    tbody.append(tr)
                    self.stack.append(tr)

            node = Node('element', name, attrs)
            cur = current()
            cur.append(node)
            if name not in VOID_ELEMENTS and not self_closing:
                self.stack.append(node)
            return node

        def insert_text(text):
            cur = current()
            if state == 'in-head':
                # If current is an in-head element (like title), put text there
                if cur.name != 'head':
                    self._append_text(cur, text)
                    return
                # Whitespace stays in head; non-whitespace switches to body
                if text.strip() == '':
                    self._append_text(cur, text)
                else:
                    # Move to body
                    close_head()
                    ensure_body()
                    cur = current()
                    self._append_text(cur, text)
            elif state in ('before-html', 'before-head'):
                if text.strip() == '':
                    # Ignore leading whitespace
                    return
                ensure_body()
                cur = current()
                self._append_text(cur, text)
            elif state == 'after-head':
                if text.strip() == '':
                    self._append_text(cur, text)
                else:
                    ensure_body()
                    cur = current()
                    self._append_text(cur, text)
            else:
                # in-body or other
                if cur.name == 'html':
                    # text shouldn't be in html directly; move to body
                    ensure_body()
                    cur = current()
                self._append_text(cur, text)

        def insert_comment(data):
            # Drop comments before any <html> tag and after </html>
            if not nonlocal_holder['seen_html']:
                return
            if nonlocal_holder['after_html']:
                return
            node = Node('comment', data=data)
            cur = current()
            cur.append(node)

        for token in tokens:
            if token[0] == 'doctype':
                # Drop doctype
                continue
            elif token[0] == 'comment':
                insert_comment(token[1])
            elif token[0] == 'text':
                insert_text(token[1])
            elif token[0] == 'start_tag':
                _, name, attrs, self_closing = token
                insert_element(name, attrs, self_closing)
            elif token[0] == 'end_tag':
                _, name = token
                if name == 'html':
                    nonlocal_holder['after_html'] = True
                    # Close everything except html itself; mode goes to after-body
                    while len(self.stack) > 1:
                        self.stack.pop()
                elif name == 'body':
                    if state == 'in-body':
                        # Close all in body
                        while self.stack and self.stack[-1].name != 'body':
                            self.stack.pop()
                        if self.stack and self.stack[-1].name == 'body':
                            self.stack.pop()
                        state = 'after-body'
                elif name == 'head':
                    if state == 'in-head':
                        close_head()
                else:
                    # Pop until matching tag
                    found = False
                    for k in range(len(self.stack) - 1, -1, -1):
                        if self.stack[k].name == name:
                            # Pop everything down to and including this
                            del self.stack[k:]
                            found = True
                            break
                    # If not found and tag is <p>: HTML5 spec says insert empty <p></p>
                    if not found and name == 'p' and state == 'in-body':
                        empty_p = Node('element', 'p')
                        cur = current()
                        cur.append(empty_p)

        # Final: ensure head and body exist
        if not head_inserted:
            html_node.append(head)
            head_inserted = True
        if not body_inserted:
            html_node.append(body)
            body_inserted = True

        return self.doc

    def _close_to(self, name):
        """Pop stack until and including element with given name (if found)."""
        for k in range(len(self.stack) - 1, -1, -1):
            if self.stack[k].name == name:
                del self.stack[k:]
                return

    def _close_to_set(self, names):
        for k in range(len(self.stack) - 1, -1, -1):
            if self.stack[k].name in names:
                del self.stack[k:]
                return

    def _append_text(self, parent, text):
        if parent.children and parent.children[-1].kind == 'text':
            parent.children[-1].data += text
        else:
            tn = Node('text', data=text)
            parent.append(tn)


# ===========================================================================
# CSS selector engine (subset)
# ===========================================================================


class Selector:
    """A compound selector (simple selectors joined with combinators)."""
    def __init__(self):
        self.parts = []  # list of (combinator, compound) tuples; first has combinator=None


class Compound:
    """A compound selector — multiple simple parts that all must match."""
    def __init__(self):
        self.element = None  # tag name or '*' or None
        self.id = None
        self.classes = []
        self.attrs = []  # list of (name, op, value) tuples
        self.pseudos = []  # list of (name, arg)


def parse_css_selector(text):
    """Parse a CSS selector list. Returns a list of Selector (one per group)."""
    text = text.strip()
    if not text:
        raise ValueError("empty selector")
    # Split on top-level commas
    groups = split_top_level(text, ',')
    if not groups:
        raise ValueError("no groups")
    result = []
    for g in groups:
        g = g.strip()
        if not g:
            raise ValueError("empty group")
        result.append(parse_selector(g))
    return result


def split_top_level(text, sep):
    """Split text by sep but respecting nested brackets/parens."""
    parts = []
    depth_bracket = 0
    depth_paren = 0
    in_str = None
    start = 0
    i = 0
    while i < len(text):
        c = text[i]
        if in_str:
            if c == '\\':
                i += 2
                continue
            if c == in_str:
                in_str = None
        else:
            if c in '"\'':
                in_str = c
            elif c == '[':
                depth_bracket += 1
            elif c == ']':
                depth_bracket -= 1
            elif c == '(':
                depth_paren += 1
            elif c == ')':
                depth_paren -= 1
            elif c == sep and depth_bracket == 0 and depth_paren == 0:
                parts.append(text[start:i])
                start = i + 1
        i += 1
    parts.append(text[start:])
    return parts


def parse_selector(text):
    """Parse a single selector (no commas). Returns a Selector."""
    sel = Selector()
    # Tokenize compounds separated by combinators
    # Combinators: ' ', '>', '+', '~'
    i = 0
    n = len(text)
    parts = []  # list of (combinator, compound_text)
    current_combinator = None  # first one
    while i < n:
        # Skip leading whitespace (but only between compounds)
        ws_start = i
        while i < n and text[i] in ' \t\n':
            i += 1
        ws_seen = i > ws_start
        if i >= n:
            break
        c = text[i]
        if c in '>+~':
            i += 1
            # Skip whitespace
            while i < n and text[i] in ' \t\n':
                i += 1
            combinator = c
            # Parse compound
            cstart = i
            while i < n and text[i] not in ' \t\n>+~':
                if text[i] == '[':
                    # Skip bracket group
                    depth = 1
                    i += 1
                    while i < n and depth > 0:
                        if text[i] == '[': depth += 1
                        elif text[i] == ']': depth -= 1
                        i += 1
                elif text[i] == '(':
                    depth = 1
                    i += 1
                    while i < n and depth > 0:
                        if text[i] == '(': depth += 1
                        elif text[i] == ')': depth -= 1
                        i += 1
                else:
                    i += 1
            compound_text = text[cstart:i]
            parts.append((combinator, compound_text))
        else:
            # Parse compound (possibly first compound, possibly descendant)
            if parts and ws_seen:
                combinator = ' '  # descendant
            else:
                combinator = None  # first compound
            cstart = i
            while i < n and text[i] not in ' \t\n>+~':
                if text[i] == '[':
                    depth = 1
                    i += 1
                    while i < n and depth > 0:
                        if text[i] == '[': depth += 1
                        elif text[i] == ']': depth -= 1
                        i += 1
                elif text[i] == '(':
                    depth = 1
                    i += 1
                    while i < n and depth > 0:
                        if text[i] == '(': depth += 1
                        elif text[i] == ')': depth -= 1
                        i += 1
                else:
                    i += 1
            compound_text = text[cstart:i]
            parts.append((combinator, compound_text))

    for combinator, ctext in parts:
        comp = parse_compound(ctext)
        sel.parts.append((combinator, comp))
    return sel


def parse_compound(text):
    """Parse a compound selector (no combinators)."""
    if not text:
        raise ValueError("empty compound selector")
    comp = Compound()
    i = 0
    n = len(text)
    # First token can be a tag name or *
    if i < n and (text[i].isalpha() or text[i] == '*'):
        if text[i] == '*':
            comp.element = '*'
            i += 1
        else:
            j = i
            while j < n and (text[j].isalnum() or text[j] in '-_'):
                j += 1
            comp.element = text[i:j].lower()
            i = j
    saw_anything = (comp.element is not None)
    while i < n:
        c = text[i]
        if c == '#':
            i += 1
            j = i
            while j < n and (text[j].isalnum() or text[j] in '-_'):
                j += 1
            if i == j:
                raise ValueError(f"empty id in selector: {text!r}")
            comp.id = text[i:j]
            i = j
            saw_anything = True
        elif c == '.':
            i += 1
            j = i
            while j < n and (text[j].isalnum() or text[j] in '-_'):
                j += 1
            if i == j:
                raise ValueError(f"empty class in selector: {text!r}")
            comp.classes.append(text[i:j])
            i = j
            saw_anything = True
        elif c == '[':
            end = i + 1
            depth = 1
            while end < n and depth > 0:
                if text[end] == '[':
                    depth += 1
                elif text[end] == ']':
                    depth -= 1
                end += 1
            attr_text = text[i+1:end-1]
            comp.attrs.append(parse_attr_selector(attr_text))
            i = end
            saw_anything = True
        elif c == ':':
            i += 1
            j = i
            while j < n and (text[j].isalnum() or text[j] in '-_'):
                j += 1
            if i == j:
                raise ValueError(f"empty pseudo in selector: {text!r}")
            pname = text[i:j].lower()
            i = j
            arg = None
            if i < n and text[i] == '(':
                depth = 1
                end = i + 1
                while end < n and depth > 0:
                    if text[end] == '(':
                        depth += 1
                    elif text[end] == ')':
                        depth -= 1
                    end += 1
                arg = text[i+1:end-1]
                i = end
            comp.pseudos.append((pname, arg))
            saw_anything = True
        else:
            raise ValueError(f"unexpected char {c!r} in selector: {text!r}")
    if not saw_anything:
        raise ValueError("empty selector")
    return comp


def parse_attr_selector(text):
    """Parse an attribute selector body (without []).
    Forms:
      name
      name=value
      name~=value
      name|=value
      name^=value
      name$=value
      name*=value
    """
    text = text.strip()
    # Find operator
    ops = ['~=', '|=', '^=', '$=', '*=', '=']
    op_pos = -1
    op_used = None
    for op in ops:
        p = text.find(op)
        if p != -1 and (op_pos == -1 or p < op_pos):
            op_pos = p
            op_used = op
    if op_pos == -1:
        return (text.strip().lower(), None, None)
    name = text[:op_pos].strip().lower()
    value = text[op_pos + len(op_used):].strip()
    # Strip optional case-insensitive flag " i" or " s"
    if value.endswith(' i') or value.endswith(' I'):
        value = value[:-2].strip()
    elif value.endswith(' s') or value.endswith(' S'):
        value = value[:-2].strip()
    if value.startswith('"') and value.endswith('"'):
        value = value[1:-1]
    elif value.startswith("'") and value.endswith("'"):
        value = value[1:-1]
    return (name, op_used, value)


def matches_compound(node, comp):
    if node.kind != 'element':
        return False
    if comp.element and comp.element != '*' and node.name != comp.element:
        return False
    if comp.id:
        if node.get_attr('id') != comp.id:
            return False
    for cls in comp.classes:
        node_class = node.get_attr('class') or ''
        classes = node_class.split()
        if cls not in classes:
            return False
    for name, op, value in comp.attrs:
        actual = node.get_attr(name)
        if op is None:
            if actual is None:
                return False
        else:
            if actual is None:
                return False
            if op == '=':
                if actual != value:
                    return False
            elif op == '~=':
                if value not in actual.split():
                    return False
            elif op == '|=':
                if actual != value and not actual.startswith(value + '-'):
                    return False
            elif op == '^=':
                if not actual.startswith(value):
                    return False
            elif op == '$=':
                if not actual.endswith(value):
                    return False
            elif op == '*=':
                if value not in actual:
                    return False
    for pname, arg in comp.pseudos:
        if not match_pseudo(node, pname, arg):
            return False
    return True


def get_element_siblings(node):
    """Return list of element siblings (including self) of node."""
    if node.parent is None:
        return [node]
    return [c for c in node.parent.children if c.kind == 'element']


def get_element_index(node):
    """Index of node among its element siblings, 1-based."""
    sibs = get_element_siblings(node)
    return sibs.index(node) + 1


def parse_nth(arg):
    """Parse nth-child argument like '2n+1', 'odd', 'even', '3'.
    Returns (a, b) for an+b."""
    arg = arg.strip().lower()
    if arg == 'odd':
        return (2, 1)
    if arg == 'even':
        return (2, 0)
    # Match an+b
    m = re.match(r'^([+-]?\d*)n\s*([+-]\s*\d+)?$', arg)
    if m:
        a_str = m.group(1)
        if a_str in ('', '+'):
            a = 1
        elif a_str == '-':
            a = -1
        else:
            a = int(a_str)
        b_str = m.group(2)
        if b_str:
            b = int(b_str.replace(' ', ''))
        else:
            b = 0
        return (a, b)
    # Match just a number
    m = re.match(r'^[+-]?\d+$', arg)
    if m:
        return (0, int(arg))
    return None


def nth_match(a, b, n):
    """Check if n matches an+b for some non-negative integer."""
    if a == 0:
        return n == b
    diff = n - b
    if a > 0:
        return diff >= 0 and diff % a == 0
    else:
        return diff <= 0 and diff % a == 0


def match_pseudo(node, pname, arg):
    if pname == 'first-child':
        sibs = get_element_siblings(node)
        return sibs and sibs[0] is node
    if pname == 'last-child':
        sibs = get_element_siblings(node)
        return sibs and sibs[-1] is node
    if pname == 'only-child':
        sibs = get_element_siblings(node)
        return len(sibs) == 1 and sibs[0] is node
    if pname == 'first-of-type':
        if node.parent is None:
            return True
        for c in node.parent.children:
            if c.kind == 'element' and c.name == node.name:
                return c is node
        return False
    if pname == 'last-of-type':
        if node.parent is None:
            return True
        result_node = None
        for c in node.parent.children:
            if c.kind == 'element' and c.name == node.name:
                result_node = c
        return result_node is node
    if pname == 'only-of-type':
        if node.parent is None:
            return True
        same = [c for c in node.parent.children if c.kind == 'element' and c.name == node.name]
        return len(same) == 1 and same[0] is node
    if pname == 'nth-child':
        ab = parse_nth(arg) if arg else None
        if ab is None:
            return False
        n = get_element_index(node)
        return nth_match(ab[0], ab[1], n)
    if pname == 'nth-last-child':
        ab = parse_nth(arg) if arg else None
        if ab is None:
            return False
        sibs = get_element_siblings(node)
        n = len(sibs) - sibs.index(node)
        return nth_match(ab[0], ab[1], n)
    if pname == 'nth-of-type':
        ab = parse_nth(arg) if arg else None
        if ab is None:
            return False
        if node.parent is None:
            n = 1
        else:
            same = [c for c in node.parent.children if c.kind == 'element' and c.name == node.name]
            try:
                n = same.index(node) + 1
            except ValueError:
                return False
        return nth_match(ab[0], ab[1], n)
    if pname == 'nth-last-of-type':
        ab = parse_nth(arg) if arg else None
        if ab is None:
            return False
        if node.parent is None:
            n = 1
        else:
            same = [c for c in node.parent.children if c.kind == 'element' and c.name == node.name]
            try:
                n = len(same) - same.index(node)
            except ValueError:
                return False
        return nth_match(ab[0], ab[1], n)
    if pname == 'empty':
        return all(c.kind == 'comment' for c in node.children) and not any(c.kind in ('text', 'element') for c in node.children)
    if pname == 'root':
        return node.name == 'html' and node.parent is not None and node.parent.kind == 'doc'
    if pname == 'not':
        if not arg:
            return False
        try:
            subsel = parse_css_selector(arg)
        except Exception:
            return False
        return not any(matches_selector(node, s) for s in subsel)
    if pname == 'is':
        if not arg:
            return False
        try:
            subsel = parse_css_selector(arg)
        except Exception:
            return False
        return any(matches_selector(node, s) for s in subsel)
    if pname == 'where':
        return match_pseudo(node, 'is', arg)
    if pname == 'scope':
        return node.name == 'html'
    if pname == 'link':
        return node.name in ('a', 'area') and node.has_attr('href')
    if pname == 'any-link':
        return node.name in ('a', 'area') and node.has_attr('href')
    # Pseudo-elements like ::before — treat as no match (silently)
    # Unrecognized: raise error to mimic parse failure
    raise ValueError(f"unknown pseudo {pname}")


def matches_selector(node, sel):
    """Check if node matches the (full) selector (with combinators)."""
    if not sel.parts:
        return False
    # Match from last compound back to first
    return _matches_at(node, sel.parts, len(sel.parts) - 1)


def _matches_at(node, parts, idx):
    """node matches the compound at parts[idx], and considering combinators back, parts[idx-1] applies to ancestor."""
    combinator, comp = parts[idx]
    if not matches_compound(node, comp):
        return False
    if idx == 0:
        return True
    prev_combinator, prev_comp = parts[idx]
    # The combinator to the LEFT tells how to find the previous match
    left_combinator = parts[idx][0]  # This is the combinator preceding this compound
    if left_combinator == ' ':
        # Any ancestor must match
        anc = node.parent
        while anc is not None and anc.kind == 'element':
            if _matches_at(anc, parts, idx - 1):
                return True
            anc = anc.parent
        return False
    if left_combinator == '>':
        # Direct parent must match
        if node.parent is None or node.parent.kind != 'element':
            return False
        return _matches_at(node.parent, parts, idx - 1)
    if left_combinator == '+':
        # Previous element sibling must match
        if node.parent is None:
            return False
        prev = None
        for c in node.parent.children:
            if c is node:
                break
            if c.kind == 'element':
                prev = c
        if prev is None:
            return False
        return _matches_at(prev, parts, idx - 1)
    if left_combinator == '~':
        # Any prior element sibling must match
        if node.parent is None:
            return False
        for c in node.parent.children:
            if c is node:
                return False
            if c.kind == 'element':
                if _matches_at(c, parts, idx - 1):
                    return True
        return False
    return False


def find_all_matching(root, selector_list):
    """Find all nodes matching the selector list (group) in document order."""
    result = []
    visited = set()
    def walk(node):
        if node.kind == 'element':
            for sel in selector_list:
                if matches_selector(node, sel):
                    if id(node) not in visited:
                        visited.add(id(node))
                        result.append(node)
                    break
        for child in list(node.children):
            walk(child)
    walk(root)
    return result


# ===========================================================================
# Serializer
# ===========================================================================


def escape_text(s):
    """Escape text content: & < >"""
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def escape_attr(s):
    """Escape attribute value: & " (and \xa0 maybe)"""
    return s.replace('&', '&amp;').replace('"', '&quot;').replace('\xa0', '&nbsp;')


def serialize_node(node, base=None):
    """Serialize a single node to HTML string."""
    out = []
    _serialize_node(node, out, base)
    return ''.join(out)


def _serialize_node(node, out, base=None):
    if node.kind == 'text':
        # If parent is rawtext element, don't escape
        parent = node.parent
        if parent and parent.kind == 'element' and parent.name in RAWTEXT_ELEMENTS:
            out.append(node.data or '')
        else:
            out.append(escape_text(node.data or ''))
    elif node.kind == 'comment':
        out.append('<!--')
        out.append(node.data or '')
        out.append('-->')
    elif node.kind == 'element':
        out.append('<')
        out.append(node.name)
        # Output attributes alphabetically
        attrs = sorted(node.attrs, key=lambda kv: kv[0])
        for k, v in attrs:
            # Apply base URL rewriting if applicable
            if base is not None and node.name in ('a', 'link', 'area') and k == 'href':
                v = resolve_url(base, v)
            out.append(' ')
            out.append(k)
            out.append('="')
            out.append(escape_attr(v))
            out.append('"')
        out.append('>')
        if node.name in VOID_ELEMENTS:
            return
        for child in node.children:
            _serialize_node(child, out, base)
        out.append('</')
        out.append(node.name)
        out.append('>')


def resolve_url(base, url):
    """Resolve url against base URL. If base is invalid or relative, return url unchanged.
    Matches the Rust `url` crate behavior."""
    if not base or url is None:
        return url
    try:
        parsed_base = urlparse(base)
        if not parsed_base.scheme:
            return url
        # If base has no `://` (cannot-be-a-base URL like data:, mailto:),
        # joining typically returns the base for path-like refs (only fragments work).
        if '://' not in base:
            if url.startswith('#'):
                if '#' in base:
                    return base.split('#', 1)[0] + url
                return base + url
            return base  # Match Rust url crate
        # Has scheme + ://, so it's "special" or file-like URL; use urljoin
        normalized_base = base
        if parsed_base.path == '' and parsed_base.netloc:
            normalized_base = base + '/'
        result = urljoin(normalized_base, url)
        # If result has netloc but no path, ensure trailing slash
        result_parsed = urlparse(result)
        if result_parsed.netloc and result_parsed.path == '' and not result_parsed.query and not result_parsed.fragment:
            result = result + '/'
        elif result_parsed.netloc and result_parsed.path == '' and (result_parsed.query or result_parsed.fragment):
            from urllib.parse import urlunparse
            result = urlunparse((result_parsed.scheme, result_parsed.netloc, '/', result_parsed.params, result_parsed.query, result_parsed.fragment))
        return result
    except Exception:
        return url


# ===========================================================================
# Pretty serializer
# ===========================================================================

INLINE_NAMES = {
    'a', 'abbr', 'b', 'bdi', 'bdo', 'cite', 'code', 'data', 'dfn', 'em',
    'i', 'kbd', 'mark', 'q', 'rp', 'rt', 'ruby', 's', 'samp', 'small',
    'span', 'strong', 'sub', 'sup', 'time', 'u', 'var',
    'wbr', 'noscript',
    'script',  # observed: script behaves as inline in pretty mode
    'noembed',
    'object', 'output', 'progress',
    'label', 'select', 'input', 'textarea', 'button',
    'font', 'big', 'tt', 'strike',
    'img',
    'ins', 'del',
    'svg', 'math',
}


def is_block(name):
    """Check if element name should be pretty-printed as block."""
    return name not in INLINE_NAMES


class PrettyState:
    def __init__(self):
        self.block_just_closed = False


def serialize_pretty(node, base=None):
    """Pretty-print serialize a node. Returns string with leading newline."""
    out = []
    state = PrettyState()
    # Root: emit at indent 0. The "child_indent" passed to _pretty is the indent of THIS element.
    _pretty(node, out, 0, state, base, is_root=True)
    return ''.join(out)


def _pretty(node, out, indent, state, base, is_root=False):
    """Render `node`.
    - indent: the indent level at which THIS node should be rendered.
    """
    if node.kind == 'text':
        text = node.data or ''
        parent = node.parent
        if parent and parent.kind == 'element' and parent.name in RAWTEXT_ELEMENTS:
            escaped = text
        else:
            escaped = escape_text(text)
        if state.block_just_closed:
            out.append('\n')
            out.append('  ' * indent)
            state.block_just_closed = False
        out.append(escaped)
        return
    if node.kind == 'comment':
        # Comments don't consume the state and don't emit newlines
        out.append('<!--')
        out.append(node.data or '')
        out.append('-->')
        return
    if node.kind == 'element':
        name = node.name
        block = is_block(name)
        if block:
            # Block: emit newline + indent before opening tag
            if is_root:
                out.append('\n')
            else:
                out.append('\n')
                out.append('  ' * indent)
            # Block opens do NOT clear block_just_closed (it persists for inner text)
        else:
            # Inline: if block_just_closed, emit newline + indent
            if state.block_just_closed:
                out.append('\n')
                out.append('  ' * indent)
                # Don't clear — inline open doesn't consume the flag
        out.append('<')
        out.append(name)
        attrs = sorted(node.attrs, key=lambda kv: kv[0])
        for k, v in attrs:
            if base is not None and node.name in ('a', 'link', 'area') and k == 'href':
                v = resolve_url(base, v)
            out.append(' ')
            out.append(k)
            out.append('="')
            out.append(escape_attr(v))
            out.append('"')
        out.append('>')
        if name in VOID_ELEMENTS:
            if block:
                # Void block: emit newline + indent (close-phantom at same indent as open)
                out.append('\n')
                out.append('  ' * indent)
                state.block_just_closed = True
            return
        # Children (at indent + 1)
        for child in node.children:
            _pretty(child, out, indent + 1, state, base, is_root=False)
        # Close tag
        if block:
            out.append('\n')
            out.append('  ' * indent)
            out.append('</')
            out.append(name)
            out.append('>')
            state.block_just_closed = True
        else:
            out.append('</')
            out.append(name)
            out.append('>')


# ===========================================================================
# CLI parsing
# ===========================================================================


def parse_args(argv):
    """Parse CLI args. Returns dict of options or raises SystemExit on error/help/version."""
    args = {
        'help': False,
        'version': False,
        'text': False,
        'ignore_whitespace': False,
        'pretty': False,
        'detect_base': False,
        'attribute': None,
        'base': None,
        'filename': None,
        'output': None,
        'remove_nodes': [],
        'selectors': [],
    }
    i = 0
    seen_dashdash = False
    n = len(argv)
    while i < n:
        a = argv[i]
        if seen_dashdash:
            args['selectors'].append(a)
            i += 1
            continue
        if a == '--':
            seen_dashdash = True
            i += 1
            continue
        if a == '-h' or a == '--help':
            args['help'] = True
            i += 1
            continue
        if a == '-V' or a == '--version':
            args['version'] = True
            i += 1
            continue
        if a == '-t' or a == '--text':
            args['text'] = True
            i += 1
            continue
        if a == '-w' or a == '--ignore-whitespace':
            args['ignore_whitespace'] = True
            i += 1
            continue
        if a == '-p' or a == '--pretty':
            args['pretty'] = True
            i += 1
            continue
        if a == '-B' or a == '--detect-base':
            args['detect_base'] = True
            i += 1
            continue
        # Combined short flags?
        if re.match(r'^-[hVtwpB]+$', a) and a != '-h' and a != '-V':
            for ch in a[1:]:
                if ch == 'h': args['help'] = True
                elif ch == 'V': args['version'] = True
                elif ch == 't': args['text'] = True
                elif ch == 'w': args['ignore_whitespace'] = True
                elif ch == 'p': args['pretty'] = True
                elif ch == 'B': args['detect_base'] = True
            i += 1
            continue
        # Options with values
        if a == '-a' or a == '--attribute':
            if i + 1 >= n:
                cli_error_missing_value("--attribute <attribute>")
            args['attribute'] = argv[i+1]
            i += 2
            continue
        if a.startswith('--attribute='):
            args['attribute'] = a[len('--attribute='):]
            i += 1
            continue
        if a == '-b' or a == '--base':
            if i + 1 >= n:
                cli_error_missing_value("--base <base>")
            args['base'] = argv[i+1]
            i += 2
            continue
        if a.startswith('--base='):
            args['base'] = a[len('--base='):]
            i += 1
            continue
        if a == '-f' or a == '--filename':
            if i + 1 >= n:
                cli_error_missing_value("--filename <FILE>")
            args['filename'] = argv[i+1]
            i += 2
            continue
        if a.startswith('--filename='):
            args['filename'] = a[len('--filename='):]
            i += 1
            continue
        if a == '-o' or a == '--output':
            if i + 1 >= n:
                cli_error_missing_value("--output <FILE>")
            args['output'] = argv[i+1]
            i += 2
            continue
        if a.startswith('--output='):
            args['output'] = a[len('--output='):]
            i += 1
            continue
        if a == '-r' or a == '--remove-nodes':
            i += 1
            if i >= n:
                cli_error_missing_value("--remove-nodes <SELECTOR>...")
            # Takes exactly one value (despite the <SELECTOR>... in help — that means it can be repeated)
            args['remove_nodes'].append(argv[i])
            i += 1
            continue
        if a.startswith('--remove-nodes='):
            args['remove_nodes'].append(a[len('--remove-nodes='):])
            i += 1
            continue
        if a.startswith('-') and a != '-' and len(a) > 1:
            cli_error(f"Found argument '{a}' which wasn't expected, or isn't valid in this context")
        # Positional
        args['selectors'].append(a)
        i += 1
    return args


def cli_error(msg):
    sys.stderr.write(f"error: {msg}\n\n")
    sys.stderr.write("USAGE:\n")
    sys.stderr.write("    executable [FLAGS] [OPTIONS] [--] [selector]...\n\n")
    sys.stderr.write("For more information try --help\n")
    sys.exit(1)


def cli_error_missing_value(opt_spec):
    """Emit error in clap-style format for missing option value."""
    sys.stderr.write(f"error: The argument '{opt_spec}' requires a value but none was supplied\n\n")
    sys.stderr.write("USAGE:\n")
    # Extract just the option part for the usage line
    sys.stderr.write(f"    executable {opt_spec}\n\n")
    sys.stderr.write("For more information try --help\n")
    sys.exit(1)


# ===========================================================================
# Main
# ===========================================================================


def main():
    argv = sys.argv[1:]
    try:
        args = parse_args(argv)
    except SystemExit:
        raise

    if args['help']:
        sys.stdout.write(HELP_TEXT + "\n")
        return 0
    if args['version']:
        sys.stdout.write(VERSION + "\n")
        return 0

    # Read input
    if args['filename']:
        try:
            with open(args['filename'], 'rb') as f:
                input_bytes = f.read()
        except OSError as e:
            # Match the Rust panic format
            kind = 'NotFound' if isinstance(e, FileNotFoundError) else 'Other'
            code = e.errno if e.errno else 0
            sys.stderr.write(f"\nthread 'main' ({os.getpid()}) panicked at src/main.rs:196:37:\n")
            sys.stderr.write(f'should have opened input file: Os {{ code: {code}, kind: {kind}, message: "{e.strerror}" }}\n')
            sys.stderr.write("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n")
            sys.exit(101)
    else:
        input_bytes = sys.stdin.buffer.read()

    # Decode
    try:
        source = input_bytes.decode('utf-8')
    except UnicodeDecodeError:
        source = input_bytes.decode('utf-8', errors='replace')

    # Parse
    parser = HTML5Parser()
    doc = parser.parse(source)

    # Determine selector
    if args['selectors']:
        selector_text = ' '.join(args['selectors'])
    else:
        selector_text = 'html'

    # Parse selectors
    try:
        selector_list = parse_css_selector(selector_text)
    except Exception:
        sys.stderr.write(f"\nthread 'main' ({os.getpid()}) panicked at src/main.rs:221:10:\n")
        sys.stderr.write("Failed to parse CSS selector: ()\n")
        sys.stderr.write("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n")
        sys.exit(101)

    # Find removal matches first (don't detach yet — we need to compute "has removed in subtree" first)
    removed_nodes = set()
    if args['remove_nodes']:
        for rsel_text in args['remove_nodes']:
            try:
                rsel_list = parse_css_selector(rsel_text)
            except Exception:
                sys.stderr.write(f"\nthread 'main' ({os.getpid()}) panicked at src/main.rs:221:10:\n")
                sys.stderr.write("Failed to parse CSS selector: ()\n")
                sys.stderr.write("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n")
                sys.exit(101)
            matches = find_all_matching(doc, rsel_list)
            for m in matches:
                removed_nodes.add(id(m))

    # Find selected from unmodified document
    selected = find_all_matching(doc, selector_list)

    # Compute per-selected the "has removed in subtree" flag BEFORE detach
    selected_has_removed = [has_removed_in_subtree(s, removed_nodes) for s in selected]

    # Now detach the removed nodes
    if args['remove_nodes']:
        for rsel_text in args['remove_nodes']:
            try:
                rsel_list = parse_css_selector(rsel_text)
                matches = find_all_matching(doc, rsel_list)
                for m in matches:
                    m.detach()
            except Exception:
                pass

    # Determine base URL
    base = None
    if args['detect_base']:
        # Find <base href> in document
        try:
            base_sel = parse_css_selector('base')
            bases = find_all_matching(doc, base_sel)
            if bases:
                href = bases[0].get_attr('href')
                if href:
                    base = href
        except Exception:
            pass
    if base is None and args['base']:
        base = args['base']

    # Validate base URL (must have a scheme to be considered absolute)
    if base:
        try:
            parsed = urlparse(base)
            if not parsed.scheme:
                base = None
        except Exception:
            base = None

    # Output
    if args['output']:
        out_stream = open(args['output'], 'wb')
        close_out = True
    else:
        out_stream = sys.stdout.buffer
        close_out = False

    # Track "stop iteration" for -r interaction
    # Behavior observed: if any -r match is in the subtree of a selected element (or is itself),
    # iteration over selected elements stops at that element (output includes elements before it
    # but not the failing one or any after).
    # Exception: when selected element IS the -r match (was detached), it IS output, then stop.

    try:
        for idx, sel_node in enumerate(selected):
            # Check for -r stop/skip condition BEFORE outputting
            if args['remove_nodes']:
                if selected_has_removed[idx]:
                    break
            # Mode priority: -a > -t > -p > default
            if args['attribute']:
                output_attribute(sel_node, args['attribute'], base, out_stream)
            elif args['text']:
                output_text(sel_node, args['ignore_whitespace'], out_stream)
            elif args['pretty']:
                s = serialize_pretty(sel_node, base)
                out_stream.write(s.encode('utf-8'))
                out_stream.write(b'\n')
            else:
                s = serialize_node(sel_node, base)
                out_stream.write(s.encode('utf-8'))
                out_stream.write(b'\n')
    finally:
        if close_out:
            out_stream.close()
        else:
            out_stream.flush()

    return 0


def has_removed_descendant(node, removed_ids):
    """Check if node or any descendant has id in removed_ids."""
    if id(node) in removed_ids:
        return True
    for child in node.children:
        if has_removed_descendant(child, removed_ids):
            return True
    return False


def has_removed_in_subtree(node, removed_ids):
    """Check if node itself or any descendant is in removed_ids.
    This checks the ORIGINAL subtree (before detach), since we collected removed_ids
    before detaching. Walking node.children works because detach only modifies parent's
    child list, not the detached node's own children."""
    if id(node) in removed_ids:
        return True
    for child in node.children:
        if has_removed_in_subtree(child, removed_ids):
            return True
    return False


def output_text(node, ignore_ws, out_stream):
    """Output text content of node."""
    if ignore_ws:
        # For each text node descendant, if not whitespace-only, output text + \n
        # Then \n after each element
        for text in iter_text_nodes(node):
            if text.strip():
                out_stream.write(text.encode('utf-8'))
                out_stream.write(b'\n')
        out_stream.write(b'\n')
    else:
        # Concatenate all text content
        parts = []
        for text in iter_text_nodes(node):
            parts.append(text)
        result = ''.join(parts)
        out_stream.write(result.encode('utf-8'))
        out_stream.write(b'\n')


def iter_text_nodes(node):
    """Iterate text content of node and all descendants."""
    if node.kind == 'text':
        yield node.data or ''
        return
    if node.kind == 'element':
        for child in node.children:
            yield from iter_text_nodes(child)


def output_attribute(node, attr_name, base, out_stream):
    """Output attribute value if present."""
    v = node.get_attr(attr_name)
    if v is None:
        return
    if base and node.name in ('a', 'link', 'area') and attr_name == 'href':
        v = resolve_url(base, v)
    out_stream.write(v.encode('utf-8'))
    out_stream.write(b'\n')


if __name__ == '__main__':
    sys.exit(main())
