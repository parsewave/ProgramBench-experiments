#!/bin/bash
# Extended differential test driver
REF=/workspace/executable
SUT=/work/work/executable

normalize() {
  sed -E 's/thread '"'"'main'"'"' \([0-9]+\)/thread main (PID)/g'
}

pass=0
fail=0
failed_descs=()

check() {
  local desc="$1"; shift
  local input="$1"; shift
  local ref_out ref_exit
  ref_out=$(printf "%s" "$input" | timeout 5 $REF "$@" 2>&1 | normalize)
  ref_exit=${PIPESTATUS[1]}
  local sut_out sut_exit
  sut_out=$(printf "%s" "$input" | timeout 5 $SUT "$@" 2>&1 | normalize)
  sut_exit=${PIPESTATUS[1]}

  if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
    pass=$((pass+1))
  else
    fail=$((fail+1))
    failed_descs+=("$desc")
    if [ "$VERBOSE" = "1" ]; then
      echo "DIFF: $desc"
      echo "  ARGS: $@"
      echo "  REF (exit $ref_exit): $(printf "%s" "$ref_out" | head -5)"
      echo "  SUT (exit $sut_exit): $(printf "%s" "$sut_out" | head -5)"
      echo "---"
    fi
  fi
}

# Pretty mode comprehensive
check "pretty body" '<html><body>X</body></html>' "-p" "body"
check "pretty nested 2p" '<html><body><div><p>A</p><p>B</p></div></body></html>' "-p" "div"
check "pretty 3p" '<html><body><div><p>A</p><p>B</p><p>C</p></div></body></html>' "-p" "div"
check "pretty mixed text" '<html><body><div>TEXT1<span>S</span>TEXT2</div></body></html>' "-p" "div"
check "pretty text between blocks" '<html><body><div><p>A</p>TEXT<p>B</p></div></body></html>' "-p" "div"
check "pretty comment" '<html><body><div><p>A</p><!-- c --><p>B</p></div></body></html>' "-p" "div"
check "pretty span text" '<html><body><div><p>A</p><span>S</span></div></body></html>' "-p" "div"
check "pretty inline first" '<html><body><div><span>S</span><p>A</p></div></body></html>' "-p" "div"
check "pretty deep" '<html><body><div><div><div>A</div></div></div></body></html>' "-p" "body"
check "pretty table" '<html><body><table><tr><td>A</td></tr></table></body></html>' "-p" "table"
check "pretty inline only" '<html><body><span>A</span></body></html>' "-p" "span"

# Text mode edge cases
check "text body" '<html><body>Hi</body></html>' "-t" "body"
check "text whitespace" '<html><body><div>  Hello  </div></body></html>' "-t" "div"
check "text newlines" "$(printf '<html><body><div>A\nB</div></body></html>')" "-t" "div"

# Attribute edge cases
check "attr empty" '<html><body><a href="">x</a></body></html>' "-a" "href" "a"
check "attr class" '<html><body><div class="foo bar">x</div></body></html>' "-a" "class" "div"
check "attr nonexistent" '<html><body><a>x</a></body></html>' "-a" "title" "a"

# Selectors
check "type+attr" '<html><body><a href="x">A</a><b href="x">B</b></body></html>' 'a[href="x"]'
check "type+id" '<html><body><a id="x">A</a><b id="x">B</b></body></html>' 'a#x'
check "id+class" '<html><body><div id="a" class="b">X</div></body></html>' '#a.b'
check "not type" '<html><body><a>A</a><b>B</b></body></html>' ':not(a)'

# Combinators
check "child >" '<html><body><div><p>A</p><span><p>B</p></span></div></body></html>' 'div > p'
check "adjacent +" '<html><body><h1>H</h1><p>P</p></body></html>' 'h1 + p'
check "general ~" '<html><body><h1>H</h1><div>D</div><p>P</p></body></html>' 'h1 ~ p'

# Base URL
check "base relative" '<html><body><a href="foo">A</a></body></html>' "--base" "https://example.com/dir/" "a"
check "base absolute" '<html><body><a href="http://other.com">A</a></body></html>' "--base" "https://example.com" "a"
check "base frag" '<html><body><a href="#x">A</a></body></html>' "--base" "https://example.com" "a"
check "base only link" '<html><body><img src="/x"></body></html>' "--base" "https://example.com" "img"
check "base on area" '<html><body><area href="/x"></body></html>' "--base" "https://example.com" "area"
check "base on link" '<html><body><link href="/x"></body></html>' "--base" "https://example.com" "link"
check "detect base found" '<html><head><base href="https://b.com/"></head><body><a href="/x">A</a></body></html>' "-B" "a"
check "detect base no <base>" '<html><body><a href="/x">A</a></body></html>' "-B" "--base" "https://fallback.com" "a"

# Output to file
check "output file" '<html><h1>A</h1></html>' "-o" "/tmp/test_out_$$.html" "h1"
rm -f /tmp/test_out_$$.html

# Multi positional args
check "multi pos" '<html><body><div><h1>A</h1></div></body></html>' "div" "h1"
check "multi pos siblings" '<html><body><div>D</div><h1>H</h1></body></html>' "div," "h1"

# Edge cases on HTML
check "doctype with public" '<!DOCTYPE html PUBLIC "abc"><html><body>X</body></html>' "html"
check "CDATA-like" '<html><body>Hello &amp; goodbye</body></html>' "body"
check "self closing void" '<html><body><br/><img/></body></html>' "body"
check "html attrs" '<html lang="en"><body>X</body></html>' "html"
check "body attrs" '<html><body class="x">Y</body></html>' "body"
check "head with title" '<html><head><title>T</title></head><body>X</body></html>' "title"

# Larger structures
check "nested table" '<html><body><table><tr><td><b>X</b></td></tr></table></body></html>' "table"
check "form" '<html><body><form><input name="q"><button>Go</button></form></body></html>' "form"

# Remove edge cases
check "remove no match" '<html><body><div>X</div></body></html>' "-r" "p" "--" "body"
check "remove multiple" '<html><body><div>K</div><span>X</span><i>Y</i></body></html>' "-r" "span" "-r" "i" "--" "body"
check "remove without --" '<html><body><div>K</div><span>X</span></body></html>' "-r" "span" "body"
check "remove with -t" '<html><body><div>HELLO<span>X</span></div></body></html>' "-t" "-r" "span" "--" "div"

# Various combinations
check "pretty + base" '<html><body><a href="/x">A</a></body></html>' "-p" "--base" "https://example.com" "a"
check "text + base" '<html><body><a href="/x">link</a></body></html>' "-t" "--base" "https://example.com" "a"
check "attr + remove" '<html><body><a href="x">A</a><a href="y">B</a></body></html>' "-a" "href" "-r" "a:first-child" "--" "a"

# Unicode
check "unicode" '<html><body>Hello 世界</body></html>' "body"
check "unicode in attr" '<html><body><a title="café">X</a></body></html>' "a"
check "emoji" '<html><body>🚀 launch</body></html>' "body"

# Empty selectors
check "blank selector" '<html></html>' " "

# More CSS selector edge cases
check "attr existing" '<html><body><a href>X</a></body></html>' 'a[href]'
check "attr empty" '<html><body><a href="">X</a></body></html>' 'a[href=""]'

# Multiple of same attribute name
check "duplicate attr" '<html><body><a class="a" class="b">X</a></body></html>' "a"

# Comments
check "comment in head" '<html><head><!-- c --></head><body>X</body></html>' "html"
check "doctype + comment" '<!DOCTYPE html><!--top--><html><body>X</body></html>' "html"

# Pretty edge cases
check "pretty void" '<html><body><br></body></html>' "-p" "body"
check "pretty script" '<html><body><script>x=1</script></body></html>' "-p" "body"
check "pretty style" '<html><body><style>a{color:red}</style></body></html>' "-p" "body"

# Stdin issues
check "empty stdin" '' ''
check "only html tag" '<html></html>' "html"

# Removed and selected overlap
check "remove same as selected" '<html><body><div>A</div><div class="rm">X</div></body></html>' "-r" ".rm" "--" "div"

# Misc
check "html5 parsing oddity" '<html><body><div><p>A<div>B</div></p></div></body></html>' "div"

echo ""
echo "Total: $((pass+fail))  Pass: $pass  Fail: $fail"
if [ $fail -gt 0 ]; then
  echo "Failed:"
  for d in "${failed_descs[@]}"; do
    echo "  - $d"
  done
fi
