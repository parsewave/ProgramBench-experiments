#!/bin/bash
# Statistical top-up: 10 fresh probes sampled from discovered usage modes
REF=/workspace/executable
SUT=/work/work/executable

normalize() {
  sed -E 's/thread '"'"'main'"'"' \([0-9]+\)/thread main (PID)/g'
}

pass=0
fail=0
failed_descs=()

check() {
  local desc="$1"; shift
  local input="$1"; shift
  local ref_out ref_exit
  ref_out=$(printf "%s" "$input" | timeout 5 $REF "$@" 2>&1 | normalize)
  ref_exit=${PIPESTATUS[1]}
  local sut_out sut_exit
  sut_out=$(printf "%s" "$input" | timeout 5 $SUT "$@" 2>&1 | normalize)
  sut_exit=${PIPESTATUS[1]}

  if [ "$ref_out" = "$sut_out" ] && [ "$ref_exit" = "$sut_exit" ]; then
    pass=$((pass+1))
    echo "PASS: $desc"
  else
    fail=$((fail+1))
    failed_descs+=("$desc")
    echo "FAIL: $desc"
    echo "  ARGS: $@"
    printf "  REF (exit %s):\n" "$ref_exit"
    printf "%s\n" "$ref_out" | head -10 | sed 's/^/    /'
    printf "  SUT (exit %s):\n" "$sut_exit"
    printf "%s\n" "$sut_out" | head -10 | sed 's/^/    /'
  fi
}

# Probe 1: real-world page with attribute selector
check "topup_01_attr_class" \
  '<html><body><article class="post"><h1 class="title">Hello</h1><p>Some <em>content</em> here.</p></article></body></html>' \
  -t "article.post"

# Probe 2: complex CSS selector with combinators
check "topup_02_complex_sel" \
  '<html><body><nav><ul><li><a href="/home">Home</a></li><li class="active"><a href="/about">About</a></li></ul></nav></body></html>' \
  'nav li.active a'

# Probe 3: pretty mode with nested structure
check "topup_03_pretty_nested" \
  '<html><body><section><article><header><h2>Title</h2></header><p>Para</p></article></section></body></html>' \
  -p "section"

# Probe 4: base URL with various href types
check "topup_04_base_mixed" \
  '<html><body><a href="/abs">A1</a><a href="rel">A2</a><a href="https://other.com">A3</a></body></html>' \
  --base "https://example.com/path/" -a href "a"

# Probe 5: text mode with ignore-whitespace
check "topup_05_text_w" \
  "$(printf '<html><body><div>\n  Hello\n  <span>world</span>\n</div></body></html>')" \
  -tw "div"

# Probe 6: -r with multi-selector
check "topup_06_remove_multi" \
  '<html><body><script>x=1</script><style>a{}</style><div>K</div><p>P</p></body></html>' \
  -r "script" -r "style" -- "body"

# Probe 7: detect-base with fallback
check "topup_07_detect_base" \
  '<html><head><base href="https://detected.example/"></head><body><a href="/x">X</a></body></html>' \
  -B --base "https://fallback.com/" -a href "a"

# Probe 8: pretty mode with table
check "topup_08_pretty_table" \
  '<html><body><table><thead><tr><th>K</th><th>V</th></tr></thead><tbody><tr><td>A</td><td>1</td></tr></tbody></table></body></html>' \
  -p "table"

# Probe 9: nth-child with HTML5 parsing
check "topup_09_nth_child" \
  '<html><body><ul><li>1</li><li>2</li><li>3</li><li>4</li><li>5</li></ul></body></html>' \
  "li:nth-child(2n+1)"

# Probe 10: misc selector with form elements
check "topup_10_form_attr" \
  '<html><body><form><input type="text" name="user"><input type="password" name="pass"><button>Login</button></form></body></html>' \
  -a "name" 'input[type="text"], input[type="password"]'

echo ""
echo "Total: $((pass+fail))  Pass: $pass  Fail: $fail"
