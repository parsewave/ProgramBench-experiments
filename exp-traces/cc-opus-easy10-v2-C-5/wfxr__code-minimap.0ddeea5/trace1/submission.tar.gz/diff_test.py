#!/usr/bin/env python3
"""Differential test: run my impl against reference, compare outputs."""

import json
import base64
import subprocess
import sys
import os

REF = os.environ.get('REF', '/workspace/executable')
SUT = os.environ.get('SUT', '/work/work/executable')
FRAMES = os.environ.get('FRAMES', '/work/work/frames.jsonl')


def run(binary, args, stdin_bytes):
    res = subprocess.run([binary] + args, input=stdin_bytes, capture_output=True, timeout=30)
    return res.returncode, res.stdout, res.stderr


def main():
    failed = []
    total = 0
    with open(FRAMES) as f:
        for line in f:
            frame = json.loads(line)
            total += 1
            name = frame['name']
            args = frame['args']
            stdin_bytes = base64.b64decode(frame['stdin_b64'])
            exp_exit = frame['exit_code']
            exp_stdout = base64.b64decode(frame['stdout_b64'])
            exp_stderr = base64.b64decode(frame['stderr_b64'])

            try:
                got_exit, got_stdout, got_stderr = run(SUT, args, stdin_bytes)
            except Exception as e:
                failed.append((name, f"SUT exception: {e}"))
                continue

            mismatch = []
            if got_exit != exp_exit:
                mismatch.append(f"exit: expected {exp_exit}, got {got_exit}")
            if got_stdout != exp_stdout:
                mismatch.append(f"stdout differs (exp {len(exp_stdout)}b, got {len(got_stdout)}b)")
            if got_stderr != exp_stderr:
                mismatch.append(f"stderr differs (exp {len(exp_stderr)}b, got {len(got_stderr)}b)")

            if mismatch:
                failed.append((name, '; '.join(mismatch), exp_stdout, got_stdout, exp_stderr, got_stderr, exp_exit, got_exit))

    print(f"\nTotal: {total}, Passed: {total - len(failed)}, Failed: {len(failed)}")
    if failed:
        print("\nFailures:")
        for f in failed:
            print(f"\n=== {f[0]} ===")
            print(f"  {f[1]}")
            if len(f) > 2:
                _, _, eo, go, ee, ge, ex, gx = f
                print(f"  exit: exp={ex} got={gx}")
                if eo != go:
                    print(f"  stdout exp: {eo!r}")
                    print(f"  stdout got: {go!r}")
                if ee != ge:
                    print(f"  stderr exp: {ee!r}")
                    print(f"  stderr got: {ge!r}")
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
