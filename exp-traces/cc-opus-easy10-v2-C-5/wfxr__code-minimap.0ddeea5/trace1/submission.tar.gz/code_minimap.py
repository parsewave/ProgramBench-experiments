#!/usr/bin/env python3
"""Reimplementation of code-minimap 0.6.8 based on black-box observation."""

import sys
import os
import math

# Unicode White_Space property (matches Rust char::is_whitespace)
WHITESPACE = frozenset([
    0x0009, 0x000A, 0x000B, 0x000C, 0x000D,
    0x0020,
    0x0085,
    0x00A0,
    0x1680,
    0x2000, 0x2001, 0x2002, 0x2003, 0x2004,
    0x2005, 0x2006, 0x2007, 0x2008, 0x2009, 0x200A,
    0x2028, 0x2029,
    0x202F, 0x205F,
    0x3000,
])

PROG = "code-minimap"
VERSION_TEXT = b"code-minimap 0.6.8\n"

HELP_TEXT = b"""A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
"""

HELP_COMPLETION_TEXT = b"""Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
"""

HELP_HELP_TEXT = b"""Print this message or the help of the given subcommand(s)

Usage: executable help [COMMAND]...

Arguments:
  [COMMAND]...
          Print help for the subcommand(s)
"""

USAGE_TOP = b"Usage: executable [OPTIONS] [FILE] [COMMAND]\n"
USAGE_COMPLETION = b"Usage: executable completion <SHELL>\n"
USAGE_HELP = b"Usage: executable help [COMMAND]...\n"
MORE_INFO = b"\nFor more information, try '--help'.\n"

SHELLS = ["bash", "elvish", "fish", "powershell", "zsh"]


def stderr_write(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    sys.stderr.buffer.write(data)
    sys.stderr.buffer.flush()


def stdout_write(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def parse_rust_f64(s):
    if not s:
        raise ValueError("cannot parse float from empty string")
    sl = s.lower()
    if sl in ("nan", "+nan", "-nan"):
        return float('nan')
    if sl in ("inf", "+inf", "infinity", "+infinity"):
        return float('inf')
    if sl in ("-inf", "-infinity"):
        return float('-inf')
    if '_' in s or 'x' in sl:
        raise ValueError("invalid float literal")
    try:
        return float(s)
    except ValueError:
        raise ValueError("invalid float literal")


def parse_u32(s):
    if not s:
        raise ValueError("cannot parse integer from empty string")
    if not s.isascii() or not s.isdigit():
        raise ValueError("invalid digit found in string")
    v = int(s)
    if v > 0xFFFFFFFF:
        raise ValueError("number too large to fit in target type")
    return v


def load_completion(shell):
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, "completions", f"{shell}.txt")
    try:
        with open(path, 'rb') as f:
            return f.read()
    except FileNotFoundError:
        return b""


def _jaro(s1, s2):
    if not s1 and not s2:
        return 1.0
    if not s1 or not s2:
        return 0.0
    l1, l2 = len(s1), len(s2)
    match_dist = max(l1, l2) // 2 - 1
    if match_dist < 0:
        match_dist = 0
    m1 = [False] * l1
    m2 = [False] * l2
    matches = 0
    for i in range(l1):
        start = max(0, i - match_dist)
        end = min(l2, i + match_dist + 1)
        for j in range(start, end):
            if m2[j] or s1[i] != s2[j]:
                continue
            m1[i] = True
            m2[j] = True
            matches += 1
            break
    if matches == 0:
        return 0.0
    t = 0
    k = 0
    for i in range(l1):
        if not m1[i]:
            continue
        while k < l2 and not m2[k]:
            k += 1
        if k < l2 and s1[i] != s2[k]:
            t += 1
        k += 1
    t //= 2
    return (matches / l1 + matches / l2 + (matches - t) / matches) / 3


def jaro_winkler(s1, s2):
    j = _jaro(s1, s2)
    p = 0.1
    l = 0
    for i in range(min(4, len(s1), len(s2))):
        if s1[i] == s2[i]:
            l += 1
        else:
            break
    return j + l * p * (1 - j)


def suggest_shell(input_val):
    best = None
    best_score = 0.0
    for s in SHELLS:
        score = jaro_winkler(s.lower(), input_val.lower())
        if score > best_score:
            best_score = score
            best = s
    if best_score >= 0.7:
        return best
    return None


class ArgError(Exception):
    def __init__(self, msg, usage=None, with_more=True, tip=None):
        self.msg = msg
        self.usage = usage
        self.with_more = with_more
        self.tip = tip


def emit_clap_error(e):
    stderr_write(b"error: " + e.msg.encode('utf-8') + b"\n")
    if e.tip is not None:
        stderr_write(b"\n  tip: " + e.tip.encode('utf-8') + b"\n")
    if e.usage is not None:
        stderr_write(b"\n")
        stderr_write(e.usage)
    if e.with_more:
        stderr_write(MORE_INFO)


def looks_like_flag(s):
    return len(s) > 1 and s.startswith('-')


OPTIONS = [
    ('--horizontal-scale', '-H', 'HSCALE', parse_rust_f64, None, 'horizontal_scale'),
    ('--vertical-scale',   '-V', 'VSCALE', parse_rust_f64, None, 'vertical_scale'),
    ('--padding',          None, 'PADDING', parse_u32, None, 'padding'),
    ('--encoding',         None, 'ENCODING', None, ['utf8-lossy', 'utf8'], 'encoding'),
]


def match_known_flag(arg):
    for long_, short, var, parser, valid, key in OPTIONS:
        if arg == long_:
            return (long_, short, var, parser, valid, key, None)
        if arg.startswith(long_ + '='):
            return (long_, short, var, parser, valid, key, arg[len(long_) + 1:])
        if short and arg == short:
            return (long_, short, var, parser, valid, key, None)
        if short and arg.startswith(short + '='):
            return (long_, short, var, parser, valid, key, arg[len(short) + 1:])
        if short and arg.startswith(short) and len(arg) > 2 and arg[2] != '=':
            return (long_, short, var, parser, valid, key, arg[2:])
    return None


def convert_value(long_, var, parser, valid, val_str):
    if parser is not None:
        try:
            return parser(val_str)
        except ValueError as ve:
            msg = f"invalid value '{val_str}' for '{long_} <{var}>': {ve}"
            raise ArgError(msg, usage=None)
    if valid is not None:
        if val_str not in valid:
            poss = ', '.join(valid)
            msg = f"invalid value '{val_str}' for '{long_} <{var}>'\n  [possible values: {poss}]"
            raise ArgError(msg, usage=None)
        return val_str
    return val_str


def parse_main_args(argv):
    opts = {
        'horizontal_scale': 1.0,
        'vertical_scale': 1.0,
        'padding': None,
        'encoding': 'utf8-lossy',
        'file': None,
        'subcommand': None,
        'sub_args': [],
    }
    seen_flags = set()
    positionals = []
    after_dashdash = False
    i = 0
    saw_dashdash = False
    while i < len(argv):
        arg = argv[i]
        if not after_dashdash:
            if arg == "--help" or arg == "-h":
                stdout_write(HELP_TEXT)
                sys.exit(0)
            if arg == "--version":
                stdout_write(VERSION_TEXT)
                sys.exit(0)
            if arg == "--":
                after_dashdash = True
                saw_dashdash = True
                i += 1
                continue
            # Try matching known flag
            m = match_known_flag(arg)
            if m is not None:
                long_, short, var, parser, valid, key, inline = m
                if long_ in seen_flags:
                    raise ArgError(f"the argument '{long_} <{var}>' cannot be used multiple times",
                                   usage=USAGE_TOP)
                seen_flags.add(long_)
                if inline is None:
                    # next arg should be value
                    if i + 1 >= len(argv):
                        raise ArgError(
                            f"a value is required for '{long_} <{var}>' but none was supplied",
                            usage=None
                        )
                    nxt = argv[i + 1]
                    if looks_like_flag(nxt):
                        # If next is a known flag, "missing value"; else "unexpected argument"
                        if match_known_flag(nxt) is not None or nxt == "--" or nxt in ("-h", "--help", "--version"):
                            raise ArgError(
                                f"a value is required for '{long_} <{var}>' but none was supplied",
                                usage=None
                            )
                        tip = f"to pass '{nxt}' as a value, use '-- {nxt}'"
                        raise ArgError(f"unexpected argument '{nxt}' found",
                                       usage=USAGE_TOP, tip=tip)
                    val_str = nxt
                    i += 2
                else:
                    val_str = inline
                    i += 1
                opts[key] = convert_value(long_, var, parser, valid, val_str)
                continue
            # Unknown flag-like arg
            if looks_like_flag(arg):
                tip = f"to pass '{arg}' as a value, use '-- {arg}'"
                raise ArgError(f"unexpected argument '{arg}' found",
                               usage=USAGE_TOP, tip=tip)
            # Positional or subcommand
            if not positionals and arg in ("completion", "help"):
                opts['subcommand'] = arg
                opts['sub_args'] = argv[i + 1:]
                return opts
        # else: after --
        positionals.append(arg)
        i += 1

    if len(positionals) > 1:
        raise ArgError(f"unexpected argument '{positionals[1]}' found", usage=USAGE_TOP)
    if len(positionals) == 1:
        opts['file'] = positionals[0]
    return opts


def handle_completion(args):
    i = 0
    shell = None
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            stdout_write(HELP_COMPLETION_TEXT)
            sys.exit(0)
        if a == "--":
            i += 1
            while i < len(args):
                if shell is None:
                    shell = args[i]
                else:
                    raise ArgError(f"unexpected argument '{args[i]}' found", usage=USAGE_COMPLETION)
                i += 1
            break
        if looks_like_flag(a):
            tip = f"to pass '{a}' as a value, use '-- {a}'"
            raise ArgError(f"unexpected argument '{a}' found", usage=USAGE_COMPLETION, tip=tip)
        if shell is None:
            shell = a
        else:
            raise ArgError(f"unexpected argument '{a}' found", usage=USAGE_COMPLETION)
        i += 1
    if shell is None:
        stderr_write(b"error: the following required arguments were not provided:\n  <SHELL>\n\n")
        stderr_write(USAGE_COMPLETION)
        stderr_write(MORE_INFO)
        sys.exit(2)
    if shell == "":
        # clap special-case for empty string
        stderr_write(b"error: a value is required for '<SHELL>' but none was supplied\n")
        stderr_write(b"  [possible values: bash, elvish, fish, powershell, zsh]\n\n")
        stderr_write(MORE_INFO)
        sys.exit(2)
    if shell not in SHELLS:
        msg = f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n"
        stderr_write(msg.encode('utf-8'))
        sugg = suggest_shell(shell)
        if sugg is not None:
            stderr_write(b"\n  tip: a similar value exists: '" + sugg.encode('utf-8') + b"'\n")
        stderr_write(MORE_INFO)
        sys.exit(2)
    content = load_completion(shell)
    sys.stdout.buffer.write(content)
    sys.stdout.buffer.flush()
    sys.exit(0)


def handle_help(args):
    # Strip --help / -h
    args = [a for a in args if a not in ("-h", "--help")]
    if not args:
        stdout_write(HELP_TEXT)
        sys.exit(0)
    cmd = args[0]
    if cmd == "completion":
        stdout_write(HELP_COMPLETION_TEXT)
        sys.exit(0)
    if cmd == "help":
        stdout_write(HELP_HELP_TEXT)
        sys.exit(0)
    stderr_write(f"error: unrecognized subcommand '{cmd}'\n\n".encode('utf-8'))
    stderr_write(USAGE_TOP)
    stderr_write(MORE_INFO)
    sys.exit(2)


# ----- Core algorithm -----

def decode_input(raw_bytes, encoding):
    if encoding == 'utf8':
        return raw_bytes.decode('utf-8')
    return raw_bytes.decode('utf-8', errors='replace')


def split_lines(s):
    if not s:
        return []
    parts = s.split('\n')
    if parts and parts[-1] == '':
        parts.pop()
    return parts


def line_fill(line):
    """Returns (col_start, col_end, stripped_len). col_end is the start byte position of last non-ws char."""
    if not line:
        return (None, None, 0)
    col_start = None
    col_end = None
    byte_pos = 0
    for ch in line:
        cp = ord(ch)
        char_byte_len = len(ch.encode('utf-8'))
        if cp not in WHITESPACE:
            if col_start is None:
                col_start = byte_pos
            col_end = byte_pos
        byte_pos += char_byte_len
    if col_start is None:
        return (None, None, 0)
    return (col_start, col_end, col_end + 1)


def render(input_text, hscale, vscale, padding):
    lines = split_lines(input_text)
    n = len(lines)
    if n == 0:
        return b""
    # Process each line
    line_info = [line_fill(l) for l in lines]
    # Effective vertical scale: min(VSCALE, 1.0); negatives and NaN → 0
    if math.isnan(vscale):
        eff_v = 0.0
    elif vscale < 0:
        eff_v = 0.0
    else:
        eff_v = min(vscale, 1.0)
    # Pixel row of each input line
    if eff_v == 0:
        pixel_row_of = [0] * n
    else:
        pixel_row_of = [int(math.floor(i * eff_v)) for i in range(n)]
        pixel_row_of = [max(0, p) for p in pixel_row_of]
    total_pixel_rows = max(pixel_row_of) + 1 if pixel_row_of else 0
    total_cell_rows = (total_pixel_rows + 3) // 4 if total_pixel_rows > 0 else 0
    out = bytearray()
    # HSCALE safety: handle inf/-inf/NaN
    if math.isnan(hscale) or hscale < 0:
        hscale_safe = 0.0
        force_zero = True
    elif math.isinf(hscale):
        hscale_safe = 0.0  # would panic in Rust; we just produce 0 cols
        force_zero = True
    else:
        hscale_safe = hscale
        force_zero = False

    for cell_row in range(total_cell_rows):
        pr_first = cell_row * 4
        pr_last_exclusive = pr_first + 4
        # Lines contributing to this cell row
        lines_in_row = [i for i in range(n) if pr_first <= pixel_row_of[i] < pr_last_exclusive]
        # Max stripped length for width
        max_stripped = 0
        for i in lines_in_row:
            sl = line_info[i][2]
            if sl > max_stripped:
                max_stripped = sl
        # output_pixel_cols = max(floor(HSCALE), floor(max_stripped * HSCALE))
        if force_zero:
            output_pixel_cols = 0
        else:
            output_pixel_cols = max(int(math.floor(hscale_safe)), int(math.floor(max_stripped * hscale_safe)))
        if output_pixel_cols < 0:
            output_pixel_cols = 0
        output_cells = (output_pixel_cols + 1) // 2
        # Build pixel rows: 4 sets of filled cols
        row_fills = [set() for _ in range(4)]
        for i in lines_in_row:
            cs, ce, _ = line_info[i]
            if cs is None:
                continue
            if force_zero:
                continue
            start_out = int(math.floor(cs * hscale_safe))
            end_out = int(math.floor((ce + 1) * hscale_safe))
            if start_out < 0:
                start_out = 0
            if end_out > output_pixel_cols:
                end_out = output_pixel_cols
            pr_local = pixel_row_of[i] - pr_first
            if 0 <= pr_local < 4:
                row_fills[pr_local].update(range(start_out, end_out))
        # Render each cell
        for cell_idx in range(output_cells):
            x = cell_idx * 2
            bits = 0
            if (x + 0) in row_fills[0]: bits |= 0x01
            if (x + 1) in row_fills[0]: bits |= 0x08
            if (x + 0) in row_fills[1]: bits |= 0x02
            if (x + 1) in row_fills[1]: bits |= 0x10
            if (x + 0) in row_fills[2]: bits |= 0x04
            if (x + 1) in row_fills[2]: bits |= 0x20
            if (x + 0) in row_fills[3]: bits |= 0x40
            if (x + 1) in row_fills[3]: bits |= 0x80
            cp = 0x2800 + bits
            out.extend(chr(cp).encode('utf-8'))
        # Padding to char count
        if padding is not None and output_cells < padding:
            out.extend(b' ' * (padding - output_cells))
        out.append(0x0A)
    return bytes(out)


def main():
    argv = sys.argv[1:]
    try:
        opts = parse_main_args(argv)
    except ArgError as e:
        emit_clap_error(e)
        sys.exit(2)
    except SystemExit:
        raise

    if opts['subcommand'] == 'completion':
        try:
            handle_completion(opts['sub_args'])
        except ArgError as e:
            emit_clap_error(e)
            sys.exit(2)
        return

    if opts['subcommand'] == 'help':
        handle_help(opts['sub_args'])
        return

    # Read input
    if opts['file'] is None:
        raw = sys.stdin.buffer.read()
    else:
        try:
            with open(opts['file'], 'rb') as f:
                raw = f.read()
        except FileNotFoundError:
            stderr_write(f"{PROG}: No such file or directory (os error 2)\n")
            sys.exit(1)
        except IsADirectoryError:
            stderr_write(f"{PROG}: Is a directory (os error 21)\n")
            sys.exit(1)
        except PermissionError:
            stderr_write(f"{PROG}: Permission denied (os error 13)\n")
            sys.exit(1)
        except OSError as ose:
            stderr_write(f"{PROG}: {ose.strerror} (os error {ose.errno})\n")
            sys.exit(1)

    try:
        text = decode_input(raw, opts['encoding'])
    except UnicodeDecodeError:
        stderr_write(f"{PROG}: stream did not contain valid UTF-8\n")
        sys.exit(1)

    out = render(text, opts['horizontal_scale'], opts['vertical_scale'], opts['padding'])
    sys.stdout.buffer.write(out)
    sys.stdout.buffer.flush()


if __name__ == '__main__':
    main()