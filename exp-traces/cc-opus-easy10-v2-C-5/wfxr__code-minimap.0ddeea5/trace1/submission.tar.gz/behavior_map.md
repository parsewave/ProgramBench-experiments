# Behavior map for code-minimap 0.6.8

## CLI
- `--horizontal-scale`/`-H` HSCALE (float, default 1.0)
- `--vertical-scale`/`-V` VSCALE (float, default 1.0)
- `--padding` PADDING (u32, default 0)
- `--encoding` ENC (utf8-lossy default, or utf8)
- `--version`: prints `code-minimap 0.6.8\n`
- `-h`/`--help`: prints help (stdout)
- `[FILE]`: file path; absent → read stdin. `-` is NOT stdin alias.
- subcommand `completion <SHELL>`: bash|elvish|fish|powershell|zsh
- subcommand `help [COMMAND]...`
- Errors:
  - parse errors → clap-style, exit 2
  - file missing → `code-minimap: No such file or directory (os error 2)\n` to stderr, exit 1
  - dir → `code-minimap: Is a directory (os error 21)\n` to stderr, exit 1
  - utf8 strict invalid → `code-minimap: stream did not contain valid UTF-8\n` to stderr, exit 1
- Flags can't repeat (clap "cannot be used multiple times").

## Core algorithm
Renders text → braille minimap (each cell = 2 cols × 4 rows of pixels).

### Per line (UTF-8 decoded; lossy = invalid bytes → U+FFFD, strict = error):
- Iterate Unicode chars; find first and last non-whitespace char.
- col_start = byte index of first non-ws char (in lossy-decoded byte string).
- col_end = byte index of last non-ws char (start position, not end).
- Fill region = byte cols [col_start, col_end] inclusive.
- If no non-ws char: fill region empty, "stripped length" = 0.

### Whitespace classification
Uses Rust `char::is_whitespace()` (Unicode White_Space property):
- U+0009..U+000D, U+0020, U+0085, U+00A0
- U+1680
- U+2000..U+200A
- U+2028, U+2029, U+202F, U+205F, U+3000

NOT whitespace: U+001C..U+001F, U+200B (ZWSP), U+FEFF (BOM/ZWNBSP), NUL.

### Vertical (VSCALE)
- effective_vscale = min(VSCALE, 1.0); also negative/NaN ≤ 0 → effectively 0.
- Each input line i → pixel_row = floor(i * effective_vscale)
  (Rust cast `f as usize` from negative or NaN → 0.)
- Total pixel rows = floor((N-1) * effective_vscale) + 1, or 0 if N=0.
- Multiple lines mapping to same pixel row → OR their fill regions.

### Horizontal (HSCALE)
- Each input col c (in any fill region) → output cols [floor(c*H), floor((c+1)*H)).
- Per cell row, output_pixel_cols = max(floor(HSCALE), floor(max_stripped_len_in_row * HSCALE))
  - i.e. an all-empty-line cell row still produces floor(HSCALE) pixel cols of width (empty pixels).
- Number of output cells per row = ceil(output_pixel_cols / 2).
- Negative HSCALE → output_pixel_cols cast to usize → 0 → empty row (just `\n`).

### Braille encoding (U+2800 base)
Pixel offsets within cell (cell is 2 wide × 4 tall):
```
(0,0)=bit0=dot1  (1,0)=bit3=dot4
(0,1)=bit1=dot2  (1,1)=bit4=dot5
(0,2)=bit2=dot3  (1,2)=bit5=dot6
(0,3)=bit6=dot7  (1,3)=bit7=dot8
```

### Output
- For each cell row, emit ceil(out_cols/2) braille chars, then trailing spaces (`' '`) to bring char count to PADDING if PADDING > cell_count, then `\n`.
- One `\n` per cell row.
- If input is fully empty (0 bytes, no newline): output is empty (no bytes).
- If input ends with `\n`, trailing implicit empty line is NOT added.

## Edge cases verified
- CR `\r` is whitespace (treated as part of line content, stripped when non-trailing surround all-ws).
- `\n` is the only line separator.
- BOM (`\xef\xbb\xbf` = U+FEFF) is non-ws.
- Lossy: each invalid byte → 1 U+FFFD (3 bytes in resulting UTF-8).
- HSCALE=NaN, HSCALE=0, HSCALE<0 → all zero output cols.
- VSCALE>1 → effectively VSCALE=1 (cap).
- VSCALE=NaN / VSCALE<=0 → all lines map to pixel row 0.
- HSCALE=inf → Rust panics with "capacity overflow".
- Conflicting flag repetition → clap error.
- Negative numeric arg without `--horizontal-scale=-1` form → clap "unexpected argument", exit 2.

## Examples (byte-verified)
- `printf "" | exec` → `` (empty, exit 0)
- `printf "\n" | exec` → `⠀\n` (U+2800 + LF)
- `printf "a" | exec` → `⠁\n`
- `printf "ab" | exec` → `⠉\n`
- `printf "a\nb\nc\nd\ne\n" | exec` → `⡇\n⠁\n`
- `printf "a\n   \n" | exec -H 0.5` → `\n\n` (two empty rows)
- `printf "abcd\n" | exec --padding 5` → `⠉⠉   \n` (3 trailing spaces)
