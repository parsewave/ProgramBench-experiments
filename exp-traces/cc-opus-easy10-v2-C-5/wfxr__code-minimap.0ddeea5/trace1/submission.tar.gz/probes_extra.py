#!/usr/bin/env python3
"""More probes for differential testing — extends frames.jsonl with diverse inputs."""

import json
import base64
import subprocess
import os
import random

REF = os.environ.get('REF', '/workspace/executable')
OUT = os.environ.get('OUT', '/work/work/frames.jsonl')


def probe(name, stdin_bytes, args):
    try:
        res = subprocess.run([REF] + args, input=stdin_bytes,
                             capture_output=True, timeout=30)
        return {
            'name': name,
            'stdin_b64': base64.b64encode(stdin_bytes).decode('ascii'),
            'args': args,
            'exit_code': res.returncode,
            'stdout_b64': base64.b64encode(res.stdout).decode('ascii'),
            'stderr_b64': base64.b64encode(res.stderr).decode('ascii'),
        }
    except subprocess.TimeoutExpired:
        return None


cases = []

# Real code samples
python_code = b"""def hello():
    print("Hello, world!")
    for i in range(10):
        if i % 2 == 0:
            print(i)
        else:
            print(-i)
    return 42


class Foo:
    def __init__(self, x):
        self.x = x

    def bar(self):
        # comment
        return self.x * 2
"""

cases.append(('python_code', python_code, []))
cases.append(('python_code_h05', python_code, ['-H', '0.5']))
cases.append(('python_code_h2', python_code, ['-H', '2']))
cases.append(('python_code_v05', python_code, ['-V', '0.5']))
cases.append(('python_code_v025', python_code, ['-V', '0.25']))
cases.append(('python_code_h05_v05', python_code, ['-H', '0.5', '-V', '0.5']))
cases.append(('python_code_pad30', python_code, ['--padding', '30']))
cases.append(('python_code_h2_pad', python_code, ['-H', '2', '--padding', '50']))


# Random byte sequences (deterministic)
random.seed(42)
for n in [1, 2, 5, 10, 25, 50]:
    data = bytes([random.randint(0, 255) for _ in range(n)])
    cases.append((f'random_{n}b', data, []))
    cases.append((f'random_{n}b_strict', data, ['--encoding', 'utf8']))


# Random text lines
random.seed(123)
def random_text(num_lines, max_width):
    out = []
    for _ in range(num_lines):
        w = random.randint(0, max_width)
        s = ''.join(random.choice('abcdefghij    ') for _ in range(w))
        out.append(s)
    return '\n'.join(out).encode('utf-8') + b'\n'


for nl, mw in [(10, 20), (50, 80), (100, 120), (3, 5), (1, 200)]:
    txt = random_text(nl, mw)
    cases.append((f'rand_text_{nl}x{mw}', txt, []))
    cases.append((f'rand_text_{nl}x{mw}_h05', txt, ['-H', '0.5']))
    cases.append((f'rand_text_{nl}x{mw}_v05', txt, ['-V', '0.5']))


# Tricky UTF-8 patterns
cases.append(('mixed_utf8', '日本語 Hello мир\n'.encode('utf-8'), []))
cases.append(('mixed_utf8_h05', '日本語 Hello мир\n'.encode('utf-8'), ['-H', '0.5']))
cases.append(('arabic', 'مرحبا بالعالم\n'.encode('utf-8'), []))
cases.append(('combining', 'á̂b\n'.encode('utf-8'), []))
cases.append(('zwj_emoji', '👨‍👩‍👧\n'.encode('utf-8'), []))


# Very long line tests
cases.append(('1000_chars', b'a' * 1000 + b'\n', []))
cases.append(('1000_chars_h05', b'a' * 1000 + b'\n', ['-H', '0.5']))
cases.append(('1000_chars_h2', b'a' * 1000 + b'\n', ['-H', '2']))
cases.append(('1000_chars_h_15', b'a' * 1000 + b'\n', ['-H', '1.5']))
cases.append(('many_lines_100', (b'hello\n' * 100), []))
cases.append(('many_lines_100_v05', (b'hello\n' * 100), ['-V', '0.5']))
cases.append(('many_lines_100_v025', (b'hello\n' * 100), ['-V', '0.25']))


# Padding edge cases
cases.append(('pad_1_a', b'a\n', ['--padding', '1']))
cases.append(('pad_1_abcd', b'abcd\n', ['--padding', '1']))
cases.append(('pad_100_a', b'a\n', ['--padding', '100']))
cases.append(('pad_eq_5', b'abc\n', ['--padding=5']))


# Edge: leading dashes in content (not flag)
cases.append(('leading_dash_text', b'-abc\n', []))
cases.append(('dash_dash_text', b'--abc\n', []))


# Various HSCALE fractional values
for h in [0.1, 0.33, 0.66, 1.25, 1.75, 2.5, 3.7, 0.01]:
    cases.append((f'h_{h}_30', b'a' * 30 + b'\n', ['-H', str(h)]))


# Various VSCALE values
for v in [0.1, 0.33, 0.66, 0.99]:
    txt = (b'x\n' * 30)
    cases.append((f'v_{v}_30', txt, ['-V', str(v)]))


# Order of flags
cases.append(('order_h_v_file', python_code, ['-H', '2', '-V', '0.5']))
cases.append(('order_v_h_file', python_code, ['-V', '0.5', '-H', '2']))


# Encoding combinations
cases.append(('enc_lossy_explicit', b'\xff\n', ['--encoding=utf8-lossy']))
cases.append(('enc_utf8_valid', python_code, ['--encoding', 'utf8']))


# Big file
big = (b'The quick brown fox jumps over the lazy dog\n' * 50)
cases.append(('big_text', big, []))
cases.append(('big_text_h05', big, ['-H', '0.5']))
cases.append(('big_text_v05', big, ['-V', '0.5']))
cases.append(('big_text_h05_v05_pad', big, ['-H', '0.5', '-V', '0.5', '--padding', '60']))


def main():
    frames = []
    for name, stdin, args in cases:
        f = probe(name, stdin, args)
        if f is not None:
            frames.append(f)

    # Append to existing frames
    with open(OUT, 'a') as f:
        for frame in frames:
            f.write(json.dumps(frame) + '\n')

    print(f"Appended {len(frames)} frames to {OUT}")


if __name__ == '__main__':
    main()
