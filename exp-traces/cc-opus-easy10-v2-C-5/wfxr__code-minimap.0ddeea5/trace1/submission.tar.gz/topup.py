#!/usr/bin/env python3
"""Statistical top-up: 10 fresh probes from a usage Markov chain."""

import json
import base64
import subprocess
import os
import random

REF = os.environ.get('REF', '/workspace/executable')
SUT = os.environ.get('SUT', '/work/work/executable')


def run(binary, args, stdin_bytes):
    res = subprocess.run([binary] + args, input=stdin_bytes, capture_output=True, timeout=30)
    return res.returncode, res.stdout, res.stderr


# Markov-like generator: sample diverse usage patterns
def gen_input(rng):
    """Generate diverse input text."""
    kind = rng.choice(['empty', 'lines', 'long', 'utf8', 'invalid', 'whitespace'])
    if kind == 'empty':
        n_newlines = rng.randint(0, 5)
        return b'\n' * n_newlines
    elif kind == 'lines':
        n_lines = rng.randint(1, 30)
        out = []
        for _ in range(n_lines):
            w = rng.randint(0, 100)
            line = ''.join(rng.choice('abcdef ghij  klmnop') for _ in range(w))
            out.append(line)
        return ('\n'.join(out) + '\n').encode('utf-8')
    elif kind == 'long':
        return (rng.choice([b'x', b'a   b', b'abc def  ghi']) * rng.randint(1, 200) + b'\n')
    elif kind == 'utf8':
        chars = '日本語 Hello мирAB こんにちは\t世界\n'
        n = rng.randint(1, 30)
        return ''.join(rng.choice(chars) for _ in range(n)).encode('utf-8') + b'\n'
    elif kind == 'invalid':
        n = rng.randint(0, 30)
        return bytes([rng.randint(0, 255) for _ in range(n)]) + b'\n'
    elif kind == 'whitespace':
        # Lines of varying ws
        ws_chars = ' \t\r'
        n = rng.randint(1, 10)
        out = []
        for _ in range(n):
            w = rng.randint(0, 20)
            line = ''.join(rng.choice(ws_chars + 'abc') for _ in range(w))
            out.append(line)
        return ('\n'.join(out) + '\n').encode('utf-8')


def gen_args(rng):
    """Generate diverse argument lists."""
    args = []
    if rng.random() < 0.7:
        # HSCALE
        h = rng.choice([0.5, 0.25, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 0.1])
        args += ['-H', str(h)]
    if rng.random() < 0.7:
        v = rng.choice([0.5, 0.25, 0.125, 0.75, 1.0, 2.0, 0.1])
        args += ['-V', str(v)]
    if rng.random() < 0.4:
        p = rng.randint(0, 50)
        args += ['--padding', str(p)]
    if rng.random() < 0.2:
        enc = rng.choice(['utf8-lossy', 'utf8'])
        args += ['--encoding', enc]
    return args


def main():
    seed = int(os.environ.get('SEED', '777'))
    rng = random.Random(seed)
    fail = 0
    for i in range(10):
        stdin = gen_input(rng)
        args = gen_args(rng)
        try:
            ref_exit, ref_out, ref_err = run(REF, args, stdin)
            sut_exit, sut_out, sut_err = run(SUT, args, stdin)
        except Exception as e:
            print(f"#{i}: EXCEPTION: {e}")
            fail += 1
            continue
        if (ref_exit, ref_out, ref_err) != (sut_exit, sut_out, sut_err):
            print(f"#{i}: DIVERGE")
            print(f"  args: {args}")
            print(f"  stdin: {stdin[:80]!r}{'...' if len(stdin) > 80 else ''}")
            print(f"  ref exit/out/err: {ref_exit} / {ref_out[:80]!r} / {ref_err[:80]!r}")
            print(f"  sut exit/out/err: {sut_exit} / {sut_out[:80]!r} / {sut_err[:80]!r}")
            fail += 1
        else:
            print(f"#{i}: OK (args={args}, stdin {len(stdin)}b)")
    print(f"\nTop-up: {10 - fail}/10 OK")
    return fail


if __name__ == '__main__':
    import sys
    sys.exit(main())
