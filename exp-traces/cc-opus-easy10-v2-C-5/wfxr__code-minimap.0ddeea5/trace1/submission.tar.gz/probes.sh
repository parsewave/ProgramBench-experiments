#!/usr/bin/env bash
# Probe the reference binary and write frames.jsonl
# Each frame is: {name, stdin (b64), args (array), exit_code, stdout (b64), stderr (b64)}

set -u
REF=${REF:-/workspace/executable}
OUT=${OUT:-/work/work/frames.jsonl}

mkdir -p "$(dirname "$OUT")"
> "$OUT"

# helper: run with args, no stdin
run_simple() {
    local name="$1"; shift
    local args_json="$1"; shift
    local stdin_b64=""
    local stdout
    local stderr_file
    local exit_code
    stderr_file=$(mktemp)
    stdout=$("$REF" "$@" 2>"$stderr_file" </dev/null | base64 -w0)
    exit_code=$?
    local stderr_b64
    stderr_b64=$(base64 -w0 <"$stderr_file")
    rm -f "$stderr_file"
    python3 -c "
import json, sys
print(json.dumps({
  'name': '$name',
  'stdin_b64': '$stdin_b64',
  'args': $args_json,
  'exit_code': $exit_code,
  'stdout_b64': '$stdout',
  'stderr_b64': '$stderr_b64',
}, ensure_ascii=False))
" >> "$OUT"
}

# helper: run with stdin
run_stdin() {
    local name="$1"; shift
    local stdin_b64="$1"; shift
    local args_json="$1"; shift
    local stdout
    local stderr_file
    local exit_code
    stderr_file=$(mktemp)
    stdout=$(echo -n "$stdin_b64" | base64 -d | "$REF" "$@" 2>"$stderr_file" | base64 -w0)
    exit_code=$?
    local stderr_b64
    stderr_b64=$(base64 -w0 <"$stderr_file")
    rm -f "$stderr_file"
    python3 -c "
import json, sys
print(json.dumps({
  'name': '$name',
  'stdin_b64': '$stdin_b64',
  'args': $args_json,
  'exit_code': $exit_code,
  'stdout_b64': '$stdout',
  'stderr_b64': '$stderr_b64',
}, ensure_ascii=False))
" >> "$OUT"
}

# Convenience: pass raw stdin string (printf interpreted), args as JSON
probe() {
    local name="$1"
    local stdin_str="$2"
    local args_json="$3"
    shift 3
    local b64
    b64=$(printf '%b' "$stdin_str" | base64 -w0)
    run_stdin "$name" "$b64" "$args_json" "$@"
}

# Probe surface
run_simple "help_long" '["--help"]' --help
run_simple "help_short" '["-h"]' -h
run_simple "version" '["--version"]' --version
run_simple "no_args_empty" '[]'
run_simple "bogus_flag" '["--bogus"]' --bogus
run_simple "dash_only" '["-"]' -
run_simple "doubledash_only" '["--"]' --

# Empty / whitespace
probe "empty_input" "" '[]'
probe "single_newline" "\n" '[]'
probe "single_space_newline" " \n" '[]'
probe "spaces_only" "    \n" '[]'
probe "tab_only" "\t\n" '[]'
probe "single_a" "a" '[]'
probe "single_a_nl" "a\n" '[]'
probe "ab" "ab" '[]'
probe "abc" "abc" '[]'
probe "abcd" "abcd" '[]'

# Multi-line
probe "abc_def" "abc\ndef\n" '[]'
probe "5_lines" "a\nb\nc\nd\ne\n" '[]'
probe "8_lines" "a\nb\nc\nd\ne\nf\ng\nh\n" '[]'
probe "long_line_8x8" "aaaaaaaa\naaaaaaaa\naaaaaaaa\naaaaaaaa\naaaaaaaa\naaaaaaaa\naaaaaaaa\naaaaaaaa\n" '[]'
probe "mixed_widths" "a\nbb\nccc\ndddd\neeeee\nffffff\nggggggg\nhhhhhhhh\n" '[]'

# Whitespace
probe "leading_spaces" "  ab\n" '[]'
probe "trailing_spaces" "ab  \n" '[]'
probe "middle_spaces" "a  b\n" '[]'
probe "tab_a" "\ta\n" '[]'
probe "a_tab_b" "a\tb\n" '[]'
probe "all_spaces_4" "    \n" '[]'

# CR/LF
probe "crlf" "abc\r\ndef\r\n" '[]'
probe "cr_only_mid" "abc\rdef\r" '[]'

# Multi-byte UTF-8
probe "cjk_zhong" "\xe4\xb8\xad\n" '[]'
probe "two_cjk" "\xe4\xb8\xad\xe4\xb8\xad\n" '[]'
probe "a_cjk_b" "a\xe4\xb8\xadb\n" '[]'
probe "nbsp_alone" "\xc2\xa0\n" '[]'
probe "a_nbsp_b" "a\xc2\xa0b\n" '[]'
probe "emoji" "\xf0\x9f\x98\x80\n" '[]'
probe "abc_emoji" "abc\xf0\x9f\x98\x80\n" '[]'
probe "bom_hello" "\xef\xbb\xbfhello\n" '[]'

# Invalid UTF-8 (lossy)
probe "lossy_ff_alone" "\xff\n" '[]'
probe "lossy_ff_ff" "\xff\xfe\n" '[]'
probe "lossy_ff_a" "\xffa\n" '[]'
probe "lossy_a_ff" "a\xff\n" '[]'
probe "lossy_c2_alone" "\xc2\n" '[]'
probe "lossy_c2_a" "\xc2a\n" '[]'
probe "lossy_80_alone" "\x80\n" '[]'
probe "lossy_80_a" "\x80a\n" '[]'
probe "lossy_80_80_a" "\x80\x80a\n" '[]'
probe "lossy_3invalid" "\xff\xfe\xfd\n" '[]'

# UTF-8 strict mode
probe "strict_invalid" "\xff\n" '["--encoding","utf8"]' --encoding utf8
probe "strict_valid_emoji" "\xf0\x9f\x98\x80\n" '["--encoding","utf8"]' --encoding utf8

# HSCALE
probe "h_2_a" "a\n" '["-H","2"]' -H 2
probe "h_2_ab" "ab\n" '["-H","2"]' -H 2
probe "h_2_abcd" "abcd\n" '["-H","2"]' -H 2
probe "h_4_a" "a\n" '["-H","4"]' -H 4
probe "h_05_a" "a\n" '["-H","0.5"]' -H 0.5
probe "h_05_ab" "ab\n" '["-H","0.5"]' -H 0.5
probe "h_05_abcd" "abcd\n" '["-H","0.5"]' -H 0.5
probe "h_0_abc" "abc\n" '["-H","0"]' -H 0
probe "h_15_ab" "ab\n" '["-H","1.5"]' -H 1.5
probe "h_15_abcd" "abcd\n" '["-H","1.5"]' -H 1.5
probe "h_05_3sp_a" "   a\n" '["-H","0.5"]' -H 0.5
probe "h_05_2sp_a" "  a\n" '["-H","0.5"]' -H 0.5
probe "h_05_long" "aaaaaaaa\n" '["-H","0.5"]' -H 0.5
probe "h_05_empty" "\n" '["-H","0.5"]' -H 0.5
probe "h_2_empty" "\n" '["-H","2"]' -H 2
probe "h_3_empty" "\n" '["-H","3"]' -H 3
probe "h_4_empty" "\n" '["-H","4"]' -H 4

# VSCALE
probe "v_05_8" "a\nb\nc\nd\ne\nf\ng\nh\n" '["-V","0.5"]' -V 0.5
probe "v_025_8" "a\nb\nc\nd\ne\nf\ng\nh\n" '["-V","0.25"]' -V 0.25
probe "v_0125_8" "a\nb\nc\nd\ne\nf\ng\nh\n" '["-V","0.125"]' -V 0.125
probe "v_2_8" "a\nb\nc\nd\ne\nf\ng\nh\n" '["-V","2"]' -V 2
probe "v_075_8" "a\nb\nc\nd\ne\nf\ng\nh\n" '["-V","0.75"]' -V 0.75
probe "v_05_or" "a\n\n" '["-V","0.5"]' -V 0.5
probe "v_0" "a\nb\nc\nd\ne\nf\ng\nh\n" '["-V","0"]' -V 0
probe "v_neg" "a\nb\n" '["--vertical-scale=-1"]' --vertical-scale=-1

# Padding
probe "pad_5_abcd" "abcd\n" '["--padding","5"]' --padding 5
probe "pad_4_a" "a\n" '["--padding","4"]' --padding 4
probe "pad_4_empty" "\n" '["--padding","4"]' --padding 4
probe "pad_2_abcd" "abcd\n" '["--padding","2"]' --padding 2
probe "pad_0_a" "a\n" '["--padding","0"]' --padding 0
probe "pad_3_diff" "a\nb\nc\nd\nabcdefgh\ne\nf\ng\n" '["--padding","3"]' --padding 3

# Combinations
probe "h2_v05" "abc\ndef\nghi\njkl\n" '["-H","2","-V","0.5"]' -H 2 -V 0.5
probe "h05_v05_pad8" "abcdefgh\nij\nkl\nmnop\n" '["-H","0.5","-V","0.5","--padding","8"]' -H 0.5 -V 0.5 --padding 8

# Errors
run_simple "err_bad_h" '["-H","abc"]' -H abc
run_simple "err_neg_h" '["-H","-1"]' -H -1
run_simple "err_unknown_subcmd" '["foobar"]' foobar
run_simple "err_missing_file" '["/tmp/no_such_file_xyz123"]' /tmp/no_such_file_xyz123
run_simple "err_dir" '["/tmp"]' /tmp

# Completion
run_simple "completion_bash" '["completion","bash"]' completion bash
run_simple "completion_fish" '["completion","fish"]' completion fish
run_simple "completion_zsh" '["completion","zsh"]' completion zsh
run_simple "completion_powershell" '["completion","powershell"]' completion powershell
run_simple "completion_elvish" '["completion","elvish"]' completion elvish
run_simple "completion_invalid" '["completion","bogus"]' completion bogus
run_simple "completion_missing_arg" '["completion"]' completion

# Help subcommand
run_simple "help_subcmd" '["help"]' help
run_simple "help_completion" '["help","completion"]' help completion

echo "Wrote $(wc -l <"$OUT") frames to $OUT"
