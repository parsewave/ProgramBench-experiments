#!/usr/bin/env python3
"""Generate frames.jsonl by probing the reference binary."""

import json
import base64
import subprocess
import os
import sys

REF = os.environ.get('REF', '/workspace/executable')
OUT = os.environ.get('OUT', '/work/work/frames.jsonl')


def probe(name, stdin_bytes, args):
    """Run REF with given stdin and args. Capture exit, stdout, stderr."""
    try:
        res = subprocess.run([REF] + args, input=stdin_bytes,
                             capture_output=True, timeout=30)
        return {
            'name': name,
            'stdin_b64': base64.b64encode(stdin_bytes).decode('ascii'),
            'args': args,
            'exit_code': res.returncode,
            'stdout_b64': base64.b64encode(res.stdout).decode('ascii'),
            'stderr_b64': base64.b64encode(res.stderr).decode('ascii'),
        }
    except subprocess.TimeoutExpired:
        return {
            'name': name,
            'stdin_b64': base64.b64encode(stdin_bytes).decode('ascii'),
            'args': args,
            'exit_code': -1,
            'stdout_b64': '',
            'stderr_b64': '',
            'timeout': True,
        }


def main():
    cases = []

    # ---- Surface scan ----
    cases.append(('help_long', b'', ['--help']))
    cases.append(('help_short', b'', ['-h']))
    cases.append(('version', b'', ['--version']))
    cases.append(('no_args_empty', b'', []))
    cases.append(('bogus_flag', b'', ['--bogus']))
    cases.append(('dash_only', b'', ['-']))
    cases.append(('doubledash_only', b'', ['--']))

    # ---- Empty / whitespace ----
    cases.append(('empty_input', b'', []))
    cases.append(('single_newline', b'\n', []))
    cases.append(('single_space_newline', b' \n', []))
    cases.append(('spaces_only', b'    \n', []))
    cases.append(('tab_only', b'\t\n', []))
    cases.append(('single_a', b'a', []))
    cases.append(('single_a_nl', b'a\n', []))
    cases.append(('ab', b'ab', []))
    cases.append(('abc', b'abc', []))
    cases.append(('abcd', b'abcd', []))

    # ---- Multi-line ----
    cases.append(('abc_def', b'abc\ndef\n', []))
    cases.append(('5_lines', b'a\nb\nc\nd\ne\n', []))
    cases.append(('8_lines', b'a\nb\nc\nd\ne\nf\ng\nh\n', []))
    cases.append(('long_line_8x8', b'aaaaaaaa\n' * 8, []))
    cases.append(('mixed_widths', b'a\nbb\nccc\ndddd\neeeee\nffffff\nggggggg\nhhhhhhhh\n', []))

    # ---- Whitespace handling ----
    cases.append(('leading_spaces', b'  ab\n', []))
    cases.append(('trailing_spaces', b'ab  \n', []))
    cases.append(('middle_spaces', b'a  b\n', []))
    cases.append(('tab_a', b'\ta\n', []))
    cases.append(('a_tab_b', b'a\tb\n', []))
    cases.append(('all_spaces_4', b'    \n', []))

    # ---- CR/LF ----
    cases.append(('crlf', b'abc\r\ndef\r\n', []))
    cases.append(('cr_only_mid', b'abc\rdef\r', []))

    # ---- Multi-byte UTF-8 ----
    cases.append(('cjk_zhong', '中\n'.encode('utf-8'), []))
    cases.append(('two_cjk', '中中\n'.encode('utf-8'), []))
    cases.append(('a_cjk_b', 'a中b\n'.encode('utf-8'), []))
    cases.append(('nbsp_alone', ' \n'.encode('utf-8'), []))
    cases.append(('a_nbsp_b', 'a b\n'.encode('utf-8'), []))
    cases.append(('emoji', '\U0001F600\n'.encode('utf-8'), []))
    cases.append(('abc_emoji', 'abc\U0001F600\n'.encode('utf-8'), []))
    cases.append(('bom_hello', '﻿hello\n'.encode('utf-8'), []))
    cases.append(('uplus2028', 'abc def\n'.encode('utf-8'), []))
    cases.append(('uplus3000', 'a　b\n'.encode('utf-8'), []))
    cases.append(('uplus200B', 'a​b\n'.encode('utf-8'), []))
    cases.append(('uplus1F', b'a\x1fb\n', []))

    # ---- Invalid UTF-8 (lossy) ----
    cases.append(('lossy_ff_alone', b'\xff\n', []))
    cases.append(('lossy_ff_ff', b'\xff\xfe\n', []))
    cases.append(('lossy_ff_a', b'\xffa\n', []))
    cases.append(('lossy_a_ff', b'a\xff\n', []))
    cases.append(('lossy_c2_alone', b'\xc2\n', []))
    cases.append(('lossy_c2_a', b'\xc2a\n', []))
    cases.append(('lossy_c2_80', b'\xc2\x80\n', []))
    cases.append(('lossy_80_alone', b'\x80\n', []))
    cases.append(('lossy_80_a', b'\x80a\n', []))
    cases.append(('lossy_80_80_a', b'\x80\x80a\n', []))
    cases.append(('lossy_3invalid', b'\xff\xfe\xfd\n', []))
    cases.append(('lossy_overlong', b'\xc0\x80\n', []))

    # ---- UTF-8 strict mode ----
    cases.append(('strict_invalid', b'\xff\n', ['--encoding', 'utf8']))
    cases.append(('strict_valid_emoji', '\U0001F600\n'.encode('utf-8'), ['--encoding', 'utf8']))
    cases.append(('lossy_default', b'\xff\n', ['--encoding', 'utf8-lossy']))

    # ---- HSCALE ----
    cases.append(('h_2_a', b'a\n', ['-H', '2']))
    cases.append(('h_2_ab', b'ab\n', ['-H', '2']))
    cases.append(('h_2_abcd', b'abcd\n', ['-H', '2']))
    cases.append(('h_4_a', b'a\n', ['-H', '4']))
    cases.append(('h_05_a', b'a\n', ['-H', '0.5']))
    cases.append(('h_05_ab', b'ab\n', ['-H', '0.5']))
    cases.append(('h_05_abcd', b'abcd\n', ['-H', '0.5']))
    cases.append(('h_0_abc', b'abc\n', ['-H', '0']))
    cases.append(('h_15_ab', b'ab\n', ['-H', '1.5']))
    cases.append(('h_15_abcd', b'abcd\n', ['-H', '1.5']))
    cases.append(('h_05_3sp_a', b'   a\n', ['-H', '0.5']))
    cases.append(('h_05_2sp_a', b'  a\n', ['-H', '0.5']))
    cases.append(('h_05_long', b'aaaaaaaa\n', ['-H', '0.5']))
    cases.append(('h_05_empty', b'\n', ['-H', '0.5']))
    cases.append(('h_2_empty', b'\n', ['-H', '2']))
    cases.append(('h_3_empty', b'\n', ['-H', '3']))
    cases.append(('h_4_empty', b'\n', ['-H', '4']))
    cases.append(('h_05_aaa_4x', b'aaa\n' * 4, ['-H', '0.5']))

    # ---- VSCALE ----
    cases.append(('v_05_8', b'a\nb\nc\nd\ne\nf\ng\nh\n', ['-V', '0.5']))
    cases.append(('v_025_8', b'a\nb\nc\nd\ne\nf\ng\nh\n', ['-V', '0.25']))
    cases.append(('v_0125_8', b'a\nb\nc\nd\ne\nf\ng\nh\n', ['-V', '0.125']))
    cases.append(('v_2_8', b'a\nb\nc\nd\ne\nf\ng\nh\n', ['-V', '2']))
    cases.append(('v_075_8', b'a\nb\nc\nd\ne\nf\ng\nh\n', ['-V', '0.75']))
    cases.append(('v_05_or', b'a\n\n', ['-V', '0.5']))
    cases.append(('v_05_aabbcc', b'a\nbcd\n', ['-V', '0.5']))
    cases.append(('v_0', b'a\nb\nc\nd\ne\nf\ng\nh\n', ['-V', '0']))
    cases.append(('v_neg_eq', b'a\nb\n', ['--vertical-scale=-1']))
    cases.append(('v_05_16', b'1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n', ['-V', '0.5']))
    cases.append(('v_075_16', b'1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n', ['-V', '0.75']))
    cases.append(('v_025_16', b'1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n', ['-V', '0.25']))

    # ---- Padding ----
    cases.append(('pad_5_abcd', b'abcd\n', ['--padding', '5']))
    cases.append(('pad_4_a', b'a\n', ['--padding', '4']))
    cases.append(('pad_4_empty', b'\n', ['--padding', '4']))
    cases.append(('pad_2_abcd', b'abcd\n', ['--padding', '2']))
    cases.append(('pad_0_a', b'a\n', ['--padding', '0']))
    cases.append(('pad_3_diff', b'a\nb\nc\nd\nabcdefgh\ne\nf\ng\n', ['--padding', '3']))
    cases.append(('pad_eq_4', b'a\n', ['--padding=4']))
    cases.append(('pad_10_a', b'a\n', ['--padding', '10']))

    # ---- Combinations ----
    cases.append(('h2_v05', b'abc\ndef\nghi\njkl\n', ['-H', '2', '-V', '0.5']))
    cases.append(('h05_v05_pad8', b'abcdefgh\nij\nkl\nmnop\n', ['-H', '0.5', '-V', '0.5', '--padding', '8']))

    # ---- Trailing newline behavior ----
    cases.append(('a_no_nl', b'a', []))
    cases.append(('a_nl', b'a\n', []))
    cases.append(('a_nl_nl', b'a\n\n', []))
    cases.append(('a_5nl', b'a\n\n\n\n\n', []))
    cases.append(('empty_a_empty', b'\na\n', []))
    cases.append(('hello_5nl', b'hello\n\n\n\n\n', []))

    # ---- File handling ----
    cases.append(('err_missing_file', b'', ['/tmp/no_such_file_xyz123']))
    cases.append(('err_dir', b'', ['/tmp']))

    # ---- Argument errors ----
    cases.append(('err_bad_h', b'', ['-H', 'abc']))
    cases.append(('err_neg_h', b'', ['-H', '-1']))
    cases.append(('err_h_missing', b'', ['-H']))
    cases.append(('err_h_repeat', b'', ['-H', '1', '-H', '2']))
    cases.append(('err_v_repeat', b'', ['-V', '1', '-V', '2']))
    cases.append(('err_unknown_subcmd_foobar', b'', ['foobar']))
    cases.append(('err_unknown_flag', b'', ['--bogus']))
    cases.append(('err_unknown_subcmd_via_file', b'', ['noexist']))
    cases.append(('err_neg_pad', b'', ['--padding=-1']))
    cases.append(('err_neg_pad_2', b'', ['--padding', '-1']))
    cases.append(('err_two_positional', b'', ['a', 'b']))

    # ---- Completion ----
    cases.append(('completion_bash', b'', ['completion', 'bash']))
    cases.append(('completion_fish', b'', ['completion', 'fish']))
    cases.append(('completion_zsh', b'', ['completion', 'zsh']))
    cases.append(('completion_powershell', b'', ['completion', 'powershell']))
    cases.append(('completion_elvish', b'', ['completion', 'elvish']))
    cases.append(('completion_invalid_bogus', b'', ['completion', 'bogus']))
    cases.append(('completion_invalid_mybash', b'', ['completion', 'mybash']))
    cases.append(('completion_missing_arg', b'', ['completion']))

    # ---- Help subcommand ----
    cases.append(('help_subcmd', b'', ['help']))
    cases.append(('help_completion', b'', ['help', 'completion']))
    cases.append(('help_help', b'', ['help', 'help']))

    # ---- Big sweep ----
    cases.append(('big_30_lines', '\n'.join(['line ' + str(i) for i in range(30)]).encode('utf-8') + b'\n', []))
    cases.append(('mixed_5_widths_pad8', b'a\nbb\nccc\ndddd\neeeee\n', ['--padding', '8']))

    frames = []
    for name, stdin_bytes, args in cases:
        frame = probe(name, stdin_bytes, args)
        frames.append(frame)

    with open(OUT, 'w') as f:
        for frame in frames:
            f.write(json.dumps(frame) + '\n')

    print(f"Wrote {len(frames)} frames to {OUT}")


if __name__ == '__main__':
    main()
