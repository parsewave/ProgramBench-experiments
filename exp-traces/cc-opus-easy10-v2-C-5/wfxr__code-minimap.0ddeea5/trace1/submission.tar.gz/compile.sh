#!/usr/bin/env bash
# Build the executable: a shim script that invokes the Python implementation.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Copy completion scripts to a stable location relative to the script
mkdir -p completions
for sh in bash elvish fish powershell zsh; do
  if [[ -f "goldens/completion/$sh.txt" ]]; then
    cp "goldens/completion/$sh.txt" "completions/$sh.txt"
  fi
done

# Create the executable shim
cat > executable <<'EOF'
#!/usr/bin/env bash
# Shim — find code_minimap.py next to this binary and invoke with python3.
SELF="$(readlink -f "$0")"
DIR="$(dirname "$SELF")"
exec python3 "$DIR/code_minimap.py" "$@"
EOF
chmod +x executable

# Sanity check
echo "Built $SCRIPT_DIR/executable"
