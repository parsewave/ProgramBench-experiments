#!/usr/bin/env python3
"""Reimplementation of hx 0.7.0 — futuristic hex dump."""
import sys
import os
import math
import errno

VERSION = "hx 0.7.0"

HELP = """Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
"""

USAGE_SHORT = """Usage: executable [OPTIONS] [INPUTFILE]

For more information, try '--help'.
"""

USAGE_TIP = """Usage: executable [OPTIONS] [INPUTFILE]

For more information, try '--help'.
"""


def write_out(data):
    if isinstance(data, str):
        data = data.encode('utf-8', errors='surrogateescape')
    try:
        sys.stdout.buffer.write(data)
    except BrokenPipeError:
        sys.exit(0)


def write_err(data):
    if isinstance(data, str):
        data = data.encode('utf-8', errors='surrogateescape')
    sys.stderr.buffer.write(data)


def clap_unexpected(arg):
    """Print clap-style 'unexpected argument' error and exit 2."""
    write_err(f"error: unexpected argument '{arg}' found\n")
    if arg.startswith('-'):
        write_err(f"\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n")
    write_err("\n" + USAGE_TIP)
    sys.exit(2)


def clap_unexpected_pos(arg):
    """Print clap-style 'unexpected positional' (no tip)."""
    write_err(f"error: unexpected argument '{arg}' found\n\n")
    write_err(USAGE_TIP)
    sys.exit(2)


def clap_invalid_value(name_long, val, options=None, tip=None):
    """Print clap-style 'invalid value' error."""
    msg = f"error: invalid value '{val}' for '{name_long}'\n"
    if options is not None:
        msg += f"  [possible values: {', '.join(options)}]\n"
    msg += "\n"
    if tip:
        msg += f"  tip: a similar value exists: '{tip}'\n\n"
    msg += "For more information, try '--help'.\n"
    write_err(msg)
    sys.exit(2)


def clap_dup(name_long_with_val):
    write_err(f"error: the argument '{name_long_with_val}' cannot be used multiple times\n\n")
    write_err(USAGE_TIP)
    sys.exit(2)


def clap_missing_value(name_long_with_val, choices=None):
    write_err(f"error: a value is required for '{name_long_with_val}' but none was supplied\n")
    if choices is not None:
        write_err(f"  [possible values: {', '.join(choices)}]\n")
    write_err("\nFor more information, try '--help'.\n")
    sys.exit(2)


U64_MAX = (1 << 64) - 1


def parse_int_value(short, long_, raw):
    """Parse integer like Rust's u64::parse(). On failure print error and exit 1."""
    s = raw

    def fail(kind_name, msg):
        write_err(f"-{short}, --{long_} <integer> expected. ParseIntError {{ kind: {kind_name} }}\nerror: {msg}\n")
        sys.exit(1)

    if not s:
        fail("Empty", "cannot parse integer from empty string")

    # Rust's u64 parse: accepts optional leading + only, digits only.
    if s.startswith('-'):
        # Negative for u64 → NegOverflow
        fail("NegOverflow", "number too small to fit in target type")
    if s.startswith('+'):
        s2 = s[1:]
    else:
        s2 = s
    if not s2 or not s2.isdigit():
        fail("InvalidDigit", "invalid digit found in string")
    val = int(s2)
    if val > U64_MAX:
        fail("PosOverflow", "number too large to fit in target type")
    return val, None


# Color code for byte value
def color_for_byte(b):
    return 22 if b == 0 else b


def byte_to_ascii(b):
    return chr(b) if 0x20 <= b <= 0x7e else '.'


def format_byte(b, fmt, prefix):
    """Format single byte according to -f and -r."""
    if fmt == 'x':
        s = f"{b:02x}"
    elif fmt == 'X':
        s = f"{b:02X}"
    elif fmt == 'o':
        s = f"{b:04o}"
    elif fmt == 'b':
        s = f"{b:08b}"
    if prefix:
        return {'x': '0x', 'X': '0x', 'o': '0o', 'b': '0b'}[fmt] + s
    return s


def cell_width(fmt, prefix):
    if fmt == 'x' or fmt == 'X':
        return 4 if prefix else 2
    elif fmt == 'o':
        return 6 if prefix else 4
    elif fmt == 'b':
        return 10 if prefix else 8


def parse_args(argv):
    """Parse args, returning a dict of options and the (optional) file path."""
    opts = {
        'cols': None,
        'len': None,
        'format': None,
        'color': None,
        'array': None,
        'func': None,
        'places': None,
        'prefix': None,
        'file': None,
        'help': False,
        'version': False,
    }
    set_keys = set()

    # Pre-scan for -h/--help/-V/--version (first occurrence wins).
    # clap processes these before doing other validation.
    for a in argv:
        if a == '--':
            break
        if a in ('-h', '--help'):
            opts['help'] = True
            return opts
        if a in ('-V', '--version'):
            opts['version'] = True
            return opts

    i = 0
    args = list(argv)
    saw_double_dash = False
    positional_count = 0

    while i < len(args):
        a = args[i]
        if a == '--':
            saw_double_dash = True
            i += 1
            continue

        if saw_double_dash:
            if positional_count > 0:
                clap_unexpected_pos(a)
            opts['file'] = a
            positional_count += 1
            i += 1
            continue

        # Help/version - capture first occurrence
        if a in ('-h', '--help'):
            if not opts['help'] and not opts['version']:
                opts['help'] = True
            i += 1
            continue
        if a in ('-V', '--version'):
            if not opts['help'] and not opts['version']:
                opts['version'] = True
            i += 1
            continue

        # Options needing a value
        for short, long_, key, parse_kind, choices, similar_choices, metavar in [
            ('c', 'cols', 'cols', 'int', None, None, 'columns'),
            ('l', 'len', 'len', 'int', None, None, 'len'),
            ('f', 'format', 'format', 'enum', ['o', 'x', 'X', 'b'], True, 'format'),
            ('t', 'color', 'color', 'enum', ['0', '1'], False, 'color'),
            ('a', 'array', 'array', 'enum', ['r', 'c', 'g', 'p', 'k', 'j', 's', 'f'], False, 'array_format'),
            ('u', 'func', 'func', 'int', None, None, 'func_length'),
            ('p', 'places', 'places', 'int', None, None, 'func_places'),
            ('r', 'prefix', 'prefix', 'enum', ['0', '1'], False, 'prefix'),
        ]:
            short_dash = f"-{short}"
            long_dash = f"--{long_}"
            long_with_val = f"--{long_} <{metavar}>"
            # Match either form: -c, --cols, -c=val, --cols=val, or as separate tokens
            val = None
            matched = False
            if a == short_dash or a == long_dash:
                # Next token is value
                if i + 1 >= len(args):
                    clap_missing_value(long_with_val, choices=choices if parse_kind == 'enum' else None)
                val = args[i + 1]
                # Special case: if next is "--", treat as no value
                if val == '--':
                    clap_missing_value(long_with_val, choices=choices if parse_kind == 'enum' else None)
                # Reject like clap: if value looks like a flag (-X) reject? Actually clap rejects -1 here.
                if val.startswith('-') and val != '-':
                    # See if it's a number with leading minus — clap rejects
                    # Standard clap behavior: if next looks like an option, it's an error.
                    # Match observed: '-c -1' → "unexpected argument '-1' found"
                    # Truncate to '-X' (first char after dash)
                    truncated = val[:2]
                    clap_unexpected(truncated)
                i += 2
                matched = True
            elif a.startswith(short_dash) and len(a) > 2 and short != 'h' and short != 'V':
                # e.g., -c10 (not standard but possible)
                val = a[2:]
                i += 1
                matched = True
            elif a.startswith(long_dash + '='):
                val = a[len(long_dash) + 1:]
                i += 1
                matched = True

            if matched:
                if key in set_keys:
                    clap_dup(long_with_val)
                set_keys.add(key)
                if parse_kind == 'int':
                    # Defer int parsing. Empty value will trigger parse error when used.
                    # Store raw string for later validation; also keep short/long for error msg.
                    opts[key + '_raw'] = (short, long_, val)
                else:
                    # Enum validation happens in clap (immediately).
                    if val == '':
                        clap_missing_value(long_with_val, choices=choices)
                    if val not in choices:
                        tip = None
                        # clap's "similar value" tip: when value starts with a valid choice
                        if len(val) > 1 and val[0] in choices:
                            tip = val[0]
                        clap_invalid_value(long_with_val, val, options=choices, tip=tip)
                    opts[key] = val
                break
        else:
            # Not matched; treat as positional or unknown flag
            if a.startswith('-') and a != '-':
                clap_unexpected(a)
            if positional_count > 0:
                clap_unexpected_pos(a)
            opts['file'] = a
            positional_count += 1
            i += 1

    # Apply defaults (don't override raw int values; those resolve later)
    if opts['format'] is None:
        opts['format'] = 'x'
    if opts['prefix'] is None:
        opts['prefix'] = 1
    else:
        opts['prefix'] = int(opts['prefix'])

    return opts


def open_input(path):
    """Open file; on error, print message and exit 1."""
    try:
        return open(path, 'rb')
    except FileNotFoundError:
        write_err("error: No such file or directory (os error 2)\n")
        sys.exit(1)
    except IsADirectoryError:
        write_err("error: Is a directory (os error 21)\n")
        sys.exit(1)
    except PermissionError:
        write_err("error: Permission denied (os error 13)\n")
        sys.exit(1)
    except OSError as e:
        msg = e.strerror or "I/O error"
        write_err(f"error: {msg} (os error {e.errno})\n")
        sys.exit(1)


def read_input(opts):
    """Read input bytes (file or stdin), honoring -l."""
    limit = opts['len']
    if opts['file']:
        f = open_input(opts['file'])
        if limit > 0:
            data = f.read(limit)
        else:
            data = f.read()
        f.close()
        return data
    else:
        try:
            stdin = sys.stdin.buffer
            if limit > 0:
                data = stdin.read(limit)
            else:
                data = stdin.read()
            return data
        except OSError as e:
            write_err(f"error: {e.strerror or 'I/O error'} (os error {e.errno})\n")
            sys.exit(1)


def detect_color(opts):
    """Decide whether to colorize."""
    if opts['color'] == '1':
        return True
    if opts['color'] == '0':
        return False
    # Auto
    no_color = os.environ.get('NO_COLOR', '')
    if no_color:
        return False
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def emit_hex(data, opts):
    cols = opts['cols']
    fmt = opts['format']
    prefix = bool(opts['prefix'])
    color = detect_color(opts)

    n = len(data)

    def cell_for_byte(b):
        s = format_byte(b, fmt, prefix)
        if color:
            return f"\x1b[38;5;{color_for_byte(b)}m{s}\x1b[0m"
        return s

    def cell_empty():
        # Empty cells always use 4-char width (hex with prefix width), regardless of -f/-r.
        return '    '

    def ascii_for_byte(b):
        ch = byte_to_ascii(b)
        if color:
            return f"\x1b[38;5;{color_for_byte(b)}m{ch}\x1b[0m"
        return ch

    def emit_row(offset, row_bytes):
        out = f"0x{offset:06x}:"
        # Cell count: num_data + num_empty (where num_empty = max(0, cols - num_data))
        num_data = len(row_bytes)
        num_empty = max(0, cols - num_data)
        total_cells = num_data + num_empty
        out += " "
        for i in range(total_cells):
            if i < num_data:
                out += cell_for_byte(row_bytes[i])
            else:
                out += cell_empty()
            out += " "
        # ASCII
        for b in row_bytes:
            out += ascii_for_byte(b)
        out += "\n"
        write_out(out)

    chunk_size = max(cols, 1)

    # Iterate rows
    i = 0
    while i < n:
        chunk = data[i:i+chunk_size]
        emit_row(i, chunk)
        i += chunk_size
    # Trailing empty row?
    if n == 0 or (n > 0 and n % chunk_size == 0):
        emit_row(n, b'')

    # Footer
    write_out(f"   bytes: {n}\n")


def emit_array(data, opts):
    cols = opts['cols']
    fmt = opts['array']

    # Formats and bracketing
    if fmt == 'r':
        header = f"let ARRAY: [u8; {len(data)}] = [\n"
        footer = "];\n"
        sep = ', '
        suffix_byte = ''
        trailing_after_last = False
    elif fmt == 'c':
        header = f"unsigned char ARRAY[{len(data)}] = {{\n"
        footer = "};\n"
        sep = ', '
        suffix_byte = ''
        trailing_after_last = False
    elif fmt == 'g':
        header = f"a := [{len(data)}]byte{{\n"
        footer = "}\n"
        sep = ', '
        suffix_byte = ''
        trailing_after_last = True
    elif fmt == 'p':
        header = "a = [\n"
        footer = "]\n"
        sep = ', '
        suffix_byte = ''
        trailing_after_last = False
    elif fmt == 'k':
        header = "val a = byteArrayOf(\n"
        footer = ")\n"
        sep = ', '
        suffix_byte = ''
        trailing_after_last = False
    elif fmt == 'j':
        header = "byte[] a = new byte[]{\n"
        footer = "};\n"
        sep = ', '
        suffix_byte = ''
        trailing_after_last = False
    elif fmt == 's':
        header = "let a: [UInt8] = [\n"
        footer = "]\n"
        sep = ', '
        suffix_byte = ''
        trailing_after_last = False
    elif fmt == 'f':
        header = "let a = [|\n"
        footer = "|]\n"
        sep = '; '
        suffix_byte = 'uy'
        trailing_after_last = False

    write_out(header)

    n = len(data)
    if cols < 1:
        cols_eff = 1
    else:
        cols_eff = cols

    if n == 0:
        # Just print an empty indent line
        write_out("    \n")
    else:
        for row_start in range(0, n, cols_eff):
            row = data[row_start:row_start + cols_eff]
            is_last_row = (row_start + len(row) >= n)
            line = "    "
            entries = [f"0x{b:02x}{suffix_byte}" for b in row]
            for idx, e in enumerate(entries):
                line += e
                # Determine if there's a separator after
                is_last_entry_in_row = (idx == len(entries) - 1)
                if not is_last_entry_in_row:
                    line += sep
                else:
                    # Last entry in this row
                    if not is_last_row:
                        # not last row → trailing sep
                        line += sep
                    else:
                        # last row last entry
                        if trailing_after_last:
                            line += sep
                        # else: no sep
            line += '\n'
            write_out(line)
        # Trailing empty row if exact multiple
        if n % cols_eff == 0:
            write_out("    \n")

    write_out(footer)


def emit_func(opts):
    n = opts['func']
    if n < 0:
        n = 0
    places = opts['places']
    if places < 0:
        places = 0

    out_parts = []
    line_count = 0
    for i in range(n):
        v = math.sin(i * math.pi / (2 * n))
        out_parts.append(f"{v:.{places}f},")
        line_count += 1
        if line_count == 10:
            out_parts.append('\n')
            line_count = 0
    out_parts.append('\n')
    write_out(''.join(out_parts))


def resolve_int(opts, key, default):
    """Resolve a deferred int value. Validates if raw is present."""
    raw_key = key + '_raw'
    if raw_key in opts:
        short, long_, raw = opts[raw_key]
        v, _ = parse_int_value(short, long_, raw)
        return v
    return default


def main():
    argv = sys.argv[1:]
    opts = parse_args(argv)

    if opts['help']:
        write_out(HELP)
        sys.exit(0)
    if opts['version']:
        write_out(VERSION + "\n")
        sys.exit(0)

    # Mode determination: -u (func) > -a (array) > default (hex)
    if 'func_raw' in opts:
        # Validate -u and -p
        opts['func'] = resolve_int(opts, 'func', 0)
        opts['places'] = resolve_int(opts, 'places', 4)
        emit_func(opts)
        sys.exit(0)

    # Hex/array mode: validate -c, -l
    opts['cols'] = resolve_int(opts, 'cols', 10)
    opts['len'] = resolve_int(opts, 'len', 0)

    # Guard against absurd cols values that would cause panic / hang.
    # The reference panics around cols=13110 with "Formatting argument out of range".
    # We approximate by exiting with the same error code/message for huge values.
    if opts['cols'] > 100000:
        write_err("\nthread 'main' panicked at src/lib.rs:339:21:\nFormatting argument out of range\nnote: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n")
        sys.exit(101)

    data = read_input(opts)

    if opts['array'] is not None:
        emit_array(data, opts)
    else:
        emit_hex(data, opts)

    sys.exit(0)


if __name__ == '__main__':
    main()
