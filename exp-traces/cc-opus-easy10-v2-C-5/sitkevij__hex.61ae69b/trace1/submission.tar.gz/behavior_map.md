# hx 0.7.0 behavior map

## Identity
- Name: hx
- Version string: `hx 0.7.0`
- Reference: Rust binary (panics reference src/lib.rs)

## CLI

```
Usage: executable [OPTIONS] [INPUTFILE]
```

Single positional arg `INPUTFILE` (optional). Stdin used if missing.

### Options (all optional; defaults shown)
- `-c, --cols <columns>`        default 10. Number of bytes per row.
- `-l, --len <len>`             default 0 (unlimited). Read at most N bytes.
- `-f, --format <format>`       default `x`. Values: o (octal), x (LowerHex), X (UpperHex), b (binary).
- `-t, --color <color>`         Values: 0, 1. Force color on/off (overrides default).
- `-a, --array <array_format>`  Values: r,c,g,p,k,j,s,f. Emit source-code array; suppresses normal/func output.
- `-u, --func <func_length>`    default 0 (off). N>=1 emits sin wave values; suppresses normal/array output.
- `-p, --places <func_places>`  default 4. Decimal places for -u output.
- `-r, --prefix <prefix>`       default 1. 0 disables 0x/0o/0b prefix on bytes (NOT on offset, NOT on array).
- `-h, --help`                  Print help (wins over -V if it appears first; both exit 0).
- `-V, --version`               Print version (wins over -h if it appears first; both exit 0).

### Argument parsing rules
- Numeric options accept signed/unsigned ints. Negative numbers are read as flags by clap; must use `-- -1`.
- Numeric options that fail parsing (non-digit, decimal point) emit:
  `<short>, <long> <integer> expected. ParseIntError { kind: InvalidDigit }\nerror: invalid digit found in string\n`
  to stderr; exit 1.
- Numeric options that exceed i32/i64 range emit similar ParseIntError but kind: PosOverflow or NegOverflow.
- Repeated options (e.g., `-l 3 -l 5`): clap error "the argument '--<name> <val>' cannot be used multiple times", exit 2.
- Unknown options like `--bogus` or `-x`: clap error "unexpected argument", exit 2.
- Invalid enum value (`-a x`, `-t 2`, `-r 2`, `-f X1`): clap "invalid value" error, exit 2.
- Missing value (`-c` alone): clap "a value is required" error, exit 2.
- Multiple positional args: clap "unexpected argument" error, exit 2.

## Modes (priority)

1. `-h/--help` first occurrence: print help to stdout, exit 0.
2. `-V/--version` first occurrence: print `hx 0.7.0\n` to stdout, exit 0.
3. `-u/--func N` (N >= 0, even N=0 triggers func mode): print sin wave, exit 0. Ignores -a, -f, -r, -t, -c (cols), file/stdin.
4. `-a/--array X`: print source-code array. Reads input. Ignores -f, -r, -t.
5. Default: hex dump.

### Mode: help (`-h`)
```
Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
```

### Mode: version (`-V`)
```
hx 0.7.0
```

### Mode: func (`-u N`)
- Computes `sin(i * pi / (2*N))` for i=0..N-1.
- Each value formatted as `{:.Pf}` where P = -p value (default 4).
- Values separated by `,` (comma), with trailing `,` AFTER EVERY VALUE.
- After every 10 values written: newline `\n`.
- After all values: another newline `\n` (even with 0 values).
- For N=0: output is single `\n`.
- For N=10: 10 values then `\n` (from the 10-multiple) then `\n` (trailing) = ends with `\n\n`.
- For N=11: 10 values + `\n` + 1 value + `\n`.
- Cols (-c) is ignored.

### Mode: array (`-a X`)
- Reads input bytes (file or stdin), respects `-l`.
- `-c` controls bytes per row (default 10).
- No color, no -f/-r effect — bytes always formatted as `0x{:02x}` (lowerhex).
- For array X:
  - r: `let ARRAY: [u8; N] = [\n` header, `];\n` footer.
  - c: `unsigned char ARRAY[N] = {\n` header, `};\n` footer.
  - g: `a := [N]byte{\n` header, `}\n` footer.
  - p: `a = [\n` header, `]\n` footer.
  - k: `val a = byteArrayOf(\n` header, `)\n` footer.
  - j: `byte[] a = new byte[]{\n` header, `};\n` footer.
  - s: `let a: [UInt8] = [\n` header, `]\n` footer.
  - f: `let a = [|\n` header, `|]\n` footer. Bytes use suffix `uy` and `;` separator.
- Each row: 4 spaces + byte entries.
- Entry format: `0xHH` for r/c/p/k/j/s/g; `0xHHuy` for f.
- Separator between entries within a row:
  - r/c/p/k/j/s/g/f: comma+space `, ` (or semicolon+space `; ` for f).
- Trailing separator after the last entry in a non-last data row: yes, with newline.
- Trailing separator after the last entry in the last data row:
  - r/c/p/k/j/s/f: NO trailing separator.
  - g (golang): YES trailing `, `.
- If N is exact multiple of cols (including N=0): one extra "    \n" (4 spaces + newline) before the footer.

### Mode: hex (default)
Layout per row:
```
0xOOOOOO: 0xHH 0xHH ... 0xHH PPPPPPPPPP
```
Components:
- Offset: `0x` + lower-hex offset, zero-padded to at least 6 digits, then `: `.
- Hex column for each byte: encoded by -f/-r:
  - -f x (default): `0xHH` (4 chars, lowercase, with 0x prefix)
  - -f X: `0xHH` (4 chars, uppercase, with 0x prefix)
  - -f o: `0oOOOO` (6 chars, octal, 4 digits, with 0o prefix)
  - -f b: `0bBBBBBBBB` (10 chars, binary, 8 digits, with 0b prefix)
  - -r 0 strips the prefix (and `0o`->4 digits, `0x`->2 digits, `0b`->8 digits).
- Each byte cell is fixed width (depending on format). Empty cells: same width of spaces.
- After each cell, a single space separator.
- After the last cell (or empty filler) and before ASCII section: no extra space (the trailing cell space serves).
- ASCII column: each byte rendered as itself if 0x20-0x7e printable, else `.`.
- For empty cells the ASCII does not extend.
- The terminating `\n` is at end of line.

#### Color (when enabled)
- Each `0xHH` and each ASCII char is wrapped in `\033[38;5;Cm...\033[0m`
  where C = byte value (0x00 maps to color 22, all other bytes map to byte_value).
- Color also applies to the literal `0xHH` text (not just the bytes/chars).
- Offset (`0xOOOOOO:`) is NEVER colorized.
- Spaces and dots filler are NEVER colorized.

#### Color enable logic
- `-t 1`: always colorize.
- `-t 0`: never colorize.
- Otherwise: colorize iff stdout is a TTY AND NO_COLOR env var is unset (or empty).
- NO_COLOR (any non-empty) disables color UNLESS `-t 1` explicitly enables.

Wait — actually NO_COLOR doesn't override `-t 1`. Verified: `NO_COLOR=1 -t 1` still colors. So order of precedence:
- If `-t` is given: -t value wins.
- Else: color iff TTY and NO_COLOR unset/empty.

#### Footer
After all hex rows: `   bytes: N\n` where N is decimal count of bytes read.

#### Row count rule
- Rows are emitted for offsets 0, cols, 2*cols, ..., last_row_start.
- Plus one extra "empty row" (with no hex/ASCII data) when bytes count is an exact multiple of cols (including N=0).
- Empty trailing row: offset + ": " + (cols * cell_width) spaces + (no ASCII).

## Input handling
- File argument: open path; on error, emit `error: <message> (os error <N>)` to stderr, exit 1.
  - missing: "No such file or directory (os error 2)"
  - is dir: "Is a directory (os error 21)"
  - permission denied: "Permission denied (os error 13)"
- No file: read stdin (binary).
- `-l N` (N>0): read up to N bytes total.
- `-l 0`: no limit (read all).
- Multiple positional args: clap error exit 2.

## Output handling
- Always to stdout (stderr only for errors).
- Color codes use 256-color SGR sequences.

## Edge cases / panics
- `-c` with value > ~13110 causes a Rust panic at "Formatting argument out of range" — not reproducing this exactly, but tests probably won't use such values.
- `-c -1` rejected as unknown arg.

## Confirmed behaviors
- `-h` first → help (even with invalid -c).
- `-V` first → version.
- `-u 0` → just `\n`.
- File arg with `--` separator: `-- -1` treats "-1" as file path → tries to open.
- Stdin EOF: reads all available.

## Defaults summary
| Option | Default |
|--------|---------|
| cols   | 10 |
| len    | 0 (unlimited) |
| format | x |
| color  | auto (TTY + !NO_COLOR) |
| array  | none |
| func   | 0 |
| places | 4 |
| prefix | 1 |
