#!/bin/bash
# Build script: create the 'executable' wrapper that runs hx.py
set -e
cd "$(dirname "$0")"
cat > executable << 'EOF'
#!/bin/bash
exec /usr/bin/python3 "$(dirname "$0")/hx.py" "$@"
EOF
chmod +x executable
