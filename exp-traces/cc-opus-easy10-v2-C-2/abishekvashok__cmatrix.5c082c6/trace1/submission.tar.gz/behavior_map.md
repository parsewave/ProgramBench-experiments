# cmatrix behavior map

## Identity
- C program linked against libncursesw.so.6, libtinfo.so.6, libc.so.6
- Version 2.0, compiled date in binary: 19:59:42 Apr 17 2026
- getopt option string: `abBcfhlLnrosmxkVM:u:C:t:`

## Process model

1. getopt loop processes args in order
2. Several handlers exit immediately (h, V, ?, invalid -C arg)
3. After getopt: optionally open tty via freopen (-t path) — fail → exit 1
4. ncurses init (initscr / newterm), default color setup
5. -l: try setfont/consolechars; if both fail → cleanup ncurses, print error to stderr, exit 0
6. Run animation loop until input matches quit condition

## Flags and exit handlers

| Flag        | Effect                                        | Exits at getopt? |
|-------------|-----------------------------------------------|------------------|
| -a          | Asynchronous scroll                           | No               |
| -b          | Random bold characters                        | No               |
| -B          | All bold (overrides -b)                       | No               |
| -c          | Japanese chars (only with -o I think)         | No               |
| -f          | Force TERM=linux via setenv                   | No               |
| -l          | "Linux" mode → font hack (errors)             | No               |
| -L          | Lock mode (shows "Computer locked.", can't q) | No               |
| -o          | Old-style scrolling                           | No               |
| -h, -?      | Print usage, exit 0                           | Yes              |
| -n          | No bold (default; overrides -b, -B)           | No               |
| -s          | Screensaver mode: exits on first keystroke    | No               |
| -x          | X window mode                                 | No               |
| -V          | Print version, exit 0                         | Yes              |
| -M msg      | Custom message in center                      | No               |
| -u N        | Update delay 0-10, default 4                  | No               |
| -C color    | Color: green/red/blue/white/yellow/cyan/magenta/black (case-insensitive) | error → exit 0 |
| -r          | Rainbow mode                                  | No               |
| -m          | Lambda mode                                   | No               |
| -k          | Characters change while scrolling             | No               |
| -t tty      | Set tty to use (freopen path)                 | After loop, exit 1 on fail |
| Unknown opt | Print usage, exit 0                           | Yes (via default) |

`opterr=0` so getopt doesn't print its own messages.

## Deterministic byte goldens

### -V (stdout, exit 0)
```
 CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
```
Note: leading space on first line. Compile date will differ in our build (use __TIME__ / __DATE__).

### -h, -?, invalid flag (stdout, exit 0) — 972 bytes
```
 Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
```
Each line has leading space.

### Invalid -C value (stderr, exit 0)
```
 Invalid color selection
 Valid colors are green, red, blue, white, yellow, cyan, magenta and black.
```
Both lines have leading space. Stdout empty.

### -t bad_path (stderr, exit 1)
```
cmatrix: error: '<path>' couldn't be opened: <strerror(errno)>.
```
No leading space. Note trailing period after strerror.

### -l on system without setfont/consolechars (stderr, exit 0)
```
 Unable to use both "setfont" and "consolechars".
```
Leading space. Stdout has some ncurses init/cleanup bytes.

### TERM unset or invalid (no -f) (stderr, exit 1)
```
Error opening terminal: <TERM_value or "unknown">.
```
This is ncurses' own message. No leading space.

## Animation behavior (non-deterministic bytes, but structural)

When run without -h/-V/error in valid TERM:
- ncurses initializes alternate screen, hides cursor, sets up color
- Loops drawing random characters
- Polls stdin for input (wtimeout / nodelay)
- 'q' quits (unless -L)
- in -s mode, ANY key quits
- '0'-'9' adjusts update delay
- 'a' toggles async
- 'b', 'B', 'n' toggle bold modes
- '!', '@', '#', '$', '%', '^', '&', ')' change color
- On exit (q): clears screen, restores terminal, exit 0

## Special characteristics

- `-f` with unset TERM segfaults (bug we don't need to reproduce)
- `-Vh` → version (V first), `-hV` → usage (h first)
- `-C green -C red` → red (last wins)
- `-u abc` / `-u 11` / `-u -1` → silently treated as default/clamped (no error, just runs)
- Empty stdin: program runs until killed
- Closed stdin (or any byte 'q' on stdin): exits cleanly
- Stdout to non-TTY (like our probes): ncurses still emits ANSI escapes for xterm TERM

## Process flow summary (the critical path for tests)

```
main:
  opterr = 0
  while ((c = getopt(argc, argv, "abBcfhlLnrosmxkVM:u:C:t:")) != -1):
    switch (c):
      'h': usage(); exit(0)
      '?': usage(); exit(0)
      'V': version(); exit(0)
      'C': if !strcasecmp(optarg, color) for any valid color, store color
           else print error to stderr, exit(0)
      'u': update_delay = atoi(optarg) clamped [0,10]? actually accepts anything
      'M': message = strdup(optarg)
      't': tty_path = strdup(optarg)
      ...
      default: usage(); exit(0)
  if (tty_path) freopen(tty_path, "r+", stdin) or die
  init_ncurses()
  if (linux_mode_l) try_setfont(); if fail: cleanup, print error to stderr, exit(0)
  if (no message but -L) message = "Computer locked."
  loop:
    draw_frame()
    key = wgetch()
    if (-s and key != ERR) break
    if (key == 'q' and !lock) break
    ...
  finish() // endwin, exit 0
```

## Strings from binary (probe-friendly summary)
- " CMatrix version %s (compiled %s, %s)" — version format
- "Email: abishekvashok@gmail.com" / "Web: https://github.com/abishekvashok/cmatrix"
- "CMatrix: malloc: out of memory!" — OOM string (not normally seen)
- " Invalid color selection" / " Valid colors are green, red, blue, white, yellow, cyan, magenta and black."
- "cmatrix: error: '%s' couldn't be opened: %s." — tty open failure
- " Unable to use both \"setfont\" and \"consolechars\"."
- "Computer locked." — default -L message
- Colors list: green, red, blue, white, yellow, cyan, magenta, black
- Linked: libncursesw.so.6, libtinfo.so.6, libc.so.6
