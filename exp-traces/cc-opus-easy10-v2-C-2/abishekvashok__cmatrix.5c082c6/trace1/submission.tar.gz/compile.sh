#!/bin/sh
set -e
cd "$(dirname "$0")"

CFLAGS="-O2 -Wall -D_GNU_SOURCE"
LDFLAGS=""

INC=""
LIB="-lncursesw -ltinfo"
if [ -f /usr/include/ncursesw/curses.h ]; then
    INC="-I/usr/include/ncursesw -DHAVE_NCURSESW_CURSES_H=1"
fi

gcc $CFLAGS $INC cmatrix.c -o executable $LIB $LDFLAGS
