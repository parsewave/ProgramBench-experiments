#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>
#include <locale.h>
#include <wchar.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>

#ifdef HAVE_NCURSESW_CURSES_H
#include <ncursesw/curses.h>
#else
#include <curses.h>
#endif

#define VERSION "2.0"
#define BUILD_TIME "19:59:42"
#define BUILD_DATE "Apr 17 2026"

static int update_speed = 4;
static int lock_mode = 0;
static int screensaver_mode = 0;
static int rainbow_mode = 0;
static int oldstyle_mode = 0;
static int bold_mode = -1;
static int async_mode = 0;
static int lambda_mode = 0;
static int x_window_mode = 0;
static int japan_mode = 0;
static int linux_mode = 0;
static int force_linux_term = 0;
static int changes_mode = 0;
static char *message = NULL;
static char *tty_path = NULL;
static int matrix_color = COLOR_GREEN;

static volatile sig_atomic_t got_winch = 0;

static const char *USAGE =
    " Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n"
    " -a: Asynchronous scroll\n"
    " -b: Bold characters on\n"
    " -B: All bold characters (overrides -b)\n"
    " -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n"
    " -f: Force the linux $TERM type to be on\n"
    " -l: Linux mode (uses matrix console font)\n"
    " -L: Lock mode (can be closed from another terminal)\n"
    " -o: Use old-style scrolling\n"
    " -h: Print usage and exit\n"
    " -n: No bold characters (overrides -b and -B, default)\n"
    " -s: \"Screensaver\" mode, exits on first keystroke\n"
    " -x: X window mode, use if your xterm is using mtx.pcf\n"
    " -V: Print version information and exit\n"
    " -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n"
    " -u delay (0 - 10, default 4): Screen update delay\n"
    " -C [color]: Use this color for matrix (default green)\n"
    " -r: rainbow mode\n"
    " -m: lambda mode\n"
    " -k: Characters change while scrolling. (Works without -o opt.)\n"
    " -t [tty]: Set tty to use\n";

static void usage_print(void) {
    fputs(USAGE, stdout);
    fflush(stdout);
}

static void version_print(void) {
    printf(" CMatrix version %s (compiled %s, %s)\n"
           "Email: abishekvashok@gmail.com\n"
           "Web: https://github.com/abishekvashok/cmatrix\n",
           VERSION, BUILD_TIME, BUILD_DATE);
    fflush(stdout);
}

static int parse_color(const char *s) {
    if (s == NULL) return -1;
    if (strcasecmp(s, "green") == 0) return COLOR_GREEN;
    if (strcasecmp(s, "red") == 0) return COLOR_RED;
    if (strcasecmp(s, "blue") == 0) return COLOR_BLUE;
    if (strcasecmp(s, "white") == 0) return COLOR_WHITE;
    if (strcasecmp(s, "yellow") == 0) return COLOR_YELLOW;
    if (strcasecmp(s, "cyan") == 0) return COLOR_CYAN;
    if (strcasecmp(s, "magenta") == 0) return COLOR_MAGENTA;
    if (strcasecmp(s, "black") == 0) return COLOR_BLACK;
    return -1;
}

static void handle_winch(int sig) {
    (void)sig;
    got_winch = 1;
}

static void cleanup_ncurses(void) {
    curs_set(1);
    clear();
    refresh();
    resetty();
    endwin();
}

static void do_resize(int *rows_p, int *cols_p, int ***matrix_p, int ***length_p, int ***spaces_p, int ***updates_p) {
    struct winsize ws;
    if (ioctl(STDIN_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 0 && ws.ws_col > 0) {
        resizeterm(ws.ws_row, ws.ws_col);
    }
    int nrows, ncols;
    getmaxyx(stdscr, nrows, ncols);
    *rows_p = nrows;
    *cols_p = ncols;
    clear();
    refresh();
}

static int rand_printable(void) {
    if (lambda_mode) return 0x03BB;
    if (japan_mode) {
        static const wchar_t japan[] = {
            0x30A2, 0x30A4, 0x30A6, 0x30A8, 0x30AA, 0x30AB, 0x30AD, 0x30AF, 0x30B1, 0x30B3,
            0x30B5, 0x30B7, 0x30B9, 0x30BB, 0x30BD, 0x30BF, 0x30C1, 0x30C4, 0x30C6, 0x30C8,
            0x30CA, 0x30CB, 0x30CC, 0x30CD, 0x30CE, 0x30CF, 0x30D2, 0x30D5, 0x30D8, 0x30DB,
            0x30DE, 0x30DF, 0x30E0, 0x30E1, 0x30E2, 0x30E4, 0x30E6, 0x30E8, 0x30E9, 0x30EA,
            0x30EB, 0x30EC, 0x30ED, 0x30EF, 0x30F0, 0x30F1, 0x30F2, 0x30F3
        };
        int n = sizeof(japan) / sizeof(japan[0]);
        return japan[rand() % n];
    }
    return ' ' + (rand() % (126 - 32 + 1));
}

static int try_run(const char *prog) {
    char path[256];
    snprintf(path, sizeof(path), "/usr/bin/%s", prog);
    if (access(path, X_OK) == 0) return 0;
    snprintf(path, sizeof(path), "/bin/%s", prog);
    if (access(path, X_OK) == 0) return 0;
    snprintf(path, sizeof(path), "/usr/sbin/%s", prog);
    if (access(path, X_OK) == 0) return 0;
    snprintf(path, sizeof(path), "/sbin/%s", prog);
    if (access(path, X_OK) == 0) return 0;
    return -1;
}

int main(int argc, char *argv[]) {
    setlocale(LC_ALL, "");
    opterr = 0;
    int opt;
    const char *optstr = "abBcfhlLnrosmxkVM:u:C:t:";

    while ((opt = getopt(argc, argv, optstr)) != -1) {
        switch (opt) {
        case 'a': async_mode = 1; break;
        case 'b':
            if (bold_mode != 2) bold_mode = 1;
            break;
        case 'B': bold_mode = 2; break;
        case 'c': japan_mode = 1; break;
        case 'f': force_linux_term = 1; break;
        case 'l': linux_mode = 1; break;
        case 'L': lock_mode = 1; break;
        case 'n': bold_mode = -1; break;
        case 'r': rainbow_mode = 1; break;
        case 'o': oldstyle_mode = 1; break;
        case 's': screensaver_mode = 1; break;
        case 'm': lambda_mode = 1; break;
        case 'x': x_window_mode = 1; break;
        case 'k': changes_mode = 1; break;
        case 'h':
            usage_print();
            exit(0);
        case 'V':
            version_print();
            exit(0);
        case 'u':
            update_speed = atoi(optarg);
            break;
        case 'C': {
            int c = parse_color(optarg);
            if (c < 0) {
                fprintf(stderr, " Invalid color selection\n"
                                " Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n");
                exit(0);
            }
            matrix_color = c;
            break;
        }
        case 'M':
            free(message);
            message = strdup(optarg);
            break;
        case 't':
            free(tty_path);
            tty_path = strdup(optarg);
            break;
        case '?':
        default:
            usage_print();
            exit(0);
        }
    }

    if (force_linux_term) {
        setenv("TERM", "linux", 1);
    }

    if (tty_path) {
        if (!freopen(tty_path, "r+", stdin)) {
            fprintf(stderr, "cmatrix: error: '%s' couldn't be opened: %s.\n",
                    tty_path, strerror(errno));
            exit(1);
        }
    }

    if (!message && lock_mode) {
        message = strdup("Computer locked.");
    }

    srand((unsigned)time(NULL));

    if (initscr() == NULL) {
        exit(1);
    }
    savetty();
    nonl();
    cbreak();
    noecho();
    curs_set(0);
    leaveok(stdscr, TRUE);
    wtimeout(stdscr, 0);

    if (linux_mode) {
        int have_setfont = (try_run("setfont") == 0);
        int have_consolechars = (try_run("consolechars") == 0);
        if (!have_setfont && !have_consolechars) {
            cleanup_ncurses();
            fprintf(stderr, " Unable to use both \"setfont\" and \"consolechars\".\n");
            exit(0);
        }
    }

    if (has_colors()) {
        start_color();
        use_default_colors();
        init_pair(1, matrix_color, -1);
        init_pair(2, COLOR_WHITE, -1);
        init_pair(3, COLOR_GREEN, -1);
        init_pair(4, COLOR_YELLOW, -1);
        init_pair(5, COLOR_RED, -1);
        init_pair(6, COLOR_BLUE, -1);
        init_pair(7, COLOR_CYAN, -1);
        init_pair(8, COLOR_MAGENTA, -1);
        init_pair(9, COLOR_BLACK, -1);
    }

    signal(SIGWINCH, handle_winch);
    signal(SIGINT, SIG_DFL);

    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    if (rows < 1) rows = 1;
    if (cols < 1) cols = 1;

    int *length = calloc(cols + 1, sizeof(int));
    int *spaces = calloc(cols + 1, sizeof(int));
    int *updates = calloc(cols + 1, sizeof(int));
    int **matrix = calloc(rows + 2, sizeof(int *));
    for (int i = 0; i < rows + 2; i++) {
        matrix[i] = calloc(cols + 1, sizeof(int));
        for (int j = 0; j < cols + 1; j++) matrix[i][j] = -1;
    }
    int *line_pos = calloc(cols + 1, sizeof(int));
    if (!length || !spaces || !updates || !matrix || !line_pos) {
        cleanup_ncurses();
        fprintf(stderr, "CMatrix: malloc: out of memory!\n");
        exit(1);
    }

    for (int j = 0; j <= cols; j++) {
        length[j] = (rand() % (rows - 3)) + 3;
        spaces[j] = (rand() % rows) + 1;
        updates[j] = (rand() % 3) + 1;
        line_pos[j] = -1;
    }

    int frame_count = 0;

    while (1) {
        if (got_winch) {
            got_winch = 0;
            do_resize(&rows, &cols, NULL, NULL, NULL, NULL);
            int newcols = cols;
            int newrows = rows;
            for (int i = 0; i < rows + 2; i++) free(matrix[i]);
            free(matrix);
            free(length); free(spaces); free(updates); free(line_pos);
            length = calloc(newcols + 1, sizeof(int));
            spaces = calloc(newcols + 1, sizeof(int));
            updates = calloc(newcols + 1, sizeof(int));
            line_pos = calloc(newcols + 1, sizeof(int));
            matrix = calloc(newrows + 2, sizeof(int *));
            for (int i = 0; i < newrows + 2; i++) {
                matrix[i] = calloc(newcols + 1, sizeof(int));
                for (int j = 0; j < newcols + 1; j++) matrix[i][j] = -1;
            }
            for (int j = 0; j <= newcols; j++) {
                length[j] = (rand() % (newrows > 3 ? newrows - 3 : 1)) + 3;
                spaces[j] = (rand() % newrows) + 1;
                updates[j] = (rand() % 3) + 1;
                line_pos[j] = -1;
            }
        }

        int key = wgetch(stdscr);
        if (key != ERR) {
            if (screensaver_mode) break;
            if (!lock_mode) {
                if (key == 'q') break;
            }
            switch (key) {
            case '0': case '1': case '2': case '3': case '4':
            case '5': case '6': case '7': case '8': case '9':
                update_speed = key - '0';
                break;
            case 'a': async_mode = !async_mode; break;
            case 'b': bold_mode = 1; break;
            case 'B': bold_mode = 2; break;
            case 'n': bold_mode = -1; break;
            case '!': matrix_color = COLOR_RED; init_pair(1, COLOR_RED, -1); break;
            case '@': matrix_color = COLOR_GREEN; init_pair(1, COLOR_GREEN, -1); break;
            case '#': matrix_color = COLOR_YELLOW; init_pair(1, COLOR_YELLOW, -1); break;
            case '$': matrix_color = COLOR_BLUE; init_pair(1, COLOR_BLUE, -1); break;
            case '%': matrix_color = COLOR_MAGENTA; init_pair(1, COLOR_MAGENTA, -1); break;
            case '^': matrix_color = COLOR_CYAN; init_pair(1, COLOR_CYAN, -1); break;
            case '&': matrix_color = COLOR_WHITE; init_pair(1, COLOR_WHITE, -1); break;
            case ')': matrix_color = COLOR_BLACK; init_pair(1, COLOR_BLACK, -1); break;
            }
        }

        for (int j = 0; j < cols; j++) {
            int do_update = 1;
            if (async_mode) {
                if ((frame_count % updates[j]) != 0) do_update = 0;
            }
            if (do_update) {
                int p = line_pos[j];
                if (p < 0) p = 0;
                if (p < rows) {
                    int chosen = rand_printable();
                    if (matrix[p][j] != ' ') matrix[p][j] = chosen;
                }
                line_pos[j]++;
                if (line_pos[j] >= rows + length[j] + spaces[j]) {
                    line_pos[j] = 0;
                    length[j] = (rand() % (rows > 3 ? rows - 3 : 1)) + 3;
                    spaces[j] = (rand() % rows) + 1;
                }

                int head = line_pos[j];
                int tail = head - length[j];
                if (tail >= 0 && tail < rows) {
                    matrix[tail][j] = ' ';
                }
            }
        }

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int ch = matrix[i][j];
                if (ch == -1 || ch == 0) {
                    mvaddch(i, j, ' ');
                    continue;
                }
                int attrs = 0;
                if (bold_mode == 2) attrs |= A_BOLD;
                else if (bold_mode == 1 && (rand() & 1)) attrs |= A_BOLD;

                int pair = 1;
                if (rainbow_mode) {
                    int rcolors[] = { COLOR_GREEN, COLOR_RED, COLOR_BLUE,
                                     COLOR_YELLOW, COLOR_CYAN, COLOR_MAGENTA, COLOR_WHITE };
                    int rc = rcolors[(i + j + frame_count) % 7];
                    init_pair(1, rc, -1);
                    pair = 1;
                }

                attron(COLOR_PAIR(pair) | attrs);
                if (ch < 128) {
                    mvaddch(i, j, ch);
                } else {
                    cchar_t cc;
                    wchar_t w[2] = { (wchar_t)ch, 0 };
                    setcchar(&cc, w, attrs | COLOR_PAIR(pair), 0, NULL);
                    mvadd_wch(i, j, &cc);
                }
                attroff(COLOR_PAIR(pair) | attrs);
            }
        }

        if (message && *message) {
            int len = (int)strlen(message);
            int mid_y = rows / 2;
            int mid_x = (cols - len) / 2;
            if (mid_x < 0) mid_x = 0;
            attron(COLOR_PAIR(2) | A_BOLD);
            mvaddnstr(mid_y, mid_x, message, cols - mid_x);
            attroff(COLOR_PAIR(2) | A_BOLD);
        }

        refresh();
        frame_count++;
        if (update_speed > 0) napms(update_speed * 10);
    }

    cleanup_ncurses();
    free(length); free(spaces); free(updates); free(line_pos);
    for (int i = 0; i < rows + 2; i++) free(matrix[i]);
    free(matrix);
    free(message);
    free(tty_path);
    return 0;
}
