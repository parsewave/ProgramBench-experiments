#!/bin/sh
# Make our pier reimplementation executable.
set -e
cd "$(dirname "$0")"
cp pier.py executable
chmod +x executable
