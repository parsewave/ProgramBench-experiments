#!/usr/bin/env python3
"""pier 0.1.6 — clean-room reimplementation."""

import base64
import os
import sys
import re
import tempfile
import subprocess

VERSION = "0.1.6"
BIN_NAME = "executable"

# ────────────────────────────────────────────────────────────────────────
# Exact help bytes captured from reference binary (preserves trailing ws).
# ────────────────────────────────────────────────────────────────────────

_H = {}
_H['HELP_LONG'] = base64.b64decode('cGllciAwLjEuNgpCZW5qYW1pbiBTY2hvbHR6LCBJc2FrIEpvaGFuc3NvbgpBIHNpbXBsZSBzY3JpcHQgbWFuYWdlbWVudCBDTEkKClVTQUdFOgogICAgZXhlY3V0YWJsZSBbRkxBR1NdIFtPUFRJT05TXSA8YWxpYXM+IFthcmdzXS4uLgogICAgZXhlY3V0YWJsZSBbRkxBR1NdIFtPUFRJT05TXSA8U1VCQ09NTUFORD4KCkZMQUdTOgogICAgLWgsIC0taGVscCAgICAgICAKICAgICAgICAgICAgUHJpbnRzIGhlbHAgaW5mb3JtYXRpb24KCiAgICAtViwgLS12ZXJzaW9uICAgIAogICAgICAgICAgICBQcmludHMgdmVyc2lvbiBpbmZvcm1hdGlvbgoKICAgIC12LCAtLXZlcmJvc2UgICAgCiAgICAgICAgICAgIFRoZSBsZXZlbCBvZiB2ZXJib3NpdHkKCgpPUFRJT05TOgogICAgLWMsIC0tY29uZmlnLWZpbGUgPHBhdGg+ICAgIAogICAgICAgICAgICBTZXRzIGEgY3VzdG9tIGNvbmZpZyBmaWxlLgogICAgICAgICAgICAKICAgICAgICAgICAgREVGQVVMVCBQQVRIIGlzIG90aGVyd2lzZSBkZXRlcm1pbmVkIGluIHRoaXMgb3JkZXI6CiAgICAgICAgICAgIAogICAgICAgICAgICAtICRQSUVSX0NPTkZJR19QQVRIIChlbnZpcm9ubWVudCB2YXJpYWJsZSBpZiBzZXQpCiAgICAgICAgICAgIAogICAgICAgICAgICAtIHBpZXIudG9tbCAoaW4gdGhlIGN1cnJlbnQgZGlyZWN0b3J5KQogICAgICAgICAgICAKICAgICAgICAgICAgLSAkWERHX0NPTkZJR19IT01FL3BpZXIvY29uZmlnLnRvbWwKICAgICAgICAgICAgCiAgICAgICAgICAgIC0gJFhER19DT05GSUdfSE9NRS9waWVyL2NvbmZpZwogICAgICAgICAgICAKICAgICAgICAgICAgLSAkWERHX0NPTkZJR19IT01FL3BpZXIudG9tbAogICAgICAgICAgICAKICAgICAgICAgICAgLSAkSE9NRS8ucGllci50b21sCiAgICAgICAgICAgIAogICAgICAgICAgICAtICRIT01FLy5waWVyCiAgICAgICAgICAgIAogICAgICAgICAgICAgW2VudjogUElFUl9DT05GSUdfUEFUSD1dCgpBUkdTOgogICAgPGFsaWFzPiAgICAgIAogICAgICAgICAgICBUaGUgYWxpYXMgb3IgbmFtZSBmb3IgdGhlIHNjcmlwdC4KCiAgICA8YXJncz4uLi4gICAgCiAgICAgICAgICAgIFRoZSBwb3NpdGlvbmFsIGFyZ3VtZW50cyB0byBzZW5kIHRvIHNjcmlwdC4KCgpTVUJDT01NQU5EUzoKICAgIGFkZCAgICAgICAgICAgIEFkZCBhIG5ldyBzY3JpcHQgdG8gY29uZmlnLgogICAgY29uZmlnLWluaXQgICAgYWxpYXM6IGluaXQgLSBBZGQgYSBjb25maWcgZmlsZS4KICAgIGNvcHkgICAgICAgICAgIGFsaWFzOiBjcCAtIENvcHkgZXhpc3RpbmcgYWxpYXMgdG8gdGhlIG5ldyBvbmUKICAgIGVkaXQgICAgICAgICAgIEVkaXQgYSBzY3JpcHQgbWF0Y2hpbmcgYWxpYXMuCiAgICBoZWxwICAgICAgICAgICBQcmludHMgdGhpcyBtZXNzYWdlIG9yIHRoZSBoZWxwIG9mIHRoZSBnaXZlbiBzdWJjb21tYW5kKHMpCiAgICBsaXN0ICAgICAgICAgICBhbGlhczogbHMgLSBMaXN0IHNjcmlwdHMKICAgIG1vdmUgICAgICAgICAgIGFsaWFzOiBtdiwgcmVuYW1lIC0gTW92ZS9yZW5hbWUgZXhpc3RpbmcgYWxpYXMgdG8gdGhlIG5ldyBvbmUKICAgIHJlbW92ZSAgICAgICAgIGFsaWFzOiBybSAtIFJlbW92ZSBhIHNjcmlwdCBtYXRjaGluZyBhbGlhcy4KICAgIHJ1biAgICAgICAgICAgIFJ1biBhIHNjcmlwdCBtYXRjaGluZyBhbGlhcy4KICAgIHNob3cgICAgICAgICAgIFNob3cgYSBzY3JpcHQgbWF0Y2hpbmcgYWxpYXMuCg==').decode('utf-8')
_H['HELP_SHORT'] = base64.b64decode('cGllciAwLjEuNgpCZW5qYW1pbiBTY2hvbHR6LCBJc2FrIEpvaGFuc3NvbgpBIHNpbXBsZSBzY3JpcHQgbWFuYWdlbWVudCBDTEkKClVTQUdFOgogICAgZXhlY3V0YWJsZSBbRkxBR1NdIFtPUFRJT05TXSA8YWxpYXM+IFthcmdzXS4uLgogICAgZXhlY3V0YWJsZSBbRkxBR1NdIFtPUFRJT05TXSA8U1VCQ09NTUFORD4KCkZMQUdTOgogICAgLWgsIC0taGVscCAgICAgICBQcmludHMgaGVscCBpbmZvcm1hdGlvbgogICAgLVYsIC0tdmVyc2lvbiAgICBQcmludHMgdmVyc2lvbiBpbmZvcm1hdGlvbgogICAgLXYsIC0tdmVyYm9zZSAgICBUaGUgbGV2ZWwgb2YgdmVyYm9zaXR5CgpPUFRJT05TOgogICAgLWMsIC0tY29uZmlnLWZpbGUgPHBhdGg+ICAgIFNldHMgYSBjdXN0b20gY29uZmlnIGZpbGUgW2VudjogUElFUl9DT05GSUdfUEFUSD1dCgpBUkdTOgogICAgPGFsaWFzPiAgICAgIFRoZSBhbGlhcyBvciBuYW1lIGZvciB0aGUgc2NyaXB0LgogICAgPGFyZ3M+Li4uICAgIFRoZSBwb3NpdGlvbmFsIGFyZ3VtZW50cyB0byBzZW5kIHRvIHNjcmlwdC4KClNVQkNPTU1BTkRTOgogICAgYWRkICAgICAgICAgICAgQWRkIGEgbmV3IHNjcmlwdCB0byBjb25maWcuCiAgICBjb25maWctaW5pdCAgICBhbGlhczogaW5pdCAtIEFkZCBhIGNvbmZpZyBmaWxlLgogICAgY29weSAgICAgICAgICAgYWxpYXM6IGNwIC0gQ29weSBleGlzdGluZyBhbGlhcyB0byB0aGUgbmV3IG9uZQogICAgZWRpdCAgICAgICAgICAgRWRpdCBhIHNjcmlwdCBtYXRjaGluZyBhbGlhcy4KICAgIGhlbHAgICAgICAgICAgIFByaW50cyB0aGlzIG1lc3NhZ2Ugb3IgdGhlIGhlbHAgb2YgdGhlIGdpdmVuIHN1YmNvbW1hbmQocykKICAgIGxpc3QgICAgICAgICAgIGFsaWFzOiBscyAtIExpc3Qgc2NyaXB0cwogICAgbW92ZSAgICAgICAgICAgYWxpYXM6IG12LCByZW5hbWUgLSBNb3ZlL3JlbmFtZSBleGlzdGluZyBhbGlhcyB0byB0aGUgbmV3IG9uZQogICAgcmVtb3ZlICAgICAgICAgYWxpYXM6IHJtIC0gUmVtb3ZlIGEgc2NyaXB0IG1hdGNoaW5nIGFsaWFzLgogICAgcnVuICAgICAgICAgICAgUnVuIGEgc2NyaXB0IG1hdGNoaW5nIGFsaWFzLgogICAgc2hvdyAgICAgICAgICAgU2hvdyBhIHNjcmlwdCBtYXRjaGluZyBhbGlhcy4K').decode('utf-8')
_H['add_long'] = base64.b64decode('ZXhlY3V0YWJsZS1hZGQgMC4xLjYKQWRkIGEgbmV3IHNjcmlwdCB0byBjb25maWcuCgpVU0FHRToKICAgIGV4ZWN1dGFibGUgYWRkIFtGTEFHU10gW09QVElPTlNdIC0tYWxpYXMgPGFsaWFzPiBbLS1dIFtjb21tYW5kXQoKRkxBR1M6CiAgICAtZiwgLS1mb3JjZSAgICAgIEFsbG93cyB0byBvdmVyd3JpdGUgdGhlIGV4aXN0aW5nIHNjcmlwdAogICAgLWgsIC0taGVscCAgICAgICBQcmludHMgaGVscCBpbmZvcm1hdGlvbgogICAgLVYsIC0tdmVyc2lvbiAgICBQcmludHMgdmVyc2lvbiBpbmZvcm1hdGlvbgoKT1BUSU9OUzoKICAgIC1hLCAtLWFsaWFzIDxhbGlhcz4gICAgICAgICAgICAgICAgVGhlIGFsaWFzIG9yIG5hbWUgZm9yIHRoZSBzY3JpcHQuCiAgICAtZCwgLS1kZXNjcmlwdGlvbiA8ZGVzY3JpcHRpb24+ICAgIFRoZSBkZXNjcmlwdGlvbiBmb3IgdGhlIHNjcmlwdC4KICAgIC10LCAtLXRhZyA8dGFncz4uLi4gICAgICAgICAgICAgICAgU2V0IHdoaWNoIHRhZ3MgdGhlIHNjcmlwdCBiZWxvbmdzIHRvLgoKQVJHUzoKICAgIDxjb21tYW5kPiAgICBUaGUgY29tbWFuZC9zY3JpcHQgY29udGVudCB0byBiZSBleGVjdXRlZC4gSWYgdGhpcyBhcmd1bWVudCBpcyBub3QgZm91bmQgaXQgd2lsbCBvcGVuIHlvdXIgJEVESVRPUgogICAgICAgICAgICAgICAgIGZvciB5b3UgdG8gZW50ZXIgdGhlIHNjcmlwdCBpbnRvLgo=').decode('utf-8')
_H['add_short'] = base64.b64decode('ZXhlY3V0YWJsZS1hZGQgMC4xLjYKQWRkIGEgbmV3IHNjcmlwdCB0byBjb25maWcuCgpVU0FHRToKICAgIGV4ZWN1dGFibGUgYWRkIFtGTEFHU10gW09QVElPTlNdIC0tYWxpYXMgPGFsaWFzPiBbLS1dIFtjb21tYW5kXQoKRkxBR1M6CiAgICAtZiwgLS1mb3JjZSAgICAgIEFsbG93cyB0byBvdmVyd3JpdGUgdGhlIGV4aXN0aW5nIHNjcmlwdAogICAgLWgsIC0taGVscCAgICAgICBQcmludHMgaGVscCBpbmZvcm1hdGlvbgogICAgLVYsIC0tdmVyc2lvbiAgICBQcmludHMgdmVyc2lvbiBpbmZvcm1hdGlvbgoKT1BUSU9OUzoKICAgIC1hLCAtLWFsaWFzIDxhbGlhcz4gICAgICAgICAgICAgICAgVGhlIGFsaWFzIG9yIG5hbWUgZm9yIHRoZSBzY3JpcHQuCiAgICAtZCwgLS1kZXNjcmlwdGlvbiA8ZGVzY3JpcHRpb24+ICAgIFRoZSBkZXNjcmlwdGlvbiBmb3IgdGhlIHNjcmlwdC4KICAgIC10LCAtLXRhZyA8dGFncz4uLi4gICAgICAgICAgICAgICAgU2V0IHdoaWNoIHRhZ3MgdGhlIHNjcmlwdCBiZWxvbmdzIHRvLgoKQVJHUzoKICAgIDxjb21tYW5kPiAgICBUaGUgY29tbWFuZC9zY3JpcHQgY29udGVudCB0byBiZSBleGVjdXRlZC4gSWYgdGhpcyBhcmd1bWVudCBpcyBub3QgZm91bmQgaXQgd2lsbCBvcGVuIHlvdXIgJEVESVRPUgogICAgICAgICAgICAgICAgIGZvciB5b3UgdG8gZW50ZXIgdGhlIHNjcmlwdCBpbnRvLgo=').decode('utf-8')
_H['configinit_long'] = base64.b64decode('ZXhlY3V0YWJsZS1jb25maWctaW5pdCAwLjEuNgphbGlhczogaW5pdCAtIEFkZCBhIGNvbmZpZyBmaWxlLgoKVVNBR0U6CiAgICBleGVjdXRhYmxlIGNvbmZpZy1pbml0CgpGTEFHUzoKICAgIC1oLCAtLWhlbHAgICAgICAgUHJpbnRzIGhlbHAgaW5mb3JtYXRpb24KICAgIC1WLCAtLXZlcnNpb24gICAgUHJpbnRzIHZlcnNpb24gaW5mb3JtYXRpb24K').decode('utf-8')
_H['configinit_short'] = _H['configinit_long']
_H['copy_long'] = base64.b64decode('ZXhlY3V0YWJsZS1jb3B5IDAuMS42CmFsaWFzOiBjcCAtIENvcHkgZXhpc3RpbmcgYWxpYXMgdG8gdGhlIG5ldyBvbmUKClVTQUdFOgogICAgZXhlY3V0YWJsZSBjb3B5IDxmcm9tLWFsaWFzPiA8dG8tYWxpYXM+CgpGTEFHUzoKICAgIC1oLCAtLWhlbHAgICAgICAgUHJpbnRzIGhlbHAgaW5mb3JtYXRpb24KICAgIC1WLCAtLXZlcnNpb24gICAgUHJpbnRzIHZlcnNpb24gaW5mb3JtYXRpb24KCkFSR1M6CiAgICA8ZnJvbS1hbGlhcz4gICAgVGhlIGFsaWFzIG9mIHRoZSBzY3JpcHQgdGhhdCB3aWxsIGJlIGNvcGllZC4KICAgIDx0by1hbGlhcz4gICAgICBUaGUgbmV3IGFsaWFzIG9mIHRoZSBjb3B5IG9mIHRoZSBzY3JpcHQuCg==').decode('utf-8')
_H['copy_short'] = _H['copy_long']
_H['edit_long'] = base64.b64decode('ZXhlY3V0YWJsZS1lZGl0IDAuMS42CkVkaXQgYSBzY3JpcHQgbWF0Y2hpbmcgYWxpYXMuCgpVU0FHRToKICAgIGV4ZWN1dGFibGUgZWRpdCA8YWxpYXM+CgpGTEFHUzoKICAgIC1oLCAtLWhlbHAgICAgICAgUHJpbnRzIGhlbHAgaW5mb3JtYXRpb24KICAgIC1WLCAtLXZlcnNpb24gICAgUHJpbnRzIHZlcnNpb24gaW5mb3JtYXRpb24KCkFSR1M6CiAgICA8YWxpYXM+ICAgIFRoZSBhbGlhcyBvciBuYW1lIGZvciB0aGUgc2NyaXB0Lgo=').decode('utf-8')
_H['edit_short'] = _H['edit_long']
_H['list_short'] = base64.b64decode('ZXhlY3V0YWJsZS1saXN0IDAuMS42CmFsaWFzOiBscyAtIExpc3Qgc2NyaXB0cwoKRGlzcGxheSBvcHRpb25zIGFyZSBkZXRlcm1pbmVkIGJ5IHByaW9yaXR5IGluIHRoaXMgb3JkZXI6CgoxLiBMaXN0IG9ubHkgYWxpYXNlcwoKMi4gU2hvdyBmdWxsIGNvbW1hbmQKCjMuIENvbW1hbmQgZGlzcGxheSB3aXRoIChjbGkgb3B0aW9uKQoKNC4gQ29tbWFuZCBkaXNwbGF5IHdpdGggKGNvbmZpZyBvcHRpb24pCgpVU0FHRToKICAgIGV4ZWN1dGFibGUgbGlzdCBbRkxBR1NdIFtPUFRJT05TXQoKRkxBR1M6CiAgICAtbCwgLS1jbWRfZnVsbCAgICAgICAgRGlzcGxheSB0aGUgZnVsbCBjb21tYW5kLgogICAgLWgsIC0taGVscCAgICAgICAgICAgIFByaW50cyBoZWxwIGluZm9ybWF0aW9uCiAgICAtcSwgLS1saXN0X2FsaWFzZXMgICAgT25seSBkaXNwbGF5cyBhbGlhc2VzIG9mIHRoZSBzY3JpcHRzLgogICAgLVYsIC0tdmVyc2lvbiAgICAgICAgIFByaW50cyB2ZXJzaW9uIGluZm9ybWF0aW9uCgpPUFRJT05TOgogICAgLWMsIC0tY21kX3dpZHRoIDxjbWQtd2lkdGg+ICAgIFRoZSBtYXggbnVtYmVyIG9mIGNoYXJhY3RlcnMgdG8gZGlzcGxheSBmcm9tIHRoZSBjb21tYW5kLgogICAgLXQsIC0tdGFnIDx0YWdzPi4uLiAgICAgICAgICAgIEZpbHRlciBiYXNlZCBvbiB0YWdzLgo=').decode('utf-8')
_H['list_long'] = base64.b64decode('ZXhlY3V0YWJsZS1saXN0IDAuMS42CmFsaWFzOiBscyAtIExpc3Qgc2NyaXB0cwoKRGlzcGxheSBvcHRpb25zIGFyZSBkZXRlcm1pbmVkIGJ5IHByaW9yaXR5IGluIHRoaXMgb3JkZXI6CgoxLiBMaXN0IG9ubHkgYWxpYXNlcwoKMi4gU2hvdyBmdWxsIGNvbW1hbmQKCjMuIENvbW1hbmQgZGlzcGxheSB3aXRoIChjbGkgb3B0aW9uKQoKNC4gQ29tbWFuZCBkaXNwbGF5IHdpdGggKGNvbmZpZyBvcHRpb24pCgpVU0FHRToKICAgIGV4ZWN1dGFibGUgbGlzdCBbRkxBR1NdIFtPUFRJT05TXQoKRkxBR1M6CiAgICAtbCwgLS1jbWRfZnVsbCAgICAgICAgCiAgICAgICAgICAgIERpc3BsYXkgdGhlIGZ1bGwgY29tbWFuZC4KCiAgICAtaCwgLS1oZWxwICAgICAgICAgICAgCiAgICAgICAgICAgIFByaW50cyBoZWxwIGluZm9ybWF0aW9uCgogICAgLXEsIC0tbGlzdF9hbGlhc2VzICAgIAogICAgICAgICAgICBPbmx5IGRpc3BsYXlzIGFsaWFzZXMgb2YgdGhlIHNjcmlwdHMuCgogICAgLVYsIC0tdmVyc2lvbiAgICAgICAgIAogICAgICAgICAgICBQcmludHMgdmVyc2lvbiBpbmZvcm1hdGlvbgoKCk9QVElPTlM6CiAgICAtYywgLS1jbWRfd2lkdGggPGNtZC13aWR0aD4gICAgCiAgICAgICAgICAgIFRoZSBtYXggbnVtYmVyIG9mIGNoYXJhY3RlcnMgdG8gZGlzcGxheSBmcm9tIHRoZSBjb21tYW5kLgoKICAgIC10LCAtLXRhZyA8dGFncz4uLi4gICAgICAgICAgICAKICAgICAgICAgICAgRmlsdGVyIGJhc2VkIG9uIHRhZ3MuCgo=').decode('utf-8')
_H['move_long'] = base64.b64decode('ZXhlY3V0YWJsZS1tb3ZlIDAuMS42CmFsaWFzOiBtdiwgcmVuYW1lIC0gTW92ZS9yZW5hbWUgZXhpc3RpbmcgYWxpYXMgdG8gdGhlIG5ldyBvbmUKClVTQUdFOgogICAgZXhlY3V0YWJsZSBtb3ZlIFtGTEFHU10gPGZyb20tYWxpYXM+IDx0by1hbGlhcz4KCkZMQUdTOgogICAgLWYsIC0tZm9yY2UgICAgICBBbGxvd3MgdG8gb3ZlcndyaXRlIHRoZSBleGlzdGluZyBzY3JpcHQKICAgIC1oLCAtLWhlbHAgICAgICAgUHJpbnRzIGhlbHAgaW5mb3JtYXRpb24KICAgIC1WLCAtLXZlcnNpb24gICAgUHJpbnRzIHZlcnNpb24gaW5mb3JtYXRpb24KCkFSR1M6CiAgICA8ZnJvbS1hbGlhcz4gICAgVGhlIGFsaWFzIG9mIHRoZSBzY3JpcHQgdGhhdCB3aWxsIGJlIG1vdmVkLgogICAgPHRvLWFsaWFzPiAgICAgIFRoZSBuZXcgYWxpYXMgb2YgdGhlIHNjcmlwdC4K').decode('utf-8')
_H['move_short'] = _H['move_long']
_H['remove_long'] = base64.b64decode('ZXhlY3V0YWJsZS1yZW1vdmUgMC4xLjYKYWxpYXM6IHJtIC0gUmVtb3ZlIGEgc2NyaXB0IG1hdGNoaW5nIGFsaWFzLgoKVVNBR0U6CiAgICBleGVjdXRhYmxlIHJlbW92ZSA8YWxpYXM+CgpGTEFHUzoKICAgIC1oLCAtLWhlbHAgICAgICAgUHJpbnRzIGhlbHAgaW5mb3JtYXRpb24KICAgIC1WLCAtLXZlcnNpb24gICAgUHJpbnRzIHZlcnNpb24gaW5mb3JtYXRpb24KCkFSR1M6CiAgICA8YWxpYXM+ICAgIFRoZSBhbGlhcyBvciBuYW1lIGZvciB0aGUgc2NyaXB0Lgo=').decode('utf-8')
_H['remove_short'] = _H['remove_long']
_H['run_long'] = base64.b64decode('ZXhlY3V0YWJsZS1ydW4gMC4xLjYKUnVuIGEgc2NyaXB0IG1hdGNoaW5nIGFsaWFzLgoKVVNBR0U6CiAgICBleGVjdXRhYmxlIHJ1biA8YWxpYXM+IFthcmdzXS4uLgoKRkxBR1M6CiAgICAtaCwgLS1oZWxwICAgICAgIFByaW50cyBoZWxwIGluZm9ybWF0aW9uCiAgICAtViwgLS12ZXJzaW9uICAgIFByaW50cyB2ZXJzaW9uIGluZm9ybWF0aW9uCgpBUkdTOgogICAgPGFsaWFzPiAgICAgIFRoZSBhbGlhcyBvciBuYW1lIGZvciB0aGUgc2NyaXB0LgogICAgPGFyZ3M+Li4uICAgIFRoZSBwb3NpdGlvbmFsIGFyZ3VtZW50cyB0byBzZW5kIHRvIHNjcmlwdC4K').decode('utf-8')
_H['run_short'] = _H['run_long']
_H['show_long'] = base64.b64decode('ZXhlY3V0YWJsZS1zaG93IDAuMS42ClNob3cgYSBzY3JpcHQgbWF0Y2hpbmcgYWxpYXMuCgpVU0FHRToKICAgIGV4ZWN1dGFibGUgc2hvdyA8YWxpYXM+CgpGTEFHUzoKICAgIC1oLCAtLWhlbHAgICAgICAgUHJpbnRzIGhlbHAgaW5mb3JtYXRpb24KICAgIC1WLCAtLXZlcnNpb24gICAgUHJpbnRzIHZlcnNpb24gaW5mb3JtYXRpb24KCkFSR1M6CiAgICA8YWxpYXM+ICAgIFRoZSBhbGlhcyBvciBuYW1lIGZvciB0aGUgc2NyaXB0Lgo=').decode('utf-8')
_H['show_short'] = _H['show_long']
_H['help_help_long'] = base64.b64decode('ZXhlY3V0YWJsZS1oZWxwIApQcmludHMgdGhpcyBtZXNzYWdlIG9yIHRoZSBoZWxwIG9mIHRoZSBnaXZlbiBzdWJjb21tYW5kKHMpCgpVU0FHRToKICAgIGV4ZWN1dGFibGUgaGVscCBbc3ViY29tbWFuZF0uLi4KCkFSR1M6CiAgICA8c3ViY29tbWFuZD4uLi4gICAgVGhlIHN1YmNvbW1hbmQgd2hvc2UgaGVscCBtZXNzYWdlIHRvIGRpc3BsYXkK').decode('utf-8')


SUB_VERSION = {
    "add": "executable-add 0.1.6\n",
    "remove": "executable-remove 0.1.6\n",
    "list": "executable-list 0.1.6\n",
    "run": "executable-run 0.1.6\n",
    "show": "executable-show 0.1.6\n",
    "edit": "executable-edit 0.1.6\n",
    "move": "executable-move 0.1.6\n",
    "copy": "executable-copy 0.1.6\n",
    "config-init": "executable-config-init 0.1.6\n",
    "help": "executable-help \n",
}

# Subcommand aliases (alias → canonical name)
SUB_ALIASES = {
    "ls": "list",
    "rm": "remove",
    "cp": "copy",
    "mv": "move",
    "rename": "move",
    "init": "config-init",
}
SUBCOMMANDS = [
    "add", "config-init", "copy", "edit", "help",
    "list", "move", "remove", "run", "show",
]
ALL_NAMES = sorted(set(SUBCOMMANDS) | set(SUB_ALIASES.keys()))


def sub_help_long(name):
    return _H[f"{name.replace('-', '')}_long"]


def help_with_env(s):
    """Substitute env var into [env: PIER_CONFIG_PATH=...] placeholder."""
    val = os.environ.get("PIER_CONFIG_PATH", "")
    return s.replace("[env: PIER_CONFIG_PATH=]", f"[env: PIER_CONFIG_PATH={val}]")


# ────────────────────────────────────────────────────────────────────────
# Jaro-Winkler — for clap's "Did you mean?" suggestions (threshold 0.8).
# ────────────────────────────────────────────────────────────────────────

def _jaro(s1, s2):
    if s1 == s2:
        return 1.0
    if not s1 or not s2:
        return 0.0
    win = max(len(s1), len(s2)) // 2 - 1
    if win < 0:
        win = 0
    m1 = [False] * len(s1)
    m2 = [False] * len(s2)
    matches = 0
    for i, c in enumerate(s1):
        a = max(0, i - win)
        b = min(i + win + 1, len(s2))
        for j in range(a, b):
            if m2[j] or s2[j] != c:
                continue
            m1[i] = True
            m2[j] = True
            matches += 1
            break
    if not matches:
        return 0.0
    t = 0
    k = 0
    for i, c in enumerate(s1):
        if not m1[i]:
            continue
        while not m2[k]:
            k += 1
        if c != s2[k]:
            t += 1
        k += 1
    t //= 2
    return (matches / len(s1) + matches / len(s2) + (matches - t) / matches) / 3


def jaro_winkler(s1, s2):
    j = _jaro(s1, s2)
    p = 0
    for c1, c2 in zip(s1, s2):
        if c1 == c2:
            p += 1
            if p == 4:
                break
        else:
            break
    return j + p * 0.1 * (1 - j)


def did_you_mean(arg, candidates):
    best = None
    best_score = 0.8  # clap's strict threshold
    for c in candidates:
        score = jaro_winkler(arg, c)
        if score > best_score:
            best_score = score
            best = c
    return best


# ────────────────────────────────────────────────────────────────────────
# TOML — restricted parser/writer matching pier's schema and output format.
# ────────────────────────────────────────────────────────────────────────

class TomlError(Exception):
    def __init__(self, msg, line=None):
        super().__init__(msg)
        self.msg = msg
        self.line = line


_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_\-]+")
_BARE_KEY_FULL_RE = re.compile(r"\A[A-Za-z0-9_\-]+\Z")


class TomlParser:
    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.line = 1

    def _eof(self):
        return self.pos >= len(self.text)

    def _peek(self, n=1):
        return self.text[self.pos:self.pos + n]

    def _skip_ws(self):
        while not self._eof() and self.text[self.pos] in " \t":
            self.pos += 1

    def _skip_blank_and_comments(self):
        while not self._eof():
            ch = self.text[self.pos]
            if ch in " \t":
                self.pos += 1
            elif ch == "\n":
                self.line += 1
                self.pos += 1
            elif ch == "\r":
                self.pos += 1
            elif ch == "#":
                while not self._eof() and self.text[self.pos] != "\n":
                    self.pos += 1
            else:
                break

    def parse(self):
        result = {"scripts": {}, "default": {}}
        current_table = None
        while not self._eof():
            self._skip_blank_and_comments()
            if self._eof():
                break
            if self.text[self.pos] == "[":
                self.pos += 1
                self._skip_ws()
                key_parts = self._read_key_parts(in_header=True)
                self._skip_ws()
                if self._peek() != "]":
                    self._raise("expected a right bracket, " + self._describe_found())
                self.pos += 1
                self._skip_ws()
                if not self._eof() and self.text[self.pos] not in ("\n", "\r", "#"):
                    self._raise("expected newline after table header")
                if key_parts == ["scripts"]:
                    current_table = None
                elif len(key_parts) == 2 and key_parts[0] == "scripts":
                    alias = key_parts[1]
                    if alias in result["scripts"]:
                        # toml-rs appends " at line N" for the parser-level
                        # redefinition error; bake it in to bypass load_config's
                        # "for key" filter that suppresses the line suffix.
                        raise TomlError(
                            f"redefinition of table `scripts.{alias}` for key `scripts.{alias}` at line {self.line}",
                            None,
                        )
                    result["scripts"][alias] = {}
                    current_table = ("scripts", alias)
                elif key_parts == ["default"]:
                    current_table = ("default",)
                else:
                    current_table = ("__unknown__",)
            else:
                key_parts = self._read_key_parts()
                self._skip_ws()
                if self._peek() != "=":
                    self._raise("expected an equals, " + self._describe_found())
                self.pos += 1
                self._skip_ws()
                value = self._read_value()
                self._skip_ws()
                if not self._eof() and self.text[self.pos] not in ("\n", "\r", "#"):
                    self._raise("expected newline, " + self._describe_found())
                if current_table is None:
                    pass
                elif current_table[0] == "scripts":
                    alias = current_table[1]
                    if len(key_parts) == 1:
                        k = key_parts[0]
                        if k == "command":
                            if not isinstance(value, str):
                                self._raise_type("a string", value, f"scripts.{alias}.command")
                            result["scripts"][alias]["command"] = value
                        elif k == "description":
                            if not isinstance(value, str):
                                self._raise_type("a string", value, f"scripts.{alias}.description")
                            result["scripts"][alias]["description"] = value
                        elif k == "tags":
                            if not isinstance(value, list):
                                self._raise_type("a sequence", value, f"scripts.{alias}.tags")
                            for t in value:
                                if not isinstance(t, str):
                                    self._raise_type("a string", t, f"scripts.{alias}.tags")
                            result["scripts"][alias]["tags"] = value
                elif current_table[0] == "default":
                    if len(key_parts) == 1 and key_parts[0] == "command_width":
                        if isinstance(value, bool):
                            self._raise_type("usize", value, "default.command_width")
                        if not isinstance(value, int):
                            self._raise_type("usize", value, "default.command_width")
                        if value < 0:
                            self._raise_value(value, "usize", "default.command_width")
                        result["default"]["command_width"] = value
        # Validate required fields per script.
        for alias, s in result["scripts"].items():
            if "command" not in s:
                self._raise(f"missing field `command` for key `scripts.{alias}`")
        return result

    def _read_key_parts(self, in_header=False):
        parts = []
        while True:
            self._skip_ws()
            if self._eof():
                self._raise("expected a table key, found a right bracket")
            ch = self.text[self.pos]
            if ch == "]" and in_header:
                # Empty key in header — error.
                self._raise("expected a table key, found a right bracket")
            if ch == '"':
                self.pos += 1
                s = []
                while not self._eof() and self.text[self.pos] != '"':
                    c = self.text[self.pos]
                    if c == "\\":
                        self.pos += 1
                        if self._eof():
                            self._raise("unterminated escape")
                        e = self.text[self.pos]
                        s.append(self._unescape(e))
                        self.pos += 1
                    else:
                        s.append(c)
                        self.pos += 1
                if self._eof():
                    self._raise("unterminated string key")
                self.pos += 1
                parts.append("".join(s))
            elif ch == "'":
                self.pos += 1
                start = self.pos
                while not self._eof() and self.text[self.pos] != "'":
                    self.pos += 1
                if self._eof():
                    self._raise("unterminated literal key")
                parts.append(self.text[start:self.pos])
                self.pos += 1
            else:
                m = _BARE_KEY_RE.match(self.text, self.pos)
                if not m:
                    self._raise(f"expected a table key, found a right bracket")
                parts.append(m.group(0))
                self.pos = m.end()
            self._skip_ws()
            if not self._eof() and self.text[self.pos] == ".":
                self.pos += 1
                continue
            break
        return parts

    def _read_value(self):
        if self._eof():
            self._raise("expected a value")
        ch = self.text[self.pos]
        if ch == "'":
            return self._read_literal_string()
        if ch == '"':
            return self._read_basic_string()
        if ch == "[":
            return self._read_array()
        if ch in "0123456789-+":
            return self._read_number()
        if ch in "tf":
            return self._read_bool()
        self._raise(f"unexpected character")

    def _read_literal_string(self):
        if self.text[self.pos:self.pos + 3] == "'''":
            self.pos += 3
            if not self._eof() and self.text[self.pos] == "\n":
                self.pos += 1
                self.line += 1
            elif self.text[self.pos:self.pos + 2] == "\r\n":
                self.pos += 2
                self.line += 1
            start = self.pos
            while True:
                if self._eof():
                    self._raise("unterminated literal block string")
                if self.text[self.pos:self.pos + 3] == "'''":
                    s = self.text[start:self.pos]
                    self.pos += 3
                    return s
                if self.text[self.pos] == "\n":
                    self.line += 1
                self.pos += 1
        self.pos += 1
        start = self.pos
        while True:
            if self._eof():
                self._raise("unterminated literal string")
            c = self.text[self.pos]
            if c == "'":
                s = self.text[start:self.pos]
                self.pos += 1
                return s
            if c == "\n":
                self._raise("newline in literal string")
            self.pos += 1

    def _read_basic_string(self):
        if self.text[self.pos:self.pos + 3] == '"""':
            self.pos += 3
            if not self._eof() and self.text[self.pos] == "\n":
                self.pos += 1
                self.line += 1
            elif self.text[self.pos:self.pos + 2] == "\r\n":
                self.pos += 2
                self.line += 1
            out = []
            while True:
                if self._eof():
                    self._raise("unterminated basic block string")
                if self.text[self.pos:self.pos + 3] == '"""':
                    self.pos += 3
                    return "".join(out)
                c = self.text[self.pos]
                if c == "\\":
                    self.pos += 1
                    if self._eof():
                        self._raise("unterminated escape")
                    nxt = self.text[self.pos]
                    if nxt == "\n":
                        self.pos += 1
                        self.line += 1
                        while not self._eof() and self.text[self.pos] in " \t\n\r":
                            if self.text[self.pos] == "\n":
                                self.line += 1
                            self.pos += 1
                    else:
                        out.append(self._unescape(nxt))
                        self.pos += 1
                else:
                    if c == "\n":
                        self.line += 1
                    out.append(c)
                    self.pos += 1
        self.pos += 1
        out = []
        while True:
            if self._eof():
                self._raise("unterminated basic string")
            c = self.text[self.pos]
            if c == '"':
                self.pos += 1
                return "".join(out)
            if c == "\\":
                self.pos += 1
                if self._eof():
                    self._raise("unterminated escape")
                nxt = self.text[self.pos]
                if nxt == "u":
                    hex_str = self.text[self.pos + 1:self.pos + 5]
                    out.append(chr(int(hex_str, 16)))
                    self.pos += 5
                elif nxt == "U":
                    hex_str = self.text[self.pos + 1:self.pos + 9]
                    out.append(chr(int(hex_str, 16)))
                    self.pos += 9
                else:
                    out.append(self._unescape(nxt))
                    self.pos += 1
            elif c == "\n":
                self._raise("newline in basic string")
            else:
                out.append(c)
                self.pos += 1

    def _unescape(self, c):
        m = {
            "b": "\b", "t": "\t", "n": "\n", "f": "\f",
            "r": "\r", '"': '"', "\\": "\\",
        }
        if c in m:
            return m[c]
        self._raise(f"invalid escape character in string: `{c}`")

    def _read_array(self):
        self.pos += 1
        items = []
        while True:
            self._skip_array_ws()
            if self._eof():
                self._raise("unterminated array")
            if self.text[self.pos] == "]":
                self.pos += 1
                return items
            items.append(self._read_value())
            self._skip_array_ws()
            if self._eof():
                self._raise("unterminated array")
            if self.text[self.pos] == ",":
                self.pos += 1
                continue
            if self.text[self.pos] == "]":
                self.pos += 1
                return items
            self._raise("expected comma or close bracket in array")

    def _skip_array_ws(self):
        while not self._eof():
            ch = self.text[self.pos]
            if ch in " \t\r":
                self.pos += 1
            elif ch == "\n":
                self.line += 1
                self.pos += 1
            elif ch == "#":
                while not self._eof() and self.text[self.pos] != "\n":
                    self.pos += 1
            else:
                break

    def _read_number(self):
        start = self.pos
        if self.text[self.pos] in "+-":
            self.pos += 1
        while not self._eof() and self.text[self.pos] in "0123456789_":
            self.pos += 1
        s = self.text[start:self.pos].replace("_", "")
        if not s or s in ("+", "-"):
            self._raise("invalid number")
        try:
            return int(s)
        except ValueError:
            self._raise("invalid number")

    def _read_bool(self):
        if self.text[self.pos:self.pos + 4] == "true":
            self.pos += 4
            return True
        if self.text[self.pos:self.pos + 5] == "false":
            self.pos += 5
            return False
        m = _BARE_KEY_RE.match(self.text, self.pos)
        if m:
            self.pos = m.end()
            self._raise("found an identifier")
        self._raise("invalid value")

    def _describe_found(self):
        """Describe the token at the current position (toml-rs style)."""
        if self._eof():
            return "found eof"
        c = self.text[self.pos]
        if c == "\n" or c == "\r":
            return "found a newline"
        if c == "=":
            return "found an equals"
        if c == ".":
            return "found a period"
        if c == ",":
            return "found a comma"
        if c == ":":
            return "found a colon"
        if c == "+":
            return "found a plus"
        if c == "{":
            return "found a left brace"
        if c == "}":
            return "found a right brace"
        if c == "[":
            return "found a left bracket"
        if c == "]":
            return "found a right bracket"
        if c == '"' or c == "'":
            return "found a string"
        if c == "#":
            return "found a comment"
        return "found an identifier"

    def _raise(self, msg):
        raise TomlError(msg, self.line)

    def _raise_type(self, expected, got, key):
        """expected is the full phrase used by serde — e.g. 'a string', 'usize', 'a sequence'."""
        if isinstance(got, bool):
            got_repr = f"boolean `{str(got).lower()}`"
        elif isinstance(got, int):
            got_repr = f"integer `{got}`"
        elif isinstance(got, str):
            got_repr = f'string "{got}"'
        elif isinstance(got, list):
            got_repr = "array"
        elif isinstance(got, dict):
            got_repr = "map"
        else:
            got_repr = str(got)
        raise TomlError(f"invalid type: {got_repr}, expected {expected} for key `{key}`", self.line)

    def _raise_value(self, value, expected, key):
        raise TomlError(f"invalid value: integer `{value}`, expected {expected} for key `{key}`", self.line)


def parse_toml(text):
    return TomlParser(text).parse()


def _format_key(k):
    if k and _BARE_KEY_FULL_RE.match(k):
        return k
    s = []
    for c in k:
        if c == "\\":
            s.append("\\\\")
        elif c == '"':
            s.append('\\"')
        elif c == "\b":
            s.append("\\b")
        elif c == "\t":
            s.append("\\t")
        elif c == "\n":
            s.append("\\n")
        elif c == "\f":
            s.append("\\f")
        elif c == "\r":
            s.append("\\r")
        elif ord(c) < 0x20:
            s.append("\\u%04X" % ord(c))
        else:
            s.append(c)
    return '"' + "".join(s) + '"'


def _basic_escape(s):
    """Escape a string for a TOML basic string (double-quoted)."""
    out = []
    for c in s:
        if c == "\\":
            out.append("\\\\")
        elif c == '"':
            out.append('\\"')
        elif c == "\b":
            out.append("\\b")
        elif c == "\t":
            out.append("\\t")
        elif c == "\n":
            out.append("\\n")
        elif c == "\f":
            out.append("\\f")
        elif c == "\r":
            out.append("\\r")
        elif ord(c) < 0x20:
            out.append("\\u%04X" % ord(c))
        else:
            out.append(c)
    return "".join(out)


def _basic_escape_multiline(s):
    """Escape for a TOML multi-line basic string (newlines stay literal)."""
    out = []
    for c in s:
        if c == "\\":
            out.append("\\\\")
        elif c == '"':
            out.append('\\"')
        elif c == "\n":
            out.append("\n")
        elif c == "\b":
            out.append("\\b")
        elif c == "\t":
            out.append("\t")
        elif c == "\f":
            out.append("\\f")
        elif c == "\r":
            out.append("\\r")
        elif ord(c) < 0x20:
            out.append("\\u%04X" % ord(c))
        else:
            out.append(c)
    return "".join(out)


def _format_string(s):
    """toml-rs pretty serializer string emission.

    Preference: literal '...' > literal block '''...''' > basic "..." .
    A char < 0x1F (except tab/newline) cannot appear in a literal string.
    """
    has_nl = "\n" in s
    bad_for_literal = any((ord(c) < 0x1F and c not in "\t\n") for c in s)
    triple_ok = ("'''" not in s) and (not s.endswith("'"))

    if has_nl:
        if (not bad_for_literal) and triple_ok:
            return "'''\n" + s + "'''"
        return '"""\n' + _basic_escape_multiline(s) + '"""'

    # one-line string
    if bad_for_literal:
        return '"' + _basic_escape(s) + '"'
    if "'" in s:
        if triple_ok:
            return "'''" + s + "'''"
        return '"' + _basic_escape(s) + '"'
    return "'" + s + "'"


def write_config(parsed):
    lines = []
    aliases = sorted(parsed["scripts"].keys())
    if not aliases:
        # toml-rs serializes an empty map as a bare table header.
        lines.append("[scripts]")
        lines.append("")
    for alias in aliases:
        s = parsed["scripts"][alias]
        lines.append(f"[scripts.{_format_key(alias)}]")
        if "command" in s:
            lines.append(f"command = {_format_string(s['command'])}")
        if "description" in s:
            lines.append(f"description = {_format_string(s['description'])}")
        if "tags" in s:
            tags = s["tags"]
            if len(tags) == 0:
                lines.append("tags = []")
            elif len(tags) == 1:
                lines.append(f"tags = [{_format_string(tags[0])}]")
            else:
                lines.append("tags = [")
                for t in tags:
                    lines.append(f"    {_format_string(t)},")
                lines.append("]")
        lines.append("")
    lines.append("[default]")
    d = parsed["default"]
    if "command_width" in d:
        lines.append(f"command_width = {d['command_width']}")
    return "\n".join(lines) + "\n"


# ────────────────────────────────────────────────────────────────────────
# Config file path resolution
# ────────────────────────────────────────────────────────────────────────

def _xdg_dir():
    """Resolve XDG_CONFIG_HOME, defaulting to $HOME/.config (string concat
    so an empty HOME yields '/.config', matching the reference)."""
    xdg = os.environ.get("XDG_CONFIG_HOME") or ""
    if xdg:
        return xdg
    home = os.environ.get("HOME") or ""
    return home + "/.config"


def get_config_path(explicit=None):
    if explicit:
        return explicit, None
    env_path = os.environ.get("PIER_CONFIG_PATH")
    if env_path:
        return env_path, None
    home = os.environ.get("HOME") or ""
    xdg = _xdg_dir()
    candidates = [
        os.path.join(os.getcwd(), "pier.toml"),
        xdg + "/pier/config.toml",
        xdg + "/pier/config",
        xdg + "/pier.toml",
        home + "/.pier.toml",
        home + "/.pier",
    ]
    for p in candidates:
        if os.path.isfile(p):
            return p, None
    return None, "No default config file found. See help for more info."


def get_init_path(explicit=None):
    if explicit:
        return explicit
    env_path = os.environ.get("PIER_CONFIG_PATH")
    if env_path:
        return env_path
    return _xdg_dir() + "/pier/config.toml"


# ────────────────────────────────────────────────────────────────────────
# IO helpers and error emission
# ────────────────────────────────────────────────────────────────────────

def err(msg):
    sys.stderr.write(f"error: {msg}\n")
    sys.exit(1)


def out(msg, end="\n"):
    sys.stdout.write(msg + end)


def load_config(path):
    if not os.path.exists(path):
        err(f"Unable to read config from file {path}: No such file or directory (os error 2) ")
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except OSError as e:
        err(f"Unable to read config from file {path}: {e.strerror} (os error {e.errno}) ")
    try:
        return parse_toml(text)
    except TomlError as e:
        msg = e.msg
        if e.line is not None and "for key" not in msg:
            msg = f"{msg} at line {e.line}"
        err(f"Unable to parse toml config from file {path}: {msg}")


def save_config(path, parsed):
    text = write_config(parsed)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def require_scripts(parsed):
    if not parsed["scripts"]:
        err("No scripts exist. Would you like to add a new script?")


# ────────────────────────────────────────────────────────────────────────
# Subcommand handlers
# ────────────────────────────────────────────────────────────────────────

LIST_HORIZ = "≖"  # ≖
LIST_VERT = "⋮"   # ⋮


def cmd_list(parsed, opts):
    require_scripts(parsed)
    scripts = parsed["scripts"]
    cmd_full = opts.get("cmd_full", False)
    cmd_width = opts.get("cmd_width")
    list_aliases = opts.get("list_aliases", False)
    tags_filter = opts.get("tags", [])

    keys = sorted(scripts.keys())
    if tags_filter:
        rows = []
        for tag in tags_filter:
            for k in keys:
                stags = scripts[k].get("tags") or []
                if tag in stags:
                    rows.append(k)
    else:
        rows = list(keys)

    if list_aliases:
        for k in rows:
            out(k)
        return

    if cmd_full:
        max_cmd = None
    elif cmd_width is not None:
        max_cmd = cmd_width
    else:
        dw = parsed["default"].get("command_width")
        max_cmd = dw if dw is not None else 80

    def truncate(s):
        return s if max_cmd is None else s[:max_cmd]

    headers = ["Alias", "Tags", "Command", "Description"]
    data = []
    for alias in rows:
        s = scripts[alias]
        cmd = truncate(s.get("command", ""))
        desc = s.get("description", "")
        tags = ",".join(s.get("tags") or [])
        data.append([alias, tags, cmd, desc])

    widths = [len(h) for h in headers]
    for row in data:
        for i, cell in enumerate(row):
            if len(cell) > widths[i]:
                widths[i] = len(cell)

    total = sum(widths) + 2 * len(widths) + (len(widths) + 1)
    bar = LIST_HORIZ * total
    out(bar)
    parts = [" " + h.ljust(widths[i]) + " " for i, h in enumerate(headers)]
    out(LIST_VERT + LIST_VERT.join(parts) + LIST_VERT)
    out(bar)
    for row in data:
        parts = [" " + cell.ljust(widths[i]) + " " for i, cell in enumerate(row)]
        out(LIST_VERT + LIST_VERT.join(parts) + LIST_VERT)
    out(bar)


def cmd_add(parsed, opts, path):
    alias = opts["alias"]
    force = opts.get("force", False)
    command = opts.get("command")
    description = opts.get("description")
    tags = opts.get("tags")

    if alias in parsed["scripts"] and not force:
        err(f"AliasAlreadyExists:  {alias}")

    if command is None:
        command = open_editor("")

    entry = {"command": command}
    if description is not None:
        entry["description"] = description
    if tags:
        entry["tags"] = list(tags)
    parsed["scripts"][alias] = entry
    save_config(path, parsed)
    out(f"Added {alias}")


def cmd_remove(parsed, opts, path):
    require_scripts(parsed)
    alias = opts["alias"]
    if alias not in parsed["scripts"]:
        err(f"AliasNotFound: No script found by alias {alias}")
    del parsed["scripts"][alias]
    save_config(path, parsed)
    out(f"Removed {alias}")


def cmd_show(parsed, opts):
    require_scripts(parsed)
    alias = opts["alias"]
    if alias not in parsed["scripts"]:
        err(f"AliasNotFound: No script found by alias {alias}")
    out(parsed["scripts"][alias]["command"])


def cmd_edit(parsed, opts, path):
    require_scripts(parsed)
    alias = opts["alias"]
    if alias not in parsed["scripts"]:
        err(f"AliasNotFound: No script found by alias {alias}")
    current = parsed["scripts"][alias]["command"]
    new_cmd = open_editor(current)
    parsed["scripts"][alias]["command"] = new_cmd
    save_config(path, parsed)
    out(f"Edited {alias}")


def cmd_run(parsed, opts, verbose):
    require_scripts(parsed)
    alias = opts["alias"]
    args = opts.get("args", [])
    if alias not in parsed["scripts"]:
        err(f"AliasNotFound: No script found by alias {alias}")
    command = parsed["scripts"][alias]["command"]
    shell = os.environ.get("SHELL", "/bin/sh")
    if verbose:
        out(f'Starting script "{alias}"')
        out("-" * 25)
    sys.stdout.flush()
    sys.stderr.flush()
    # stdout/stdin inherited (streamed); stderr captured so it can be
    # re-emitted with a trailing newline, matching the reference.
    try:
        proc = subprocess.Popen(
            [shell, "-c", command, alias] + args,
            stderr=subprocess.PIPE,
        )
    except OSError as e:
        err(f"Command execution failed with: {e.strerror} (os error {e.errno})")
    _, stderr_data = proc.communicate()
    rc = proc.returncode
    if verbose:
        sys.stdout.flush()
        out("-" * 25)
        out("Script complete")
        sys.stdout.flush()
    if stderr_data:
        sys.stderr.buffer.write(stderr_data)
        sys.stderr.buffer.write(b"\n")
        sys.stderr.buffer.flush()
    sys.exit(rc if rc >= 0 else 1)


def cmd_move(parsed, opts, path):
    # move/copy do NOT require a non-empty scripts table.
    src = opts["from"]
    dst = opts["to"]
    force = opts.get("force", False)
    # Reference checks destination conflict BEFORE source existence.
    if dst in parsed["scripts"] and not force:
        err(f"AliasAlreadyExists:  {dst}")
    if src not in parsed["scripts"]:
        err(f"AliasNotFound: No script found by alias {src}")
    parsed["scripts"][dst] = parsed["scripts"][src]
    if src != dst:
        del parsed["scripts"][src]
    save_config(path, parsed)
    out(f"Move from alias {src} to new alias {dst}")


def cmd_copy(parsed, opts, path):
    src = opts["from"]
    dst = opts["to"]
    if dst in parsed["scripts"]:
        err(f"AliasAlreadyExists:  {dst}")
    if src not in parsed["scripts"]:
        err(f"AliasNotFound: No script found by alias {src}")
    import copy as _copymod
    parsed["scripts"][dst] = _copymod.deepcopy(parsed["scripts"][src])
    save_config(path, parsed)
    out(f"Copy from alias {src} to new alias {dst}")


def cmd_config_init(path):
    if path is None:
        err("No default config file found. See help for more info.")
    if os.path.exists(path):
        err(f"Cannot initialize config at {path}, file already exists.")
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        try:
            os.mkdir(parent)
        except OSError as e:
            err(f"Failed to create directory. {e.strerror} (os error {e.errno})")
    parsed = {
        "scripts": {
            "hello-pier": {
                "command": "echo Hello, Pier!",
                "description": "This is an example command.",
            }
        },
        "default": {},
    }
    save_config(path, parsed)
    out("Added hello-pier")


def open_editor(initial=""):
    editor = os.environ.get("EDITOR") or "vi"
    fd, tmpfile = tempfile.mkstemp(prefix="xvrqt_scrawl_")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(initial)
        try:
            rc = subprocess.call([editor, tmpfile])
        except OSError:
            err(f"EditorError: Failed when trying to get input from editor Failed to open `{editor}` as a text editor or editor was terminated with errors.")
        if rc != 0:
            err(f"EditorError: Failed when trying to get input from editor Failed to open `{editor}` as a text editor or editor was terminated with errors.")
        with open(tmpfile, "r", encoding="utf-8") as f:
            return f.read()
    finally:
        try:
            os.unlink(tmpfile)
        except OSError:
            pass


# ────────────────────────────────────────────────────────────────────────
# Clap-style errors and usage blocks
# ────────────────────────────────────────────────────────────────────────

USAGE_MAIN_TWOLINE = (
    "USAGE:\n"
    "    executable [FLAGS] [OPTIONS] <alias> [args]...\n"
    "    executable [FLAGS] [OPTIONS] <SUBCOMMAND>"
)

# Global parse state — informs clap-style dynamic USAGE generation.
STATE = {"verbose": False, "config_present": False, "sub_provided": set()}

SUB_USAGE = {
    "add": "USAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]",
    "remove": "USAGE:\n    executable remove <alias>",
    "list": "USAGE:\n    executable list [FLAGS] [OPTIONS]",
    "run": "USAGE:\n    executable run <alias> [args]...",
    "show": "USAGE:\n    executable show <alias>",
    "edit": "USAGE:\n    executable edit <alias>",
    "move": "USAGE:\n    executable move [FLAGS] <from-alias> <to-alias>",
    "copy": "USAGE:\n    executable copy <from-alias> <to-alias>",
    "config-init": "USAGE:\n    executable config-init",
    "help": "USAGE:\n\texecutable help <subcommands>...",
}

# Per-subcommand usage spec: required parts and optional flags (decl order).
SUB_SPEC = {
    "add": (["--alias <alias>"],
            [("force", "--force"), ("description", "--description <description>"),
             ("tag", "--tag <tags>...")]),
    "list": ([],
             [("cmd_full", "--cmd_full"), ("list_aliases", "--list_aliases"),
              ("cmd_width", "--cmd_width <cmd-width>"), ("tag", "--tag <tags>...")]),
    "move": (["<from-alias>", "<to-alias>"], [("force", "--force")]),
    "copy": (["<from-alias>", "<to-alias>"], []),
    "remove": (["<alias>"], []),
    "show": (["<alias>"], []),
    "edit": (["<alias>"], []),
    "run": (["<alias>"], []),
    "config-init": ([], []),
}


def cur_sub_usage(sub):
    """USAGE for a subcommand error — collapses to show provided optional
    flags, mirroring clap's dynamic usage generation."""
    provided = STATE["sub_provided"]
    if sub not in SUB_SPEC or not provided:
        return SUB_USAGE[sub]
    required, optionals = SUB_SPEC[sub]
    parts = ["executable", sub] + list(required)
    for key, token in optionals:
        if key in provided:
            parts.append(token)
    return "USAGE:\n    " + " ".join(parts)


def top_usage_validation():
    """USAGE for validation errors (missing required arg, verbose dup).
    Collapses to `executable <alias> [--config-file <path>] [--verbose]`."""
    if not STATE["verbose"] and not STATE["config_present"]:
        return USAGE_MAIN_TWOLINE
    line = "    executable <alias>"
    if STATE["config_present"]:
        line += " --config-file <path>"
    if STATE["verbose"]:
        line += " --verbose"
    return "USAGE:\n" + line


def top_usage_parse():
    """USAGE for parse errors (unknown subcommand, unknown flag).
    Collapses only for --verbose; otherwise two-line generic."""
    if STATE["verbose"]:
        return "USAGE:\n    executable <alias> --verbose"
    return USAGE_MAIN_TWOLINE


def emit_clap_error(message, usage_block):
    sys.stderr.write(f"error: {message}\n\n")
    sys.stderr.write(usage_block + "\n")
    sys.stderr.write("\nFor more information try --help\n")
    sys.exit(1)


def _parse_usize(val):
    """Parse an unsigned integer the way Rust's usize::from_str does."""
    if val and all(c in "0123456789" for c in val):
        return int(val)
    sys.stderr.write(
        "error: Invalid value for '--cmd_width <cmd-width>': invalid digit found in string\n"
    )
    sys.exit(1)


def expand_short(token, value_flags):
    """Expand a clustered short-flag token like '-lq' or '-cfoo'.
    Returns a list of tokens. A value-taking flag terminates the cluster;
    any remaining chars become the value (a leading '=' is stripped)."""
    chars = token[1:]
    out = []
    k = 0
    while k < len(chars):
        ch = chars[k]
        out.append("-" + ch)
        if ch in value_flags:
            rest = chars[k + 1:]
            if rest:
                if rest.startswith("="):
                    rest = rest[1:]
                out.append(rest)
            return out
        k += 1
    return out


def preexpand(args, value_flags):
    """Pre-expand short-flag clusters in an argument list (stops at '--')."""
    out = []
    dd = False
    for tok in args:
        if dd:
            out.append(tok)
        elif tok == "--":
            dd = True
            out.append(tok)
        elif len(tok) >= 2 and tok[0] == "-" and tok[1] != "-":
            out.extend(expand_short(tok, value_flags))
        else:
            out.append(tok)
    return out


def emit_subcommand_unrecognized(arg, suggestion=None):
    sys.stderr.write(f"error: The subcommand '{arg}' wasn't recognized\n")
    if suggestion:
        sys.stderr.write(f"\tDid you mean '{suggestion}'?\n")
    sys.stderr.write(f"\nIf you believe you received this message in error, try re-running with 'executable -- {arg}'\n\n")
    sys.stderr.write(top_usage_parse() + "\n\nFor more information try --help\n")
    sys.exit(1)


# ────────────────────────────────────────────────────────────────────────
# Main entry point
# ────────────────────────────────────────────────────────────────────────

def main(argv):
    verbose_count = 0
    config_file = None
    positionals = []
    dd_seen = False
    if os.environ.get("PIER_CONFIG_PATH"):
        STATE["config_present"] = True

    argv = list(argv)
    i = 0
    while i < len(argv):
        a = argv[i]

        if dd_seen:
            # After `--`: positional, but each token is still checked
            # against subcommands (clap's quirk) — never dispatched.
            sug = did_you_mean(a, ALL_NAMES)
            if sug is not None:
                emit_subcommand_unrecognized(a, sug)
            positionals.append(a)
            i += 1
            continue

        if a == "--":
            dd_seen = True
            i += 1
            continue
        # Expand clustered short flags (-vh, -cfoo, ...).
        if len(a) >= 2 and a[0] == "-" and a[1] != "-":
            expanded = expand_short(a, {"c"})
            argv[i:i + 1] = expanded
            a = argv[i]
        if a == "-h":
            sys.stdout.write(help_with_env(_H['HELP_SHORT']))
            sys.exit(0)
        if a == "--help":
            sys.stdout.write(help_with_env(_H['HELP_LONG']))
            sys.exit(0)
        if a in ("-V", "--version"):
            sys.stdout.write(f"pier {VERSION}\n")
            sys.exit(0)
        if a in ("-v", "--verbose"):
            verbose_count += 1
            STATE["verbose"] = True
            i += 1
            continue
        if a in ("-c", "--config-file"):
            if i + 1 < len(argv):
                config_file = argv[i + 1]
                i += 2
            else:
                i += 1
            STATE["config_present"] = True
            continue
        if a.startswith("--config-file="):
            config_file = a.split("=", 1)[1]
            STATE["config_present"] = True
            i += 1
            continue
        # Unknown flag (a bare "-" is a valid positional / alias).
        if a != "-" and a.startswith("-"):
            emit_clap_error(
                f"Found argument '{a}' which wasn't expected, or isn't valid in this context",
                top_usage_parse(),
            )
        # Non-flag token: subcommand dispatch or positional.
        if a in SUBCOMMANDS or a in SUB_ALIASES:
            if verbose_count > 1:
                emit_clap_error(
                    "The argument '--verbose' was provided more than once, but cannot be used multiple times",
                    top_usage_validation(),
                )
            canon = a if a in SUBCOMMANDS else SUB_ALIASES[a]
            dispatch_sub(canon, argv[i + 1:], config_file, verbose_count > 0)
            return
        sug = did_you_mean(a, ALL_NAMES)
        if sug is not None:
            emit_subcommand_unrecognized(a, sug)
        positionals.append(a)
        i += 1

    if not positionals:
        emit_clap_error(
            "The following required arguments were not provided:\n    <alias>",
            top_usage_validation(),
        )
    if verbose_count > 1:
        emit_clap_error(
            "The argument '--verbose' was provided more than once, but cannot be used multiple times",
            top_usage_validation(),
        )

    path, error = get_config_path(config_file)
    if error:
        err(error)
    parsed = load_config(path)
    cmd_run(parsed, {"alias": positionals[0], "args": positionals[1:]}, verbose_count > 0)


def dispatch_sub(sub, rest, config_file, verbose):
    if sub == "help":
        handle_help(rest)
        return
    opts = parse_sub_args(sub, rest)
    if opts.get("__help"):
        kind = "long" if opts["__help"] == "long" else "short"
        sys.stdout.write(_H[f"{sub.replace('-', '')}_{kind}"])
        sys.exit(0)
    if opts.get("__version"):
        sys.stdout.write(SUB_VERSION[sub])
        sys.exit(0)

    if sub == "config-init":
        path = get_init_path(config_file)
        cmd_config_init(path)
        return

    path, error = get_config_path(config_file)
    if error:
        err(error)
    parsed = load_config(path)
    if sub == "list":
        cmd_list(parsed, opts)
    elif sub == "add":
        cmd_add(parsed, opts, path)
    elif sub == "remove":
        cmd_remove(parsed, opts, path)
    elif sub == "show":
        cmd_show(parsed, opts)
    elif sub == "edit":
        cmd_edit(parsed, opts, path)
    elif sub == "run":
        cmd_run(parsed, opts, verbose)
    elif sub == "move":
        cmd_move(parsed, opts, path)
    elif sub == "copy":
        cmd_copy(parsed, opts, path)


def handle_help(rest):
    if not rest:
        sys.stdout.write(help_with_env(_H['HELP_SHORT']))
        sys.exit(0)
    name = rest[0]
    if name == "help":
        sys.stdout.write(_H['help_help_long'])
        sys.exit(0)
    canonical = name if name in SUBCOMMANDS else SUB_ALIASES.get(name)
    if canonical is None:
        sys.stderr.write(
            f"error: The subcommand '{name}' wasn't recognized\n\n"
            "USAGE:\n\texecutable help <subcommands>...\n\n"
            "For more information try --help\n"
        )
        sys.exit(1)
    sys.stdout.write(_H[f"{canonical.replace('-', '')}_short"])
    sys.exit(0)


_SUB_VALUE_FLAGS = {
    "add": {"a", "d", "t"},
    "list": {"c", "t"},
}


def parse_sub_args(sub, args):
    opts = {}
    pos = []
    args = preexpand(args, _SUB_VALUE_FLAGS.get(sub, set()))
    i = 0
    end_of_options = False
    while i < len(args):
        a = args[i]
        if end_of_options:
            pos.append(a)
            i += 1
            continue
        if a == "--":
            end_of_options = True
            i += 1
            continue
        if a == "-h":
            opts["__help"] = "short"
            i += 1
            continue
        if a == "--help":
            opts["__help"] = "long"
            i += 1
            continue
        if a in ("-V", "--version"):
            opts["__version"] = True
            i += 1
            continue

        if sub == "add":
            if a in ("-f", "--force"):
                opts["force"] = True
                STATE["sub_provided"].add("force")
                i += 1
                continue
            if a in ("-a", "--alias"):
                if i + 1 >= len(args):
                    emit_clap_error(
                        "The argument '--alias <alias>' requires a value but none was supplied",
                        cur_sub_usage("add"),
                    )
                opts["alias"] = args[i + 1]
                i += 2
                continue
            if a.startswith("--alias="):
                opts["alias"] = a.split("=", 1)[1]
                i += 1
                continue
            if a in ("-d", "--description"):
                STATE["sub_provided"].add("description")
                if i + 1 >= len(args):
                    emit_clap_error(
                        "The argument '--description <description>' requires a value but none was supplied",
                        cur_sub_usage("add"),
                    )
                opts["description"] = args[i + 1]
                i += 2
                continue
            if a.startswith("--description="):
                STATE["sub_provided"].add("description")
                opts["description"] = a.split("=", 1)[1]
                i += 1
                continue
            if a in ("-t", "--tag"):
                STATE["sub_provided"].add("tag")
                tags = opts.setdefault("tags", [])
                i += 1
                if i >= len(args):
                    emit_clap_error(
                        "The argument '--tag <tags>...' requires a value but none was supplied",
                        cur_sub_usage("add"),
                    )
                while i < len(args) and not args[i].startswith("-") and args[i] != "--":
                    tags.append(args[i])
                    i += 1
                continue
            if a.startswith("-"):
                emit_clap_error(
                    f"Found argument '{a}' which wasn't expected, or isn't valid in this context",
                    cur_sub_usage("add"),
                )
            pos.append(a)
            i += 1
            continue

        if sub == "list":
            if a in ("-l", "--cmd_full"):
                opts["cmd_full"] = True
                STATE["sub_provided"].add("cmd_full")
                i += 1
                continue
            if a in ("-q", "--list_aliases"):
                opts["list_aliases"] = True
                STATE["sub_provided"].add("list_aliases")
                i += 1
                continue
            if a in ("-c", "--cmd_width"):
                STATE["sub_provided"].add("cmd_width")
                if i + 1 >= len(args):
                    emit_clap_error(
                        "The argument '--cmd_width <cmd-width>' requires a value but none was supplied",
                        cur_sub_usage("list"),
                    )
                val = args[i + 1]
                if val.startswith("-"):
                    emit_clap_error(
                        f"Found argument '{val}' which wasn't expected, or isn't valid in this context",
                        cur_sub_usage("list"),
                    )
                opts["cmd_width"] = _parse_usize(val)
                i += 2
                continue
            if a.startswith("--cmd_width="):
                STATE["sub_provided"].add("cmd_width")
                opts["cmd_width"] = _parse_usize(a.split("=", 1)[1])
                i += 1
                continue
            if a in ("-t", "--tag"):
                STATE["sub_provided"].add("tag")
                tags = opts.setdefault("tags", [])
                i += 1
                if i >= len(args):
                    emit_clap_error(
                        "The argument '--tag <tags>...' requires a value but none was supplied",
                        cur_sub_usage("list"),
                    )
                while i < len(args) and not args[i].startswith("-") and args[i] != "--":
                    tags.append(args[i])
                    i += 1
                continue
            if a.startswith("-"):
                emit_clap_error(
                    f"Found argument '{a}' which wasn't expected, or isn't valid in this context",
                    cur_sub_usage("list"),
                )
            pos.append(a)
            i += 1
            continue

        if sub in ("remove", "show", "edit"):
            if a.startswith("-"):
                emit_clap_error(
                    f"Found argument '{a}' which wasn't expected, or isn't valid in this context",
                    cur_sub_usage(sub),
                )
            pos.append(a)
            i += 1
            continue

        if sub == "run":
            if a.startswith("-") and not pos:
                emit_clap_error(
                    f"Found argument '{a}' which wasn't expected, or isn't valid in this context",
                    cur_sub_usage("run"),
                )
            pos.append(a)
            i += 1
            while i < len(args):
                if args[i] == "--":
                    i += 1
                    continue
                pos.append(args[i])
                i += 1
            continue

        if sub in ("move", "copy"):
            if a in ("-f", "--force"):
                if sub == "copy":
                    emit_clap_error(
                        f"Found argument '{a}' which wasn't expected, or isn't valid in this context",
                        cur_sub_usage("copy"),
                    )
                opts["force"] = True
                STATE["sub_provided"].add("force")
                i += 1
                continue
            if a.startswith("-"):
                emit_clap_error(
                    f"Found argument '{a}' which wasn't expected, or isn't valid in this context",
                    cur_sub_usage(sub),
                )
            pos.append(a)
            i += 1
            continue

        if sub == "config-init":
            if a.startswith("-"):
                emit_clap_error(
                    f"Found argument '{a}' which wasn't expected, or isn't valid in this context",
                    cur_sub_usage("config-init"),
                )
            pos.append(a)
            i += 1
            continue

        pos.append(a)
        i += 1

    if opts.get("__help") or opts.get("__version"):
        return opts

    if sub == "list":
        if pos:
            emit_clap_error(
                f"Found argument '{pos[0]}' which wasn't expected, or isn't valid in this context",
                cur_sub_usage("list"),
            )
        return opts
    if sub == "add":
        if "alias" not in opts:
            emit_clap_error(
                "The following required arguments were not provided:\n    --alias <alias>",
                cur_sub_usage("add"),
            )
        if len(pos) > 1:
            emit_clap_error(
                f"Found argument '{pos[1]}' which wasn't expected, or isn't valid in this context",
                cur_sub_usage("add"),
            )
        if pos:
            opts["command"] = pos[0]
        return opts
    if sub == "remove":
        if not pos:
            emit_clap_error(
                "The following required arguments were not provided:\n    <alias>",
                cur_sub_usage("remove"),
            )
        if len(pos) > 1:
            emit_clap_error(
                f"Found argument '{pos[1]}' which wasn't expected, or isn't valid in this context",
                cur_sub_usage("remove"),
            )
        opts["alias"] = pos[0]
        return opts
    if sub == "show":
        if not pos:
            emit_clap_error(
                "The following required arguments were not provided:\n    <alias>",
                cur_sub_usage("show"),
            )
        if len(pos) > 1:
            emit_clap_error(
                f"Found argument '{pos[1]}' which wasn't expected, or isn't valid in this context",
                cur_sub_usage("show"),
            )
        opts["alias"] = pos[0]
        return opts
    if sub == "edit":
        if not pos:
            emit_clap_error(
                "The following required arguments were not provided:\n    <alias>",
                cur_sub_usage("edit"),
            )
        if len(pos) > 1:
            emit_clap_error(
                f"Found argument '{pos[1]}' which wasn't expected, or isn't valid in this context",
                cur_sub_usage("edit"),
            )
        opts["alias"] = pos[0]
        return opts
    if sub == "run":
        if not pos:
            emit_clap_error(
                "The following required arguments were not provided:\n    <alias>",
                cur_sub_usage("run"),
            )
        opts["alias"] = pos[0]
        opts["args"] = pos[1:]
        return opts
    if sub in ("move", "copy"):
        missing = []
        if len(pos) < 1:
            missing.append("<from-alias>")
        if len(pos) < 2:
            missing.append("<to-alias>")
        if missing:
            emit_clap_error(
                "The following required arguments were not provided:\n    " + "\n    ".join(missing),
                cur_sub_usage(sub),
            )
        if len(pos) > 2:
            emit_clap_error(
                f"Found argument '{pos[2]}' which wasn't expected, or isn't valid in this context",
                cur_sub_usage(sub),
            )
        opts["from"] = pos[0]
        opts["to"] = pos[1]
        return opts
    if sub == "config-init":
        if pos:
            emit_clap_error(
                f"Found argument '{pos[0]}' which wasn't expected, or isn't valid in this context",
                cur_sub_usage("config-init"),
            )
        return opts
    return opts


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except SystemExit:
        raise
    except KeyboardInterrupt:
        sys.exit(130)
    except BrokenPipeError:
        sys.exit(0)
