#!/bin/bash
# Statistical top-up: generate fresh, untested probes and compare.
B=/workspace/executable
M=/work/work/executable
PASS=0; FAIL=0; FAILS=""

T=/tmp/topup
rm -rf "$T" && mkdir -p "$T" && cd "$T"

cmp_run() {
    local name="$1"; shift
    local stdin="$1"; shift
    local b_out=$(mktemp) b_err=$(mktemp) m_out=$(mktemp) m_err=$(mktemp)
    "$B" "$@" <"$stdin" >"$b_out" 2>"$b_err"; b_ec=$?
    "$M" "$@" <"$stdin" >"$m_out" 2>"$m_err"; m_ec=$?
    local match=true
    [ "$b_ec" != "$m_ec" ] && match=false
    cmp -s "$b_out" "$m_out" || match=false
    cmp -s "$b_err" "$m_err" || match=false
    if $match; then
        PASS=$((PASS+1))
        echo "PASS $name"
    else
        FAIL=$((FAIL+1))
        echo "FAIL $name (B ec=$b_ec, M ec=$m_ec)"
        diff <(od -c "$b_out") <(od -c "$m_out") | head -8
        diff <(od -c "$b_err") <(od -c "$m_err") | head -8
    fi
    rm -f "$b_out" "$b_err" "$m_out" "$m_err"
}

# Generate 15 fresh probes covering discovered modes
P1=$(mktemp); printf 'The quick brown fox jumps over the lazy dog\n' > "$P1"
P2=$(mktemp); printf 'AAA bbb CCC ddd\n' > "$P2"
P3=$(mktemp); printf 'foo=1; bar=2; baz=3' > "$P3"
P4=$(mktemp); printf 'one\ntwo three\nfour\n' > "$P4"
P5=$(mktemp); python3 -c "import sys; sys.stdout.buffer.write(b'\\x00\\x01\\x02hello\\x03\\x04')" > "$P5"
P6=$(mktemp); printf '   leading and trailing   ' > "$P6"
P7=$(mktemp); printf 'line\r\nline\r\nlast' > "$P7"
P8=$(mktemp); printf 'aaaaaa' > "$P8"
P9=$(mktemp); python3 -c "print('hello' * 1000, end='')" > "$P9"
P10=$(mktemp); printf '' > "$P10"

cmp_run "tu-quick-brown"      "$P1" '(\w+) (\w+)' '$2 $1'
cmp_run "tu-uppercase-words"  "$P2" '[A-Z]+' '##'
cmp_run "tu-key-val"          "$P3" '(\w+)=(\d)' '${1}:${2}'
cmp_run "tu-multiline-line-prefix" "$P4" '^' '> '
cmp_run "tu-binary-null"      "$P5" 'hello' 'WORLD'
cmp_run "tu-trim-trailing"    "$P6" '\s+$' ''
cmp_run "tu-crlf"             "$P7" '\r' ''
cmp_run "tu-greedy-vs-lazy"   "$P8" 'a+?' 'b'
cmp_run "tu-large-input"      "$P9" 'l' 'X'
cmp_run "tu-empty-content"    "$P10" 'x' 'y'

# More edge cases
cmp_run "tu-flag-is-combined" "$P4" -f sw '(\w+) (\w+)' '$2 $1'
cmp_run "tu-F-empty-replace"  "$P1" -F 'lazy' ''
cmp_run "tu-named-with-flag"  "$P1" -f i '(?P<word>QUICK)' '<$word>'
cmp_run "tu-bk-bk"            "$P1" '\bthe\b' 'a'
cmp_run "tu-anchor-mid"       "$P4" -f e '^line' 'X'

# File errors
cmp_run "tu-missing-stdin-ignored-files-priority" "$P1" -p a b /tmp/doesnt-exist-xyz
cmp_run "tu-multi-stdin-empty" "$P10" -f i 'x' 'y'

# Hex / unescape corner
cmp_run "tu-hex-7f"           "$P1" T '\x7fY'
cmp_run "tu-hex-then-tab"     "$P1" T '\x41\tdone'
cmp_run "tu-bs-bs-bs"         "$P1" T '\\\\done'

# A regex compile error
cmp_run "tu-bad-regex"        "$P1" '++' '##'

# Limit edge cases
cmp_run "tu-n-zero-many"      "$P1" -n 0 'o' 'O'
cmp_run "tu-n-big"            "$P1" -n 999 'o' 'O'

# Help & version mixed with args
cmp_run "tu-help-after-bad"   "$P1" --bogus --help
cmp_run "tu-version-after-bad" "$P1" --bogus --version

echo
echo "TOPUP PASS=$PASS  FAIL=$FAIL"
