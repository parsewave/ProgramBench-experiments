# sd v1.0.0 — behavioral spec (recovered from black-box probing)

The reference is a Rust binary using clap 4.4.6 + regex 1.10.2 + memmap2 0.9 + tempfile 3.8.
Reimplementation uses the same crates (cached offline) for byte-perfect fidelity.

## CLI surface (clap)

```
sd v1.0.0                      <- header line; help_template "{name} v{version}"
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...
```

- name = "sd", version = "1.0.0", about = "An intuitive find & replace CLI"
- bin name in Usage = argv[0] basename (= "executable" at grading time)
- Custom help_template: `{name} v{version}\n{about-with-newline}\n{usage-heading} {usage}\n\n{all-args}{after-help}`

### Flags
- `-p, --preview`     bool, no multi-occurrence
- `-F, --fixed-strings` bool
- `-n, --max-replacements <LIMIT>` usize, default 0 (=unlimited)
- `-f, --flags <FLAGS>` Option<String>
- `-h, --help`, `-V, --version` (clap auto)

### Positionals
- `<FIND>` String, required
- `<REPLACE_WITH>` String, required
- `[FILES]...` Vec<PathBuf>, optional

### Arg help/long_help — full strings in goldens/help_long.txt, goldens/help_short.txt.
- FILES: short ≠ long (short has no period; long has period + "Note:" paragraph)
- `-f flags`: short = first paragraph WITH period; long adds the six "c -", "e -" ... paragraphs.
- Others: help == long_help.

## Process model
- One-shot: read all input, transform, write, exit. Not streaming.

## Replacer construction order (regex mode)
1. **Validate replacement for ambiguous `$N` references** (raw replace_with arg, before unescape).
2. **Wrap pattern with `\b...\b`** if `w` flag in `-f`.
3. Build `regex::bytes::RegexBuilder`:
   - default: `multi_line(true)` (THIS is `sd`'s key default — multiline ON)
   - iterate flags chars:
     - `c` → case_insensitive(false)
     - `i` → case_insensitive(true)
     - `e` → multi_line(false)        (only `e` controls multiline; `m` is no-op since default is on)
     - `s` → dot_matches_new_line(true)
     - `w` → already wrapped pattern (no builder effect here)
     - other chars (including `m`, `Q`, etc.) → SILENTLY IGNORED.
4. `.build()` → on err, return `Error::Regex`. Error display: `error: invalid regex {regex::Error display}`.
5. Unescape replacement (regex mode only).

### `-F` (literal) mode
- Pattern: `regex::escape(find)`. Then if `w`, wrap `\b...\b`.
- Replacement: used verbatim as bytes via `regex::bytes::NoExpand`. No unescape, no ambiguity check.
- Flags still apply (`-F -f i` → case-insensitive literal).

## Replacement unescape (regex mode)
- `\n` → 0x0A
- `\t` → 0x09
- `\r` → 0x0D
- `\\` → `\`
- `\xHH` → byte 0xHH **as a char** (UTF-8 encoded: e.g. `\xFF` → 2 bytes `c3 bf`).
  Quirk: when `\xHH` matches, **one additional char after the 2 hex digits is consumed and discarded** (if present).
  - `\x4Aq` → `J` (q consumed)
  - `\x414q` → `Aq` (`4` consumed after the hex pair)
  - `\x41` at EOS → `A` (no extra to consume)
- `\<anything else>` → `\` kept literal, anything else reprocessed (so `\d` → `\d`, `\0` → `\0`, `\a` → `\a`, `\u{41}` → `\u{41}`)
- trailing `\` → kept literal
- ASCII hex case insensitive (`\x4a` == `\x4A`).

## Ambiguity check (regex mode only)
Scan **raw** replace_with char-by-char. Maintain index `i`:
- `$` followed by `$` → consume both as `$$` escape, continue.
- `$` followed by `[0-9]`:
  - Collect maximal `[A-Za-z0-9_]+` run starting after the `$`.
  - Let `digits` = maximal `[0-9]+` prefix of the run.
  - If `run.len() > digits.len()` (i.e., run contains a non-digit) → **ambiguous**.
- `$` followed by anything else (incl. `{`, letter, `_`, eof) → consume just `$`, continue.

`\` is NOT special to the ambiguity scanner (so `\$1a` is still ambiguous on `$1a`).

### Ambiguity error message (4 lines, then `\n` from eprintln)
```
The numbered capture group `${digits}` in the replacement text is ambiguous.
hint: Use curly braces to disambiguate it `${{{digits}}}{rest}`.
{raw replacement string}
{spaces}{carets}
```
- spaces = char-offset of run start = char-index of `$` + 1.
- carets = `^` × char-length of the run (digits + rest).
- rest = run chars after the digit prefix.

`sd` then prints: `error: <Display>` and exits 1.

## Flag combinations & defaults
- multi_line default: TRUE (matches at line boundaries). `e` turns OFF.
- case_insensitive default: FALSE. `i` ON, `c` OFF (last-wins for case).
- dot_matches_new_line default: FALSE. `s` ON.
- `w` (word) wraps PATTERN as `\bPAT\b` (no group — alternation `a|b` becomes `\ba|b\b`).
- Unknown flag chars (incl `m`, `Q`, …) — silently ignored.

## Replacement application
- Use `Regex::replacen(haystack, limit, rep)`. `limit = max_replacements` (0 = all).
- Regex mode: rep = `&replacement_bytes` (does `$N` / `${N}` / `$name` / `$$` expansion via regex crate).
- Literal mode: rep = `regex::bytes::NoExpand(&replacement_bytes)`.

## Sources & output
- **No FILES**: read all stdin → bytes → replace → write to stdout. (`-p` has no effect here.)
- **FILES**:
  - **Pre-flight**: for each file in order, validate path & mmap:
    - `if !path.exists()` → `Error::InvalidPath(path)` → `error: invalid path: {path}`.
    - else `File::open(path)?` → propagate io::Error on EACCES etc.
    - else `unsafe { Mmap::map(&file) }?` → io::Error on dir / /dev/null → `error: No such device (os error 19)` etc.
    - empty regular file (`is_file() && len==0`) → treat as empty content (do not mmap).
    - **If any file fails, error out — NO files are written.**
  - **Without `-p`**: in-place write via tempfile in same dir, copy original perms, persist (rename). Inode changes; perms preserved.
  - **With `-p`**: write to stdout.
    - If files.len() > 1: precede each file's result with `----- FILE {path-as-given} -----\n`.
    - If files.len() == 1: just the result, no header.

## Error printing & exit codes
- Success → exit 0.
- clap parse errors (missing args, unknown flag, repeated flag, bad value) → clap prints to stderr → exit 2.
- `--help`/`-h` / `--version`/`-V` → clap prints to stdout → exit 0.
- All other `sd` errors → `eprintln!("error: {}", e);` exit 1.

### Error variants & Display
- `Regex(regex::Error)` → `invalid regex {regex::Error display}`  
  (regex parse error format includes pattern visualization with `^`)
- `InvalidPath(PathBuf)` → `invalid path: {path-as-given}`
- `AmbiguousReplace { ... }` → multi-line as above
- `Io(io::Error)` → `{io::Error display}` (e.g. `Permission denied (os error 13)`, `No such device (os error 19)`)

## Notable behaviors
- Stdout is bytes-exact; no trailing-newline addition.
- File rewrite happens even when no match (inode changes, content same).
- Permissions of original file are preserved on in-place writes (probed 754 → 754).
- Can rewrite read-only files (temp+rename trusts dir permission).
- Binary/invalid-UTF-8 file content is handled fine (`regex::bytes::Regex`, default Unicode mode on; ASCII patterns match within invalid sequences without erroring).
- Pattern arg (FIND) must be valid UTF-8 (clap String parse), else clap error.
- Determinism: identical inputs → identical outputs.
