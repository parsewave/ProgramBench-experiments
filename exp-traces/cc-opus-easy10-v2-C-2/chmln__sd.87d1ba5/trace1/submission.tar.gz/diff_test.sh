#!/bin/bash
# Differential harness: run a probe against B (reference) and M (mine), compare exit + stdout + stderr.
B=/workspace/executable
M=/work/work/executable
PASS=0
FAIL=0
FAILS=""

run_case() {
    local name="$1"; shift
    local stdin_file="$1"; shift
    # remaining args are the args to pass to the binary
    local b_out b_err b_ec m_out m_err m_ec
    b_out=$(mktemp); b_err=$(mktemp); m_out=$(mktemp); m_err=$(mktemp)
    if [ "$stdin_file" = "-" ]; then
        "$B" "$@" >"$b_out" 2>"$b_err"; b_ec=$?
        "$M" "$@" >"$m_out" 2>"$m_err"; m_ec=$?
    else
        "$B" "$@" <"$stdin_file" >"$b_out" 2>"$b_err"; b_ec=$?
        "$M" "$@" <"$stdin_file" >"$m_out" 2>"$m_err"; m_ec=$?
    fi
    local match=true
    [ "$b_ec" != "$m_ec" ] && match=false
    cmp -s "$b_out" "$m_out" || match=false
    cmp -s "$b_err" "$m_err" || match=false
    if $match; then
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
        FAILS="$FAILS
=== $name ===
B exit=$b_ec  M exit=$m_ec
B stdout: $(od -c "$b_out" | head -3)
M stdout: $(od -c "$m_out" | head -3)
B stderr: $(od -c "$b_err" | head -3)
M stderr: $(od -c "$m_err" | head -3)"
    fi
    rm -f "$b_out" "$b_err" "$m_out" "$m_err"
}

# Create staging dir + sample files
T=/tmp/diff_test
rm -rf "$T" && mkdir -p "$T"
cd "$T"

# stdin samples
EMPTY=$(mktemp); : >"$EMPTY"
HELLO=$(mktemp); printf 'hello world\n' >"$HELLO"
MULTI=$(mktemp); printf 'line1\nline2\nline3\n' >"$MULTI"
NUMS=$(mktemp); printf 'a1b22c333\n' >"$NUMS"
DIGITS=$(mktemp); printf '2024-01-02\n' >"$DIGITS"
BIN=$(mktemp); python3 -c "import sys; sys.stdout.buffer.write(b'\xff\xfe x \xc0\xc0\n')" >"$BIN"
UNI=$(mktemp); python3 -c "import sys;sys.stdout.buffer.write('café é'.encode())" >"$UNI"
NONL=$(mktemp); printf 'abc' >"$NONL"

# --- meta ---
run_case "version-long" "-" --version
run_case "version-short" "-" -V
run_case "help-short" "-" -h
run_case "help-long" "-" --help
run_case "help-precedes-error" "-" --help nonsense
run_case "version-precedes-help" "-" --version --help

# --- arg parsing errors ---
run_case "no-args" "-"
run_case "one-arg" "-" foo
run_case "bogus-long" "-" --bogus
run_case "bogus-short" "-" -x
run_case "n-neg" "$HELLO" -n -1 a X
run_case "n-bad" "$HELLO" -n abc a X
run_case "n-huge" "$HELLO" -n 99999999999999999999999 a X
run_case "double-p" "$HELLO" -p -p a X
run_case "double-F" "$HELLO" -F -F a X
run_case "double-f" "$HELLO" -f i -f c a X
run_case "double-n" "$HELLO" -n 1 -n 2 a X
run_case "missing-only-flags" "-" -p foo

# --- basic stdin ---
run_case "basic" "$HELLO" hello bye
run_case "no-match" "$HELLO" zzzz QQQQ
run_case "empty-stdin" "$EMPTY" a b
run_case "no-trailing-nl" "$NONL" b X
run_case "regex-digits" "$NUMS" '\d+' N
run_case "capture-3" "$DIGITS" '(\d+)-(\d+)-(\d+)' '$3/$2/$1'
DOL=$(mktemp); printf '123.45' >"$DOL"
run_case "named-cap" "$DOL" '(?P<d>\d+)\.(?P<c>\d+)' '$d dollars $c cents'

# --- $ expansion ---
PROBE1=$(mktemp); printf 'foo' >"$PROBE1"
run_case "dollar-dollar" "$PROBE1" 'foo' '$$bar'
PROBE2=$(mktemp); printf 'a1' >"$PROBE2"
run_case "dollar-end" "$PROBE2" '(\d)' 'pq$'
run_case "dollar-bad-name" "$PROBE2" '(\d)' 'p$q'
run_case "dollar-brace" "$PROBE2" '(?P<x>\d)' 'p${x}q'
run_case "dollar-brace-num" "$PROBE2" '(\d)' '${1}abc'

# --- ambiguity ---
run_case "amb-1word" "$PROBE2" '(\d)' 'p$1xq'
run_case "amb-12word" "$PROBE2" '(\d)' 'p$12q'
run_case "amb-end" "$PROBE2" '(\d)' '$1abc'
run_case "amb-middle" "$PROBE2" '(\d)' 'pre$1abc post'
run_case "amb-0word" "$PROBE2" '(\d)' '$0z'
run_case "amb-underscore" "$PROBE2" '(\d)' '$1_q'
run_case "amb-dash-ok" "$PROBE2" '(\d)' '$1-q'
run_case "amb-space-ok" "$PROBE2" '(\d)' '$1 q'
run_case "amb-dollar-escape" "$PROBE2" '(\d)' 'p$$1q'
run_case "amb-multibyte-before" "$PROBE2" '(.)' 'héllo$1abc'
run_case "amb-after-unescape" "$PROBE2" '(.)' 'x\t$1a'
run_case "amb-backslash-prefix" "$PROBE2" '(.)' 'v\$1a'
run_case "amb-regex-loses" "$PROBE2" '(' '$1a'

# --- escapes ---
run_case "esc-n" "$HELLO" o '<\n>'
run_case "esc-t" "$HELLO" o '<\t>'
run_case "esc-r" "$HELLO" o '<\r>'
run_case "esc-bs" "$HELLO" o '<\\>'
run_case "esc-d-noop" "$HELLO" o '\d'
run_case "esc-x41" "$HELLO" o '<\x41>'
run_case "esc-xff" "$HELLO" o '<\xffX>'
run_case "esc-x80" "$HELLO" o '<\x80X>'
run_case "esc-x-bad" "$HELLO" o '\xZZ'
run_case "esc-x-1digit" "$HELLO" o '\x4q'
run_case "esc-x-alone" "$HELLO" o '\x'
run_case "esc-trailing-bs" "$HELLO" o '<\>'
run_case "esc-x-eats-bs" "$HELLO" o 'p\x41\n'
run_case "esc-x-eats-dollar" "$PROBE2" '(.)' 'p\x41$1'

# --- -F mode ---
LITS=$(mktemp); printf 'a.b' >"$LITS"
run_case "F-dot" "$LITS" -F '.' '#'
run_case "F-literal-dollar" "$PROBE1" -F 'foo' '$$bar'
run_case "F-literal-bs" "$HELLO" -F 'o' '\n'
run_case "F-with-i" "$HELLO" -F -f i 'HELLO' 'X'
CATF=$(mktemp); printf 'catfish cat' >"$CATF"
run_case "F-with-w" "$CATF" -F -f w 'cat' Z
run_case "F-empty-find" "$HELLO" -F '' X

# --- regex flags ---
ABC=$(mktemp); printf 'abc' >"$ABC"
run_case "flag-i" "$ABC" -f i 'ABC' z
run_case "flag-c-after-i" "$ABC" -f ic 'ABC' z
run_case "flag-i-after-c" "$ABC" -f ci 'ABC' z
run_case "flag-s" "$MULTI" -f s 'line1.line2' SQUASHED
run_case "flag-m-noop-multiline-on" "$MULTI" -f m '^' '>'
run_case "flag-e-disable-multi" "$MULTI" -f e '^' '>'
run_case "flag-em" "$MULTI" -f em '^' '>'
run_case "flag-me" "$MULTI" -f me '^' '>'
CDC=$(mktemp); printf 'cat dog catfish doggone' >"$CDC"
run_case "flag-w-alt" "$CDC" -f w 'cat|dog' Z
run_case "flag-bad-Q" "$HELLO" -f Q 'h' z
run_case "flag-empty" "$HELLO" -f '' 'h' z
run_case "default-caret-multiline" "$MULTI" '^' '>'
run_case "default-dollar-multiline" "$MULTI" '$' '<'

# --- -n ---
AA=$(mktemp); printf 'a a a a\n' >"$AA"
run_case "n-1" "$AA" -n 1 a X
run_case "n-2" "$AA" -n 2 a X
run_case "n-0" "$AA" -n 0 a X
run_case "n-many" "$AA" -n 1000 a X
run_case "n-attached" "$AA" -n2 a X
run_case "n-eq" "$AA" --max-replacements=2 a X

# --- preview ---
F1=$(mktemp -p . XXXXX.txt)
F2=$(mktemp -p . XXXXX.txt)
F3=$(mktemp -p . XXXXX.txt)
printf 'cat\n' >"$F1"
printf 'cat\n' >"$F2"
printf 'cat\n' >"$F3"
run_case "preview-1file" "-" -p cat DOG "$F1"
# Reset files for next test
printf 'cat\n' >"$F1"; printf 'cat\n' >"$F2"
run_case "preview-2files" "-" -p cat DOG "$F1" "$F2"
printf 'cat\n' >"$F1"; printf 'cat\n' >"$F2"; printf 'cat\n' >"$F3"
run_case "preview-3files" "-" -p cat DOG "$F1" "$F2" "$F3"
NONL2=$(mktemp -p . XXXXX.txt)
NONL3=$(mktemp -p . XXXXX.txt)
printf 'cat' >"$NONL2"; printf 'cat' >"$NONL3"
run_case "preview-nonl-1" "-" -p cat DOG "$NONL2"
printf 'cat' >"$NONL2"; printf 'cat' >"$NONL3"
run_case "preview-nonl-2" "-" -p cat DOG "$NONL2" "$NONL3"
run_case "preview-stdin" "$HELLO" -p o O

# --- files in-place: do separately so we can re-init each time (capture stdout+stderr+exit only) ---
# We re-init each file for both runs since they modify content.
# To check in-place properly we need to also compare resulting file content. Do it manually below.

# --- file errors ---
run_case "missing-file" "-" a b /nonexistent/zzz.txt
run_case "dash-as-file" "-" l L -
run_case "dir-as-file" "-" a b /tmp
run_case "devnull-as-file" "-" a b /dev/null
run_case "preview-missing-file" "-" -p a b /nonexistent/zzz.txt

# --- binary / unicode ---
run_case "stdin-binary" "$BIN" x Y
run_case "stdin-unicode" "$UNI" 'é' E
CAFE=$(mktemp); printf 'café' >"$CAFE"
run_case "stdin-unicode-dot" "$CAFE" '.' X

# --- edge: regex compile errors ---
run_case "regex-unclosed-group" "$HELLO" '(' z
run_case "regex-unclosed-class" "$HELLO" '[a' z
run_case "regex-bad-quantifier" "$HELLO" '*' z
run_case "empty-pattern" "$NONL" '' X

# --- arg parsing: -- and -- ---
DD=$(mktemp); printf './x foo' >"$DD"
run_case "double-dash" "$DD" -- foo -w
run_case "dashflag-after-pos" "$AA" a X -n 1

echo
echo "================="
echo "PASS: $PASS  FAIL: $FAIL"
echo "================="
if [ "$FAIL" -gt 0 ]; then
    echo "$FAILS" | head -200
fi
