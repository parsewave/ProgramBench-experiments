use clap::Parser;
use memmap2::Mmap;
use std::fs::{self, File};
use std::io::{BufWriter, Read, Write, stdin, stdout};
use std::path::{Path, PathBuf};
use std::process::ExitCode;

#[derive(Parser, Debug)]
#[command(
    name = "sd",
    version = "1.0.0",
    about = "An intuitive find & replace CLI",
    help_template = "{name} v{version}\n{about-with-newline}\n{usage-heading} {usage}\n\n{all-args}{after-help}"
)]
struct Options {
    #[arg(
        short = 'p',
        long,
        help = "Display changes in a human reviewable format (the specifics of the format are likely to change in the future)"
    )]
    preview: bool,

    #[arg(
        short = 'F',
        long,
        help = "Treat FIND and REPLACE_WITH args as literal strings"
    )]
    fixed_strings: bool,

    #[arg(
        short = 'n',
        long,
        value_name = "LIMIT",
        default_value_t = 0usize,
        help = "Limit the number of replacements that can occur per file. 0 indicates unlimited replacements"
    )]
    max_replacements: usize,

    #[arg(
        short = 'f',
        long,
        help = "Regex flags. May be combined (like `-f mc`).",
        long_help = "Regex flags. May be combined (like `-f mc`).\n\nc - case-sensitive\n\ne - disable multi-line matching\n\ni - case-insensitive\n\nm - multi-line matching\n\ns - make `.` match newlines\n\nw - match full words only"
    )]
    flags: Option<String>,

    #[arg(help = "The regexp or string (if using `-F`) to search for")]
    find: String,

    #[arg(
        help = "What to replace each match with. Unless in string mode, you may use captured values like $1, $2, etc"
    )]
    replace_with: String,

    #[arg(
        help = "The path to file(s). This is optional - sd can also read from STDIN",
        long_help = "The path to file(s). This is optional - sd can also read from STDIN.\n\nNote: sd modifies files in-place by default. See documentation for examples."
    )]
    files: Vec<PathBuf>,
}

#[derive(Debug)]
enum Error {
    Regex(regex::Error),
    InvalidPath(PathBuf),
    AmbiguousReplace {
        replacement: String,
        digits: String,
        rest: String,
        run_start: usize,
        run_len: usize,
    },
    Io(std::io::Error),
}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e)
    }
}

impl From<regex::Error> for Error {
    fn from(e: regex::Error) -> Self {
        Error::Regex(e)
    }
}

impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Error::Regex(e) => write!(f, "invalid regex {}", e),
            Error::InvalidPath(p) => write!(f, "invalid path: {}", p.display()),
            Error::AmbiguousReplace {
                replacement,
                digits,
                rest,
                run_start,
                run_len,
            } => {
                write!(
                    f,
                    "The numbered capture group `${}` in the replacement text is ambiguous.\nhint: Use curly braces to disambiguate it `${{{}}}{}`.\n{}\n{}{}",
                    digits,
                    digits,
                    rest,
                    replacement,
                    " ".repeat(*run_start),
                    "^".repeat(*run_len)
                )
            }
            Error::Io(e) => write!(f, "{}", e),
        }
    }
}

fn is_word_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

fn validate_replace(replacement: &str) -> Result<(), Error> {
    let chars: Vec<char> = replacement.chars().collect();
    let n = chars.len();
    let mut i = 0;
    while i < n {
        if chars[i] == '$' {
            // $$ -> escape, skip both
            if i + 1 < n && chars[i + 1] == '$' {
                i += 2;
                continue;
            }
            // $<digit> -> may be ambiguous
            if i + 1 < n && chars[i + 1].is_ascii_digit() {
                let run_start = i + 1;
                let mut j = run_start;
                while j < n && is_word_char(chars[j]) {
                    j += 1;
                }
                let mut digit_end = run_start;
                while digit_end < j && chars[digit_end].is_ascii_digit() {
                    digit_end += 1;
                }
                if digit_end < j {
                    let digits: String = chars[run_start..digit_end].iter().collect();
                    let rest: String = chars[digit_end..j].iter().collect();
                    return Err(Error::AmbiguousReplace {
                        replacement: replacement.to_string(),
                        digits,
                        rest,
                        run_start,
                        run_len: j - run_start,
                    });
                }
                i = j;
                continue;
            }
            i += 1;
        } else {
            i += 1;
        }
    }
    Ok(())
}

fn unescape(s: &str) -> String {
    let chars: Vec<char> = s.chars().collect();
    let n = chars.len();
    let mut out = String::with_capacity(s.len());
    let mut i = 0;
    while i < n {
        if chars[i] == '\\' && i + 1 < n {
            match chars[i + 1] {
                'n' => {
                    out.push('\n');
                    i += 2;
                }
                't' => {
                    out.push('\t');
                    i += 2;
                }
                'r' => {
                    out.push('\r');
                    i += 2;
                }
                '\\' => {
                    out.push('\\');
                    i += 2;
                }
                'x' => {
                    if i + 3 < n
                        && chars[i + 2].is_ascii_hexdigit()
                        && chars[i + 3].is_ascii_hexdigit()
                    {
                        let hex: String = [chars[i + 2], chars[i + 3]].iter().collect();
                        let byte = u8::from_str_radix(&hex, 16).unwrap();
                        out.push(byte as char);
                        i += 4;
                        if i < n {
                            i += 1; // discard one extra char (sd quirk)
                        }
                    } else {
                        out.push('\\');
                        i += 1;
                    }
                }
                _ => {
                    out.push('\\');
                    i += 1;
                }
            }
        } else {
            out.push(chars[i]);
            i += 1;
        }
    }
    out
}

struct Replacer {
    regex: regex::bytes::Regex,
    replace_with: Vec<u8>,
    is_literal: bool,
    limit: usize,
}

impl Replacer {
    fn new(
        look_for: String,
        replace_with: String,
        is_literal: bool,
        flags: Option<&str>,
        limit: usize,
    ) -> Result<Self, Error> {
        if !is_literal {
            validate_replace(&replace_with)?;
        }

        let mut pattern = if is_literal {
            regex::escape(&look_for)
        } else {
            look_for
        };

        let flags_str = flags.unwrap_or("");
        if flags_str.contains('w') {
            pattern = format!(r"\b{}\b", pattern);
        }

        let mut builder = regex::bytes::RegexBuilder::new(&pattern);
        builder.multi_line(true);
        for c in flags_str.chars() {
            match c {
                'c' => {
                    builder.case_insensitive(false);
                }
                'i' => {
                    builder.case_insensitive(true);
                }
                'e' => {
                    builder.multi_line(false);
                }
                's' => {
                    builder.dot_matches_new_line(true);
                }
                _ => {} // 'w' (already handled), 'm', and any unknown char: silently ignored
            }
        }
        let regex = builder.build()?;

        let replace_with_bytes = if is_literal {
            replace_with.into_bytes()
        } else {
            unescape(&replace_with).into_bytes()
        };

        Ok(Replacer {
            regex,
            replace_with: replace_with_bytes,
            is_literal,
            limit,
        })
    }

    fn replace(&self, content: &[u8]) -> Vec<u8> {
        if self.is_literal {
            self.regex
                .replacen(
                    content,
                    self.limit,
                    regex::bytes::NoExpand(&self.replace_with),
                )
                .into_owned()
        } else {
            self.regex
                .replacen(content, self.limit, &self.replace_with[..])
                .into_owned()
        }
    }
}

fn read_file(path: &Path) -> Result<Vec<u8>, Error> {
    if !path.exists() {
        return Err(Error::InvalidPath(path.to_path_buf()));
    }
    let file = File::open(path)?;
    let meta = file.metadata()?;
    if meta.is_file() && meta.len() == 0 {
        return Ok(Vec::new());
    }
    let mmap = unsafe { Mmap::map(&file)? };
    Ok(mmap.to_vec())
}

fn write_inplace(path: &Path, content: &[u8]) -> Result<(), Error> {
    let dir = path
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."));
    let mut tmp = tempfile::NamedTempFile::new_in(dir)?;
    tmp.write_all(content)?;
    tmp.flush()?;
    if let Ok(meta) = fs::metadata(path) {
        let _ = fs::set_permissions(tmp.path(), meta.permissions());
    }
    tmp.persist(path).map_err(|e| Error::Io(e.error))?;
    Ok(())
}

fn run(opts: Options) -> Result<(), Error> {
    let replacer = Replacer::new(
        opts.find,
        opts.replace_with,
        opts.fixed_strings,
        opts.flags.as_deref(),
        opts.max_replacements,
    )?;

    if opts.files.is_empty() {
        let mut buf = Vec::new();
        stdin().read_to_end(&mut buf)?;
        let result = replacer.replace(&buf);
        let stdout_handle = stdout();
        let mut out = BufWriter::new(stdout_handle.lock());
        out.write_all(&result)?;
        out.flush()?;
    } else {
        let mut contents: Vec<Vec<u8>> = Vec::with_capacity(opts.files.len());
        for path in &opts.files {
            contents.push(read_file(path)?);
        }
        let results: Vec<Vec<u8>> = contents.iter().map(|c| replacer.replace(c)).collect();

        if opts.preview {
            let multi = opts.files.len() > 1;
            let stdout_handle = stdout();
            let mut out = BufWriter::new(stdout_handle.lock());
            for (path, result) in opts.files.iter().zip(results.iter()) {
                if multi {
                    writeln!(out, "----- FILE {} -----", path.display())?;
                }
                out.write_all(result)?;
            }
            out.flush()?;
        } else {
            for (path, result) in opts.files.iter().zip(results.iter()) {
                write_inplace(path, result)?;
            }
        }
    }
    Ok(())
}

fn main() -> ExitCode {
    let opts = Options::parse();
    match run(opts) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {}", e);
            ExitCode::FAILURE
        }
    }
}
