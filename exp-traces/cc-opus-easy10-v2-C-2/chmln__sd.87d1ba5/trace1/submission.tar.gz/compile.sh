#!/bin/bash
set -e
cd "$(dirname "$0")"
export CARGO_HOME=/usr/local/cargo
export RUSTUP_HOME=/usr/local/rustup
export PATH="/usr/local/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin:$PATH"
cargo build --release --offline
cp target/release/executable ./executable
