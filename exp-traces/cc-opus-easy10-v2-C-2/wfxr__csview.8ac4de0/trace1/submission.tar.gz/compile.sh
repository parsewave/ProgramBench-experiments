#!/bin/bash
set -e
cd "$(dirname "$0")"
# Create an executable wrapper that runs the Python script
cat > executable <<'EOF'
#!/usr/bin/env python3
import sys
import os
script = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'csview.py')
os.execvp(sys.executable, [sys.executable, script] + sys.argv[1:])
EOF
chmod +x executable csview.py
