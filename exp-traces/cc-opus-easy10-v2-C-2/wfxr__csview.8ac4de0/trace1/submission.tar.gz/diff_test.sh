#!/bin/bash
# Run all frames against my reimplementation, compare with reference output.
set -u
REF=/workspace/executable
SUT=/work/work/executable
FRAMES=/work/work/frames.jsonl

pass=0
fail=0
fail_names=()

while IFS= read -r line; do
    name=$(python3 -c "import json,sys; print(json.loads(sys.argv[1])['name'])" "$line")
    args=$(python3 -c "import json,sys; print(json.dumps(json.loads(sys.argv[1])['args']))" "$line")
    stdin=$(python3 -c "import json,sys; d=json.loads(sys.argv[1]); print(d['stdin'] if d['stdin'] else '')" "$line")
    has_stdin=$(python3 -c "import json,sys; d=json.loads(sys.argv[1]); print('1' if d['stdin'] else '0')" "$line")
    expected_stdout=$(python3 -c "import json,sys; print(json.loads(sys.argv[1])['stdout'])" "$line")
    expected_stderr=$(python3 -c "import json,sys; print(json.loads(sys.argv[1])['stderr'])" "$line")
    expected_exit=$(python3 -c "import json,sys; print(json.loads(sys.argv[1])['exit'])" "$line")

    args_array=$(python3 -c "import json,sys,shlex; print(' '.join(shlex.quote(a) for a in json.loads(sys.argv[1])))" "$args")

    # Run SUT
    if [ "$has_stdin" = "1" ]; then
        actual_stdout=$(echo -n "$stdin" | eval "$SUT $args_array" 2>/tmp/sut_stderr_$$)
    else
        actual_stdout=$(eval "$SUT $args_array" 2>/tmp/sut_stderr_$$ </dev/null)
    fi
    actual_exit=$?
    actual_stderr=$(cat /tmp/sut_stderr_$$)
    rm -f /tmp/sut_stderr_$$

    pass_this=1
    if [ "$actual_stdout" != "$expected_stdout" ]; then
        pass_this=0
    fi
    if [ "$actual_stderr" != "$expected_stderr" ]; then
        pass_this=0
    fi
    if [ "$actual_exit" != "$expected_exit" ]; then
        pass_this=0
    fi

    if [ $pass_this -eq 1 ]; then
        pass=$((pass+1))
    else
        fail=$((fail+1))
        fail_names+=("$name")
    fi
done < "$FRAMES"

echo "Pass: $pass"
echo "Fail: $fail"
echo ""
if [ $fail -gt 0 ]; then
    echo "Failed tests:"
    for n in "${fail_names[@]}"; do
        echo "  $n"
    done
fi
