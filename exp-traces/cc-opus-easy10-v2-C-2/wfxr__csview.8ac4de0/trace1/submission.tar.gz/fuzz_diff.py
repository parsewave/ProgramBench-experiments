#!/usr/bin/env python3
"""Fuzz-style differential testing."""
import subprocess
import random
import string
import sys

REF = "/workspace/executable"
SUT = "/work/work/executable"


def run(binary, args, stdin_bytes=None, timeout=10):
    try:
        p = subprocess.run([binary] + args, input=stdin_bytes, capture_output=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"<TIMEOUT>", b""


def shrink(args, stdin):
    """Try to shrink the failing case."""
    # Try removing each arg
    for i in range(len(args)):
        new_args = args[:i] + args[i+1:]
        try:
            rc_r, so_r, se_r = run(REF, new_args, stdin)
            rc_s, so_s, se_s = run(SUT, new_args, stdin)
            if rc_r != rc_s or so_r != so_s or se_r != se_s:
                return shrink(new_args, stdin)
        except Exception:
            pass
    # Try halving stdin
    if stdin and len(stdin) > 10:
        half = stdin[:len(stdin)//2]
        try:
            rc_r, so_r, se_r = run(REF, args, half)
            rc_s, so_s, se_s = run(SUT, args, half)
            if rc_r != rc_s or so_r != so_s or se_r != se_s:
                return shrink(args, half)
        except Exception:
            pass
    return args, stdin


def gen_test(rng):
    args = []
    if rng.random() < 0.5:
        args.extend(['-s', rng.choice(['none', 'ascii', 'ascii2', 'sharp', 'rounded', 'reinforced', 'markdown', 'grid'])])
    if rng.random() < 0.3:
        args.extend(['-p', str(rng.randint(0, 5))])
    if rng.random() < 0.3:
        args.extend(['-i', str(rng.randint(0, 8))])
    if rng.random() < 0.3:
        args.append('-H')
    if rng.random() < 0.3:
        args.append('-n')
    if rng.random() < 0.3:
        args.extend(['--header-align', rng.choice(['left', 'center', 'right'])])
    if rng.random() < 0.3:
        args.extend(['--body-align', rng.choice(['left', 'center', 'right'])])
    if rng.random() < 0.2:
        args.extend(['--sniff', str(rng.randint(0, 5))])

    rows = rng.randint(1, 8)
    cols = rng.randint(1, 5)
    alphabet_choices = [
        string.ascii_letters,
        string.digits,
        string.printable,
        'abcde123 ',
        'abc日本語',
        '日本',
        '😀😁',
        '',
    ]
    lines = []
    for r in range(rows):
        line = []
        for c in range(cols):
            alphabet = rng.choice(alphabet_choices)
            length = rng.randint(0, 8)
            field = ''.join(rng.choice(alphabet) for _ in range(length)) if alphabet else ''
            # Quote if needed
            if ',' in field or '\n' in field or '"' in field:
                field = '"' + field.replace('"', '""') + '"'
            line.append(field)
        lines.append(','.join(line))
    stdin = ('\n'.join(lines) + '\n').encode('utf-8', errors='replace')
    return args, stdin


def main():
    seed = 1
    if len(sys.argv) > 1:
        seed = int(sys.argv[1])
    rng = random.Random(seed)
    n_tests = 200
    if len(sys.argv) > 2:
        n_tests = int(sys.argv[2])
    pass_count = 0
    fail_count = 0
    failures = []
    for i in range(n_tests):
        args, stdin = gen_test(rng)
        rc_r, so_r, se_r = run(REF, args, stdin)
        rc_s, so_s, se_s = run(SUT, args, stdin)
        ok = rc_r == rc_s and so_r == so_s and se_r == se_s
        if ok:
            pass_count += 1
        else:
            fail_count += 1
            failures.append((args, stdin, (rc_r, so_r, se_r), (rc_s, so_s, se_s)))

    print(f"Pass: {pass_count}")
    print(f"Fail: {fail_count}")
    for args, stdin, ref, sut in failures[:5]:
        print()
        print("=== Failure ===")
        print(f"args: {args}")
        print(f"stdin: {stdin!r}")
        rc_r, so_r, se_r = ref
        rc_s, so_s, se_s = sut
        if rc_r != rc_s:
            print(f"exit ref={rc_r} sut={rc_s}")
        if so_r != so_s:
            print(f"stdout differ")
            print(f"  REF: {so_r!r}")
            print(f"  SUT: {so_s!r}")
        if se_r != se_s:
            print(f"stderr differ")
            print(f"  REF: {se_r!r}")
            print(f"  SUT: {se_s!r}")
        # Shrink
        try:
            s_args, s_stdin = shrink(list(args), stdin)
            print(f"shrunk args: {s_args}")
            print(f"shrunk stdin: {s_stdin!r}")
        except Exception as e:
            print(f"shrink failed: {e}")


if __name__ == '__main__':
    main()
