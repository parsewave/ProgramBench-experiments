#!/usr/bin/env python3
import sys
import os
import io
import unicodedata


HELP_TEXT = """A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version
"""

VERSION_TEXT = "csview 1.3.4\n"


STYLES = {
    'sharp': {
        'top':    ('┌', '─', '┬', '┐'),
        'mid':    ('├', '─', '┼', '┤'),
        'bot':    ('└', '─', '┴', '┘'),
        'row':    ('│', '│', '│'),
        'has_top': True, 'has_bot': True, 'has_hdr_sep': True, 'has_body_sep': False,
    },
    'rounded': {
        'top':    ('╭', '─', '┬', '╮'),
        'mid':    ('├', '─', '┼', '┤'),
        'bot':    ('╰', '─', '┴', '╯'),
        'row':    ('│', '│', '│'),
        'has_top': True, 'has_bot': True, 'has_hdr_sep': True, 'has_body_sep': False,
    },
    'reinforced': {
        'top':    ('┏', '─', '┬', '┓'),
        'mid':    ('├', '─', '┼', '┤'),
        'bot':    ('┗', '─', '┴', '┛'),
        'row':    ('│', '│', '│'),
        'has_top': True, 'has_bot': True, 'has_hdr_sep': True, 'has_body_sep': False,
    },
    'grid': {
        'top':    ('┌', '─', '┬', '┐'),
        'mid':    ('├', '─', '┼', '┤'),
        'bot':    ('└', '─', '┴', '┘'),
        'row':    ('│', '│', '│'),
        'has_top': True, 'has_bot': True, 'has_hdr_sep': True, 'has_body_sep': True,
    },
    'ascii': {
        'top':    ('+', '-', '+', '+'),
        'mid':    ('+', '-', '+', '+'),
        'bot':    ('+', '-', '+', '+'),
        'row':    ('|', '|', '|'),
        'has_top': True, 'has_bot': True, 'has_hdr_sep': True, 'has_body_sep': False,
    },
    'ascii2': {
        'top':    None,
        'mid':    (' ', '-', '+', ' '),
        'bot':    None,
        'row':    (' ', '|', ' '),
        'has_top': False, 'has_bot': False, 'has_hdr_sep': True, 'has_body_sep': False,
    },
    'markdown': {
        'top':    None,
        'mid':    ('|', '-', '|', '|'),
        'bot':    None,
        'row':    ('|', '|', '|'),
        'has_top': False, 'has_bot': False, 'has_hdr_sep': True, 'has_body_sep': False,
    },
    'none': {
        'top':    None,
        'mid':    None,
        'bot':    None,
        'row':    ('', '', ''),
        'has_top': False, 'has_bot': False, 'has_hdr_sep': False, 'has_body_sep': False,
    },
}

STYLE_VALUES = ['none', 'ascii', 'ascii2', 'sharp', 'rounded', 'reinforced', 'markdown', 'grid']
ALIGN_VALUES = ['left', 'center', 'right']


# Emoji bases that get emoji presentation with VS16
EMOJI_BASES = set([0x23, 0x2A])
for c in range(0x30, 0x3A):
    EMOJI_BASES.add(c)
EMOJI_BASES.update([0xA9, 0xAE])
EMOJI_BASES.update([
    0x203C, 0x2049, 0x2122, 0x2139,
    0x2194, 0x2195, 0x2196, 0x2197, 0x2198, 0x2199,
    0x21A9, 0x21AA,
    0x2328, 0x23CF,
    0x23ED, 0x23EE, 0x23EF, 0x23F1, 0x23F2, 0x23F8, 0x23F9, 0x23FA,
    0x24C2,
    0x25AA, 0x25AB, 0x25B6, 0x25C0, 0x25FB, 0x25FC,
    0x2600, 0x2601, 0x2602, 0x2603, 0x2604,
    0x260E, 0x2611, 0x2618, 0x261D, 0x2620, 0x2622, 0x2623, 0x2626,
    0x262A, 0x262E, 0x262F,
    0x2638, 0x2639, 0x263A,
    0x2640, 0x2642,
    0x265F, 0x2660, 0x2663, 0x2665, 0x2666, 0x2668, 0x267B, 0x267E,
    0x2692, 0x2694, 0x2695, 0x2696, 0x2697, 0x2699,
    0x269B, 0x269C,
    0x26A0, 0x26A7, 0x26B0, 0x26B1, 0x26C8, 0x26CF, 0x26D1, 0x26D3, 0x26D4,
    0x26E9, 0x26F0, 0x26F1, 0x26F4, 0x26F7, 0x26F8, 0x26F9,
    0x2702, 0x2708, 0x2709, 0x270C, 0x270D, 0x270F, 0x2712, 0x2714, 0x2716, 0x271D,
    0x2721, 0x2733, 0x2734, 0x2744, 0x2747, 0x2763, 0x2764,
    0x27A1,
    0x2934, 0x2935, 0x2B05, 0x2B06, 0x2B07,
    0x3030, 0x303D, 0x3297, 0x3299,
])

ZWJ = '‍'
VS16 = '️'


def char_width(c):
    cp = ord(c)
    if cp == 0x200D:
        return 0
    cat = unicodedata.category(c)
    if cat in ('Mn', 'Mc', 'Me'):
        return 0
    if cat == 'Cf':
        return 0
    eaw = unicodedata.east_asian_width(c)
    if eaw in ('W', 'F'):
        return 2
    return 1


def is_skin_tone(c):
    return 0x1F3FB <= ord(c) <= 0x1F3FF


def text_width(s):
    if not s:
        return 0
    chars = list(s)
    n = len(chars)
    width = 0
    i = 0
    while i < n:
        c = chars[i]
        # \r\n paired - count as 1 (csv-line-ending convention)
        if c == '\r' and i + 1 < n and chars[i+1] == '\n':
            width += 1
            i += 2
            continue
        w = char_width(c)
        # ZWJ emoji sequence
        if w == 2 and not is_skin_tone(c) and i + 2 < n and chars[i+1] == ZWJ and char_width(chars[i+2]) == 2:
            width += 2
            i += 1
            while i + 1 < n and chars[i] == ZWJ and char_width(chars[i+1]) == 2:
                i += 2
            while i < n and is_skin_tone(chars[i]):
                i += 1
            continue
        if is_skin_tone(c) and i > 0:
            prev = chars[i-1]
            if char_width(prev) == 2 and not is_skin_tone(prev):
                i += 1
                continue
        if c == VS16 and i > 0:
            prev = chars[i-1]
            if ord(prev) in EMOJI_BASES:
                width += 1
                i += 1
                continue
        width += w
        i += 1
    return width


def char_advance(s, i):
    """Walk text_width's cluster algorithm at position i. Return (chars_consumed, display_width)."""
    chars = s
    n = len(chars)
    c = chars[i]
    if c == '\r' and i + 1 < n and chars[i+1] == '\n':
        return (2, 1)
    w = char_width(c)
    if w == 2 and not is_skin_tone(c) and i + 2 < n and chars[i+1] == ZWJ and char_width(chars[i+2]) == 2:
        seen_w = 2
        j = i + 1
        while j + 1 < n and chars[j] == ZWJ and char_width(chars[j+1]) == 2:
            j += 2
        while j < n and is_skin_tone(chars[j]):
            j += 1
        return (j - i, seen_w)
    if is_skin_tone(c) and i > 0:
        prev = chars[i-1]
        if char_width(prev) == 2 and not is_skin_tone(prev):
            return (1, 0)
    if c == VS16 and i > 0:
        prev = chars[i-1]
        if ord(prev) in EMOJI_BASES:
            return (1, 1)
    return (1, w)


def truncate_to_width(s, max_width):
    if text_width(s) <= max_width:
        return s
    result = []
    cur_w = 0
    n = len(s)
    i = 0
    while i < n:
        # Use the same cluster algorithm
        consumed, w = char_advance(s, i)
        if cur_w + w > max_width:
            break
        for j in range(consumed):
            result.append(s[i + j])
        cur_w += w
        i += consumed
    return ''.join(result)


def align_text(s, width, alignment):
    w = text_width(s)
    pad = max(0, width - w)
    if alignment == 'left':
        return s + ' ' * pad
    elif alignment == 'right':
        return ' ' * pad + s
    else:
        left = pad // 2
        right = pad - left
        return ' ' * left + s + ' ' * right


def print_clap_error(msg, usage="executable [OPTIONS] [FILE]"):
    sys.stderr.write("error: " + msg + "\n\n")
    sys.stderr.write("Usage: " + usage + "\n\n")
    sys.stderr.write("For more information, try '--help'.\n")
    sys.exit(2)


def print_clap_error_no_usage(msg):
    sys.stderr.write("error: " + msg + "\n\n")
    sys.stderr.write("For more information, try '--help'.\n")
    sys.exit(2)


FLAG_DISPLAY = {
    'no-headers': "'--no-headers'",
    'number': "'--number'",
    'tsv': "'--tsv'",
    'delimiter': "'--delimiter <DELIMITER>'",
    'style': "'--style <STYLE>'",
    'padding': "'--padding <PADDING>'",
    'indent': "'--indent <INDENT>'",
    'sniff': "'--sniff <LIMIT>'",
    'header-align': "'--header-align <HEADER_ALIGN>'",
    'body-align': "'--body-align <BODY_ALIGN>'",
    'disable-pager': "'--disable-pager'",
    'help': "'--help'",
    'version': "'--version'",
}

LONG_FLAGS = {
    'no-headers': 'bool',
    'number': 'bool',
    'tsv': 'bool',
    'delimiter': 'value',
    'style': 'value',
    'padding': 'value',
    'indent': 'value',
    'sniff': 'value',
    'header-align': 'value',
    'body-align': 'value',
    'disable-pager': 'bool',
    'help': 'bool',
    'version': 'bool',
}

SHORT_TO_LONG = {
    'H': 'no-headers',
    'n': 'number',
    't': 'tsv',
    'd': 'delimiter',
    's': 'style',
    'p': 'padding',
    'i': 'indent',
    'P': 'disable-pager',
    'h': 'help',
    'V': 'version',
}


def looks_like_flag(s):
    """Whether s looks like a flag (starts with - and isn't just -)."""
    return len(s) > 1 and s.startswith('-')


def parse_args(argv):
    opts = {
        'no_headers': False,
        'number': False,
        'tsv': False,
        'delimiter': ',',
        'style': 'sharp',
        'padding': 1,
        'indent': 0,
        'sniff': 1000,
        'header_align': 'center',
        'body_align': 'left',
        'disable_pager': False,
        'file': None,
    }
    seen = set()
    args = list(argv)
    i = 0
    end_of_opts = False

    def check_repeated(name):
        if name in seen:
            print_clap_error("the argument " + FLAG_DISPLAY[name] + " cannot be used multiple times")
        seen.add(name)

    def check_conflicts(name):
        if name == 'tsv' and 'delimiter' in seen:
            print_clap_error("the argument '--delimiter <DELIMITER>' cannot be used with '--tsv'",
                             "executable --delimiter <DELIMITER> [FILE]")
        if name == 'delimiter' and 'tsv' in seen:
            print_clap_error("the argument '--tsv' cannot be used with '--delimiter <DELIMITER>'",
                             "executable --tsv [FILE]")

    def apply_value(name, value):
        if name == 'delimiter':
            if len(value) == 0:
                print_clap_error_no_usage("invalid value '' for '--delimiter <DELIMITER>': cannot parse char from empty string")
            if len(value) > 1:
                print_clap_error_no_usage("invalid value '" + value + "' for '--delimiter <DELIMITER>': too many characters in string")
            opts['delimiter'] = value
        elif name == 'style':
            if value not in STYLE_VALUES:
                msg = "invalid value '" + value + "' for '--style <STYLE>'\n  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]"
                print_clap_error_no_usage(msg)
            opts['style'] = value
        elif name == 'header-align':
            if value not in ALIGN_VALUES:
                msg = "invalid value '" + value + "' for '--header-align <HEADER_ALIGN>'\n  [possible values: left, center, right]"
                print_clap_error_no_usage(msg)
            opts['header_align'] = value
        elif name == 'body-align':
            if value not in ALIGN_VALUES:
                msg = "invalid value '" + value + "' for '--body-align <BODY_ALIGN>'\n  [possible values: left, center, right]"
                print_clap_error_no_usage(msg)
            opts['body_align'] = value
        elif name == 'padding':
            v = parse_uint(value, 'padding', 'PADDING')
            opts['padding'] = v
        elif name == 'indent':
            v = parse_uint(value, 'indent', 'INDENT')
            opts['indent'] = v
        elif name == 'sniff':
            v = parse_uint(value, 'sniff', 'LIMIT')
            opts['sniff'] = v

    def parse_uint(value, flag_short, flag_meta):
        # Match Rust's parse error messages
        if value == '':
            print_clap_error_no_usage("invalid value '' for '--" + flag_short + " <" + flag_meta + ">': cannot parse integer from empty string")
        # First check if it's a valid u32/usize: only digits
        if not value.lstrip('+').isdigit() or value.startswith('-'):
            # Negative or non-digit
            print_clap_error_no_usage("invalid value '" + value + "' for '--" + flag_short + " <" + flag_meta + ">': invalid digit found in string")
        try:
            return int(value)
        except ValueError:
            print_clap_error_no_usage("invalid value '" + value + "' for '--" + flag_short + " <" + flag_meta + ">': invalid digit found in string")

    while i < len(args):
        arg = args[i]
        if end_of_opts:
            if opts['file'] is None:
                opts['file'] = arg
            else:
                print_clap_error("unexpected argument '" + arg + "' found")
            i += 1
            continue
        if arg == '--':
            end_of_opts = True
            i += 1
            continue
        if arg.startswith('--'):
            eq_pos = arg.find('=')
            if eq_pos >= 0:
                name = arg[2:eq_pos]
                value = arg[eq_pos+1:]
                has_value = True
            else:
                name = arg[2:]
                value = None
                has_value = False
            if name not in LONG_FLAGS:
                tip = "\n\n  tip: to pass '" + arg + "' as a value, use '-- " + arg + "'"
                print_clap_error("unexpected argument '" + arg + "' found" + tip)
            kind = LONG_FLAGS[name]
            check_repeated(name)
            if name == 'help':
                sys.stdout.write(HELP_TEXT)
                sys.exit(0)
            if name == 'version':
                sys.stdout.write(VERSION_TEXT)
                sys.exit(0)
            if kind == 'bool':
                if has_value:
                    print_clap_error("unexpected value '" + value + "' for " + FLAG_DISPLAY[name] + " found; no more were expected")
                if name == 'no-headers':
                    opts['no_headers'] = True
                elif name == 'number':
                    opts['number'] = True
                elif name == 'tsv':
                    opts['tsv'] = True
                elif name == 'disable-pager':
                    opts['disable_pager'] = True
                check_conflicts(name)
            else:
                if not has_value:
                    # Need to consume next arg as value
                    if i + 1 >= len(args) or looks_like_flag(args[i+1]):
                        print_clap_error("a value is required for " + FLAG_DISPLAY[name] + " but none was supplied")
                    value = args[i+1]
                    i += 1
                apply_value(name, value)
                check_conflicts(name)
            i += 1
            continue
        if arg.startswith('-') and len(arg) > 1:
            rest = arg[1:]
            j = 0
            while j < len(rest):
                ch = rest[j]
                if ch == 'h':
                    sys.stdout.write(HELP_TEXT)
                    sys.exit(0)
                if ch == 'V':
                    sys.stdout.write(VERSION_TEXT)
                    sys.exit(0)
                if ch not in SHORT_TO_LONG:
                    short_arg = '-' + ch
                    tip = "\n\n  tip: to pass '" + short_arg + "' as a value, use '-- " + short_arg + "'"
                    print_clap_error("unexpected argument '" + short_arg + "' found" + tip)
                long_name = SHORT_TO_LONG[ch]
                check_repeated(long_name)
                kind = LONG_FLAGS[long_name]
                if kind == 'bool':
                    if long_name == 'no-headers':
                        opts['no_headers'] = True
                    elif long_name == 'number':
                        opts['number'] = True
                    elif long_name == 'tsv':
                        opts['tsv'] = True
                    elif long_name == 'disable-pager':
                        opts['disable_pager'] = True
                    check_conflicts(long_name)
                    j += 1
                else:
                    # Value follows. If j+1 < len(rest), the rest is value.
                    if j + 1 < len(rest):
                        value_part = rest[j+1:]
                        if value_part.startswith('='):
                            value_part = value_part[1:]
                        value = value_part
                    else:
                        if i + 1 >= len(args) or looks_like_flag(args[i+1]):
                            print_clap_error("a value is required for " + FLAG_DISPLAY[long_name] + " but none was supplied")
                        value = args[i+1]
                        i += 1
                    apply_value(long_name, value)
                    check_conflicts(long_name)
                    j = len(rest)
                    break
            i += 1
            continue
        # Positional
        if opts['file'] is None:
            opts['file'] = arg
        else:
            print_clap_error("unexpected argument '" + arg + "' found")
        i += 1
        continue

    return opts


# CSV parser - tracks byte offsets and line numbers
def parse_csv(data_bytes, delimiter_char):
    """Parse CSV bytes. Returns list of (record_idx, line, byte, fields)."""
    delim_bytes = delimiter_char.encode('utf-8') if isinstance(delimiter_char, str) else delimiter_char
    if len(delim_bytes) != 1:
        delim_bytes = delim_bytes[:1]
    delim_byte = delim_bytes[0]

    records = []
    i = 0
    n = len(data_bytes)
    line_num = 1
    record_idx = 0
    # Reported (line, byte) for the next record - "snaps" to right after previous record's end
    next_line = 1
    next_byte = 0

    while i < n:
        # Skip blank lines (don't update next_line/next_byte)
        while i < n and data_bytes[i] in (0x0A, 0x0D):
            if data_bytes[i] == 0x0D:
                if i + 1 < n and data_bytes[i+1] == 0x0A:
                    i += 2
                    line_num += 1
                else:
                    i += 1
            else:
                i += 1
                line_num += 1
        if i >= n:
            break

        rec_line = next_line
        rec_byte = next_byte
        fields = []
        cur = bytearray()
        in_quote = False
        broke = False
        while i < n:
            b = data_bytes[i]
            if in_quote:
                if b == 0x22:
                    if i + 1 < n and data_bytes[i+1] == 0x22:
                        cur.append(0x22)
                        i += 2
                        continue
                    in_quote = False
                    i += 1
                    continue
                if b == 0x0A:
                    line_num += 1
                cur.append(b)
                i += 1
                continue
            if b == delim_byte:
                fields.append(bytes(cur))
                cur = bytearray()
                i += 1
                continue
            if b == 0x22 and len(cur) == 0:
                in_quote = True
                i += 1
                continue
            if b == 0x0D:
                fields.append(bytes(cur))
                cur = bytearray()
                if i + 1 < n and data_bytes[i+1] == 0x0A:
                    i += 2
                    line_num += 1
                else:
                    i += 1
                broke = True
                break
            if b == 0x0A:
                fields.append(bytes(cur))
                cur = bytearray()
                i += 1
                line_num += 1
                broke = True
                break
            cur.append(b)
            i += 1
        if not broke:
            fields.append(bytes(cur))
            cur = bytearray()

        next_line = line_num
        next_byte = i

        try:
            decoded = [f.decode('utf-8') for f in fields]
        except UnicodeDecodeError:
            for fi, f in enumerate(fields):
                try:
                    f.decode('utf-8')
                except UnicodeDecodeError as e2:
                    raise CSVUtf8Error(record_idx, rec_line, fi, rec_byte, e2.start)
            raise

        records.append((record_idx, rec_line, rec_byte, decoded))
        record_idx += 1
    return records


class CSVUtf8Error(Exception):
    def __init__(self, record_idx, line, field_idx, rec_byte_offset, byte_in_field):
        self.record_idx = record_idx
        self.line = line
        self.field_idx = field_idx
        self.rec_byte_offset = rec_byte_offset
        self.byte_in_field = byte_in_field


def render_border(parts, widths, padding, indent):
    if parts is None:
        return ''
    left, fill, mid, right = parts
    cells = [fill * (w + 2 * padding) for w in widths]
    line = left + mid.join(cells) + right
    return ' ' * indent + line + '\n'


def render_row(cells, widths, alignment, row_parts, padding, indent):
    left, mid, right = row_parts
    parts = []
    for k, w in enumerate(widths):
        content = cells[k] if k < len(cells) else ''
        aligned = align_text(content, w, alignment)
        parts.append(' ' * padding + aligned + ' ' * padding)
    line = left + mid.join(parts) + right
    return ' ' * indent + line + '\n'


def render_table(records_data, has_headers, opts, skip_bottom=False):
    style = STYLES[opts['style']]
    padding = opts['padding']
    indent = opts['indent']
    out = []

    if records_data:
        if has_headers:
            header = records_data[0]
            body = records_data[1:]
            ncols = len(header)
        else:
            header = None
            body = records_data
            ncols = len(records_data[0])
    else:
        if has_headers:
            header = []
            body = []
            ncols = 0
        else:
            header = None
            body = []
            ncols = 0

    sniff = opts['sniff']

    cols_widths = [0] * ncols
    if header is not None:
        for c in range(ncols):
            if c < len(header):
                cols_widths[c] = max(cols_widths[c], text_width(header[c]))
    limit = sniff if sniff > 0 else len(body)
    for r in range(min(limit, len(body))):
        for c in range(ncols):
            if c < len(body[r]):
                cols_widths[c] = max(cols_widths[c], text_width(body[r][c]))

    body_render = list(body)
    if sniff > 0 and sniff < len(body):
        body_render = list(body[:sniff])
        for r in range(sniff, len(body)):
            new_row = []
            for c in range(ncols):
                if c < len(body[r]):
                    new_row.append(truncate_to_width(body[r][c], cols_widths[c]))
                else:
                    new_row.append('')
            body_render.append(new_row)

    if opts['number']:
        num_data = [str(r+1) for r in range(len(body_render))]
        num_width = max([1] + [text_width(s) for s in num_data])
        cols_widths = [num_width] + cols_widths

    if style['has_top']:
        out.append(render_border(style['top'], cols_widths, padding, indent))

    if header is not None:
        cells = list(header)
        if opts['number']:
            cells = ['#'] + cells
        out.append(render_row(cells, cols_widths, opts['header_align'], style['row'], padding, indent))
        if style['has_hdr_sep'] and body_render:
            out.append(render_border(style['mid'], cols_widths, padding, indent))

    for r, row in enumerate(body_render):
        cells = list(row)
        if opts['number']:
            cells = [str(r+1)] + cells
        out.append(render_row(cells, cols_widths, opts['body_align'], style['row'], padding, indent))
        if style['has_body_sep'] and r < len(body_render) - 1:
            out.append(render_border(style['mid'], cols_widths, padding, indent))

    if style['has_bot'] and not skip_bottom:
        out.append(render_border(style['bot'], cols_widths, padding, indent))

    return ''.join(out)


def main():
    argv = sys.argv[1:]
    opts = parse_args(argv)

    if opts['tsv']:
        delim = '\t'
    else:
        delim = opts['delimiter']

    try:
        if opts['file'] is not None:
            with open(opts['file'], 'rb') as f:
                data = f.read()
        else:
            data = sys.stdin.buffer.read()
    except IsADirectoryError:
        sys.stderr.write("csview: Is a directory (os error 21)\n")
        sys.exit(1)
    except PermissionError:
        sys.stderr.write("csview: Permission denied (os error 13)\n")
        sys.exit(1)
    except FileNotFoundError:
        sys.stderr.write("csview: No such file or directory (os error 2)\n")
        sys.exit(1)
    except OSError as e:
        sys.stderr.write("csview: " + (e.strerror or str(e)) + " (os error " + str(e.errno) + ")\n")
        sys.exit(1)

    # Strip BOM (UTF-8 BOM is 0xEF 0xBB 0xBF)
    if data.startswith(b'\xef\xbb\xbf'):
        data = data[3:]

    error_msg = None
    try:
        all_records = parse_csv(data, delim)
    except CSVUtf8Error as e:
        sys.stderr.write("csview: CSV parse error: record " + str(e.record_idx) + " (line " + str(e.line) + ", field: " + str(e.field_idx) + ", byte: " + str(e.rec_byte_offset) + "): invalid utf-8: invalid UTF-8 in field " + str(e.field_idx) + " near byte index " + str(e.byte_in_field) + "\n")
        sys.exit(1)

    all_records = [r for r in all_records if len(r[3]) > 0]
    has_headers = not opts['no_headers']
    sniff = opts['sniff']

    # Sniff phase: errors within this range cause NO output, only stderr error.
    # Errors after sniff phase cause PARTIAL output + error.
    if sniff == 0:
        sniff_phase_end = len(all_records)
    else:
        sniff_phase_end = sniff + (1 if has_headers else 0)

    error_in_sniff = False
    records = []
    if all_records:
        expected = len(all_records[0][3])
        records.append(all_records[0])
        for idx in range(1, len(all_records)):
            rec = all_records[idx]
            r_idx, r_line, r_byte, r_fields = rec
            if len(r_fields) != expected:
                error_msg = "csview: CSV error: record " + str(r_idx) + " (line: " + str(r_line) + ", byte: " + str(r_byte) + "): found record with " + str(len(r_fields)) + " fields, but the previous record has " + str(expected) + " fields\n"
                if idx < sniff_phase_end:
                    error_in_sniff = True
                break
            records.append(rec)

    if error_in_sniff:
        sys.stderr.write(error_msg)
        sys.exit(1)

    records_data = [r[3] for r in records]
    output = render_table(records_data, has_headers, opts, skip_bottom=(error_msg is not None))
    sys.stdout.write(output)
    if error_msg:
        sys.stderr.write(error_msg)
        sys.exit(1)


if __name__ == '__main__':
    main()
