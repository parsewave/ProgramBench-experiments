#!/bin/bash
# Generate test frames by probing the reference binary.
# Each test case: input file (or - for stdin), args, expected stdout, stderr, exit code

set -u
REF=/workspace/executable
OUTDIR=/work/work/goldens
INDIR=/work/work/inputs
FRAMES=/work/work/frames.jsonl

mkdir -p "$OUTDIR" "$INDIR"
> "$FRAMES"

# Create input files
printf 'a,b,c\n1,2,3\n4,5,6\n' > "$INDIR/basic.csv"
printf 'name,city\nAlice,NewYorkCity\nBob,LA\n' > "$INDIR/names.csv"
printf 'a,b,c\n1,2,3\n' > "$INDIR/small.csv"
printf '' > "$INDIR/empty.csv"
printf '\n' > "$INDIR/newline.csv"
printf 'a,b,c\n' > "$INDIR/header_only.csv"
printf 'a,b\n"hello, world","x"\nfoo,bar\n' > "$INDIR/quoted.csv"
printf 'a,b\n"line1\nline2",x\n' > "$INDIR/multiline.csv"
printf 'a,b\n\xe6\x97\xa5\xe6\x9c\xac,\xe6\x9d\xb1\xe4\xba\xac\n' > "$INDIR/cjk.csv"
printf 'a,b\n\xf0\x9f\x98\x80,c\n' > "$INDIR/emoji.csv"
printf 'a\tb\tc\n1\t2\t3\n' > "$INDIR/tsv.csv"
printf 'a;b;c\n1;2;3\n' > "$INDIR/semicolon.csv"
printf 'a,b,c\n1,2,3\n4,5\n' > "$INDIR/inconsistent.csv"
printf 'a,b,c\n,,\n1,,3\n' > "$INDIR/empty_fields.csv"

# Function to capture a frame
capture() {
    local name="$1"
    shift
    local stdin_file="$1"
    shift
    local args=("$@")

    local stdout_file="$OUTDIR/$name.stdout"
    local stderr_file="$OUTDIR/$name.stderr"
    local exit_file="$OUTDIR/$name.exit"

    if [ "$stdin_file" = "NONE" ]; then
        "$REF" "${args[@]}" > "$stdout_file" 2> "$stderr_file"
    else
        "$REF" "${args[@]}" < "$stdin_file" > "$stdout_file" 2> "$stderr_file"
    fi
    echo $? > "$exit_file"

    # Append to frames.jsonl
    local stdin_content="null"
    if [ "$stdin_file" != "NONE" ] && [ -f "$stdin_file" ]; then
        stdin_content=$(python3 -c "import json,sys; print(json.dumps(open(sys.argv[1],'rb').read().decode('utf-8','replace')))" "$stdin_file")
    fi
    local stdout_content=$(python3 -c "import json,sys; print(json.dumps(open(sys.argv[1],'rb').read().decode('utf-8','replace')))" "$stdout_file")
    local stderr_content=$(python3 -c "import json,sys; print(json.dumps(open(sys.argv[1],'rb').read().decode('utf-8','replace')))" "$stderr_file")
    local exit_content=$(cat "$exit_file")
    local args_json=$(python3 -c "import json,sys; print(json.dumps(sys.argv[1:]))" "${args[@]}")

    python3 -c "
import json,sys
frame = {
    'name': sys.argv[1],
    'args': json.loads(sys.argv[2]),
    'stdin': json.loads(sys.argv[3]),
    'stdout': json.loads(sys.argv[4]),
    'stderr': json.loads(sys.argv[5]),
    'exit': int(sys.argv[6])
}
print(json.dumps(frame))
" "$name" "$args_json" "$stdin_content" "$stdout_content" "$stderr_content" "$exit_content" >> "$FRAMES"
}

# Surface scan
capture "help_long" NONE --help
capture "help_short" NONE -h
capture "version_long" NONE --version
capture "version_short" NONE -V
capture "bogus_flag" NONE --bogus

# Empty inputs
capture "empty_stdin" "$INDIR/empty.csv"
capture "empty_stdin_H" "$INDIR/empty.csv" -H
capture "newline_stdin" "$INDIR/newline.csv"
capture "newline_stdin_H" "$INDIR/newline.csv" -H

# Basic
capture "basic_default" "$INDIR/basic.csv"
capture "basic_noheaders" "$INDIR/basic.csv" -H
capture "basic_number" "$INDIR/basic.csv" -n
capture "basic_header_only" "$INDIR/header_only.csv"
capture "basic_header_only_H" "$INDIR/header_only.csv" -H

# All styles with basic
for s in none ascii ascii2 sharp rounded reinforced markdown grid; do
    capture "style_${s}" "$INDIR/basic.csv" -s "$s"
    capture "style_${s}_H" "$INDIR/basic.csv" -s "$s" -H
    capture "style_${s}_empty" "$INDIR/empty.csv" -s "$s"
    capture "style_${s}_empty_H" "$INDIR/empty.csv" -s "$s" -H
    capture "style_${s}_header_only" "$INDIR/header_only.csv" -s "$s"
done

# Padding
for p in 0 1 2 3; do
    capture "padding_${p}" "$INDIR/basic.csv" -p "$p"
    capture "padding_${p}_ascii2" "$INDIR/basic.csv" -p "$p" -s ascii2
    capture "padding_${p}_none" "$INDIR/basic.csv" -p "$p" -s none
    capture "padding_${p}_markdown" "$INDIR/basic.csv" -p "$p" -s markdown
done

# Indent
for i in 0 1 2 5; do
    capture "indent_${i}" "$INDIR/basic.csv" -i "$i"
    capture "indent_${i}_none" "$INDIR/basic.csv" -i "$i" -s none
done

# Alignment
for ha in left center right; do
    for ba in left center right; do
        capture "align_h${ha}_b${ba}" "$INDIR/names.csv" --header-align "$ha" --body-align "$ba"
    done
done

# Delimiters
capture "delim_semi" "$INDIR/semicolon.csv" -d ";"
capture "delim_tsv" "$INDIR/tsv.csv" -t
capture "delim_tsv_d" "$INDIR/tsv.csv" -d $'\t'
capture "delim_invalid_empty" "$INDIR/basic.csv" -d ""
capture "delim_invalid_multi" "$INDIR/basic.csv" -d "ab"

# Style invalid
capture "style_invalid" "$INDIR/basic.csv" -s "bogus"

# Conflicting flags
capture "conflict_tsv_delim" "$INDIR/tsv.csv" -t -d ","
capture "conflict_delim_tsv" "$INDIR/tsv.csv" -d "," -t
capture "repeated_style" "$INDIR/basic.csv" -s ascii -s sharp

# Multi-line, quoted
capture "quoted_basic" "$INDIR/quoted.csv"
capture "multiline_field" "$INDIR/multiline.csv"

# CJK / Emoji
capture "cjk" "$INDIR/cjk.csv"
capture "emoji" "$INDIR/emoji.csv"

# Sniff
capture "sniff_0" "$INDIR/names.csv" --sniff 0
capture "sniff_1" "$INDIR/names.csv" --sniff 1
capture "sniff_2" "$INDIR/names.csv" --sniff 2

# Empty fields
capture "empty_fields" "$INDIR/empty_fields.csv"

# Errors
capture "inconsistent" "$INDIR/inconsistent.csv"
capture "nonexistent" NONE /tmp/nonexistent_file_xyz_99.csv
capture "dir_as_file" NONE /tmp
capture "stdin_dash" "$INDIR/basic.csv" -

# Misc
capture "double_dash" "$INDIR/basic.csv" --

echo "Captured frames: $(wc -l < $FRAMES)"
