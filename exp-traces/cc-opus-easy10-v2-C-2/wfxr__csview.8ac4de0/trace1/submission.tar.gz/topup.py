#!/usr/bin/env python3
"""Markov-chain style probe for csview: realistic usage patterns."""
import subprocess
import random
import string
import sys

REF = "/workspace/executable"
SUT = "/work/work/executable"

random.seed(2026)


def run(binary, args, stdin_bytes=None, timeout=10):
    p = subprocess.run([binary] + args, input=stdin_bytes, capture_output=True, timeout=timeout)
    return p.returncode, p.stdout, p.stderr


# Markov chain over the discovered modes
# Each mode generates a likely realistic invocation pattern

MODES = []

# Mode 1: View basic CSV
def gen_basic():
    args = []
    rows = random.randint(2, 8)
    cols = random.randint(2, 5)
    header = ','.join([random.choice(['name', 'id', 'value', 'date', 'time', 'count', 'score', 'rank']) + str(i) for i in range(cols)])
    body = []
    for r in range(rows):
        row = []
        for c in range(cols):
            choice = random.random()
            if choice < 0.3:
                row.append(str(random.randint(0, 99999)))
            elif choice < 0.7:
                row.append(''.join(random.choice(string.ascii_letters) for _ in range(random.randint(1, 8))))
            else:
                row.append(random.choice(['', 'foo', 'bar', 'baz', 'qux']))
        body.append(','.join(row))
    csv = header + '\n' + '\n'.join(body) + '\n'
    return args, csv.encode()
MODES.append(('basic', gen_basic, 0.20))

# Mode 2: View with style
def gen_styled():
    style = random.choice(['none', 'ascii', 'ascii2', 'sharp', 'rounded', 'reinforced', 'markdown', 'grid'])
    args = ['-s', style]
    if random.random() < 0.3:
        args.append('-n')
    if random.random() < 0.3:
        args.append('-H')
    csv = "col1,col2,col3\nfoo,42,bar\nbaz,7,qux\n"
    return args, csv.encode()
MODES.append(('styled', gen_styled, 0.15))

# Mode 3: TSV file
def gen_tsv():
    args = ['-t'] if random.random() < 0.5 else ['-d', '\t']
    csv = "a\tb\tc\n1\t2\t3\nhello\tworld\t!\n"
    return args, csv.encode()
MODES.append(('tsv', gen_tsv, 0.10))

# Mode 4: Custom delimiter
def gen_delim():
    delim = random.choice([';', '|', ':', ' '])
    args = ['-d', delim]
    csv = f"col1{delim}col2{delim}col3\nfoo{delim}bar{delim}baz\n1{delim}2{delim}3\n"
    return args, csv.encode()
MODES.append(('delim', gen_delim, 0.10))

# Mode 5: Adjustment options (padding, indent)
def gen_adjusted():
    args = []
    if random.random() < 0.7:
        args.extend(['-p', str(random.randint(0, 3))])
    if random.random() < 0.5:
        args.extend(['-i', str(random.randint(0, 5))])
    if random.random() < 0.4:
        args.extend(['--header-align', random.choice(['left', 'center', 'right'])])
    if random.random() < 0.4:
        args.extend(['--body-align', random.choice(['left', 'center', 'right'])])
    csv = "header1,header2,header3\nrow1col1,row1col2,row1col3\nrow2col1,row2col2,row2col3\n"
    return args, csv.encode()
MODES.append(('adjusted', gen_adjusted, 0.15))

# Mode 6: CJK / Emoji content
def gen_unicode():
    args = []
    if random.random() < 0.5:
        args.extend(['-s', random.choice(['sharp', 'ascii', 'grid'])])
    headers = '名前,都市,数値'
    body_options = ['田中,東京,42', '李,北京,7', 'Smith,New York,100', 'Alice,日本,99', '😀,😀😀,1']
    body = '\n'.join(random.sample(body_options, k=random.randint(2, len(body_options))))
    csv = headers + '\n' + body + '\n'
    return args, csv.encode()
MODES.append(('unicode', gen_unicode, 0.10))

# Mode 7: Sniff
def gen_sniff():
    args = ['--sniff', str(random.randint(0, 5))]
    if random.random() < 0.3:
        args.extend(['-s', 'sharp'])
    rows = []
    rows.append('a,b,c')
    for _ in range(random.randint(3, 7)):
        rows.append(','.join(random.choice([
            ''.join(random.choice(string.ascii_letters) for _ in range(random.randint(1, 10))),
            str(random.randint(0, 99))
        ]) for _ in range(3)))
    csv = '\n'.join(rows) + '\n'
    return args, csv.encode()
MODES.append(('sniff', gen_sniff, 0.10))

# Mode 8: Error cases
def gen_error():
    err_type = random.choice(['inconsistent', 'invalid_style', 'invalid_padding', 'unknown_flag'])
    if err_type == 'inconsistent':
        csv = "a,b,c\n1,2,3\n4,5\n"
        return [], csv.encode()
    elif err_type == 'invalid_style':
        return ['-s', 'bogus'], b'a\n1\n'
    elif err_type == 'invalid_padding':
        return ['-p', 'xx'], b'a\n1\n'
    else:
        return ['--bogus'], None
MODES.append(('error', gen_error, 0.10))


def gen_one():
    r = random.random()
    cum = 0
    for name, fn, prob in MODES:
        cum += prob
        if r < cum:
            return name, fn()
    return MODES[-1][0], MODES[-1][1]()


def main():
    n_probes = 10
    if len(sys.argv) > 1:
        n_probes = int(sys.argv[1])

    pass_count = 0
    fail_count = 0
    failures = []
    for i in range(n_probes):
        name, (args, stdin) = gen_one()
        rc_r, so_r, se_r = run(REF, args, stdin)
        rc_s, so_s, se_s = run(SUT, args, stdin)
        ok = rc_r == rc_s and so_r == so_s and se_r == se_s
        if ok:
            pass_count += 1
            print(f"[{i+1}] {name}: PASS")
        else:
            fail_count += 1
            print(f"[{i+1}] {name}: FAIL")
            failures.append((name, args, stdin, (rc_r, so_r, se_r), (rc_s, so_s, se_s)))

    print()
    print(f"Total: {pass_count}/{n_probes} passed")
    if failures:
        for name, args, stdin, ref, sut in failures[:3]:
            print(f"\n=== {name} ===")
            print(f"args: {args}")
            print(f"stdin: {stdin!r}")
            print(f"  REF: rc={ref[0]} stdout={ref[1]!r} stderr={ref[2]!r}")
            print(f"  SUT: rc={sut[0]} stdout={sut[1]!r} stderr={sut[2]!r}")


if __name__ == '__main__':
    main()
