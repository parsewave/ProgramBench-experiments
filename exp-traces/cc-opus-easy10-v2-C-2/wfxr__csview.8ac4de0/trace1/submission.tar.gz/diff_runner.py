#!/usr/bin/env python3
"""Run extensive differential testing between REF and SUT."""
import subprocess
import os
import sys
import json
import itertools
import random
import string

REF = "/workspace/executable"
SUT = "/work/work/executable"

random.seed(42)


def run(binary, args, stdin_bytes=None, timeout=10):
    try:
        p = subprocess.run([binary] + args, input=stdin_bytes, capture_output=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, b"<TIMEOUT>", b""


def compare(label, args, stdin_bytes):
    rc_r, so_r, se_r = run(REF, args, stdin_bytes)
    rc_s, so_s, se_s = run(SUT, args, stdin_bytes)
    diffs = []
    if rc_r != rc_s:
        diffs.append(f"exit: ref={rc_r} sut={rc_s}")
    if so_r != so_s:
        diffs.append(f"stdout: differ ({len(so_r)} vs {len(so_s)} bytes)")
    if se_r != se_s:
        diffs.append(f"stderr: differ")
    if diffs:
        return False, diffs, (rc_r, so_r, se_r), (rc_s, so_s, se_s)
    return True, [], None, None


def main():
    tests = []

    # Generate randomized CSV inputs
    def rand_word(min_len=1, max_len=10, alphabet=None):
        if alphabet is None:
            alphabet = string.ascii_letters + string.digits + ' '
        n = random.randint(min_len, max_len)
        return ''.join(random.choice(alphabet) for _ in range(n))

    def rand_csv(rows, cols, alphabet=None):
        rs = []
        for _ in range(rows):
            rs.append(','.join(rand_word(0, 10, alphabet) for _ in range(cols)))
        return '\n'.join(rs) + '\n'

    # Tests
    # 1. Random CSVs with various row/col counts
    for i in range(20):
        rows = random.randint(1, 5)
        cols = random.randint(1, 5)
        csv = rand_csv(rows, cols)
        tests.append((f"rand_csv_{i}", [], csv.encode()))

    # 2. All styles with random data
    for s in ['none', 'ascii', 'ascii2', 'sharp', 'rounded', 'reinforced', 'markdown', 'grid']:
        for i in range(3):
            csv = rand_csv(random.randint(1, 4), random.randint(1, 4))
            tests.append((f"rand_style_{s}_{i}", ['-s', s], csv.encode()))

    # 3. Different padding values
    for p in [0, 1, 2, 3, 5]:
        for i in range(2):
            csv = rand_csv(2, 3)
            tests.append((f"rand_pad_{p}_{i}", ['-p', str(p)], csv.encode()))

    # 4. Different indent values
    for ind in [0, 1, 2, 5, 10]:
        csv = rand_csv(2, 3)
        tests.append((f"rand_indent_{ind}", ['-i', str(ind)], csv.encode()))

    # 5. Alignment combinations
    for ha in ['left', 'center', 'right']:
        for ba in ['left', 'center', 'right']:
            csv = 'short,longer_name,medium\nA,longer_value_here,123\nBob,Z,456789\n'
            tests.append((f"align_{ha}_{ba}", ['--header-align', ha, '--body-align', ba], csv.encode()))

    # 6. -H combinations
    csv = '1,2,3\n4,5,6\n'
    tests.append(("noheaders_basic", ['-H'], csv.encode()))
    for s in ['none', 'ascii', 'ascii2', 'sharp', 'rounded', 'markdown', 'grid', 'reinforced']:
        tests.append((f"noheaders_style_{s}", ['-H', '-s', s], csv.encode()))

    # 7. Number column
    csv = 'a,b\n1,2\n3,4\n5,6\n7,8\n9,10\n11,12\n13,14\n'
    tests.append(("number", ['-n'], csv.encode()))
    tests.append(("number_noheaders", ['-Hn'], csv.encode()))

    # 8. Sniff
    csv = 'a,b\nshort,b\nverylongdata,d\n'
    for sn in [0, 1, 2, 3, 5, 10]:
        tests.append((f"sniff_{sn}", ['--sniff', str(sn)], csv.encode()))

    # 9. Quoted CSV
    tests.append(("quoted_basic", [], b'a,b\n"hello, world","x"\nfoo,"bar"\n'))
    tests.append(("quoted_dquot", [], b'a,b\n"he said ""hi""",x\n'))
    tests.append(("quoted_newline", [], b'a,b\n"line1\nline2",x\n'))
    tests.append(("quoted_complex", [], b'a,b,c\n"1,2","3\n4","5,""6"""\n'))

    # 10. CJK / unicode
    tests.append(("cjk_basic", [], '日本,東京\n중국,서울\n'.encode()))
    tests.append(("cjk_mixed", [], 'name,city\nAlice,日本\n田中,Tokyo\n'.encode()))
    tests.append(("emoji_basic", [], 'a,b\n😀,c\n😀😀,d\n'.encode()))
    tests.append(("cjk_long", [], 'a,b\n日本語のテキスト,short\nshort,日本語のテキスト\n'.encode()))

    # 11. Empty fields
    tests.append(("empty_fields", [], b'a,b,c\n,,\n1,,3\n,5,\n'))
    tests.append(("trailing_comma", [], b'a,b,c\n1,2,\n3,4,\n'))
    tests.append(("only_commas", [], b',,\n,,\n'))

    # 12. Different delimiters
    tests.append(("delim_semi", ['-d', ';'], b'a;b;c\n1;2;3\n'))
    tests.append(("delim_pipe", ['-d', '|'], b'a|b|c\n1|2|3\n'))
    tests.append(("delim_space", ['-d', ' '], b'a b c\n1 2 3\n'))
    tests.append(("delim_tab", ['-d', '\t'], b'a\tb\tc\n1\t2\t3\n'))
    tests.append(("delim_tsv", ['-t'], b'a\tb\tc\n1\t2\t3\n'))

    # 13. Edge cases
    tests.append(("empty_stdin", [], b''))
    tests.append(("just_newline", [], b'\n'))
    tests.append(("multi_newlines", [], b'\n\n\n'))
    tests.append(("crlf", [], b'a,b\r\n1,2\r\n'))
    tests.append(("cr_only", [], b'a,b\r1,2\r'))
    tests.append(("no_trailing_nl", [], b'a,b\n1,2'))
    tests.append(("single_record", [], b'a,b,c\n'))
    tests.append(("single_field", [], b'a\n1\n2\n'))

    # 14. Error cases
    tests.append(("inconsistent_fields", [], b'a,b,c\n1,2\n'))
    tests.append(("inconsistent_more", [], b'a,b\n1,2,3\n'))

    # 15. Various flag combos
    tests.append(("combo1", ['-n', '-s', 'ascii', '-p', '2'], b'a,b\n1,2\n3,4\n'))
    tests.append(("combo2", ['-i', '3', '-s', 'rounded'], b'a,b\n1,2\n'))
    tests.append(("combo3", ['-H', '-n', '-s', 'grid'], b'1,2\n3,4\n'))
    tests.append(("combo4", ['--sniff', '1', '--body-align', 'right'], b'a,b\nshort,b\nlong_data,c\n'))

    # 16. Help / version
    tests.append(("help_long", ['--help'], None))
    tests.append(("help_short", ['-h'], None))
    tests.append(("version_long", ['--version'], None))
    tests.append(("version_short", ['-V'], None))

    # 17. Invalid values
    tests.append(("invalid_style", ['-s', 'bogus'], b'a\n1\n'))
    tests.append(("invalid_padding", ['-p', 'abc'], b'a\n1\n'))
    tests.append(("invalid_align_h", ['--header-align', 'foo'], b'a\n1\n'))
    tests.append(("invalid_align_b", ['--body-align', 'foo'], b'a\n1\n'))
    tests.append(("invalid_delim_empty", ['-d', ''], b'a\n1\n'))
    tests.append(("invalid_delim_long", ['-d', 'xy'], b'a\n1\n'))

    # 18. Long file name
    tests.append(("nonexistent_file", ['/tmp/nonexistent_xyz_abc.csv'], None))

    # 19. Conflicting flags
    tests.append(("conflict_t_d", ['-t', '-d', ','], b'a\tb\n1\t2\n'))
    tests.append(("conflict_d_t", ['-d', ',', '-t'], b'a\tb\n1\t2\n'))

    # 20. Repeated flags
    tests.append(("repeat_H", ['-H', '-H'], b'1,2\n'))
    tests.append(("repeat_s", ['-s', 'sharp', '-s', 'ascii'], b'a,b\n1,2\n'))
    tests.append(("repeat_p", ['-p', '1', '-p', '2'], b'a,b\n1,2\n'))

    # 21. Argument parsing edge cases
    tests.append(("dash_dash", ['--'], b'a,b\n1,2\n'))
    tests.append(("dash", ['-'], b'a,b\n1,2\n'))
    tests.append(("multiple_positional", ['file1', 'file2'], None))
    tests.append(("unknown_long", ['--bogus'], None))
    tests.append(("unknown_short", ['-z'], None))
    tests.append(("eq_style", ['--style=ascii'], b'a,b\n1,2\n'))
    tests.append(("eq_short_style", ['-s=ascii'], b'a,b\n1,2\n'))

    # Run all tests
    pass_count = 0
    fail_count = 0
    failures = []
    for name, args, stdin in tests:
        ok, diffs, ref_out, sut_out = compare(name, args, stdin)
        if ok:
            pass_count += 1
        else:
            fail_count += 1
            failures.append((name, args, stdin, diffs, ref_out, sut_out))

    print(f"Pass: {pass_count}")
    print(f"Fail: {fail_count}")
    print()
    if failures:
        print("Failures:")
        for name, args, stdin, diffs, ref_out, sut_out in failures[:20]:
            print(f"\n=== {name} ===")
            print(f"  args: {args}")
            print(f"  stdin: {stdin!r}")
            for d in diffs:
                print(f"  {d}")
            if ref_out and sut_out:
                rc_r, so_r, se_r = ref_out
                rc_s, so_s, se_s = sut_out
                if so_r != so_s:
                    print(f"  REF stdout: {so_r!r}")
                    print(f"  SUT stdout: {so_s!r}")
                if se_r != se_s:
                    print(f"  REF stderr: {se_r!r}")
                    print(f"  SUT stderr: {se_s!r}")
                if rc_r != rc_s:
                    print(f"  REF exit: {rc_r}, SUT exit: {rc_s}")


if __name__ == '__main__':
    main()
